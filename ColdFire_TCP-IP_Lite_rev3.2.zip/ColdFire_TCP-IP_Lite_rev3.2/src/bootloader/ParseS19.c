/******************************************************************************
*                                                  
*  (c) copyright Freescale Semiconductor 2008
*  ALL RIGHTS RESERVED
*
*  File Name: ParseS19.c
*                                                                          
*  Purpose: This file is for a USB Mass-Storage Device bootloader.  This file 
*           has functions to read S19 file sent over USB, and parse s-records
*           to program to flash.
*                                                                          
*  Assembler:  Codewarrior for Microcontrollers V6.2
*                                            
*  Version:  1.0
*                                                                          
*                                                                          
*  Author: Derek Snell                             
*                                                                                       
*  Location: Indianapolis, IN. USA                                            
*                                                                                  
* UPDATED HISTORY:
*
* REV   YYYY.MM.DD  AUTHOR        DESCRIPTION OF CHANGE
* ---   ----------  ------        --------------------- 
* 1.1   2008.11.05  David Seymour modified for Ethernet
* 1.0   2008.06.10  Derek Snell   Initial version
* 
*
******************************************************************************/                                                                        
/* Freescale  is  not  obligated  to  provide  any  support, upgrades or new */
/* releases  of  the Software. Freescale may make changes to the Software at */
/* any time, without any obligation to notify or provide updated versions of */
/* the  Software  to you. Freescale expressly disclaims any warranty for the */
/* Software.  The  Software is provided as is, without warranty of any kind, */
/* either  express  or  implied,  including, without limitation, the implied */
/* warranties  of  merchantability,  fitness  for  a  particular purpose, or */
/* non-infringement.  You  assume  the entire risk arising out of the use or */
/* performance of the Software, or any systems you design using the software */
/* (if  any).  Nothing  may  be construed as a warranty or representation by */
/* Freescale  that  the  Software  or  any derivative work developed with or */
/* incorporating  the  Software  will  be  free  from  infringement  of  the */
/* intellectual property rights of third parties. In no event will Freescale */
/* be  liable,  whether in contract, tort, or otherwise, for any incidental, */
/* special,  indirect, consequential or punitive damages, including, but not */
/* limited  to,  damages  for  any loss of use, loss of time, inconvenience, */
/* commercial loss, or lost profits, savings, or revenues to the full extent */
/* such  may be disclaimed by law. The Software is not fault tolerant and is */
/* not  designed,  manufactured  or  intended by Freescale for incorporation */
/* into  products intended for use or resale in on-line control equipment in */
/* hazardous, dangerous to life or potentially life-threatening environments */
/* requiring  fail-safe  performance,  such  as  in the operation of nuclear */
/* facilities,  aircraft  navigation  or  communication systems, air traffic */
/* control,  direct  life  support machines or weapons systems, in which the */
/* failure  of  products  could  lead  directly to death, personal injury or */
/* severe  physical  or  environmental  damage  (High  Risk Activities). You */
/* specifically  represent and warrant that you will not use the Software or */
/* any  derivative  work of the Software for High Risk Activities.           */
/* Freescale  and the Freescale logos are registered trademarks of Freescale */
/* Semiconductor Inc.                                                        */ 
/*****************************************************************************/

#include "common.h"		//DES added
//DES #include "derivative.h" /* include peripheral declarations */
#include "ParseS19.h"
//DES #include "SCSI_Process.h"

#ifdef _MCF51JM128_H
	#include <hidef.h>
#endif
	
#include "Bootloader.h"
//#include "ICP_Flash.h"

/*****************************************************************************
 * Macro definitions
 *****************************************************************************/
 // None
 
/*****************************************************************************
 * Local types.
 *****************************************************************************/
 // None

/*****************************************************************************
 * External references.
 *****************************************************************************/
 //DES extern byte  BlockWriteDone;


/*****************************************************************************
 * Module variables.
 *****************************************************************************/
 unsigned char *SRecCharPointer;
 unsigned char *SRecBufferEndAddress;
 unsigned char S19FileDone;
 
/*****************************************************************************
 * Public memory declarations
 *****************************************************************************/
 extern unsigned char BootloaderStatus;
 extern unsigned char FlashErased;
 //DES extern byte  vCSWResult;         // CSW result
 //DES extern byte vCBWBuf_flag;
 //DES extern byte vEP2Data[512];
 //DES extern volatile unsigned char FLASHPGM[59];   


/*****************************************************************************
 * Function predefinitions.
 *****************************************************************************/
#if 0	//DES not needed
 void GetUSBOutFileData(void);
 void Send_CSW(void);
 void PollUSB (void);
 void SCSI_Process(void);
#endif  


/*********************************************************
* Name: GetHexValue
*
* Desc: Converts ASCII character to hex value 
*
* Parameter: text - ASCII to convert 
*
* Return: unsigned char, hex value of character
*             
**********************************************************/
unsigned char GetHexValue (unsigned char text)
{
    switch (text)
    {
        case '0':
        case '1':
        case '2':
        case '3':
        case '4':
        case '5':
        case '6':
        case '7':
        case '8':
        case '9':
            return (byte)(text - '0');
        case 'A':
        case 'a':
            return 10;
        case 'B':
        case 'b':
            return 11;
        case 'C':
        case 'c':
            return 12;
        case 'D':
        case 'd':
            return 13;
        case 'E':
        case 'e':
            return 14;
        case 'F':
        case 'f':
            return 15;
        default:
            return 0;
    }
}

#if 0		//DES not needed for Ethernet
/*********************************************************
* Name: GetUSBchar
*
* Desc: Gets next character out of buffer used for USB data
*
* Parameter: None 
*
* Return: unsigned char, Next character in buffer
*             
**********************************************************/
unsigned char GetUSBchar (void)
{
    unsigned char c;
   
    c = *SRecCharPointer;
    SRecCharPointer++;
    
    if(SRecCharPointer == SRecBufferEnd) {    // Pointer at end of USB buffer
        if(!BlockWriteDone) {                 // if more USB data coming in same write transfer
            GetUSBOutFileData();              // Put USB data into buffer
        } if(BlockWriteDone) {
            vCSWResult = kCSWPass;
            Send_CSW();                       // finish current USB transfer
          
            if(!S19FileDone){                 // Need to get next USB transfer started
                while(BlockWriteDone) {       // Wait to receive new block of write data
                    PollUSB();                // Wait for USB data to come and fill buffer
                    if(vCBWBuf_flag==1)
                    {
                        SCSI_Process();
                        vCBWBuf_flag=0;
                    }
                }
            }
        }
    SRecCharPointer = SRecBufferAddress;    // reset pointer to beginning of buffer
    }
    
    return c;
}

#endif
/*********************************************************
* Name: GetETHchar
*
* Desc: Gets next character out of buffer used for data
*
* Parameter: pointer to buffer to read from and length
*				remaining in buffer (ie:index to next char
*				to read from buffer)
*
* Return: unsigned char, Next character in buffer
*             
**********************************************************/
unsigned char GetETHchar (volatile unsigned char *buffer)
{
    volatile unsigned char c;
   
    c = *buffer;		// get char
    
    return c;
}


/*********************************************************
* Name: GetS
*
* Desc: This routine skips all characters until an `S' is received.
*		This implies we search array byte by byte.
*       It then returns the next character.
*
* Parameter: pointer to buffer to read from and length
*				remaining in buffer (ie:index to next char
*				to read from buffer)
*
* Return: unsigned char, Next character after 'S'
*             
**********************************************************/
unsigned char GetS (volatile unsigned char *buffer)
{
    volatile unsigned char c;

    for(;;)
    {
#if 0
        c = GetUSBchar();
#else        
        c = GetETHchar(buffer++);
#endif        
        if (c == 'S')
            break;
    }

    /* Get type of S-record */
//DES    return GetUSBchar();
#if 0
        return GetUSBchar();
#else        
        c = GetETHchar(buffer++);
        return (c);
#endif        
}

/*********************************************************
* Name: GetSpair
*
* Desc: Gets pair of characters, and converts to hex byte
*
* Parameter: pointer to buffer to read from and length
*				remaining in buffer (ie:index to next char
*				to read from buffer)
*
* Return: unsigned char, converted hex byte
*             
**********************************************************/
unsigned char GetSpair (volatile unsigned char *buffer)
{
    volatile unsigned char ch;
    volatile unsigned char upper;

#if 0
        ch = GetUSBchar();
#else        
        ch = GetETHchar(buffer++);
#endif        
    upper = (unsigned char)(GetHexValue(ch));
    
    if(upper == 0xFF) {           // Not a proper S19 file
        S19FileDone = TRUE;
    } else
        upper = (byte)(upper << 4);
    
#if 0
        ch = GetUSBchar();
#else        
        ch = GetETHchar(buffer++);
#endif        
    ch = (unsigned char)(GetHexValue(ch));
    if(ch == 0xFF) {           // Not a proper S19 file
        S19FileDone = TRUE;
    } 
    
    return (byte)(upper | ch);
}




/*********************************************************
* Name: ParseSRec
*
* Desc: Read from buffer of S-Record, and parse for programming.
*		Expects one and only one S-Record line. 
*
* Parameter: pointer to buffer to read from and length
*				remaining in buffer (ie:index to next char
*				to read from buffer)
*
* Return: None
*             
**********************************************************/
void ParseS19(volatile unsigned char *buffer) {

 	unsigned char length, checksum, data, i, temp, offset;
    dword address;
    volatile unsigned char type;
    unsigned char tmp_buffer[252];
    
//DES only used with USB stuff    SRecCharPointer = (unsigned char *)buffer;		//DES was SRecBufferAddress;
//DES   S19FileDone=FALSE;	//DES force FALSE for debugging
       
    while (!S19FileDone)
    {
        // Get start of S-record 
        type = GetS(buffer);
        buffer+=2;
        
        // Get record length 
        length = GetSpair(buffer);
        buffer+=2;
        if(S19FileDone) {       // not a valid S19 file
//DES            BootloaderStatus = BootloaderS19Error;
        	printf("\n Get record length BootloaderStatus = BootloaderS19Error;\n");

            return;
        }
        checksum = length;

        // Take appropriate action 
        switch (type)
        {
            case '1':
            case '2':
            case '3':
                address = (dword) NULL;
                type -= '0';
                for (i = 0; i <= type ; i++)
                {
                    // Formulate address
                    // Address needs to be word aligned for successful flash program 
                    data = GetSpair(buffer);
        			buffer+=2;
                    if(S19FileDone) {       // not a valid S19 file
                        BootloaderStatus = BootloaderS19Error;
        	printf("\n Get Address BootloaderStatus = BootloaderS19Error;\n");
                        return;
                    }
                    address = (address << 8) | data;
                    
                    // Maintain 8-bit checksum 
                    checksum = (unsigned char)((data + checksum) & 0x00FF);
                    length--;
                }
                
                if (CheckAddressValid(address))
                {
  
                    // If flash not erased, erase flash
                    if(!FlashErased){
                        EraseFlash();
                        if(BootloaderStatus == BootloaderFlashError) {
                            // Abort S19 download
                            S19FileDone = TRUE;
        	printf("\n S19FileDone = TRUE;\n");
                            return;
                        }
                        FlashErased = TRUE;
                    }
                                  
                    // Pad beginning of buffer if address not word aligned
                    offset = (byte) (address & 0x0003);
                    address = (dword) (address & 0xFFFFFFFC);
                    length += offset;
                    for (i = 0; i < offset; i++) {
                        buffer[i] = 0xFF; 
                    }
                    
                    // Get data and put into buffer 
                    for (i = offset; i < (length - 1); i++)
                    {
                        tmp_buffer[i] = GetSpair(buffer);
                        buffer+=2;
                        if(S19FileDone) {       // not a valid S19 file
                            BootloaderStatus = BootloaderS19Error;
        	printf("\n Get data BootloaderStatus = BootloaderS19Error;\n");
                            return;
                        }
                        
                    }
                    
                    // Calculate checksum 
                    for (i = offset; i < (length - 1); i++)
                    {
                        checksum = (unsigned char)((tmp_buffer[i] + checksum) & 0x00FF);
                    }
                    
                    // Get checksum byte 
                    data = GetSpair(buffer);
                    buffer+=2;
					if(S19FileDone) {       // not a valid S19 file
                        BootloaderStatus = BootloaderS19Error;
                        return;
                    }
                    
                    if (((data - ~checksum) & 0x00FF) != 0)
                    {
                        BootloaderStatus = BootloaderS19Error;
                        S19FileDone = TRUE;
                        return;
                    }
                    
                    // Flash_Prog writes 32-bit words, not bytes.
                    // if last 32-bit word in s-record is not complete, finish word
                    if((i & 0x0003) != 0x0000) {    // 32-bit word not complete
                        tmp_buffer[i++] = 0xFF;         // pad end of word 
                        tmp_buffer[i++] = 0xFF;         // pad end of word 
                        tmp_buffer[i++] = 0xFF;         // pad end of word 
                    }

                    // Write buffered data to Flash 
//DES                    if((address > FLASH_PROTECTED_ADDRESS) && (address <= MAX_FLASH1_ADDRESS)) {
                    if((address >= FLASH_PROTECTED_ADDRESS) && (address <= MAX_FLASH1_ADDRESS)) {
                        
                        // call flash program
                        #ifdef  _MCF51JM128_H	// call this way for 8-bit
                        	temp = (unsigned char) Flash_Prog(address, (dword) &tmp_buffer, (byte)(i >> 2));
                        #else	// call this way for 32-bit
                        	temp = (unsigned char) Flash_Prog(address, (dword) &tmp_buffer, (i >> 2));
                        #endif
                        	
                        if(gFlashError == temp){
                            BootloaderStatus = BootloaderFlashError;
                            return;
                        }
                        return;		//DES should we return after flash write?
                    }
                                
                }

                else    // S-Record points to invalid address
                {
                    BootloaderStatus = BootloaderS19Error;
                    return;
                }

                break;
            case '7':
            case '8':
            case '9':
                address = (dword) NULL; 
                type = (unsigned char)(type - '0');
                type = (unsigned char)(10 - type);
                
                // Get Address
                for (i = 0; i <= type ; i++)
                {
                    data = GetSpair(buffer);
                    buffer+=2;
                    if(S19FileDone) {       // not a valid S19 file
                        BootloaderStatus = BootloaderS19Error;
                        return;
                    }
                    checksum = (unsigned char)((data + checksum) & 0x00FF);
                    address = (address << 8) | data;
                    length--;
                }
                
                // Get Data
                while (length-- > 1)
                {
                    data = GetSpair(buffer);
                   	buffer+=2;
                    if(S19FileDone) {       // not a valid S19 file
                        BootloaderStatus = BootloaderS19Error;
                        return;
                    }
                    checksum = (unsigned char)((data + checksum) & 0x00FF);
                }

                // Read checksum value
                data = GetSpair(buffer);
                buffer+=2;
                if(S19FileDone) {       // not a valid S19 file
                    BootloaderStatus = BootloaderS19Error;
                    return;
                }

                if (((data - ~checksum) & 0x00FF) != 0)
                {
                    BootloaderStatus = BootloaderS19Error;
                    S19FileDone = TRUE;
                    return;
                }
                else // File completely read successfully
                {
                    BootloaderStatus = BootloaderSuccess;
                    S19FileDone = TRUE;
                    return;
                }
                
                break;
            case '0':
            case '4':
            case '5':
            case '6':
            default:
                break;
        }
    }

    return;    
}

