/******************************************************************************
*                                                  
*  (c) copyright Freescale Semiconductor 2008
*  ALL RIGHTS RESERVED
*
*  File Name: Bootloader.C
*                                                                          
*  Purpose: This file is for a USB Mass-Storage Device bootloader.  This file 
*           has the main routine for the bootloader
*                                                                          
*  Assembler:  Codewarrior for ColdFire V7.0
*                                            
*  Version:  1.3
*                                                                          
*                                                                          
*  Author: Derek Snell                             
*                                                                                       
*  Location: Indianapolis, IN. USA                                            
*                                                                                  
* UPDATED HISTORY:
*
* REV   YYYY.MM.DD  AUTHOR        DESCRIPTION OF CHANGE
* ---   ----------  ------        --------------------- 
* 1.0   2008.06.10  Derek Snell   Initial version
* 1.1	2008.06.30	Derek Snell	  Ported from JM128
* 1.2	2008.08.14	Derek Snell	  Fixed delay in enumeration
* 1.3	2008.08.26	Derek Snell	  Fixed MaxLUN response so only 1 drive enumerates
*					& Jose Ruiz	  Added Endpoint 0 stalls
*								  Stopped accepting write data from host after successful S19 transfer
* 1.4   2008.11.05  David Seymour modified for Ethernet
* 
*
******************************************************************************/                                                                        
/* Freescale  is  not  obligated  to  provide  any  support, upgrades or new */
/* releases  of  the Software. Freescale may make changes to the Software at */
/* any time, without any obligation to notify or provide updated versions of */
/* the  Software  to you. Freescale expressly disclaims any warranty for the */
/* Software.  The  Software is provided as is, without warranty of any kind, */
/* either  express  or  implied,  including, without limitation, the implied */
/* warranties  of  merchantability,  fitness  for  a  particular purpose, or */
/* non-infringement.  You  assume  the entire risk arising out of the use or */
/* performance of the Software, or any systems you design using the software */
/* (if  any).  Nothing  may  be construed as a warranty or representation by */
/* Freescale  that  the  Software  or  any derivative work developed with or */
/* incorporating  the  Software  will  be  free  from  infringement  of  the */
/* intellectual property rights of third parties. In no event will Freescale */
/* be  liable,  whether in contract, tort, or otherwise, for any incidental, */
/* special,  indirect, consequential or punitive damages, including, but not */
/* limited  to,  damages  for  any loss of use, loss of time, inconvenience, */
/* commercial loss, or lost profits, savings, or revenues to the full extent */
/* such  may be disclaimed by law. The Software is not fault tolerant and is */
/* not  designed,  manufactured  or  intended by Freescale for incorporation */
/* into  products intended for use or resale in on-line control equipment in */
/* hazardous, dangerous to life or potentially life-threatening environments */
/* requiring  fail-safe  performance,  such  as  in the operation of nuclear */
/* facilities,  aircraft  navigation  or  communication systems, air traffic */
/* control,  direct  life  support machines or weapons systems, in which the */
/* failure  of  products  could  lead  directly to death, personal injury or */
/* severe  physical  or  environmental  damage  (High  Risk Activities). You */
/* specifically  represent and warrant that you will not use the Software or */
/* any  derivative  work of the Software for High Risk Activities.           */
/* Freescale  and the Freescale logos are registered trademarks of Freescale */
/* Semiconductor Inc.                                                        */ 
/*****************************************************************************/

#include "processor.h"		//DES added for integration to Ethernet stack
#include "Bootloader.h"
#include "common.h"

#if 0 //DES added
#include "SCSI_Process.h"



void _Entry(void);
extern asm void _startup(void);

tICPSTR _ICP_VAR;
#define ICP_VAR               _ICP_VAR.Byte
#define ICP_AddrPend          _ICP_VAR.Bits.AddrPend
#define ICP_Prog              _ICP_VAR.Bits.Prog
#define ICP_Verify            _ICP_VAR.Bits.Verify

extern unsigned long far _SDA_BASE;

byte EP1Tx_Data[MSD_BUFFER_SIZE];
byte EP2Rx_Data[MSD_BUFFER_SIZE];

tICP_BDT EP0Rx[2]           @(USB_BUFFER_START);
tICP_BDT EP0Tx[2]           @(USB_BUFFER_START + BDT_SIZE);
volatile tICP_BDT EP1Rx[2]  @(USB_BUFFER_START + 2*BDT_SIZE);
tICP_BDT EP1Tx[2]           @(USB_BUFFER_START + 3*BDT_SIZE);
tICP_BDT EP2Rx[2]           @(USB_BUFFER_START + 4*BDT_SIZE);
tUSB_Setup Setup_Pkt        @(USB_BUFFER_START + 5*BDT_SIZE);

byte ICP_OUT_Data[ICP_BUFFER_SIZE]       @(USB_BUFFER_START + 6*BDT_SIZE);
byte ICP_IN_Data[ICP_BUFFER_SIZE]        @(USB_BUFFER_START + 6*BDT_SIZE + ICP_BUFFER_SIZE);

byte *pEP0IN_Data;
byte vEP0IN_DataCnt;
word vEP1Idx;
word vEP2Idx;
byte vEP1Data[MSD_BUFFER_SIZE];
byte vEP2Data[MSD_BUFFER_SIZE];  

word vEP1_Cnt;


byte vEP0RxData;          // data0/1 toggle
byte vEP0TxData;          // data0/1 toggle
byte vEP1TxData;          // data0/1 toggle
byte vEP2RxData;          // data0/1 toggle
byte vEP0RxBuf;           // odd buf and even buf
byte vEP0TxBuf;           
byte vEP1TxBuf;           // odd buf and even buf
byte vEP2RxBuf;           // odd buf and even buf

byte ICP_USB_State;
byte ICP_Result;
byte vCBWBuf_flag;

dword vStartAddr;
byte vLongNumber;

#endif 

typedef byte (*pCmdInRam)(byte cmd);

typedef struct {
  unsigned char code[100];              
} CmdInRam_t;

CmdInRam_t CmdInRam;
pCmdInRam FnCmdInRam;
byte result;

/************************************************************************************
*************************************************************************************
* Private memory declarations
*************************************************************************************
************************************************************************************/

unsigned char BootloaderStatus;
unsigned char FlashErased;

/************************************************************************************
*************************************************************************************
* Public memory declarations
*************************************************************************************
************************************************************************************/

//DES extern byte vCBWBuf_flag;
//DES extern byte  vSCSIState;         // State of SCSI State Machine
//DES extern word vEP1_Cnt;
//DES extern dword	v_LBA;            // BLock address
extern byte S19FileDone;
//DES extern byte  BlockWriteDone;
//DES extern byte  vCSWResult;         // CSW result
//DES extern byte vCBW_Buf[31];
//DES extern byte vCSWResult; 
//DES extern dword	v_LBA;            // BLock address
//DES extern byte  PacketNum;
//DES extern byte  MultiLBAToken;



/************************************************************************************
*************************************************************************************
* Public functions
*************************************************************************************
************************************************************************************/
//DES void FLASHPGM_Copy(void)  ;
//DES void SCSI_Init(void);
void ParseS19(unsigned char *);
//DES void GetUSBOutFileData(void);
//DES void Send_CSW(void);
//DES void SCSI_Process(void);



/********************************************************************
*********************************************************************
*     Flash subroutines
*********************************************************************
********************************************************************/


byte Flash_Cmd(byte Cmd)
{  
    MCF_CFM_CFMCMD = Cmd;			// flash command to execute
  
    MCF_CFM_CFMUSTAT = 0x80;     	// launch command to start state machine
    
    if(MCF_CFM_CFMUSTAT&0x30)		// check for errors
    {
      return 0xFF;					// return error code
    }
    
    while(!MCF_CFM_CFMUSTAT_CCIF){}	// wait for state machine to complete
    
    
  return 0x01;						// return success code
  
}

// sector erase (2k bytes)
byte Flash_Erase(dword addr)

{
#if 0	//DES not needed for V2 flash
    FnCmdInRam = (void*)((dword)&CmdInRam); 
    CmdInRam = *(CmdInRam_t *)(Flash_Cmd);
#endif
    MCF_CFM_CFMUSTAT = 0x30;        // clear error flags
    
    *(dword *)addr = 0x55;			// address phase with dummy data to sector to erase
    
    return(Flash_Cmd(0x40));    	// send flash command to execute and execute it

}


// dword(32bit) programming
byte Flash_Prog(dword flash_addr,dword data_addr,dword number)

{
   
   byte i;
   
   flash_addr += FLASH_ADDR_OFFSET;
   
#if 0	//DES not needed for V2 flash
   FnCmdInRam = (void*)((dword)&CmdInRam); 
   CmdInRam = *(CmdInRam_t *)(Flash_Cmd);
#endif
   MCF_CFM_CFMUSTAT = 0x30; 		// clear error flags
    
   for(i=0;i<number;i++)
   {
      while(!(MCF_CFM_CFMUSTAT & MCF_CFM_CFMUSTAT_CBEIF)) { };	// wait for CFM to be ready for new command
      *(dword *)flash_addr = *(dword *)data_addr;			// addr and data to write
      result= Flash_Cmd(0x20);								// send Word Program command and execute
      if(result == 0xFF)									// if error
        return 0xFF;										//		return error
      flash_addr +=4;										// increment addr pointer
      data_addr +=4;										// increment data pointer
   }
   
   return result;
}
    

byte Flash_Verify(dword dst_addr, dword data_addr, byte length) 
{
  do
	 {
		  if(*(dword *)dst_addr != *(dword *)data_addr) // compare two values
		{
		   return 0xFF;
		}	
		
		dst_addr +=4;
		data_addr +=4; 
	}	 
	while(--length);		
    
  return 0x01;
}

/*********************************************************
* Name: CheckAddressValid
*
* Desc: Checks if Address of S-Record is valid for device
*
* Parameter: Address
*
* Return: unsigned char, TRUE or FALSE if valid
*             
**********************************************************/
unsigned char CheckAddressValid(dword Address) {

    if((Address >= MIN_FLASH1_ADDRESS) && (Address <= MAX_FLASH1_ADDRESS))
        return TRUE;
    else if ((Address >= MIN_RAM1_ADDRESS) && (Address <= MAX_RAM1_ADDRESS))
        return TRUE;
    else
        return FALSE;
}

/*********************************************************
* Name: EraseFlash
*
* Desc: Erases all unprotected pages of flash
*
* Parameter: None
*
* Return: None
*             
**********************************************************/
void EraseFlash(void) {
    
volatile dword addr;
    unsigned char temp;
    
    // erase each page of flash
    for(addr=MIN_FLASH1_ADDRESS;addr<=MAX_FLASH1_ADDRESS;addr+=FLASH_PAGE_SIZE) {
        if(addr > FLASH_PROTECTED_ADDRESS) {
            while(!(MCF_CFM_CFMUSTAT & MCF_CFM_CFMUSTAT_CBEIF)) { };	// wait for CFM to be ready for new command
            temp = (byte) Flash_Erase(addr + FLASH_ADDR_OFFSET);
            if(gFlashError == temp) {
                // Error Erasing Flash
                BootloaderStatus = BootloaderFlashError;
                return;
            }
        } 
    }

}


#if 0		//DES remove USB code

/********************************************************************
*********************************************************************
*       ICP Device Descriptor
*********************************************************************
********************************************************************/
const byte Device_Descriptor[18]= 
{
	0x12,		      //blength
	0x01,		      //bDescriptor
	0x00,0x02,	  //bcdUSB ver R=2.00 
	0x00,		      //bDeviceClass
	0x00,		      //bDeviceSubClass			
	0x00,		      //bDeviceProtocol			
	0x40,		      //bMaxPacketSize0
	0xA2,0x15,	  //idVendor - 0x15A2(freescale Vendor ID)
	0x3F,0x00,	  //idProduct - 0x003F
	0x00,0x01,	  //bcdDevice - Version 1.00
	0x01,		      //iManufacturer - Index to string descriptor
	0x02,		      //iProduct - Index to string descriptor
	0x00,		      //iSerialNumber - Index to string descriptor
	0x01	       	//bNumConfigurations - # of config. at current speed,
};




/********************************************************************
*********************************************************************
*       ICP Configuration Descriptor
*********************************************************************
********************************************************************/
const byte Configuration_Descriptor[32]= 
{
	0x09,		      //blength
	0x02,		      //bDescriptor
	0x20,0x00,	  //wTotalLength - # of bytes including interface and endpoint descpt.
	0x01,		      //bNumInterfaces - at least 1 data interface
	0x01,		      //bConfigurationValue - 
	0x00,		      //iConfiguration - index to string descriptor	
	0x80,		      //bmAttributes - 0x?0	bit 7-bus powered
				        //						        bit 6-self powered
				        //						        bit 5-remote wakeup
				        //						        bit 4-0-reserved
	0x64,		      //bMaxPower - 200mA
	
// ======================================================
// 		Standard Interface Descriptor
// ======================================================

	0x09,		      //blength
	0x04,		      //bDescriptorType - Interface descriptor
	0x00,		      //bInterfaceNumber - Zero based value identifying the index of the config.
	0x00,		      //bAlternateSetting;
	0x02,		      //bNumEndpoints - 2 endpoints
	0x08,		      //bInterfaceClass - mass storage 
	0x06,		      //bInterfaceSubClass - SCSI Transparent command Set
	0x50,		      //bInterfaceProtocol - Bulk-Only transport
	0x00,		      //iInterface - Index to String descriptor
	
// ======================================================
// 		Standard Endpoint Descriptor
//    	Bulk IN Endpoint
// ======================================================
	0x07,		      //bLength;
	0x05,		      //bDescriptorType - Endpoint descriptor
	0x81,		      //bEndpointAddress - bit 3..0 endpoint number
				        // 					         bit 6..4 Reserved reset to zero
				        //					         bit 7	0-OUT, 1-IN									
	0x02,		      //bmAttributes _ Bulk endpoint
	0x40,0x00,	  //wMaxPacketSize - 64 byte packet size
	0x00,		      //bInterval - do not apply to BULK endpoint
	
// ======================================================
// 		Standard Endpoint Descriptor
//    	Bulk OUT Endpoint
// ======================================================
	0x07,		      //bLength;
	0x05,		      //bDescriptorType - Endpoint descriptor
	0x02,		      //bEndpointAddress - bit 3..0 endpoint number
				        // 					         bit 6..4 Reserved reset to zero
				        //					         bit 7	0-OUT, 1-IN									
	0x02,		      //bmAttributes _ Bulk endpoint
	0x40,0x00,	  //wMaxPacketSize - 64 byte packet size
	0x00,		      //bInterval - do not apply to BULK endpoint	
 
};



// ======================================================
//
// 		String Descriptor Zero
//
// ======================================================
const byte String_Descriptor0[4] = {
	0x04,		      //bLength;
	0x03,		      //bDescriptorType - STRING descriptor
	0x09,0x04,	  //wLANDID0 - English (American)
};

// ======================================================
//
// 		String Descriptor one
//
// ======================================================
const byte String_Descriptor1[] = {
	0x14,			    //bLength; 11 bytes
	0x03,		      //bDescriptorType - STRING descriptor
	'F',0x00,	    // "F"
	'r',0x00,	    // "r"
	'e',0x00,	    // "e"
	'e',0x00,	    // "e"
	's',0x00,	    // "s"
	'c',0x00,	    // "c"
	'a',0x00,	    // "a"
	'l',0x00,	    // "l"
	'e',0x00,	    // "e"
};	 


// ======================================================
//
// 		String Descriptor two
//
// ======================================================
const byte String_Descriptor2[] = {
	0x12,			    //bLength;
	0x03,		      //bDescriptorType - STRING descriptor
	'M',0x00,	    // MCF5225x
	'C',0x00,	
	'F',0x00,	
	'5',0x00,
	'2',0x00,
	'2',0x00,
	'5',0x00,
	'x',0x00,
};	 


/********************************************************************
*********************************************************************
*       ICP Device Descriptor
*********************************************************************
********************************************************************/
const byte MaxLUNResponse[1]= 
{
	0x00		     
};



/********************************************************************
*********************************************************************
*     USB subroutines
*********************************************************************
********************************************************************/

/*********************************************************
* Name: USB_InitBulk
*
* Desc: Initialize EP1 and EP2 as Bulk only endpoint
*       EP1- IN  EP2-OUT
* 
* Parameter: None
*
* Return: None
*            
**********************************************************/

void USB_InitBulk(void) 
{
  MCF_USB_OTG_ENDPT1=0x05;                          // endpoint 1 for IN only
  MCF_USB_OTG_ENDPT2=0x09;                          // endpoint 2 for OUT only
  
  EP1Tx[0].BDT_Stat._byte= mUDATA0;
  EP1Tx[0].Cnt = cEP1_BUFF_SIZE;
  EP1Tx[0].Addr0 = (byte) (((dword)&EP1Tx_Data) >>  0);          // EP1 IN buffer;
  EP1Tx[0].Addr1 = (byte) (((dword)&EP1Tx_Data) >>  8);          // EP1 IN buffer;
  EP1Tx[0].Addr2 = (byte) (((dword)&EP1Tx_Data) >> 16);          // EP1 IN buffer;
  EP1Tx[0].Addr3 = (byte) (((dword)&EP1Tx_Data) >> 24);          // EP1 IN buffer;
  
  EP1Tx[1].BDT_Stat._byte= mUDATA1;
  EP1Tx[1].Cnt = cEP1_BUFF_SIZE;
  EP1Tx[1].Addr0 = (byte) (((dword)&EP1Tx_Data) >>  0);          // EP1 IN buffer;
  EP1Tx[1].Addr1 = (byte) (((dword)&EP1Tx_Data) >>  8);          // EP1 IN buffer;
  EP1Tx[1].Addr2 = (byte) (((dword)&EP1Tx_Data) >> 16);          // EP1 IN buffer;
  EP1Tx[1].Addr3 = (byte) (((dword)&EP1Tx_Data) >> 24);          // EP1 IN buffer;
  vEP1TxBuf = 0;
  vEP1TxData = mUDATA0;
  
  EP2Rx[0].BDT_Stat._byte = mUDATA0;
  EP2Rx[0].Cnt  = cEP2_BUFF_SIZE;
  EP2Rx[0].Addr0 = (byte) (((dword)&EP2Rx_Data) >>  0);          // EP2 buffer;
  EP2Rx[0].Addr1 = (byte) (((dword)&EP2Rx_Data) >>  8);          // EP2 buffer;
  EP2Rx[0].Addr2 = (byte) (((dword)&EP2Rx_Data) >> 16);          // EP2 buffer;
  EP2Rx[0].Addr3 = (byte) (((dword)&EP2Rx_Data) >> 24);          // EP2 buffer;
  
  EP2Rx[1].BDT_Stat._byte = mMCU;
  EP2Rx[1].Cnt  = cEP2_BUFF_SIZE;
  EP2Rx[1].Addr0 = (byte) (((dword)&EP2Rx_Data) >>  0);          // EP2 buffer;
  EP2Rx[1].Addr1 = (byte) (((dword)&EP2Rx_Data) >>  8);          // EP2 buffer;
  EP2Rx[1].Addr2 = (byte) (((dword)&EP2Rx_Data) >> 16);          // EP2 buffer;
  EP2Rx[1].Addr3 = (byte) (((dword)&EP2Rx_Data) >> 24);          // EP2 buffer;
  vEP2RxBuf = 0;
  vEP2RxData = mUDATA0;
  
  vEP2Idx = 0;
  
}


void Init_USB(void) 
{
  long *ptr;
  byte i;
  
  ptr= (long *) &EP0Rx;
  
  for(i=0; i<64;i++)
    *(ptr+i)=0;
  
    
  EP0Rx[0].BDT_Stat._byte = mUDATA0;
	EP0Rx[0].Cnt = mEP0_BUFF_SIZE;
  EP0Rx[0].Addr0 = (byte) (((dword)&Setup_Pkt) >>  0);                     
  EP0Rx[0].Addr1 = (byte) (((dword)&Setup_Pkt) >>  8);                     
  EP0Rx[0].Addr2 = (byte) (((dword)&Setup_Pkt) >> 16);                     
  EP0Rx[0].Addr3 = (byte) (((dword)&Setup_Pkt) >> 24);                     
  
  
  EP0Rx[1].BDT_Stat._byte = mUDATA1;
	EP0Rx[1].Cnt = mEP0_BUFF_SIZE;
  EP0Rx[1].Addr0 = (byte) (((dword)&ICP_OUT_Data) >>  0);                     
  EP0Rx[1].Addr1 = (byte) (((dword)&ICP_OUT_Data) >>  8);                     
  EP0Rx[1].Addr2 = (byte) (((dword)&ICP_OUT_Data) >> 16);                     
  EP0Rx[1].Addr3 = (byte) (((dword)&ICP_OUT_Data) >> 24);                     
  

  EP0Tx[0].BDT_Stat._byte = mUDATA0;
	EP0Tx[0].Cnt = mEP0_BUFF_SIZE;
  EP0Tx[0].Addr0 = (byte) (((dword)&ICP_IN_Data) >>  0);                     
  EP0Tx[0].Addr1 = (byte) (((dword)&ICP_IN_Data) >>  8);                     
  EP0Tx[0].Addr2 = (byte) (((dword)&ICP_IN_Data) >> 16);                     
  EP0Tx[0].Addr3 = (byte) (((dword)&ICP_IN_Data) >> 24);                     
  
  
  EP0Tx[1].BDT_Stat._byte = mUDATA1;
	EP0Tx[1].Cnt = mEP0_BUFF_SIZE;
  EP0Tx[1].Addr0 = (byte) (((dword)&ICP_IN_Data) >>  0);                     
  EP0Tx[1].Addr1 = (byte) (((dword)&ICP_IN_Data) >>  8);                     
  EP0Tx[1].Addr2 = (byte) (((dword)&ICP_IN_Data) >> 16);                     
  EP0Tx[1].Addr3 = (byte) (((dword)&ICP_IN_Data) >> 24);                     
  

  MCF_CIM_CCE = 0;
  
  MCF_USB_OTG_USB_CTRL = 0x01;              // oscillator clock
  
  MCF_USB_OTG_BDT_PAGE_01 = (byte) (((dword)USB_BUFFER_START) >>  8);           
  MCF_USB_OTG_BDT_PAGE_02 = (byte) (((dword)USB_BUFFER_START) >> 16);
  MCF_USB_OTG_BDT_PAGE_03 = (byte) (((dword)USB_BUFFER_START) >> 24);
  
  
  MCF_USB_OTG_ENDPT0 = 0x0D;                // enable endpoint  
  
  MCF_USB_OTG_INT_ENB = 0x00;               // disable all interrupt
  MCF_USB_OTG_OTG_INT_EN = 0x00;            // disable all OTG interrupt
  MCF_USB_OTG_ERR_ENB = 0x00;               // disable all error interrupt
  MCF_USB_OTG_INT_STAT = 0xFF;
  
  MCF_USB_OTG_CTL = 0x01;                   // USB module enable
  
  MCF_USB_OTG_OTG_CTRL |= (MCF_USB_OTG_OTG_CTRL_DP_HIGH | MCF_USB_OTG_OTG_CTRL_OTG_EN);		// enable USBDP pull-up resistor
  
  
}
  


void EP0_Load(void)
{    
    
    byte *pDst;
    
    if(vEP0IN_DataCnt==0)
      return;
                  
    pDst=(byte *)&ICP_IN_Data;
    
    
    EP0Tx[vEP0TxBuf].Cnt = vEP0IN_DataCnt;
   
 
    while(vEP0IN_DataCnt)
    {
       *pDst = *pEP0IN_Data;
       pDst++;
       pEP0IN_Data++;
       vEP0IN_DataCnt--;
    }
    
    EP0Tx[vEP0TxBuf].BDT_Stat._byte = vEP0TxData;
    vEP0TxData ^=0x40;
    vEP0TxBuf ^=0x01;
      
}     


/*********************************************************
* Name: EP0_Stall
*
* Desc: Stalls Endpoint 0
* 
* Parameter: None
*
* Return: None            
*
**********************************************************/
void EP0_Stall(void)
{

   MCF_USB_OTG_ENDPT0 |= MCF_USB_OTG_ENDPT_EP_STALL;                // stall EP0
}


/*********************************************************
* Name: EP1_Load
*
* Desc: Load data to Endpoint 1 buffer
* 
* Parameter: None
*
* Return: None            
*
**********************************************************/
void EP1_Load(void)
{
    uint16 i,counter;
    byte *pBuffer;
     
    pBuffer=(byte *)&EP1Tx_Data;
    
    if(vEP1_Cnt > cEP1_BUFF_SIZE)
      counter = cEP1_BUFF_SIZE;
    else
      counter = (byte)vEP1_Cnt;
    
    for(i=0;i<counter;i++,vEP1Idx++){
      pBuffer[i]=vEP1Data[vEP1Idx];
    }
       
    
    EP1Tx[vEP1TxBuf].Cnt = counter;
    EP1Tx[vEP1TxBuf].BDT_Stat._byte= vEP1TxData;
    vEP1TxData ^=0x40;  
    vEP1TxBuf  ^=0x01;

    vEP1_Cnt = (word)(vEP1_Cnt - counter);
    
}


void ICP_USB_Wait(void)
{
            
    MCF_USB_OTG_CTL |= MCF_USB_OTG_CTL_ODD_RST; 
    
    vEP0RxBuf = 0;
    vEP0TxBuf = 0;
    vEP0RxData = mUDATA0;
    vEP0TxData = mUDATA0;
    
    MCF_USB_OTG_CTL &= ~MCF_USB_OTG_CTL_ODD_RST;
      
    EP0Rx[0].BDT_Stat._byte = mUDATA0;
	  EP0Rx[0].Cnt = mEP0_BUFF_SIZE;
	  
	  EP0Rx[1].BDT_Stat._byte = mMCU;
	  EP0Rx[1].Cnt = mEP0_BUFF_SIZE;
   
    EP0Tx[0].BDT_Stat._byte = mMCU;
	  EP0Tx[0].Cnt = mEP0_BUFF_SIZE;
	  EP0Tx[1].BDT_Stat._byte = mMCU;
	  EP0Tx[1].Cnt = mEP0_BUFF_SIZE;
   
    EP1Tx[0].BDT_Stat._byte= mUDATA0;
    EP1Tx[0].Cnt = cEP1_BUFF_SIZE;
  
    EP1Tx[1].BDT_Stat._byte= mUDATA1;
    EP1Tx[1].Cnt = cEP1_BUFF_SIZE;
    vEP1TxBuf = 0;
    vEP1TxData = mUDATA0;
  
    EP2Rx[0].BDT_Stat._byte = mUDATA0;
    EP2Rx[0].Cnt  = cEP2_BUFF_SIZE;
  
    EP2Rx[1].BDT_Stat._byte = mMCU;
    EP2Rx[0].Cnt  = cEP2_BUFF_SIZE;
    vEP2RxBuf = 0;
    vEP2RxData = mUDATA0;
    
    MCF_USB_OTG_CTL &= ~MCF_USB_OTG_CTL_TXSUSPEND_TOKENBUSY; 
    
    ICP_USB_State = mICP_WAIT;              
   
}

/*********************************************************
* Name: USB_CLsReq_Handler
*
* Desc: Handle USB class request
* 
* Parameter: None
*
* Return: None            
*
**********************************************************/

void USB_ClsReq_Handler(void)
{
  
   if(mGET_MAXLUN == Setup_Pkt.bRequest)
   {
      pEP0IN_Data = (byte*)&MaxLUNResponse;
      vEP0IN_DataCnt = sizeof(MaxLUNResponse);
   } 
   else
   {
      ICP_USB_Wait();
   }
}
   



void ICP_Setup_Handler(void)
{
   byte length;
   
   vEP0IN_DataCnt= 0;
   ICP_USB_State = mICP_WAIT;
   
   if(0x00 == (Setup_Pkt.bmRequestType & 0x60)) {
      
      switch(Setup_Pkt.bRequest) 
      {
     
        case mGET_STATUS:
          pEP0IN_Data = (byte*)&Device_Descriptor+4; 			
          vEP0IN_DataCnt = 0x02;   
          break;
      
        case mSET_ADDR:
          ICP_AddrPend = 1;
          break;
      
        case mGET_DESC:
        
            switch(Setup_Pkt.wValue_h) 
            {
              case mDESC_DEV:
                pEP0IN_Data = (byte*)&Device_Descriptor;
                vEP0IN_DataCnt = sizeof(Device_Descriptor);
                break;
          
              case mDESC_CFG:
                pEP0IN_Data = (byte*)&Configuration_Descriptor;
                vEP0IN_DataCnt = sizeof(Configuration_Descriptor);
                break;
        
              case mDESC_STR:
                      switch (Setup_Pkt.wValue_l) {
                          case 0:
                              pEP0IN_Data = (byte*)String_Descriptor0;
                              break;
                          case 1:
                              pEP0IN_Data = (byte*)String_Descriptor1;
                              break;
                          case 2:
                              pEP0IN_Data = (byte*)String_Descriptor2;
                              break;
                      }
                      vEP0IN_DataCnt = *pEP0IN_Data;
                      break;
          
              default: 
                EP0_Stall();
                break;  
            }
        
            break;

        case mSET_CFG:
              if(Setup_Pkt.wValue_h+Setup_Pkt.wValue_l) // value is not zero
              {
                  USB_InitBulk();                         // init EP1 and EP2
            
              } 
              else
                  ICP_AddrPend = 1;
                  break;
      
      
/*        case mPROGRAM:
			      vStartAddr = *(dword *)&Setup_Pkt.wValue_l;
			      vLongNumber = (byte)(Setup_Pkt.wLength_l);
			      ICP_Prog=1;
	          ICP_Result = 0;
			      break;
      
        case mSECTOR_ERASE:
			      vStartAddr = *(dword *)&Setup_Pkt.wValue_l;
			      ICP_Result = 0;
			      ICP_Result=Flash_Erase(vStartAddr);
			      asm (nop);
	
			      break;
			  
        case mVERIFY:
            vStartAddr = *(dword *)&Setup_Pkt.wValue_l;
            vLongNumber = (byte)(Setup_Pkt.wLength_l);
            ICP_Verify=1;
	          ICP_Result = 0;
            break;
			  
        case mGET_RESULT:
            pEP0IN_Data = (byte*)&ICP_Result;
            vEP0IN_DataCnt = 1;
            break;  
*/     
      
        default:                         // not support
            EP0_Stall();
            break;
          
      } 
   } else if(0x20 == (Setup_Pkt.bmRequestType & 0x60)) {
        USB_ClsReq_Handler();       
   }
   else									// not supported
   		EP0_Stall();



   if(Setup_Pkt.bmRequestType &0x80)              // Device to Host
    {
       
       length = Setup_Pkt.wLength_l;
              
  		 if(length < vEP0IN_DataCnt)
         vEP0IN_DataCnt = length;
  			
       vEP0TxData = mUDATA1; 
       EP0_Load();
       ICP_USB_State   = mICP_TX; 
      
    }
    else    
    {
       ICP_USB_State   = mICP_RX;
       EP0Tx[vEP0TxBuf].Cnt = 0x00;                              // return zero IN data
       EP0Tx[vEP0TxBuf].BDT_Stat._byte = mUDATA1;  
    }
  
         
 	 vEP0RxData ^= 0x40;
	 vEP0RxBuf ^= 0x01;
	 EP0Rx[vEP0RxBuf].Cnt = mEP0_BUFF_SIZE;
         
   EP0Rx[vEP0RxBuf].BDT_Stat._byte = vEP0RxData; 
   MCF_USB_OTG_CTL &= ~MCF_USB_OTG_CTL_TXSUSPEND_TOKENBUSY;
 
}


 void ICP_In_Handler(void)
{
   
    if(ICP_AddrPend ==1) {
        MCF_USB_OTG_ADDR = Setup_Pkt.wValue_l;
        ICP_AddrPend =0;
    }
           
    if(ICP_USB_State == mICP_TX)
    {
      EP0_Load();
    } 
    
    else
      ICP_USB_Wait(); 
}


void ICP_Out_Handler(void)
{
   byte Len;
    
   Len=EP0Rx[vEP0RxBuf].Cnt;
  
   if(ICP_USB_State==mICP_RX)
   {
   
     if(ICP_Prog==1 && Len==vLongNumber)  
     {
         vLongNumber>>=2; 
         ICP_Result=Flash_Prog(vStartAddr, (dword)&ICP_OUT_Data,vLongNumber);//Setup_Pkt,vLongNumber); 
         ICP_Prog=0;
      }
          
        
     if( ICP_Verify==1 && Len==vLongNumber)  
     {         
         vLongNumber >>=2;
         ICP_Result= Flash_Verify(vStartAddr, (unsigned int)&ICP_OUT_Data,vLongNumber); 
         ICP_Verify =0;
         
      }
        
    
    
    vEP0RxData ^=0x40;
    vEP0RxBuf ^=0x01;
    
   }
   else
      ICP_USB_Wait();  
}



void ICP_Reset_Handler(void)
{
 
   MCF_USB_OTG_INT_STAT = 0xFF;              // clear all flag
   MCF_USB_OTG_INT_ENB = 0x00;
   MCF_USB_OTG_ADDR = 0x00;
   ICP_USB_Wait();   
    
}

/*********************************************************
* Name: USB_EP1_IN_Handler
*
* Desc: Handle USB Endpoint1 IN token
* 
* Parameter: None
*
* Return: None            
*
**********************************************************/
void USB_EP1_IN_Handler(void)
{
   
   if( ICP_USB_State == cCSW) 
   {
      Send_CSW();
   } 
   
   else if(ICP_USB_State == cEP1Tx)
   {
     
     EP1_Load();
     if(vEP1_Cnt == 0)
    {
      ICP_USB_State=mICP_WAIT; 
    } 
    
   }
   
   else
   {
      EP1Tx[0].Cnt = 0;
      EP1Tx[0].BDT_Stat._byte= mMCU;  
      EP1Tx[1].Cnt = 0;
      EP1Tx[1].BDT_Stat._byte= mMCU;  
   }
    
}


/*********************************************************
* Name: USB_EP2_OUT_Handler
*
* Desc: Handle USB Endpoint2 OUT token
* 
* Parameter: None
*
* Return: None            
*
**********************************************************/ 
void USB_EP2_OUT_Handler(void)
{
    uint16 i;
    byte *pCBW_Pkt;
    
    pCBW_Pkt=(byte *)&EP2Rx_Data;
      

    
    if(EP2Rx[vEP2RxBuf].Cnt ==31)        // CBW should be 31 bytes
    {
      ICP_USB_State = cCBW;
      vCBWBuf_flag=1;   
      
      for(i=0;i<EP2Rx[vEP2RxBuf].Cnt;i++)
      {
          vCBW_Buf[i]= pCBW_Pkt[i];
          
      }
             
      vEP2RxData ^=0x40;
      vEP2RxBuf  ^=0x01;
      EP2Rx[vEP2RxBuf].BDT_Stat._byte=vEP2RxData;
      EP2Rx[vEP2RxBuf].Cnt  = cEP2_BUFF_SIZE;
    }
      
    else
    {
         
      for(i=0;i<EP2Rx[vEP2RxBuf].Cnt;i++,vEP2Idx++)
      {
         vEP2Data[vEP2Idx]= pCBW_Pkt[i];
      }
         
      if(vEP2Idx == 512)
      {
        ICP_USB_State = cEP2Rx;
        vEP2RxData ^=0x40;
        vEP2RxBuf  ^=0x01;
        EP2Rx[vEP2RxBuf].Cnt  = cEP2_BUFF_SIZE;
        EP2Rx[vEP2RxBuf].BDT_Stat._byte=vEP2RxData;
      } 
      else
      {
          
        vEP2RxData ^=0x40;
        vEP2RxBuf  ^=0x01;
        EP2Rx[vEP2RxBuf].BDT_Stat._byte=vEP2RxData;
        EP2Rx[vEP2RxBuf].Cnt  = cEP2_BUFF_SIZE;
      }  
        
    }
}

/*********************************************************
* Name: USB_Stall_Handler
*
* Desc: Handles stall on endpoint 0
* 
* Parameter: None
*
* Return: None            
*
**********************************************************/ 
void USB_Stall_Handler(void) 
{
	if(MCF_USB_OTG_ENDPT0 & MCF_USB_OTG_ENDPT_EP_STALL)
		MCF_USB_OTG_ENDPT0 &= ~(MCF_USB_OTG_ENDPT_EP_STALL);
	
	MCF_USB_OTG_INT_STAT |= MCF_USB_OTG_INT_STAT_STALL;		// clear stall flag
}

/*********************************************************
* Name: PollUSB
*
* Desc: Polls USB flags instead of using interrupts
* 
* Parameter: None
*
* Return: None            
*
**********************************************************/ 
void PollUSB(void) {

    byte stat;
    byte odd; 

    if(MCF_USB_OTG_INT_STAT & MCF_USB_OTG_INT_STAT_USB_RST)
     {
       ICP_Reset_Handler();
     }
     
     if(MCF_USB_OTG_INT_STAT & MCF_USB_OTG_INT_STAT_STALL)
     	USB_Stall_Handler();
    
    
    if(MCF_USB_OTG_INT_STAT & MCF_USB_OTG_INT_STAT_TOK_DNE)
    {
        stat=(byte)(MCF_USB_OTG_STAT & 0xF8);
 	    if(MCF_USB_OTG_STAT & MCF_USB_OTG_STAT_ODD)
 	    	odd = 1;
 	    else
 	    	odd = 0;
         
        // OUT or SETUP token
        if(stat == mEP0_OUT)
        {
          // SETUP token
          if(EP0Rx[odd].BDT_Stat.RecPid.PID == mSETUP_TOKEN)
          {
            ICP_Setup_Handler();
          }  
          // OUT token
          else                                              
            ICP_Out_Handler();
        }
        
        else if(stat == mEP0_IN)
        {
          // IN token                                 
           ICP_In_Handler();
        }
        else if (stat==mEP1_IN){
           USB_EP1_IN_Handler();
        }
        else if (stat==mEP2_OUT) {
           USB_EP2_OUT_Handler();
        }

      // Clear token flag  
      MCF_USB_OTG_INT_STAT |= MCF_USB_OTG_INT_STAT_TOK_DNE;
      MultiLBAToken = 0;  
    
    }
  
}
#endif




void Bootloader_Main(void) 
{
	BootloaderStatus = BootloaderReady;
	S19FileDone = FALSE;		//DES was TRUE
	FlashErased = FALSE;			//DES was FALSE;

//	MCF_CFM_CFMCLKD=0x4F;               // for bus clock=24MHz 
	MCF_CFM_CFMCLKD = 0x5A;		//FSL 80MHz/8/51=196.078KHz
   
}




#if 0 
void Bootloader_Main(void) 
{
   
   asm {
    move.w	#0x2700,sr

    /* Initialize RAMBAR1: locate SRAM and validate it */
	move.l	#__SRAM,d0
	andi.l	#0xFFFF0000,d0
    add.l   #0x21,d0
    movec   d0,RAMBAR1

	/* Locate Stack Pointer */ 
	move.l	#__SP_INIT,sp

    /* Initialize IPSBAR */
	move.l	#__IPSBAR,d0
    add.l   #0x1,d0
	move.l	d0,0x40000000
	
    /* Initialize FLASHBAR */
    move.l  #__FLASH,d0
    cmp.l   #0x00000000,d0
    add.l   #0x61,d0
    movec   d0,RAMBAR0

   };
   
   //clear ram
   ICP_VAR = 0x00;
   ICP_Result = 0x00;
   vEP0IN_DataCnt = 0x00;
   vEP0RxData = 0x00;          
   vEP0TxData = 0x00;
   vEP1TxData = 0x00;
   vEP2RxData = 0x00;          
   vEP0RxBuf = 0x00;           
   vEP0TxBuf = 0x00;
   vEP1TxBuf = 0x00;
   vEP2RxBuf = 0x00;           
   vStartAddr = 0;
   vLongNumber = 0;

	 BootloaderStatus = BootloaderReady;
	 S19FileDone = TRUE;
	 FlashErased = FALSE;

   
   MCF_CFM_CFMCLKD=0x4F;               // for bus clock=24MHz 
   
   SCSI_Init();
   Init_USB();
   
   for(;;)
   {
      PollUSB(); 
      if(vCBWBuf_flag==1)
      {
          SCSI_Process();
          vCBWBuf_flag=0;
      }
      if(!S19FileDone && (BootloaderStatus == BootloaderReady)){
          BootloaderStatus = BootloaderStarted;
   jhaksdh       ParseS19();
          while(!BlockWriteDone)                // Finish USB transfer
              GetUSBOutFileData();              
          vCSWResult = kCSWPass;
          Send_CSW();                       // finish current USB transfer

      }    
    
   }// for end

}

#endif




