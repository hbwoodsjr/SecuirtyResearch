/*
 * File:		uart.h
 * Purpose:     Provide common ColdFire UART routines for polled serial IO
 *
 * Notes:
 */

#ifndef __UART_H__
#define __UART_H__

/********************************************************************/

int  uart_init (int);
int  uart_getchar (int);
int  uart_putchar (int, int);
int  uart_getchar_present (int);

/********************************************************************/

#endif /* __UART_H__ */
