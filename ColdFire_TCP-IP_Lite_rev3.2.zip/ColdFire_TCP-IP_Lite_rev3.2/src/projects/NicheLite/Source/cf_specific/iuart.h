/*
 * File:		iuart.h
 * Purpose:     Provide common ColdFire UART routines for polled serial IO
 *
 * Notes: FSL created file
 */

#ifndef __IUART_H__
#define __IUART_H__

/********************************************************************/

int uart_init(int);
int uart_putc(int, unsigned char);
int uart_getc(int);
int uart_flush(int);
int uart_ready(int);
int uart_ready(int);
int uart_present(int);
void uart_close(int);
int uart_stats(void *, int);
void uart_check();
void uart_isr(int);
__interrupt__ void uart0_isr(void);
__interrupt__ void uart1_isr(void);
#if defined(MCF53013) || defined(MCF54455)
__interrupt__ void uart2_isr(void);
#endif

void iuart_set_baud( int, int);

/********************************************************************/

#endif /* __IUART_H__ */
