/* 
 * FILENAME ce.h 
 *
 * In the full TCP/IP product from Interniche (www.iniche.com), 
 * this file would have the header definitions for the optional 
 * module described here.
 *
 * "Cryptographic Engine" 
 *
 */


