/* 
 * FILENAME snmp_vie.h 
 *
 * In the full TCP/IP product from Interniche (www.iniche.com), 
 * this file would have the header definitions for the optional 
 * module described here.
 *
 * "SNMP network management" 
 *
 */


