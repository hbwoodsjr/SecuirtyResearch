/*
 * FILENAME: menulib.c
 *
 * Copyright 1997- 2006 By InterNiche Technologies Inc. All rights reserved
 *
 * Portions Copyright 1986 by Carnegie Mellon
 * Portions Copyright 1984 by the Massachusetts Institute of Technology
 *
 * Copyright (c) 1982, 1986, 1988 Regents of the University of California.
 * All rights reserved.
 *
 * Redistribution and use in source and binary forms are permitted
 * provided that the above copyright notice and this paragraph are
 * duplicated in all such forms and that any documentation and other 
 * materials related to such distribution and use acknowledge that 
 * the software was developed by the University of California, Berkeley.
 * The name of the University may not be used to endorse or promote 
 * products derived from this software without specific prior written 
 * permission. THIS SOFTWARE IS PROVIDED "AS IS" AND WITHOUT ANY EXPRESS
 * OR IMPLIED WARRANTIES, INCLUDING, WITHOUT LIMITATION, THE IMPLIED
 * WARRANTIES OF MERCHANTIBILITY AND FITNESS FOR A PARTICULAR PURPOSE.
 *
 *
 * Rights, responsibilities and use of this software are controlled by
 * the agreement found in the "LICENSE.H" file distributed with this
 * source code.  "LICENSE.H" may not be removed from this distribution,
 * modified, enhanced nor references to it omitted.
 *
 * Misc utility routines for Interniche menuing system
 *
 * MODULE: MISCLIB
 *
 * ROUTINES: setdebug(), set_upc(), snmp_stat(), iface_stats(), 
 * ROUTINES: ifstats(), linkstats(), settrapsize(), if_configbyname()
 * ROUTINES: if_netbytext
 *
 * PORTABLE: yes
 */

#include "license.h"
#include "ipport.h"
#include "in_utils.h"

#include "q.h"
#include "netbuf.h"
#include "net.h"
#include "ip.h"
#include "icmp.h"
#include "ether.h"
#include "arp.h"

#include "menu.h"

#include "nvparms.h"

extern uint8 ephy_isr;
extern void iuart_set_baud( int, int);	

int ifstats(void * , struct net * );
char * print_uptime(unsigned long);

unsigned atoh(char *);

#ifdef IP_V6
#include "ip6.h"
#endif

/* FUNCTION: setdebug()
 *
 * setdebug() - toggle NDEBUG protocol stack debugging options
 * 
 * PARAM1: void * pio
 *
 * RETURNS: 0
 */

int
setdebug(void * pio)
{
#ifdef NPDEBUG
     char *   cp;

   /* get an optional parameter */
   cp = nextarg(((GEN_IO)pio)->inbuf);

   /* if no parameter was entered */
   if (!*cp)
   {
      if (NDEBUG)
      { NDEBUG &= UPCTRACE;
         ns_printf(pio,"IP stack debug tracing off\n");
      }
      else
      { NDEBUG |= INFOMSG|IPTRACE|PROTERR|TPTRACE;
         ns_printf(pio,"IP stack debug tracing on\n");
      }
   }
   else
   {
      /* '?' means display NDEBUG value, else set NDEBUG flag to parameter value */
      if (*cp != '?')
      {
#ifdef IN_MENUS
         NDEBUG = atoh(cp);
#endif
      }
      ns_printf(pio,"NDEBUG is now 0x%x\n",NDEBUG);
   }
#else
   ns_printf(pio,"not a DEBUG compile.\n");
#endif
   return 0;
}



/* FUNCTION: set_upc()
 *
 * toggle state of upcall variable
 *
 * PARAM1: void * pio
 *
 * RETURNS: 0
 */

int
set_upc(void * pio)
{
   if (NDEBUG & UPCTRACE)
      NDEBUG &= ~UPCTRACE;
   else
      NDEBUG |= UPCTRACE;

   ns_printf(pio,"Upcall debugging %sabled\n", 
    (NDEBUG&UPCTRACE)?"en":"dis");

   return 0;
}


/* FUNCTION: if_configbyname(NET ifp)
 *
 * Configure the passed net interface from a set of NV parameters with
 * same name. This allows the NV system to specify parameters for
 * dynamic interfaces, and also frees the NV file from having to
 * specifiy the nets in the order they come up.
 *
 *
 * PARAM1: NET to configure - should have ifp->name set up.
 *
 * RETURNS: Returns 0 if OK, -1 if name not found
 */

#ifdef   INCLUDE_NVPARMS   /* only if using NV parms */
int
if_configbyname(NET ifp)
{
   int   i;

   /* search the NV parameters "nets" array for for our name */
   for(i = 0; i < MAXNETS; i++)
   {
      if(strncmp(inet_nvparms.ifs[i].name, ifp->name, IF_NAMELEN - 1) == 0)
      {
         /* found a matching name, set our IP congif from NV entry */
         ifp->n_ipaddr = inet_nvparms.ifs[i].ipaddr;
         ifp->snmask = inet_nvparms.ifs[i].subnet;
         ifp->n_defgw = inet_nvparms.ifs[i].gateway;
         return 0;
      }
   }
   return -1;
}
#endif   /* INCLUDE_NVPARMS */

/* FUNCTION: if_netbytext()
 *
 * get a net pointer based on a user text string. The string may be a ones
 * based number index (eg "1", "2") or an iface name ("pp0"). Prints error
 * message to passed output device if text does not map to an interface.
 * 
 *
 * PARAM1: void * pio   - output stream for error reporting
 * PARAM2: char * iftext - text of interface.
 *
 * RETURNS: pointer to iface if OK, else NULL.
 */


NET
if_netbytext(void * pio, char * iftext)
{
   unsigned iface;
   NET      ifp;

   if((strlen(iftext) == 1) && (isdigit(*iftext)))
   {
      iface = (unsigned)(*iftext - '0') - 1;
      if((iface >= ifNumber) ||
         ((ifp = if_getbynum((int)iface)) == NULL))
      {
           ns_printf(pio,"interface number must be 1 to %d.\n", ifNumber);
           return NULL;
      }
      else
         return (ifp);
   }
   else     /* not a single digit, look up as name */
   {
      for(ifp = (NET)(netlist.q_head); ifp; ifp = ifp->n_next)
      {
         if(strcmp(iftext, ifp->name) == 0)
            return ifp;
      }
      if(!ifp)
           ns_printf(pio,"no interface named \"%s\".\n", iftext);
   }
   return NULL;
}


/* FUNCTION: iface_stats()
 * 
 * menu routine to get iface number and invoke stats
 *
 * PARAM1: void * pio - output stream
 *
 * RETURNS: 0
 */

int
iface_stats(void * pio)
{
//   char *   cp;
   struct net * ifp;

   ifp = (NET)(netlist.q_head);   /* default to first net */

#if 0  // We only support 1 interface
   cp = nextarg(((GEN_IO)pio)->inbuf);    /* get console arg */
   if(cp && *cp)     /* arg is present on command line */
   {
      ifp = if_netbytext(pio, cp);
      if(ifp == NULL)      /* error parsing iface name/number text? */
         return -1;
   }
#endif

   ifstats(pio, ifp);
   return 0;
}


//*****************************************************************************
// int SoftEthernetNegotiation( int seconds )   Written By Eric Gregori has
// been removed.
// Deprecated because a PHY register PHY_REG_ANAR next page bit is defaulted
// set when it should be cleared to disable next page mode.
// mcf5223x_ePHY_init() function now properly configures the ePHY
//*****************************************************************************


/* FUNCTION: ifstats()
 *
 * per-iface portion of iface_stats()
 *
 * PARAM1: void * pio   - output stream
 * PARAM2: int ifp      - interface to dump		//FSL changed "ifp" from "ifc"
 *
 * Overloaded function with autonegotiation configuration and soft negotiation
 *
 * RETURNS: 0
 */
extern char * prompt;
int
ifstats(void * pio, struct net * ifp)
{
	uint16 		reg0, reg4, settings;
	uint8		datarate, duplex, manual, autodone;
	char 		*cp;


	datarate = 0;
	duplex  = 0;
	manual   = 0;
	autodone = 0;
	
	/* get an optional parameter */
	cp = nextarg(((GEN_IO)pio)->inbuf);

	if( *cp )
	{
		// We have a parameter
		if( strstr(cp, "10") )
			datarate = 10;
		
		if( strstr(cp, "100") )
			datarate = 100;
		
		if( strstr(cp, "man") )
			manual = 'm';
		
		if( strstr(cp, "auto") )
			manual = 'a';
		
			if( strstr(cp, "half") )
			duplex = 'h';
		
			if( strstr(cp, "full") )
			duplex = 'f';			
	}
	
	
	if( datarate || duplex || manual )
	{
		ns_printf(pio,"\nSetting ePHY to:\n");
	
		(void)fec_mii_read(FEC_PHY0, PHY_REG_CR, &reg0);
		(void)fec_mii_read(FEC_PHY0, PHY_REG_ANAR, &reg4);
		if( datarate == 100 )
		{
			ns_printf(pio," - 100 Mbps\n");
			reg0 |= 0x2000;
		}
		else
		{
			reg0 &= ~0x2000;			
			ns_printf(pio," - 10 Mbps\n");
		}
		
		if( duplex == 'f' )
		{
			ns_printf(pio," - Full Duplex\n");
			reg0 |= 0x0100;	
		}
		else
		{
			reg0 &= ~0x0100;	
			ns_printf(pio," - Half Duplex\n");
		}
		
		if( manual == 'm' )
		{
			ns_printf(pio," - manual\n");
			reg0 &= ~0x1000;	
		}

		if( manual == 'a' )
		{
			ns_printf(pio," - auto\n");
			reg0 |= 0x1000;	
		}
		
		if( (datarate == 100) && (duplex == 'f') )
		{
			ns_printf(pio," - Advertise 100FD\n");		
			reg4 |= 0x0100;
		}
		else
		{
			ns_printf(pio," - do NOT Advertise 100FD\n");
			reg4 &= ~0x0100;
		}

		if( (datarate == 100) && (duplex == 'h') )
		{
			ns_printf(pio," - Advertise 100HD\n");		
			reg4 |= 0x0080;
		}
		else
		{
			ns_printf(pio," - do NOT Advertise 100HD\n");
			reg4 &= ~0x0080;
		}

		if( (datarate == 10) && (duplex == 'f') )
		{
			ns_printf(pio," - Advertise 10FD\n");		
			reg4 |= 0x0040;
		}
		else
		{
			ns_printf(pio," - do NOT Advertise 10FD\n");
			reg4 &= ~0x0040;
		}

		if( (datarate == 10) && (duplex == 'h') )
		{
			ns_printf(pio," - Advertise 10HD\n");		
			reg4 |= 0x0020;
		}
		else
		{
			ns_printf(pio," - do NOT Advertise 10HD\n");
			reg4 &= ~0x0020;
		}
		
		(void)fec_mii_write( FEC_PHY0, PHY_REG_ANAR, reg4 );
		(void)fec_mii_write( FEC_PHY0, PHY_REG_CR, reg0 );
		(void)fec_mii_write( FEC_PHY0, PHY_REG_CR, (reg0|0x0200) ); // Force re-negotiate 
		
		while (!(fec_mii_write(FEC_PHY0, PHY_REG_SR, PHY_R1_ANC))) //wait for it
		{uart_check();		
		};
		
		ns_printf(pio,"\n\n" );
	    printf(prompt);

		return 0;	
	}
	
	
   ns_printf(pio, "\nInterface %s - %s \n", 
      ifp->name, ifp->n_mib->ifDescr);
#ifdef IP_V4
   ns_printf(pio,"IPv4 address: %s, " , print_ipad(ifp->n_ipaddr));
   ns_printf(pio,"subnet mask: %s, ", print_ipad(ifp->snmask));
   ns_printf(pio,"gateway: %s\n"    , print_ipad(ifp->n_defgw));
#endif   /* IP_V4 */
#ifdef IP_V6
   if(ifp->n_flags & NF_IPV6)
   {
      int i;
      char ip6buf[46];     /* tmp buffer for ipv6 address text */

      for(i = 0; i < MAX_V6_ADDRS; i++)
      {
         if(ifp->v6addrs[i])
         {
            ns_printf(pio,"IPv6 %6s addr: %s", v6types[i], 
               print_ip6(&(ifp->v6addrs[i]->addr), ip6buf));
            ns_printf(pio," - %s\n", 
               ip6addrstates[ifp->v6addrs[i]->flags & IA_STATEMASK]);
         }
      }
   }
   else
      ns_printf(pio,"No IPv6 addresses\n");
#endif   /* IP_V6 */
   ns_printf(pio,"Status; Admin:%s Oper:%s for: %s\n", 
      ifp->n_mib->ifAdminStatus==1?"up":"down",
      ifp->n_mib->ifOperStatus==1?"up":"down",
      print_uptime(sysuptime() - (ifp->n_mib->ifLastChange)));
   ns_printf(pio,"rcvd: errors:%lu   dropped:%lu   station:%lu   bcast:%lu   bytes:%lu\n",
      ifp->n_mib->ifInErrors, ifp->n_mib->ifInDiscards,
      ifp->n_mib->ifInUcastPkts, ifp->n_mib->ifInNUcastPkts,
      ifp->n_mib->ifInOctets);
   ns_printf(pio,"sent: errors:%lu   dropped:%lu   station:%lu   bcast:%lu   bytes:%lu\n",
      ifp->n_mib->ifOutErrors, ifp->n_mib->ifOutDiscards,
      ifp->n_mib->ifOutUcastPkts, ifp->n_mib->ifOutNUcastPkts,
      ifp->n_mib->ifOutOctets);
   ns_printf(pio,"MAC address: ");
   hexdump(pio,ifp->n_mib->ifPhysAddress, 6);
   ns_printf(pio," \n");

#ifdef IP_MULTICAST
   /* Print any multicast addresses assign to this iface */
   if(ifp->mc_list)
   {
      struct in_multi * imp;

      ns_printf(pio, "   Multicast addresses: \n");
      for (imp = ifp->mc_list; imp; imp = imp->inm_next)
      {
#ifdef IP_V6
         if(imp->inm_addr == 0)  /* not v4 means it;s v6 */
         {
            char ip6buf[40];     /* tmp buffer for ipv6 address text */
            ns_printf(pio, "   %s\n", print_ip6(&(imp->ip6addr), ip6buf));
            continue;
         }
#endif   /* IP_V6 */
         ns_printf(pio, "   %s\n",  print_ipad(imp->inm_addr) );
      }
   }
#endif   /* IP_MULTICAST */

		ns_printf(pio, "-------------------------------------------\n");

#ifdef MCF5223x 
	ns_printf(pio, "EPHYCTL0 Register                    = %04x\n",MCF_EPHY_EPHYCTL0);
	if (!fec_mii_read(FEC_PHY0, 3, &settings))
		ns_printf(pio, "PHY Identifier 2 Register        =  Error  \n");
	else
		ns_printf(pio, "PHY Identifier 2 Register        = %04x\n",settings);
	if (!fec_mii_read(FEC_PHY0, 2, &settings))
		ns_printf(pio, "PHY Identifier 1 Register        =  Error  \n");
	else
		ns_printf(pio, "PHY Identifier 1 Register        = %04x\n",settings);
	if (!fec_mii_read(FEC_PHY0, 16, &settings))
		ns_printf(pio, "Interrupt Control Register      =  Error  \n");
	else
		ns_printf(pio, "Interrupt Control Register (16) = %04x\n",settings);
	if (!fec_mii_read(FEC_PHY0, 17, &settings))
		ns_printf(pio, "Proprietary Status Register      =  Error  \n");
	else
		ns_printf(pio, "Proprietary Status Register (17) = %04x\n",settings);
	if (!fec_mii_read(FEC_PHY0, 18, &settings))
		ns_printf(pio, "Proprietary Control Register     =  Error  \n");
	else
		ns_printf(pio, "Proprietary Control Register(18) = %04x\n",settings);
	if (!fec_mii_read(FEC_PHY0, 20, &settings))
		ns_printf(pio, "Register 20                      =  Error  ");
	else
		ns_printf(pio, "Register 20                      = %04x\n",settings);
#endif	
	
	
	if (!fec_mii_read(FEC_PHY0, PHY_REG_CR, &settings))
    	ns_printf(pio, "\nControl Register                 =  Error  \n");
    else
    {
		ns_printf(pio, "\nControl Register                 = %04x\n",settings);
		if( settings & 0x1000 )
			ns_printf( pio, "\tANE = Autonegotiation Enabled\n" );
		else
		{
			ns_printf( pio, "\tANE = Autonegotiation Disabled\n" );
			
			if( settings & 0x2000 )
				ns_printf( pio,"\tDATARATE = 100Mbps\n");
			else
				ns_printf( pio,"\tDATARATE = 10Mbps\n");
			if( settings & 0x0100 )
				ns_printf( pio,"\tDPLX = Full Duplex\n");
			else
				ns_printf( pio,"\tDPLX = Half Duplex\n");
		}
    }
	if (!fec_mii_read(FEC_PHY0, 4, &settings))
		ns_printf(pio, "\nAuto-Neg. Advertisement Register =  Error  \n");
	else
	{
		ns_printf(pio, "\nAuto-Neg. Advertisement Register(4)= %04x\n",settings);
		if( settings & 0x8000 )
			ns_printf( pio, "\tCapable of Sending Next Pages\n");
		else
			ns_printf( pio, "\tNot Capable of Sending Next Pages\n");
		if( settings & 0x0100 )
			ns_printf( pio, "\t100BASE-TX full-duplex capable\n");
		else
			ns_printf( pio, "\tNot 100BASE-TX full-duplex capable\n");
		if( settings & 0x0080 )
			ns_printf( pio, "\t100BASE-TX half-duplex capable\n");
		else
			ns_printf( pio, "\tNot 100BASE-TX half-duplex capable\n");
		if( settings & 0x0040 )
			ns_printf( pio, "\t10BASE-T full-duplex capable\n");
		else
			ns_printf( pio, "\tNot 10BASE-T full-duplex capable\n");
		if( settings & 0x0020 )
			ns_printf( pio, "\t10BASE-T half-duplex capable\n");
		else
			ns_printf( pio, "\tNot 10BASE-T half-duplex capable\n");
	}
	
if (!fec_mii_read(FEC_PHY0, PHY_REG_SR, &settings))
    	ns_printf(pio, "\nStatus Register                  =  Error  \n");
    else
    {
		ns_printf(pio, "\nStatus Register                  = %04x\n",settings);
		if( settings & 0x0010 )
			ns_printf( pio, "\tRemote fault condition has been detected\n");
		else
			ns_printf( pio, "\tNo fault Signaled\n");
		
		if( settings & 0x0004 )
			ns_printf( pio, "\tValid link has been established\n");
		else
			ns_printf( pio, "\tValid link has NOT been established\n");
		
		if( settings & 0x0020 )
		{
			ns_printf( pio, "\tAuto-Neg complete - Data is Valid\n");
			autodone = 1;
		}
		else
			ns_printf( pio, "\tAuto-Neg NOT complete - Data is NOT Valid\n");
    }
	
//	if( autodone )
	if( 1 )
    {
    	if (!fec_mii_read(FEC_PHY0, 5, &settings))
    		ns_printf(pio, "\nLink Partner Base Page           =  Error  \n");
    	else
    	{
			ns_printf(pio, "\nLink Partner Base Page Register (5)= %04x\n",settings);
			if( settings & 0x8000 )
				ns_printf( pio, "\tLink partner is next page capable\n");
			else
				ns_printf( pio, "\tLink partner is not next page capable\n");
			if( settings & 0x4000 )
				ns_printf( pio, "\tLink partner has code word\n");
			else
				ns_printf( pio, "\tLink partner does not have code word\n");
			if( settings & 0x2000 )
				ns_printf( pio, "\tLink partner signaling Fault\n");
			else
				ns_printf( pio, "\tLink partner is not signaling fault\n");




			if( settings & 0x0200 )
				ns_printf( pio, "\tLink partner is 100BASE-T4 capable\n");
			else
				ns_printf( pio, "\tLink partner is not 100BASE-T4 capable\n");
			if( settings & 0x0100 )
				ns_printf( pio, "\tLink partner is 100BASE-TX full-duplex capable\n");
			else
				ns_printf( pio, "\tLink partner is not 100BASE-TX full-duplex capable\n");
			if( settings & 0x0080 )
				ns_printf( pio, "\tLink partner is 100BASE-TX half-duplex capable\n");
			else
				ns_printf( pio, "\tLink partner is not 100BASE-TX half-duplex capable\n");
			if( settings & 0x0040 )
				ns_printf( pio, "\tLink partner is 10BASE-T full-duplex capable\n");
			else
				ns_printf( pio, "\tLink partner is not 10BASE-T full-duplex capable\n");
			
			if( settings & 0x0020 )
				ns_printf( pio, "\tLink partner is 10BASE-T half-duplex capable\n");
			else
				ns_printf( pio, "\tLink partner is not 10BASE-T half-duplex capable\n");
		}
    
    	if (!fec_mii_read(FEC_PHY0, 6, &settings))
    		ns_printf(pio, "Auto-Neg. Expansion Register     =  Error  \n");
    	else
    	{
			ns_printf(pio, "Auto-Neg. Expansion Register (6) = %04x\n",settings);
			if( settings & 0x8000 )
				ns_printf( pio, "\tAdditional Next Pages will follow.\n");
			else
				ns_printf( pio, "\tLast Page transmitted\n");
			if( settings & 0x4000 )
				ns_printf( pio, "\tLink Partner has received Link Code Word\n");
			else
				ns_printf( pio, "\tLink Partner has not received Link Code Word\n");
			if( settings & 0x2000 )
				ns_printf( pio, "\tWill comply with message.\n");
			else
				ns_printf( pio, "\tCannot comply with message.\n");
			if( settings & 0x1000 )
				ns_printf( pio, "\tCode Word equalled logic zero\n");
			else
				ns_printf( pio, "\tLink Code Word equalled logic one\n");
    	}

    	if (!fec_mii_read(FEC_PHY0, 7, &settings))
    		ns_printf(pio, "Auto-Neg. Next Page Transmit     =  Error  \n");
    	else
    	{
			ns_printf(pio, "Auto-Neg. Next Page Transmit (7) = %04x\n",settings);
			if( settings & 0x0010 )
				ns_printf( pio, "\tParallel detection fault\n");
			else
				ns_printf( pio, "\tNo parallel detection fault\n");
			if( settings & 0x0008 )
				ns_printf( pio, "\tLink partner is next page able.\n");
			else
				ns_printf( pio, "\tLink partner is not next page able.\n");
			if( settings & 0x0002 )
				ns_printf( pio, "\t3 ident and consecutive code words received\n");
			else
				ns_printf( pio, "\t3 ident and consecutive code words not received\n");
			if( settings & 0x0001 )
				ns_printf( pio, "\tLink Partner is A/N able.\n");
			else
				ns_printf( pio, "\tLink Partner is not A/N able.\n");
    	}

    }
    
    ns_printf(pio, "\n\n" );
	return 0;
}





/* FUNCTION: linkstats()
 * 
 * printf stats for link interface. default to iface 1
 *
 * PARAM1: void * pio   - output stream
 *
 * RETURNS: 0 if OK, else -1 if arg is bad.
 */

int
linkstats(void * pio)
{
   int      iface =  1;
   char *   cp;

   cp = nextarg(((GEN_IO)pio)->inbuf);

   if (*cp)
   {
      iface = atoi(cp);
      if (iface < 1 || iface > (int)ifNumber)
      {
         ns_printf(pio,"interface number must be 1 to %d.\n", ifNumber);
         return -1;
      }
   }
   iface--;

   if (nets[iface]->n_stats)
      nets[iface]->n_stats(pio,iface);  /* actually call the stats */
   else									//FSL n_stats points to fec_stats()
      ns_printf(pio,"no stats routine for interface %d\n", iface+1);
   return 0;
}


/* FUNCTION: settrapsize()
 *
 * settrapsize() - This sets a value which will cause the memory 
 * managment monitoring code to trap to a debugger if a malloc is 
 * attempted for this size. This is usefull when a memory leak is 
 * occuring of memory buffers on an unusual size, as often happens 
 * with networking code. It has nothing to do with SNMP traps. 
 * Returns no meaningfull value; declared as int to make compiler 
 * happy. 
 *
 * 
 * PARAM1: void * pio   - output stream
 *
 * RETURNS: 0
 */

extern   int   memtrapsize;   /* in memman.c or user heap code */

int
settrapsize(void * pio) 
{
   char *   cp;

   cp = nextarg(((GEN_IO)pio)->inbuf);

   memtrapsize = atoi(cp);
   ns_printf(pio,"malloc trap size set to %d\n", memtrapsize);
   return 0;
}


//*****************************************************************************
// int   set_baud(void * pio)   Written By Eric Gregori
//						        
//
// User command to set baud rate for serial port.
//
//*****************************************************************************
int   set_baud(void * pio)
{
   	char 	*cp;


   	cp = nextarg(((GEN_IO)pio)->inbuf);
   	
   	if( *cp )
		iuart_set_baud( 0, atoi(cp) );	
	
	return(0);
}

//*****************************************************************************
// int   set_Loopback(void * pio)   
//
// User command to set loopack for testing.
//
//*****************************************************************************
int   set_loopback(void * pio)		//FSL TBD
{
   	char 	*cp;


   	cp = nextarg(((GEN_IO)pio)->inbuf);
   	
   	if( *cp )
		iuart_set_baud( 0, atoi(cp) );	
	
	return(0);
}



