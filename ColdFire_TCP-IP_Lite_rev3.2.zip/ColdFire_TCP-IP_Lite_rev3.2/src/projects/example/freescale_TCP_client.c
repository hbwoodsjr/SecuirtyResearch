//*****************************************************************************
// Copyright (c) 2006, Freescale Semiconductor
// For use on Freescale products only.
//
// File name :   	emg_http_server.c
// Project name: 	emg_HTTP web server for ColdFire
// Author:			Eric Gregori
//		   			
//
// Description : 	HTTP/Web server with static anf dynamic FFS support.
//					Dynamic HTML is supported via tokens in the HTML.
//					A key is used to support run time ( dynamic ) web page uploads.
//					Without the correct key, the download is rejected.
//					The web server supports multiple sessions as defined by EMG_HTTP_SESSION.
//					The web server supports 'GET', 'POST','EMG'.
//					EMG is a unique non-standard HTTP command to request a upload.
//					Uploading is done using the same server that serves up the web pages.
//					Long filenames are supported, along with subdirectories.
//
//*****************************************************************************
#include "ipport.h"
#include "tcpapp.h"
#include "msring.h"
#include "menu.h"
#include OSPORT_H

				 // comm port, data
extern int uart_putc(int unit, unsigned char ch);

extern	void freescale_http_process( int i );
extern	int  freescale_http_connection( M_SOCK so );
extern	void freescale_http_delete( void );
extern	void freescale_http_remove( M_SOCK so );
extern 	struct menu_op emg_ffs_dir_menu[];
extern 	TK_OBJECT(to_keyboard);

#define 		PORT_NUMBER			5678
#define 		RX_BUFFER_SIZE		256
#define			TEST_BUFFER			250		// *4 = 1000 bytes
#define			INTER_PACKET_DELAY	1
#define			SERVER_IP			0xC0A80009	//0xC0A80009 = 192.168.0.9

//*****************************************************************************
// Global vars
//*****************************************************************************
int 				semaphore;
int					flash_ffs_lockout;	//FSL 0=dynamic flash file system present, 1=not present


//*****************************************************************************
// Declare Task Object
//*****************************************************************************
TK_OBJECT(to_emgtcpsrv);
TK_ENTRY(tk_emgtcpsrv);
struct inet_taskinfo emg_tcp_task = {
      									&to_emgtcpsrv,
      									"TCP server",
      									tk_emgtcpsrv,
      									NET_PRIORITY,
      									0x400
									};


//*****************************************************************************
// Declare a Socket structure and communications queue "msring"
//*****************************************************************************
struct sockaddr_in   		emg_tcp_sin;
M_SOCK	 					emg_tcp_server_socket = INVALID_SOCKET;
static struct msring 		emg_tcp_msring;
static M_SOCK 				emg_tcp_msring_buf[10];
M_SOCK						emg_tcp_communication_socket = INVALID_SOCKET;


#if 1
//*****************************************************************************
// emg_tcp_rx()
//
// Use the m_recv() function to RX packets from ethernet.
// Send the data out the serial port.
//*****************************************************************************
void emg_tcp_rx( void )
{
	int		length, i;
	uint8	buffer[RX_BUFFER_SIZE+1];
	
	// PARAM1: M_SOCK socket,
	// PARAM2: char * buffer
	// PARAM3: unsigned length
	//
	// RETURNS: number of bytes actually read, or -1 if error. 
	// int m_recv(M_SOCK so, char * buf, unsigned buflen)
	length = m_recv( emg_tcp_communication_socket, (char *)buffer, RX_BUFFER_SIZE );

	for( i=0; length>0; length-- )
		uart_putc(0, buffer[i]);  // 0 = Comm port 0
}
#endif

//*****************************************************************************
// emg_tcp_tx()
//
// Take data from the UART RX buffer and send it out over
// Ethernet using the m_send() function.
//*****************************************************************************
#define SEC2PRINT	10
extern int tcp_bsdsendstat(void *);
uint32 BytesSentTCP	= 0;
void emg_tcp_tx( void )
{
	PACKET			pkt;
	unsigned int	emg;
	static unsigned short  adc0_pot=1400;
	static unsigned int	count2print=0, ctick_counter=0;

	tk_sleep(1);						//FSL sometimes need delay to slow transmission when using WireShark
	
    pkt = tcp_pktalloc(TCP_MSS);		//FSL alloc a big or little buf
    if( !pkt )							//FSL if buf not available, sleep and return later to try again
    {
		tk_sleep(2);	
    	return;
    }
	//FSL pkt assigned to big or little buf sucessfully
	
	// Set length section of packet to (int)(temp-buff) //FSL temp is end memory address of payload, buff is the start mem address of payload.
#if 1							//FSL use constant packet size
	pkt->m_len = TCP_MSS;		//FSL was 1450
#else							//FSL use variable packet size
#ifdef M52233DEMO
	adc0_pot = ((MCF_ADC_ADRSLT0&0x7FF8)>>3);	//FSL read M52233DEMO potentiometer on ADC channel 0
	adc0_pot = (adc0_pot*TCP_MSS)/4095;			//FSL scale result
	if(adc0_pot > pkt->m_len) adc0_pot = TCP_MSS;
	pkt->m_len = (adc0_pot); 	//FSL write size to packet
#endif	
#endif

#if 1
	for(emg=0;emg<pkt->m_len;emg++)
	{
		*pkt->m_data++ = (char)(0xff & emg);		//FSL fill the packet with modulo byte data
	}
#endif

	// Send data
	emg = tcp_send(emg_tcp_communication_socket, pkt);   /* pass packet to tcp layer */
	
	// If tcp_send returns an error,  we need to release the packet.
	if( emg )	//FSL error happened
	{
		tcp_pktfree( pkt );			//FSL free the big or little buffer
		tk_sleep(1);				//FSL recovery time...
		tcp_bsdsendstat(NULL);		//FSL print statistics
		tk_sleep(1);				//FSL recovery time...
	}
	else		//FSL no error...print statistics
	{
#if 0									//FSL no printf	if 0, printf if 1
		BytesSentTCP += pkt->m_len;		//FSL Bytes Sent over TCP counter
		count2print += pkt->m_len;		//FSL increment counter
#if 0		
		if(count2print > (1000*pkt->m_len))
		{
			printf("\nBytes Sent %9d MegaBytes\n", BytesSentTCP/(1024*1024));
			tcp_bsdsendstat(NULL);
			count2print=0;				//FSL reset counter
		}
#else
		if(cticks > ctick_counter)
		{
			printf("\nKiloBytes Sent per second %9d\n", BytesSentTCP/(1024)/SEC2PRINT);
			ctick_counter=cticks+(TPS*SEC2PRINT);	//FSL reset counter and add number of seconds to wait
			BytesSentTCP = 0;						//FSL reset Byte counter to zero
		}		
#endif		
#endif
	}

//	tk_sleep(1);				//FSL coarse setting: sometimes need delay to slow transmission when using WireShark
#if 0
	for(emg=0;emg<512;emg++)
	{
		tk_yield();				//FSL fine setting:   sometimes need delay to slow transmission when using WireShark
	}
#endif
}


//*****************************************************************************
// emg_tcp_loop() -  Written By Eric Gregori
//		   			 
//
// Run application
//
//*****************************************************************************
int freescale_tcp_loop()
{
	int			i;
		
	emg_tcp_tx();

   	return SUCCESS;
}


//*****************************************************************************
// emg_http_cmdcb() - Written by Eric Gregori
//		   			  
//
// This is the mini-sockets callback function.
// We only uses to detect a connection to the socket.
// When a connection is made, this function is called by the stack.
// The connection message is sent to the application through a 
// msring queue.
//*****************************************************************************
int freescale_tcp_cmdcb(int code, M_SOCK so, void * data)
{
	int e = 0;

	switch(code)
	{
		// socket open complete
		case M_OPENOK:
			msring_add(&emg_tcp_msring, so);
			break;
      
		// socket has closed      
   		case M_CLOSED:  
   			while( semaphore ){};
   			semaphore = 1;
			emg_tcp_communication_socket = INVALID_SOCKET;  	
			semaphore = 0;
     		break;								// let stale conn timer catch these 
      
		// passing received data
		// blocked transmit now ready
		case M_RXDATA:          				// received data packet, let recv() handle it 
		case M_TXDATA:          				// ready to send more, loop will do it
			e = -1;        						// return nonzero code to indicate we don't want it 
			break;
      
   		default:
      		dtrap();             				// not a legal case
      		return 0;
   }

   TK_WAKE(&to_emgtcpsrv);    					// wake server task	if sleeping

   USE_VOID(data);
   return e;
}


//*****************************************************************************
// emg_tcp_init() - written by Eric Gregori
//		   			 
//
// Create and bind a socket to our listening port ( PORT_NUMBER ).
// Set the socket to listen and non-blocking.
//*****************************************************************************
int freescale_tcp_init()
{
	int e;
	
	
	semaphore 						= 0;
	flash_ffs_lockout 				= 0;		//FSL 0=dynamic flash file system present, 1=not present
	emg_tcp_communication_socket 	= INVALID_SOCKET;
	
	// Init message queue for MINI_TCP socket interface
    msring_init(&emg_tcp_msring, emg_tcp_msring_buf, sizeof(emg_tcp_msring_buf) / sizeof(emg_tcp_msring_buf[0]));

	// Init a socket structure with our Port Number
	emg_tcp_sin.sin_addr.s_addr 	= (SERVER_IP);
	emg_tcp_sin.sin_port        	= (PORT_NUMBER);

	emg_tcp_communication_socket	= m_socket();	//FSL allocate socket from heap and place in socket queue

	printf( "\nConnecting to target -> %u.%u.%u.%u:%u",PUSH_IPADDR(emg_tcp_sin.sin_addr.s_addr),PORT_NUMBER);
	 
	// Socket is blocking.  The m_connect call will block
	// until it connects.
    e = m_connect(emg_tcp_communication_socket, &emg_tcp_sin, freescale_tcp_cmdcb );
    if( e > 0 )
    {
    	if( e == ECONNREFUSED )
    		printf( " - Could Not Find Target, retry..." );
    	else 
    		printf(" - error %d starting listen on TCP server\n", e);
    	
   		emg_tcp_server_socket = INVALID_SOCKET;		//FSL reset socket to invalid state
   		m_close(emg_tcp_communication_socket);		//FSL close the socket
   		return FAILURE;
    }

	emg_tcp_server_socket = emg_tcp_communication_socket;

	printf( " - Connected" );


   	return SUCCESS ;
}


//*****************************************************************************
// emg_http_cleanup() - Written by Eric Gregori
//		   			    
//
// Delete all sessions.
//*****************************************************************************
void freescale_http_cleanup()
{
}


//*****************************************************************************
// emg_tcp_check() -  Written by Eric Gregori
//		   			  
//
// Check msring for message from socket callback function.
// If we received a connect request, call the connection function.
// While we are waiting for a connection to complete, we need to
// continue running our loop.
// Make the socket non-blocking.
//
// Call the loop function to execute any pending sessions.
//*****************************************************************************
void freescale_tcp_check(void)
{
	M_SOCK 		so;


	if ( emg_tcp_server_socket == INVALID_SOCKET )
    	return ;
	
	if( emg_tcp_communication_socket != INVALID_SOCKET )
		freescale_tcp_loop();
	
}


//*****************************************************************************
// The application thread works on a "controlled polling" basis: 
// it wakes up periodically and polls for work.
//
// The task could aternativly be set up to use blocking sockets,
// in which case the loops below would only call the "xxx_check()"
// routines - suspending would be handled by the TCP code.
//
//
// FUNCTION: tk_emg_tcp_srv
// 
// PARAM1: n/a
//
// RETURNS: n/a
//
//*****************************************************************************
TK_ENTRY(tk_emgtcpsrv)
{
   int err;
   int retry=1;

   while (!iniche_net_ready)
      TK_SLEEP(1);

	do
	{
	   err = freescale_tcp_init();
	   if( err == SUCCESS )
	   {
	      exit_hook(freescale_tcp_cleanup);
	      retry = 0;	//FSL cancel retry
	      break;		//FSL exit while loop
	   }
       tk_sleep(100);	//FSL sleep a bit
	} while (retry++ < 10);

	if(retry)
      dprintf("retry error....connection failed\n");
	
   for (;;)
   {
      freescale_tcp_check();         	// will block on select
      tk_yield();          				// give up CPU in case it didn't block

      if (net_system_exit)
         break;
   }
   TK_RETURN_OK();
}


//*****************************************************************************
// create_freescale_task() - Written by Eric Gregori
//		   			  		 
//
// Insert the FreeScale task into the RTOS.
//*****************************************************************************
void create_freescale_task( void )
{
	int e = 0;

   	e = TK_NEWTASK(&emg_tcp_task);
   	if (e != 0)
   	{
      dprintf("freescale task create error\n");
      panic("create_apptasks");
   	}   	
}

