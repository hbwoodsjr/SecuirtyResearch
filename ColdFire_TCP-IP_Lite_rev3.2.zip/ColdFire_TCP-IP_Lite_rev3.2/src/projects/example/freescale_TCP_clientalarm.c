//*****************************************************************************
// Copyright (c) 2006, Freescale Semiconductor
// For use on Freescale products only.
//
// File name :   	emg_http_server.c
// Project name: 	emg_HTTP web server for Coldfire
// Author:			Eric Gregori 
//		   			
//
// Description : 	HTTP/Web server with static anf dynamic FFS support.
//					Dynamic HTML is supported via tokens in the HTML.
//					A key is used to support run time ( dynamic ) web page uploads.
//					Without the correct key, the download is rejected.
//					The web server supports multiple sessions as defined by EMG_HTTP_SESSION.
//					The web server supports 'GET', 'POST','EMG'.
//					EMG is a unique non-standard HTTP command to request a upload.
//					Uploading is done using the same server that serves up the web pages.
//					Long filenames are supported, along with subdirectories.
//
//*****************************************************************************
#include "ipport.h"
#include "tcpapp.h"
#include "msring.h"
#include "menu.h"
#include OSPORT_H

				 // comm port, data
extern int uart_putc(int unit, unsigned char ch);

extern	void freescale_http_process( int i );
extern	int  freescale_http_connection( M_SOCK so );
extern	void freescale_http_delete( void );
extern	void freescale_http_remove( M_SOCK so );
extern 	struct menu_op emg_ffs_dir_menu[];
extern 	TK_OBJECT(to_keyboard);


#define 		PORT_NUMBER			1234
#define 		RX_BUFFER_SIZE		256
#define			TEST_BUFFER			10		// *4 = 1000 bytes
#define			INTER_PACKET_DELAY	1
#define			SERVER_IP			0xC0A80101 // 0xC0A80101 = 192.168.1.1

//*****************************************************************************
// Global vars
//*****************************************************************************
int 				semaphore;
int					flash_ffs_lockout;	//FSL 0=dynamic flash file system present, 1=not present
unsigned char		analog_data;
unsigned char 		data[TEST_BUFFER];


//*****************************************************************************
// Declare Task Object
//*****************************************************************************
TK_OBJECT(to_emgtcpsrv);
TK_ENTRY(tk_emgtcpsrv);
struct inet_taskinfo emg_tcp_task = {
      									&to_emgtcpsrv,
      									"TCP server",
      									tk_emgtcpsrv,
      									NET_PRIORITY,
      									0x800
									};


//*****************************************************************************
// Declare a Socket structure and communications queue "msring"
//*****************************************************************************
struct sockaddr_in   		emg_tcp_sin;
M_SOCK	 					emg_tcp_server_socket = INVALID_SOCKET;
static struct msring 		emg_tcp_msring;
static M_SOCK 				emg_tcp_msring_buf[10];
M_SOCK						emg_tcp_communication_socket = INVALID_SOCKET;


//*****************************************************************************
// emg_tcp_rx()
//
// Use the m_recv() function to RX packets from ethernet.
// Send the data out the serial port.
//*****************************************************************************
void emg_tcp_rx( void )
{
	int		length, i;
	
	// PARAM1: M_SOCK socket,
	// PARAM2: char * buffer
	// PARAM3: unsigned length
	//
	// RETURNS: number of bytes actually read, or -1 if error. 
	// int m_recv(M_SOCK so, char * buf, unsigned buflen)
	length = m_recv( emg_tcp_communication_socket, (char *)data, RX_BUFFER_SIZE );

	if( length > 0 )
	{
		if( data[0] == '<' )
		{
			if( (data[1] == 'S') && (data[2] == 'W') )
			{
				if( data[3] == '1' )
						LED2_TOGGLE;					
				
				if( data[3] == '2' )
						LED3_TOGGLE;					
			}
		}
	}
	
	for( i=0; length>0; length-- )
		uart_putc(0, data[i]);  // 0 = Comm port 0
}


//*****************************************************************************
// emg_tcp_tx()
//
// Take data from the UART RX buffer and send it out over
// ethernet using the m_send() function.
//*****************************************************************************
void emg_tcp_tx( void )
{
	int		len, send;

	send = 0;
	len = read_AD(0)/32;	
	if( len != analog_data )
	{
		analog_data = len;
		data[0] = '>';
		data[1] = 'P';
		data[2]	= len;	
		send = 1;
	}
		
	if( poll_switches() == 1 )
	{
		// SW1
		data[0] = '>';
		data[1] = 'S';
		data[2] = 'W';
		data[3] = '1';
		len = 4;
		send = 1;
	}

	if( poll_switches() == 8 )
	{		
		// SW2
		data[0] = '>';
		data[1] = 'S';
		data[2] = 'W';
		data[3] = '2';
		len = 4;
		send = 1;
	}
		
	if( send )
	{
		(void)m_send( emg_tcp_communication_socket, (char *)data, len );
		printf( "\nsent %d", len );
	}
}


//*****************************************************************************
// emg_tcp_loop() -  Written By Eric Gregori
//		   			 
//
// Run application
//
//*****************************************************************************
int freescale_tcp_loop()
{
	int			i;
	
	
	emg_tcp_tx();
	emg_tcp_rx();
	tk_sleep( INTER_PACKET_DELAY );	
   	return SUCCESS;
}


//*****************************************************************************
// emg_http_cmdcb() - Written by Eric Gregori
//		   			  
//
// This is the mini-sockets callback function.
// We only uses to detect a connection to the socket.
// When a connection is made, this function is called by the stack.
// The connection message is sent to the application through a 
// msring queue.
//*****************************************************************************
int freescale_tcp_cmdcb(int code, M_SOCK so, void * data)
{
	int e = 0;

	switch(code)
	{
		// socket open complete
		case M_OPENOK:
			msring_add(&emg_tcp_msring, so);
			break;
      
		// socket has closed      
   		case M_CLOSED:  
   			while( semaphore ){};
   			semaphore = 1;
			emg_tcp_communication_socket = INVALID_SOCKET;  	
			semaphore = 0;
     		break;								// let stale conn timer catch these 
      
		// passing received data
		// blocked transmit now ready
		case M_RXDATA:          				// received data packet, let recv() handle it 
		case M_TXDATA:          				// ready to send more, loop will do it
			e = -1;        						// return nonzero code to indicate we don't want it 
			break;
      
   		default:
      		dtrap();             				// not a legal case
      		return 0;
   }

   TK_WAKE(&to_emgtcpsrv);    					// wake server task

   USE_VOID(data);
   return e;
}


//*****************************************************************************
// emg_tcp_init() - written by Eric Gregori
//		   			 
//
// Create and bind a socket to our listening port ( PORT_NUMBER ).
// Set the socket to listen and non-blocking.
//*****************************************************************************
int freescale_tcp_init()
{
	int e, i;
	
	
	semaphore 						= 0;
	flash_ffs_lockout 				= 0;	//FSL 0=dynamic flash file system present, 1=not present
	emg_tcp_communication_socket 	= INVALID_SOCKET;
	
	// Init message queue for MINI_TCP socket interface
    msring_init(&emg_tcp_msring, emg_tcp_msring_buf, sizeof(emg_tcp_msring_buf) / sizeof(emg_tcp_msring_buf[0]));

	printf( "\nConnecting to target" );

	i = 0;
	if( poll_switches() & 1 )
	{
		// SW1
		i++;
	}

	if( poll_switches() & 8 )
	{		
		// SW2
		i += 2;
	}


		emg_tcp_communication_socket	= m_socket();

		// Init a socket structure with server Port Number
		emg_tcp_sin.sin_addr.s_addr 	= (SERVER_IP);
		emg_tcp_sin.sin_port        	= (PORT_NUMBER)+i;

		// Socket is blocking.  The m_connect call will block
		// until it connects.
    	e = m_connect(emg_tcp_communication_socket, &emg_tcp_sin, freescale_tcp_cmdcb );
    	if( e > 0 )
    	{
    		if( e == ECONNREFUSED )
    			printf( " - Cold Not Find Target, reset" );
    		else
    			printf(" - error %d starting listen on TCP server\n", e);
    		
    		m_close( emg_tcp_communication_socket );
    	
    			while(1)
    				tk_sleep(100);
    	}

    m_ioctl(emg_tcp_communication_socket, SO_NONBLOCK, NULL);   /* make socket non-blocking */

	emg_tcp_server_socket = emg_tcp_communication_socket;

	printf( " - Connected" );

   	return SUCCESS ;
}


//*****************************************************************************
// emg_http_cleanup() - Written by Eric Gregori
//		   			    
//
// Delete all sessions.
//*****************************************************************************
void freescale_http_cleanup()
{
}


//*****************************************************************************
// emg_tcp_check() -  Written by Eric Gregori
//		   			  
//
// Check msring for message from socket callback function.
// If we received a connect request, call the connection function.
// While we are waiting for a connection to complete, we need to
// continue running our loop.
// Make the socket non-blocking.
//
// Call the loop function to execute any pending sessions.
//*****************************************************************************
void freescale_tcp_check(void)
{
	M_SOCK 		so;


	if ( emg_tcp_server_socket == INVALID_SOCKET )
    	return ;
	
	if( emg_tcp_communication_socket != INVALID_SOCKET )
		freescale_tcp_loop();
}


//*****************************************************************************
// The application thread works on a "controlled polling" basis: 
// it wakes up periodically and polls for work.
//
// The task could aternativly be set up to use blocking sockets,
// in which case the loops below would only call the "xxx_check()"
// routines - suspending would be handled by the TCP code.
//
//
// FUNCTION: tk_emg_tcp_srv
// 
// PARAM1: n/a
//
// RETURNS: n/a
//
//*****************************************************************************
TK_ENTRY(tk_emgtcpsrv)
{
   int err;

   while (!iniche_net_ready)
      TK_SLEEP(1);

   err = freescale_tcp_init();
   if( err == SUCCESS )
   {
      exit_hook(freescale_tcp_cleanup);
   }
   else
   {
      dtrap();    						// emghttp_init()  shouldn't ever fail
   }

   for (;;)
   {
      freescale_tcp_check();         	// will block on select
      tk_yield();          				// give up CPU in case it didn't block

      if (net_system_exit)
         break;
   }
   TK_RETURN_OK();
}


//*****************************************************************************
// create_freescale_task() - Written by Eric Gregori
//		   			  		 
//
// Insert the FreeScale task into the RTOS.
//*****************************************************************************
void create_freescale_task( void )
{
	int e = 0;

   	e = TK_NEWTASK(&emg_tcp_task);
   	if (e != 0)
   	{
      dprintf("freescale task create error\n");
      panic("create_apptasks");
   	}   	
}

