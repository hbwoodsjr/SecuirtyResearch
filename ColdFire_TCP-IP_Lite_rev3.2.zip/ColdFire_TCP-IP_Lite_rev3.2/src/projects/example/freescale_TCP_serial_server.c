//*****************************************************************************
// Copyright (c) 2006, Freescale Semiconductor
// For use on Freescale products only.
//
// File name :   	emg_http_server.c
// Project name: 	emg_HTTP web server for Coldfire
// Author:			Eric Gregori
//		   			
//
// Description : 	HTTP/Web server with static anf dynamic FFS support.
//					Dynamic HTML is supported via tokens in the HTML.
//					A key is used to support run time ( dynamic ) web page uploads.
//					Without the correct key, the download is rejected.
//					The web server supports multiple sessions as defined by EMG_HTTP_SESSION.
//					The web server supports 'GET', 'POST','EMG'.
//					EMG is a unique non-standard HTTP command to request a upload.
//					Uploading is done using the same server that serves up the web pages.
//					Long filenames are supported, along with subdirectories.
//
//*****************************************************************************
#include "ipport.h"
#include "tcpapp.h"
#include "msring.h"
#include "menu.h"
#include OSPORT_H

				 // comm port, data
extern int uart_putc(int unit, unsigned char ch);

extern	void freescale_http_process( int i );
extern	int  freescale_http_connection( M_SOCK so );
extern	void freescale_http_delete( void );
extern	void freescale_http_remove( M_SOCK so );
extern 	struct menu_op emg_ffs_dir_menu[];
extern 	TK_OBJECT(to_keyboard);

#define PORT_NUMBER		1234
#define RX_BUFFER_SIZE	256

//*****************************************************************************
// Global vars
//*****************************************************************************
int 				semaphore;
int					flash_ffs_lockout;	//FSL 0=dynamic flash file system present, 1=not present

//*****************************************************************************
// Declare Task Object
//*****************************************************************************
TK_OBJECT(to_emgtcpsrv);
TK_ENTRY(tk_emgtcpsrv);
struct inet_taskinfo emg_tcp_task = {
      									&to_emgtcpsrv,
      									"EMG TCP server",
      									tk_emgtcpsrv,
      									NET_PRIORITY,
      									0x800
									};


//*****************************************************************************
// Declare a Socket structure and communications queue "msring"
//*****************************************************************************
struct sockaddr_in   		emg_tcp_sin;
M_SOCK	 					emg_tcp_server_socket = INVALID_SOCKET;
static struct msring 		emg_tcp_msring;
static M_SOCK 				emg_tcp_msring_buf[10];
M_SOCK						emg_tcp_communication_socket = INVALID_SOCKET;
unsigned char 				buffer[RX_BUFFER_SIZE];		

//*****************************************************************************
// emg_tcp_rx()
//
// Use the m_recv() function to RX packets from ethernet.
// Send the data out the serial port.
//*****************************************************************************
void emg_tcp_rx( void )
{
	int		length, i;
	
	// PARAM1: M_SOCK socket,
	// PARAM2: char * buffer
	// PARAM3: unsigned length
	//
	// RETURNS: number of bytes actually read, or -1 if error. 
	// int m_recv(M_SOCK so, char * buf, unsigned buflen)
	length = m_recv( emg_tcp_communication_socket, (char *)buffer, RX_BUFFER_SIZE );

	for( i=0; length>0; length-- )
		uart_putc(CONSOLE_UART, buffer[i]);  //FSL change CONSOLE_UART from 0 
}

//*****************************************************************************
// emg_tcp_tx()
//
// Take data from the UART RX buffer and send it out over
// ethernet using the m_send() function.
//*****************************************************************************
void emg_tcp_tx( void )
{
	int		i;

	for( i=0; (kbhit() && (i<RX_BUFFER_SIZE)); i++ )
	{
		buffer[i] = getch();
	}

	if( i )	
		(void)m_send( emg_tcp_communication_socket, (char *)buffer, i );
}

//*****************************************************************************
// emg_tcp_loop() -  Written By Eric Gregori
//		   			 
//
// Run application
//
//*****************************************************************************
int freescale_tcp_loop()
{
	int			i;
	
	emg_tcp_rx();
	emg_tcp_tx();
	tk_sleep( 5 );	
   	return SUCCESS;
}

//*****************************************************************************
// emg_http_cmdcb() - Written by Eric Gregori
//		   			  
//
// This is the mini-sockets callback function.
// We only use to detect a connection to the socket.
// When a connection is made, this function is called by the stack.
// The connection message is sent to the application through a 
// msring queue.
//*****************************************************************************
int freescale_tcp_cmdcb(int code, M_SOCK so, void * data)
{
	int e = 0;

	switch(code)
	{
		// socket open complete
		case M_OPENOK:
			msring_add(&emg_tcp_msring, so);
			break;
      
		// socket has closed      
   		case M_CLOSED:  
   			while( semaphore ){};
   			semaphore = 1;
			emg_tcp_communication_socket = INVALID_SOCKET;  
			m_close(so);						//FSL close the socket
			semaphore = 0;
     		break;								// let stale conn timer catch these 
      
		// passing received data
		// blocked transmit now ready
		case M_RXDATA:          				// received data packet, let recv() handle it 
		case M_TXDATA:          				// ready to send more, loop will do it
			e = -1;        						// return nonzero code to indicate we don't want it 
			break;
      
   		default:
      		dtrap();             				// not a legal case
      		return 0;
   }

   TK_WAKE(&to_emgtcpsrv);    					// wake server task

   USE_VOID(data);
   return e;
}

//*****************************************************************************
// emg_tcp_init() - written by Eric Gregori
//		   			 
//
// Create and bind a socket to our listening port ( PORT_NUMBER ).
// Set the socket to listen and non-blocking.
//*****************************************************************************
int freescale_tcp_init()
{
	int e;
	
	
	semaphore 						= 0;
	flash_ffs_lockout 				= 0;	//FSL 0=dynamic flash file system present, 1=not present
	emg_tcp_communication_socket 	= INVALID_SOCKET;
	
	// kill the console task so it does not intercept our serial input
//	tk_kill( to_keyboard );			//FSL comment out to have console access....uncomment to kill console.
	
	// Init message queue for MINI_TCP socket interface
    msring_init(&emg_tcp_msring, emg_tcp_msring_buf, sizeof(emg_tcp_msring_buf) / sizeof(emg_tcp_msring_buf[0]));

	// Init a socket structure with our Port Number
	emg_tcp_sin.sin_addr.s_addr 	= (INADDR_ANY);
	emg_tcp_sin.sin_port        	= (PORT_NUMBER);
    emg_tcp_server_socket 			= m_listen(&emg_tcp_sin, freescale_tcp_cmdcb, &e);

    if (emg_tcp_server_socket == INVALID_SOCKET)
    {
    	dprintf("error %d starting listen on TCP server\n", e);
    }

   	return SUCCESS ;
}

//*****************************************************************************
// emg_http_cleanup() - Written by Eric Gregori
//		   			    
//
// Delete all sessions.
//*****************************************************************************
void freescale_http_cleanup()
{
}

//*****************************************************************************
// emg_tcp_check() -  Written by Eric Gregori
//		   			  
//
// Check msring for message from socket callback function.
// If we received a connect request, call the connection function.
// While we are waiting for a connection to complete, we need to
// continue running our loop.
// Make the socket non-blocking.
//
// Call the loop function to execute any pending sessions.
//*****************************************************************************
void freescale_tcp_check(void)
{
	M_SOCK 		so;


	if ( emg_tcp_server_socket == INVALID_SOCKET )
    	return ;

   	while(msring_del(&emg_tcp_msring, &so) == 0)
   	{
   	   	while( semaphore ){};
   		semaphore = 1;
   		if( emg_tcp_communication_socket == INVALID_SOCKET )
   		{
      		m_ioctl(so, SO_NONBLOCK, NULL);   /* make socket non-blocking */
   			emg_tcp_communication_socket = so;
      		semaphore = 0;
      	}
      	
		if( emg_tcp_communication_socket != INVALID_SOCKET )
			freescale_tcp_loop();
		
      	semaphore = 0;      
   	} // while

	if( emg_tcp_communication_socket != INVALID_SOCKET )
		freescale_tcp_loop();
}

//*****************************************************************************
// The application thread works on a "controlled polling" basis: 
// it wakes up periodically and polls for work.
//
// The task could alternativly be set up to use blocking sockets,
// in which case the loops below would only call the "xxx_check()"
// routines - suspending would be handled by the TCP code.
//
//
// FUNCTION: tk_emg_tcp_srv
// 
// PARAM1: n/a
//
// RETURNS: n/a
//
//*****************************************************************************
TK_ENTRY(tk_emgtcpsrv)
{
   int err;

   while (!iniche_net_ready)
      TK_SLEEP(1);

   err = freescale_tcp_init();
   if( err == SUCCESS )
   {
      exit_hook(freescale_tcp_cleanup);
   }
   else
   {
      dtrap();    						// emghttp_init()  shouldn't ever fail
   }

   for (;;)
   {
      freescale_tcp_check();         	// will block on select
      tk_yield();          				// give up CPU in case it didn't block

      if (net_system_exit)
         break;
   }
   TK_RETURN_OK();
}

//*****************************************************************************
// create_freescale_task() - Written by Eric Gregori
//		   			  		 
//
// Insert the FreeScale task into the RTOS.
//*****************************************************************************
void create_freescale_task( void )
{
	int e = 0;

   	e = TK_NEWTASK(&emg_tcp_task);
   	if (e != 0)
   	{
      dprintf("freescale task create error\n");
      panic("create_apptasks");
   	}   	
}
