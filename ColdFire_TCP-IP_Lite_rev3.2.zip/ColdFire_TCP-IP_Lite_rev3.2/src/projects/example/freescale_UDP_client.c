//*****************************************************************************
// Copyright (c) 2006, Freescale Semiconductor
// For use on Freescale products only.
//
// File name :   	freescale_UDP_client.c
// Author:			Eric Gregori
//		   			
//
// Description : 	UDP client
//*****************************************************************************
#include "ipport.h"
#include "tcpapp.h"
#include "msring.h"
#include "menu.h"
#include OSPORT_H
#include "ipport.h"
#include "libport.h"
#include "udp.h"


#define PORT_NUMBER			5678
#define	TEST_BUFFER			250			// *4 = 1000 bytes
#define	INTER_PACKET_DELAY	1
#define			SERVER_IP			0xC0A80004	//0xC0A80004 = 192.168.0.4

//*****************************************************************************
// Declare Task Object
//*****************************************************************************
TK_OBJECT(to_freescale);
TK_ENTRY(tk_freescale);
struct inet_taskinfo freescale_task = {
      									&to_freescale,
      									"FreeScale Task",
      									tk_freescale,
      									NET_PRIORITY,
      									0x400
									};


//*****************************************************************************
// Declare a Socket structure and communications queue "msring"
//*****************************************************************************



//*****************************************************************************
//
// emg_udpsend based on tftp_udpsend
// Written by Eric Gregori
//
// Send outbuf to dest_port at ip address dest_ip
//
//*****************************************************************************
int BytesSentUDP	=	0;	//FSL Experiment
int emg_udpsend (	ip_addr dest_ip, 
					unsigned short dest_port, 
					int outlen
				)
{
	static PACKET 		pkt2;   // packet to send & free 
	int			e;
	int			i;
	static unsigned int	count2print=0;
	
	pkt2 = udp_alloc(outlen, 0);	//FSL allocate heap space and map PACKET pkt2 to that space
	if(!pkt2)						//FSL pkt2 heap space freed in ip_write()
		return -1;
	
   	pkt2->nb_plen 	= outlen;
  	pkt2->fhost 	= dest_ip;
   	pkt2->net 		= NULL;
   	
/* Experiment - fill packet with sequentially generated data */
#if 1
	for(i=0;i<pkt2->nb_plen;i++)
	{
//		pkt2->nb_prot[i] = (i % 256);
		pkt2->nb_prot[i] = (char)(0xff & i);
	}
#endif
/* End Experiment */	
						  // local port
   	e = udp_send( dest_port, 0x1234, pkt2 );

   if(e < 0)
   {
#ifdef NPDEBUG
      dprintf("udpsend(): udp_send() error %d\n", e);
#endif
      return e;
   }
   else
   	{
#if 0   	
		BytesSentUDP += pkt2->nb_plen;		//FSL Bytes Sent over TCP counter
		count2print += pkt2->nb_plen;		//FSL increment counter
		if(count2print > (2000*pkt2->nb_plen))
		{
			printf("\nBytes Sent %9d MegaBytes\n", BytesSentUDP/(1024*1024));
			count2print=0;					//FSL reset counter
      		e = 0;
		}
#endif		
   	}
	return e;

}


//*****************************************************************************
//
// Sample function for a UDP client
//
//*****************************************************************************
void emg_send_data_via_udp( void )
{
	int retry=0;
	
	// Send data_to_send to ip address det_ip, port PORT_NUMBER
	do 
	{
	  if (emg_udpsend( SERVER_IP, PORT_NUMBER, 1450 ))
	  		retry++;	
	} while(retry<100);
	
}


//*****************************************************************************
//
// UDP client init
//
//*****************************************************************************
void emg_init_udp_client( void )
{
	tk_sleep( 1000 );
}


//*****************************************************************************
//
// UDP client init
//
//*****************************************************************************
void emg_udp_client_cleanup( void )
{
	
}


//*****************************************************************************
// The application thread works on a "controlled polling" basis: 
// it wakes up periodically and polls for work.
//
// The task could aternativly be set up to use blocking sockets,
// in which case the loops below would only call the "xxx_check()"
// routines - suspending would be handled by the TCP code.
//
//
// FUNCTION: tk_emg_http_srv
// 
// PARAM1: n/a
//
// RETURNS: n/a
//
//*****************************************************************************
TK_ENTRY(tk_freescale)
{
	while (!iniche_net_ready)
    	TK_SLEEP(1);

	emg_init_udp_client();
      
	for (;;)
	{
    	emg_send_data_via_udp();         	
      	tk_yield();          			

      	if (net_system_exit)
        	break;
   	}
   	TK_RETURN_OK();
}


//*****************************************************************************
// create_freescale_task() - Written by Eric Gregori
//		   			  		 
//
// Insert the FreeScale task into the RTOS.
//*****************************************************************************
void create_freescale_task( void )
{
	int e = 0;

   	e = TK_NEWTASK(&freescale_task);
   	if (e != 0)
   	{
      dprintf("freescale task create error\n");
      panic("create_apptasks");
   	}   	
}

