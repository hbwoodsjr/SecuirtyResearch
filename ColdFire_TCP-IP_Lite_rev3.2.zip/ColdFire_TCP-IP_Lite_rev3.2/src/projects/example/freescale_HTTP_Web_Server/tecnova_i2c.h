/*********************************************************************
*
* SOURCE FILENAME:	I2C.h
*
* DATE CREATED:			1 June 2006
*
* PROGRAMMER:				Karl Kobel
*
* DESCRIPTION:  		I2C driver module
*
* Copyright (c) 2006 Tecnova.
* All rights reserved. 
* 
* Redistribution and use in source and binary forms, with or without modification, 
* are permitted provided that the following conditions are met:
*
* 1. Redistributions of source code must retain the above copyright notice,
*    this list of conditions and the following disclaimer.
* 2. Redistributions in binary form must reproduce the above copyright notice,
*    this list of conditions and the following disclaimer in the documentation
*    and/or other materials provided with the distribution.
* 3. The name of the author may not be used to endorse or promote products
*    derived from this software without specific prior written permission. 
*
* THIS SOFTWARE IS PROVIDED BY THE AUTHOR ``AS IS'' AND ANY EXPRESS OR IMPLIED 
* WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF 
* MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT 
* SHALL THE AUTHOR BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, 
* EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT 
* OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS 
* INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN 
* CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING 
* IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY 
* OF SUCH DAMAGE.
*
* Tecnova
* 1486 Saint Paul Avenue
* Gurnee, IL  60031-2129
* U.S.A.
 
* Telephone: +1.847.662.6260
* Facsimile: +1.847.336.7288
* Internet:  www.Tecnova.com
*
*********************************************************************/
#ifndef _I2C_H
#define _I2C_H


/*********************************************************************
*
*							DEFINITIONS
*
*********************************************************************/

#define READ_MODE	0x80

/*********************************************************************
*
*							VARIABLES
*
*********************************************************************/

/*********************************************************************
*
*							FUNCTION PROTOTYPES
*
*********************************************************************/

	
/*********************************************************************
*
* FUNCTION:			I2C_Read
*
* ARGUMENTS:		unsigned char slaveAddress	- Slave address (the code will take care of avoiding the R/W bit
*								unsigned char* pbCommands		- Pointer to the write data buffer
*								unsigned int bNCommandbytes	- The length of the data to write
*								unsigned char* pbPacket			- Pointer to the read data buffer
*								unsigned int bNbytes				- The length of the data to read
*
* RETURNS:			none
*
* DESCRIPTION:	Procedure which receives data on the I2C bus
*								Set the pbCommands buffer with commands and or addresses
*								Set the bNCommandbytes to the number of command/address bytes (can be zero)
*								The bNbytes of data will be read into pbPacket
*              
* RESTRICTIONS:	Puts the I2C module in master mode
*
*********************************************************************/
void I2C_Read(unsigned char slaveAddress, unsigned char* pbPacket, unsigned int bNbytes);

/*********************************************************************
*
* FUNCTION:			I2C_Write
*
* ARGUMENTS:		unsigned char slaveAddress	- Slave address (the code will take care of avoiding the R/W bit
*								unsigned char* pbPacket			- Pointer to the data to write
*								unsigned int bNbytes				- The length of the data to write
*								unsigned char bWait					- Non-zero = wait for transmittion to complete
*
* RETURNS:			none
*
* DESCRIPTION:	Procedure which sends data on the I2C bus
*              
* RESTRICTIONS:	Puts the I2C module in master mode
*
*********************************************************************/
void I2C_Write(unsigned char slaveAddress, unsigned char* pbPacket, unsigned int bNbytes, unsigned char bWait);

#endif					  
