//*****************************************************************************
// Copyright (c) 2006, Freescale Semiconductor
// For use on Freescale products only.
//
// File name :   	freescale_file_api.c
// Project name: 	emg_HTTP web server for ColdFire
// Author:			Eric Gregori
//
// Description :    File system entry point and API.
//
//*****************************************************************************
#include "ipport.h"
#include "tcpapp.h"
#include "menu.h"
#include "freescale_http_server.h"

extern EMG_HTTP_SESSION 	freescale_http_sessions[];
extern const unsigned char 	*emg_static_ffs_ptrs[];
extern const unsigned short emg_static_ffs_len[];
extern const unsigned char 	emg_static_ffs_nof;
extern const unsigned long 	emg_static_ffs_type[];
extern const char 			*emg_static_ffs_filenames[];
extern const char 			page_not_found[];
extern int					flash_ffs_lockout;		//FSL 0=dynamic flash file system present, 1=not present
extern int 					flash_erase( void *pio  );
extern int 					emg_http_var( void *pio  );
extern int 					emg_http_sessions( void *pio  );
extern int   				cat(void * pio);

int emg_ffs_dir(void * pio);

//*****************************************************************************
// File Not Found Web Page
//*****************************************************************************
const char page_not_found[] = "HTTP/1.0 200 OK\r\n\
Last-modified: Wed, 15 Mar 2006 10:42:00 GMT\r\n\
Server: EMG_HTTP 1.0.0\nContent-type: text/html\r\n\
\r\n\
<HEAD>\
<TITLE>Dynamic HTTP Server by Eric Gregori</TITLE></HEAD>\
<BODY>\
<H2>HTTP 1.0 404 Error. File Not Found</H2>\
The requested URL was not found on this server.\
<HR>\
<BR>\
<I>\r\n\
Freescale Semiconductor 2006\
<BR>\
Web Server for Embedded Applications\
</I>\r\n\
<BR>\
</BODY>";

//*****************************************************************************
// Fill out structure for EMG FFS DIRectory menu command
//*****************************************************************************
struct menu_op emg_ffs_dir_menu[] = 	{
											"EMG HTTP",  		stooges,			"EMG HTTP menu",
								   			"dir",    			emg_ffs_dir,    	"Dir of EMG FFS",
								   			"flash_erase",    	flash_erase,    	"Erase the dynamic FLASH area",
								   			"var",				emg_http_var,		"Dynamic HTML variable",
								   			"http",				emg_http_sessions, 	"Dump HTTP sessions array",
								   			"cat",      		cat,                "CAT file to terminal",
								   			NULL,
										};

//*****************************************************************************
// skip_past_header
//
// Author: Eric Gregori
//		   
//*****************************************************************************
void skip_past_header( uint32 *data_pointer, uint32 *file_size )
{
	char 	*data;
	uint32 	index;
	uint32	count;
	
	index 	= 0;
	count	= 0;
	data 	= (char *)*data_pointer;
	for( index=0; index<*file_size; index++ )
	{
		if( (data[index] == 0x0D) || (data[index] == 0x0A) )
			count++;
		else
			count = 0;
		
		if( count == 4 )
			break;
	}
	
	if( count == 4 )
	{
		*file_size = *file_size - (index+1);
		*data_pointer = *data_pointer + (index+1);
	}	
}

//*****************************************************************************
// Print Directory of Static and Dynamic Flash File Systems.
//
// Author: Eric Gregori
//		   
//*****************************************************************************
int emg_ffs_dir(void * pio)
{
	int   						file_count, total_file_size, k, j, done;
	volatile unsigned long		*fat_file_sys;
	volatile unsigned char		*fat_file_names;
	unsigned char				filename[64];
	unsigned char				temp;
	unsigned long				total_size_of_files;
	unsigned long				number_of_files;
	unsigned long				fat_pointer;
	unsigned long				address_ptr;
	unsigned long				filename_ptr;
	unsigned long				file_pointer;
	unsigned long				file_size_in_bytes;
	unsigned char				file_type[4];
	
	ns_printf( pio, "\nStatic FFS" );
	ns_printf( pio, "\n\n%-32s %-6s %-8s", 
					"FILENAME",
					"LENGTH",
					" POINTER" );

	total_file_size = 0;

	// Loop through each file printing the info
	for( file_count=0; file_count<emg_static_ffs_nof; file_count++ )
	{
		ns_printf( pio, "\n%-33s", emg_static_ffs_filenames[file_count] );
		ns_printf( pio, "%-9d", emg_static_ffs_len[file_count] );
		ns_printf( pio, "0x%-8x", (unsigned long)emg_static_ffs_ptrs[file_count] );			
		total_file_size += emg_static_ffs_len[file_count];
   	}

   	ns_printf(pio,"\n\n                                   Total Size = %d",total_file_size);
   	ns_printf(pio,"\ntotal static files = %d\n",file_count);

	fat_file_sys 	= (unsigned long *)FAT_FILE_BASE_ADDR;
	if( fat_file_sys[0] == (unsigned long)'EMG1' )
	{
		ns_printf( pio, "\nDynamic FFS" );
		ns_printf( pio, "\n\n%-32s %-6s %-8s", 
						"FILENAME",
						"LENGTH",
						" POINTER" );

		total_file_size = 0;
		file_count		= 0;

		// Use downloadable FFS
		// EMG1 ffs structures
		// typedef struct	{
		//						unsigned long	fatID;
		//						unsigned long	total_size_in_bytes;
		//						unsigned long	number_of_files;
		//						unsigned long	fat_pointer;
		//					}		FAT_HEADER;
		//
		// typedef struct	{
		//						unsigned long	file_pointer;
		//						unsigned long	file_size_in_bytes;
		//						unsigned long	file_type;
		//					}		FAT_FILE_DESCRIPTOR; 
		// 
		// After the header is a list of filenames
		fat_file_names = (unsigned char *)&fat_file_sys[4];
				
		// First char is 0
		j = 0;
		k = 0;				
		while(1)
		{
			// Scan to start of string
			// 2 consecutive NULL equals end
			for( ; fat_file_names[j]; j++ )
			{};
			if( fat_file_names[j+1] == 0 )
				break;
			
			j++;
			ns_printf( pio, "\n%-33s", &fat_file_names[j] );
			
			fat_file_sys 	= (unsigned long *)FAT_FILE_BASE_ADDR;
							
			// If found, K = index into FILE DESCRIPTORS
			// Set fat_file_sys to start of descriptors
			fat_file_sys = (unsigned long *)((unsigned long)fat_file_sys[3] + (unsigned long)FAT_FILE_BASE_ADDR);				

			// Index into descriptors, K is index
			// [0] = file pointer
			// [1] = file size
			// [2] = file type
			fat_file_sys = &fat_file_sys[k*3];

//			ns_printf( pio, "   %c   ", fat_file_sys[2] );
			ns_printf( pio, "%-9d", 	fat_file_sys[1] );
			ns_printf( pio, "0x%-8x", 	((unsigned long)fat_file_sys[0] + (unsigned long)FAT_FILE_BASE_ADDR) );			
			total_file_size += fat_file_sys[1];
			file_count++;
			k++;
		}
		
   		ns_printf(pio,"\n\n                                   Total Size = %d",total_file_size);
   		ns_printf(pio,"\ntotal dynamic files = %d\n",file_count);
		
	}

	ns_printf(pio,"\n\n" );
	
   	return 0;
}


//*****************************************************************************
// void emg_web_open( session, filename )
//
//	Open a file by initializing the web server session structure. 
//
// Author: Eric Gregori
//		   
//*****************************************************************************
void emg_web_open( unsigned char session, unsigned char *filename )
{
	int   						k, j, found, i;
	unsigned long				file_pointer, file_index, file_size;
	volatile unsigned long		*fat_file_sys;
	volatile unsigned char		*fat_file_names;
	
	unsigned long				filename_ptr;
	unsigned long				file_size_in_bytes;
	unsigned long				total_size_of_files;
	unsigned long				number_of_files;
	unsigned long 				fat_pointer;
	unsigned char				file_type[4];
	
	fat_file_sys = (unsigned long *)FAT_FILE_BASE_ADDR;

	// Find the file
	if(1)	
	{
		found = 0;
//FSL check for dynamic flash file system...if found, change session state to 
//FSL send default file which is the first file in the list of files.
		if( (fat_file_sys[0] == (unsigned long)'EMG1' ) && !flash_ffs_lockout )
		{
			// Use downloadable FFS
			// EMG1 ffs structures
			// typedef struct	{
			//						unsigned long	fatID;
			//						unsigned long	total_size_in_bytes;
			//						unsigned long	number_of_files;
			//						unsigned long	fat_pointer;
			//					}		FAT_HEADER;
			//
			// typedef struct	{
			//						unsigned long	file_pointer;
			//						unsigned long	file_size_in_bytes;
			//						unsigned long	file_type;
			//					}		FAT_FILE_DESCRIPTOR; 
			// 				
			// After the header is a list of filenames
			fat_file_names = (unsigned char *)&fat_file_sys[4];
				
			// First char is 0				
			// buffer[0] = filaname
			for( k=0, j=0, found=0; ;k++ )
			{
				if( filename[0] == 0 )
				{
					found = 1;
					break;
				}
			
				// Scan to start of string
				// 2 consecutive NULL equals end
				for( ; fat_file_names[j]; j++ )
				{};
				if( fat_file_names[j+1] == 0 )
					break;
					
				for( i=0, j++; filename[i]; i++ )
				{
					if( fat_file_names[j+i] != filename[i])
						break;
				}
					
				if( filename[i] == 0 )
				{
					found = 1;
					break;
				}
			}
				
			// If found, K = index into FILE DESCRIPTORS
			// Set fat_file_sys to start of descriptors
			fat_file_sys = (unsigned long *)((unsigned long)fat_file_sys[3] + (unsigned long)FAT_FILE_BASE_ADDR);				

			// Index into descriptors, K is index
			// [0] = file pointer
			// [1] = file size
			// [2] = file type
			fat_file_sys = &fat_file_sys[k*3];
#if HTTP_VERBOSE>1
			printf( "\nFile Found - %d", k );
#endif	

			if( found )
			{
				freescale_http_sessions[session].file_type		= fat_file_sys[2];
				freescale_http_sessions[session].file_size 		= fat_file_sys[1];
				freescale_http_sessions[session].file_pointer	= (void *)((unsigned long)fat_file_sys[0] + (unsigned long)FAT_FILE_BASE_ADDR);
				freescale_http_sessions[session].file_index 	= 0;
				freescale_http_sessions[session].state			= EMG_HTTP_STATE_SEND_FILE;			
			}
		}

//FSL No dynamic flash file system found.  Look for static file system, then
//FSL change session state to send default file which is the first file in the 
//FSL list of files.
		if( !found )
		{
			// Use compiled FFS
			// Scan through the filenames, and find ours
			for( i=0, found=0; i<emg_static_ffs_nof; i++ )
			{
				if( filename[0] == 0 )
				{
					i 		= 0;
					found 	= 1;
					break;
				}
			
				for( j=0, k=0; filename[j]; j++ )
				{
					if( filename[j] == emg_static_ffs_filenames[i][k] )
						k++;		
				}
			
				if( emg_static_ffs_filenames[i][k] == 0 )
				{
					// Filename found
					found = 1;
#if HTTP_VERBOSE>1
					printf( "\nFile Found - %d", emg_static_ffs_len[i] );
#endif	
					break;
				}
			}
		
			if( found )
			{
				freescale_http_sessions[session].file_type		= (int)emg_static_ffs_type[i];
				freescale_http_sessions[session].file_size 		= emg_static_ffs_len[i];
				freescale_http_sessions[session].file_pointer	= (void *)emg_static_ffs_ptrs[i];
				freescale_http_sessions[session].file_index 	= 0;
				freescale_http_sessions[session].state			= EMG_HTTP_STATE_SEND_FILE;			
			}
			else
			{			
				freescale_http_sessions[session].file_type		= 0;
				freescale_http_sessions[session].file_size 		= strlen(page_not_found);
				freescale_http_sessions[session].file_pointer	= (void *)page_not_found;
				freescale_http_sessions[session].file_index 	= 0;
				freescale_http_sessions[session].state			= EMG_HTTP_STATE_SEND_FILE;			
			}
		}
	}
}

//*****************************************************************************
// uint32 emg_web_read( session, scratch_ram_for_send, freescale_http_sessions[session].file_size );
//
//	Open a file by initializing the web server session structure. 
//
//	Returns: # of bytes read
//
// Author: Eric Gregori
//		   
//*****************************************************************************
unsigned long emg_web_read( unsigned char session, unsigned char *buffer_out, unsigned long max_bytestoread )
{
	unsigned long	i, k, j; 
	unsigned long	read_index, bytes_to_read, last_read, read_size;
	unsigned char	*data;

	if( freescale_http_sessions[session].file_index >= freescale_http_sessions[session].file_size ) 
	{
		return(0);
	}
	
	if( (freescale_http_sessions[session].file_index + max_bytestoread) >
		freescale_http_sessions[session].file_size ) 
	{
		max_bytestoread = freescale_http_sessions[session].file_size - 
						  freescale_http_sessions[session].file_index;
	}
	
		// memory Mapped Flash
	data = freescale_http_sessions[session].file_pointer;
	data = &data[freescale_http_sessions[session].file_index];

	for( i=0; i<max_bytestoread; i++ ) 
	{
		buffer_out[i] = data[i]; 
	}
	
	freescale_http_sessions[session].file_index += i;
	
	return(i);	
}

//*****************************************************************************
// uint32 emg_web_rewind( session, bytestorewind );
//
//	Open a file by initializing the web server session structure. 
//
// Author: Eric Gregori
//		   
//*****************************************************************************
void emg_web_rewind( unsigned char session, unsigned long bytestorewind )
{
	unsigned long	i;
	unsigned char	*data;

	
	if( freescale_http_sessions[session].file_index == 0 )
		return;
	
	if( freescale_http_sessions[session].file_index < bytestorewind )
		return;
	
	freescale_http_sessions[session].file_index -= bytestorewind;	
}

//*****************************************************************************
// void emg_web_write( session, buffer, length )
//
//	Open a file by initializing the web server session structure. 
//
//	Returns: # of bytes read
//
// Author: Eric Gregori
//		   
//*****************************************************************************
void emg_web_write( unsigned char session, unsigned long *buffer, unsigned long length )
{
	unsigned long	j;
	
	// length is in bytes, we need to write longwords (4 bytes)
	for( j=0;j<(length/4); j++ )
	{
		flash_write( (unsigned long *)freescale_http_sessions[session].file_index, buffer[j] );	
		freescale_http_sessions[session].file_index += 4;
		freescale_http_sessions[session].file_size  -= 4;
	}

	if( freescale_http_sessions[session].file_size < 4 )
	{
		flash_write( (unsigned long *)freescale_http_sessions[session].file_index, buffer[j] );	
	}
	
}

//*****************************************************************************
// uint32 emg_web_flash_parm( session )
//
//	Returns size of dynamic flash 
//
// Author: Eric Gregori
//		   
//*****************************************************************************
unsigned long emg_web_flash_parms( unsigned long parameter, unsigned char session )
{
	unsigned long	retval;

	switch( parameter )
	{
		case (unsigned long)'size':
			retval = FLASH_END_ADDRESS-FLASH_START_ADDRESS;
			break;
			
		case (unsigned long)'strt':
			retval = FLASH_START_ADDRESS;
			break;

		case (unsigned long)'endd':
			retval = FLASH_END_ADDRESS;
			break;
	}

	return( retval );
}

//*****************************************************************************
// uint32 emg_web_erase( session )
//
//	Returns size of dynamic flash 
//
// Author: Eric Gregori
//		   
//*****************************************************************************
unsigned long emg_web_erase( unsigned char session )
{
	unsigned long	address, end_address;

	address 	= freescale_http_sessions[session].file_index;
	end_address = address + (PAGES_PER_SESSION*FLASH_PAGE_SIZE);

	for( ; address < end_address; address += FLASH_PAGE_SIZE )
	{
		flash_page_erase( (unsigned long *)address, 0x00000000 );
	}
	
	return( address );
}

//*****************************************************************************
// int emg_open( char *filename, uint32 *data_pointer, uint32 *file_size )
//
// User API to dynamic flash file system
//
// Finds the file descriptor in the FAT.
// Sets data_pointer to start of data.
// Sets file_size to size of file in bytes.  
// returns a < 0 if error, 0 = success
//
// for an example of using emg_open(), see cat command in menulib.c
// 
//
// Author: Eric Gregori
//		   
//*****************************************************************************
int emg_open( char *filename, unsigned long *data_pointer, unsigned long *file_size )
{
	int   						k, j, found, i;
	volatile unsigned long		*fat_file_sys;
	volatile unsigned char		*fat_file_names;

	fat_file_sys 	= (unsigned long *)FAT_FILE_BASE_ADDR;
	if( fat_file_sys[0] == (unsigned long)'EMG1' )
	{
		// Use downloadable FFS
		// EMG1 ffs structures
		// typedef struct	{
		//						unsigned long	fatID;
		//						unsigned long	total_size_in_bytes;
		//						unsigned long	number_of_files;
		//						unsigned long	fat_pointer;
		//					}		FAT_HEADER;
		//
		// typedef struct	{
		//						unsigned long	file_pointer;
		//						unsigned long	file_size_in_bytes;
		//						unsigned long	file_type;
		//					}		FAT_FILE_DESCRIPTOR; 
		// 
		// After the header is a list of filenames
		fat_file_names = (unsigned char *)&fat_file_sys[4];
				
		// First char is 0
		j 		= 0;
		k 		= 0;
		found 	= 0;				
		while(1)
		{
			// Scan to start of string
			// 2 consecutive NULL equals end
			for( ; fat_file_names[j]; j++ ){};
			if( fat_file_names[j+1] == 0 )
				break;
			
			j++;
			
			// &fat_file_names[j] = start of filename
			if( strcmp( (char *)&fat_file_names[j], filename ) == 0 )
			{
				found = 1;
				break;				
			}
			
			k++;
		}
		
		if( found )
		{				
			fat_file_sys 	= (unsigned long *)FAT_FILE_BASE_ADDR;
							
			// If found, K = index into FILE DESCRIPTORS
			fat_file_sys = (unsigned long *)((unsigned long)fat_file_sys[3] + (unsigned long)FAT_FILE_BASE_ADDR);				

			// Index into descriptors, K is index
			// [0] = file pointer
			// [1] = file size
			// [2] = file type
			fat_file_sys = &fat_file_sys[k*3];

			*data_pointer = ((unsigned long)fat_file_sys[0] + (unsigned long)FAT_FILE_BASE_ADDR);
			*file_size    = (uint32)fat_file_sys[1];
			
			skip_past_header( data_pointer, file_size );
			return(0);
		}
	}

	// Static
	for( i=0, found=0; i<emg_static_ffs_nof; i++ )
	{
		for( j=0, k=0; filename[j]; j++ )
		{
			if( filename[j] == emg_static_ffs_filenames[i][k] )
				k++;		
		}
		
		if( emg_static_ffs_filenames[i][k] == 0 )
		{
			// Filename found
			found = 1;
			break;
		}
	}
	
	if( found )
	{
		*data_pointer = (unsigned long)emg_static_ffs_ptrs[i];
		*file_size    = emg_static_ffs_len[i];
		
		skip_past_header( data_pointer, file_size );
		return(0);
	}

	return(-1);
}

//*****************************************************************************
// int   cat(void * pio)   Written By Eric Gregori
//						   
//
// Outputs file to console.
//
//*****************************************************************************
int   cat(void * pio)
{
   	char 			*cp;
   	unsigned char	*data;
   	uint8			bad_char;
   	uint32			bytes;
   	uint32			index;
   	uint32			i;

	ns_printf(pio, "\n\n" );

   	cp = nextarg(((GEN_IO)pio)->inbuf);
	if( emg_open(cp, &index, &bytes) == 0 )
	{
		data 		= (unsigned char *)index;
		index 		= 0;
		bad_char 	= 0;
		while( (index < bytes) && !bad_char )
		{
			for( i=0; i<10; i++ )
			{
				if( (data[index] < 8) || (data[index] > 127) )
				{
//FSL					skip and do not print bad character
				}
				else		
					ns_printf( pio, "%c", data[index]);
				
				index++;
				
				if( index == bytes )
					break;
			}
			
			tk_sleep(2);
		}		
	}
	else
	   ns_printf(pio, "File Not Found" );
	
	if( bad_char )
	   ns_printf(pio, "\n\nCAT stopped, non-ascii character detected 0x%x", bad_char );
	
	ns_printf(pio, "\n\n" );
	
	return(0);
}
