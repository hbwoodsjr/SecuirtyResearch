//*****************************************************************************
// Copyright (c) 2006, Freescale Semiconductor
// For use on Freescale products only.
//
// File name :   	emg_dynamic_http.c
// Project name: 	emg_HTTP web server for ColdFire
// Author:			Eric Gregori
//
// Description : 	This file supports dynamic HTML using Tokens.
//					Dynamic HTML allows for dynamic content to reside
//					on a static HTML web page.
//
//*****************************************************************************
#include "ipport.h"
#include "tcpapp.h"
#include "menu.h"
#include "freescale_http_server.h"

extern unsigned long html_vars[MAX_NUMBER_OF_VARS];
extern unsigned char html_vars_flags[MAX_NUMBER_OF_VARS];

//*****************************************************************************
// Function Prototypes
//*****************************************************************************
void form_led_function( char *);
void form_serial_function( char *);
void form_var_function( char * );

//*****************************************************************************
// Form Strings
//*****************************************************************************
const FORM_STRUCTURE forms[] = 
								{
									{"led", 	form_led_function},		
									{"serial",	form_serial_function},
									{"var",     form_var_function},		//FSL This is not implemented....should remove.  Think we can delete the function too!!
									{"",		form_led_function}
								};
//FSL I think this is nice example code but dead code at that (i.e. never called)
//*****************************************************************************
// Form for setting var.
//
// var=II_decimal or II_off
//
// Author: Eric Gregori
//		   
//*****************************************************************************
void form_var_function( char *data )
{
	unsigned int	index;

	if( data[2] == '_' )
	{
		data[2] = 0;
   	   	index = atoi(&data[0]);
   	   	if( index < MAX_NUMBER_OF_VARS )
   	   	{
   	   		if( (data[3] == 'o') || (data[3] == 'O' ))
   	   		{
   	   			html_vars[index] 		= 0;
   	   			html_vars_flags[index] 	= 0;
   	   		}
   	   		else
   	   		{
   	   			html_vars[index]		= atoi(&data[3]);
   	   			html_vars_flags[index] 	= 1;
   	   		}
   	   	}			
	}	
}

//*****************************************************************************
// Form for blinking a LED.
//
// Author: Eric Gregori
//		   
//*****************************************************************************
void form_led_function( char *data )
{
	if( data[6] == 'O' )
	{
		// LEDx_TOGGLE
		switch( data[3] )
		{
			case '1':
			if(LED0) 
			{
				LED0_OFF;LED0--;	
			}
			else
			{
				LED0_ON;LED0++;
			}
//				LED0_TOGGLE;
				break;
							
			case '2':
			if(LED1)
			{
				LED1_OFF;LED1--;
			}
				
			else
			{
				LED1_ON;LED1++;
			}
//				LED1_TOGGLE;
				break;

			case '3':
			if(LED2) 
			{
				LED2_OFF;LED2--;
			}
				
			else
			{
				LED2_ON;LED2++;
			}
//				LED2_TOGGLE;
				break;
							
			case '4':
			if(LED3) 
			{
				LED3_OFF;LED3--;
			}
				
			else
			{
				LED3_ON;LED3++;
			}
//				LED3_TOGGLE;
				break;

			default:
				break;
		}
	}

	if( data[6] == 'N' )
	{
		// LEDx_ON
		switch( data[3] )
		{
			case '1':
				LED0_ON;
				break;
							
			case '2':
				LED1_ON;
				break;

			case '3':
				LED2_ON;
				break;
							
			case '4':
				LED3_ON;
				break;

			default:
				break;
		}
	}

	if( data[6] == 'F' )
	{
		// LEDx_ON
		switch( data[3] )
		{
			case '1':
				LED0_OFF;
				break;
							
			case '2':
				LED1_OFF;
				break;

			case '3':
				LED2_OFF;
				break;
							
			case '4':
				LED3_OFF;
				break;
			
			default:
				break;
		}
	}		
}

//*****************************************************************************
// Form for outputting to serial.
//
// Author: Eric Gregori
//		   
//*****************************************************************************
void form_serial_function( char *data )
{
	printf("%s", data );	
}

