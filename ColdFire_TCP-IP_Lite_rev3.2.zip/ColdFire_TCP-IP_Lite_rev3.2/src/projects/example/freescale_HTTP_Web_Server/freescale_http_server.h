//*****************************************************************************
// Copyright (c) 2006, Freescale Semiconductor
// For use on Freescale products only.
//
// File name :   	emg_http_server.h
// Project name: 	emg_HTTP web server for ColdFire
// Author:			Eric Gregori
//		   			
//
// Description : 	HTTP/Web server with static anf dynamic FFS support.
//					Dynamic HTML is supported via tokens in the HTML.
//					A key is used to support run time ( dynamic ) web page uploads.
//					Without the correct key, the download is rejected.
//					The web server supports multiple sessions as defined by EMG_HTTP_SESSION.
//					The web server supports 'GET', 'POST','EMG'.
//					EMG is a unique non-standard HTTP command to request a upload.
//					Uploading is done using the same server that serves up the web pages.
//					Long filenames are supported, along with subdirectories.
//
//*****************************************************************************

//*****************************************************************************
// There are 6 levels of Verbose.
//
// Level 0 - Only fatal errors are output to the console.
// Level 1 - Future expansion
// Level 2 - File system
// Level 3 - Server + File system
// Level 4 - Server + File system + Internal variables
// Level 5 - All the above + Download progress ( slows things way down ).
// Level 6 - Dynamic HTML + all the above.
//*****************************************************************************
#define HTTP_VERBOSE		0		//FSL was 0...good for testing to change to non-0 value

//*****************************************************************************
// HEADER TYPES
//*****************************************************************************
typedef enum 
{
							NO_HEADER_FOUND,	//==0
							TYPE_GET,			//==1
							TYPE_UPLOAD,		//==2
							TYPE_POST			//==3
} HEADER_TYPES;

//*****************************************************************************
// Session Structure
//*****************************************************************************
typedef struct
{
	int            			state;         	// state of the protocol.  
   	int         			valid;     		// Data in this entry is valid
   	unsigned long			keep_alive;		// Connection Persistance
   	unsigned long			file_type;		// File Type
   	unsigned long			file_size;		// Overall File size in bytes
	unsigned long			file_index;		// Index for referencing data	
	HEADER_TYPES			headertype;		// Header type
   	void					*file_pointer;	// Pointer to start data - do not change
   	M_SOCK       			socket;        	// the open socket we are using  
} EMG_HTTP_SESSION;

//*****************************************************************************
// Forms Structure
//*****************************************************************************
typedef struct
{
	unsigned char			form_name[8];		// Name on form
	void 					(*func)(char *);  	// Function pointer	
} FORM_STRUCTURE;

//*****************************************************************************
// FLAGS
//*****************************************************************************
#define HTTP_KEEP_ALIVE_TIME				100	// 10 seconds

//*****************************************************************************
// Session Structure - valid
//*****************************************************************************
#define INVALID_EMG_SESSION					0
#define VALID_EMG_SESSION					1

//*****************************************************************************
// HTTP server port #, default to 80
//*****************************************************************************
#define PORT_NUMBER							80

//*****************************************************************************
// Receive buffer, DO NOT CHANGE!!!
//*****************************************************************************
#define RECV_BUFFER_SIZE					0x100
#define MAX_HEADER_READS					(1548/RECV_BUFFER_SIZE)

//*****************************************************************************
// MAX bytes to send in one packet
//*****************************************************************************
#define MAX_BYTES_TO_SEND					TCP_MSS		//FSL was 1400
#define EMG_HTTP_INIT_FAILED				1

//*****************************************************************************
// The EMG HTTP server supports multiple sessions.  This increases the download
// speed considerably.  
//*****************************************************************************
#define MAX_NUMBER_OF_SESSIONS				4

//*****************************************************************************
// Dynamic HTML settings
//*****************************************************************************
// max size of a dynamic HTML token string
#define MAX_DYNAMIC_STRING_SIZE				256

// max number of dynamic HTML variables
#define MAX_NUMBER_OF_VARS					32

// File types scanned for dynamic HTML content
#define FILE_TYPE_DYANMIC1					'html'
#define FILE_TYPE_DYANMIC2					'text'

// dynamic HTML ascii tokens
#define DYNAMIC_REPLACE_TOKEN				'~'
#define DYNAMIC_COMPARE_TOKEN				'^'
#define DYNAMIC_EOS_TOKEN					';'

//*****************************************************************************
// EMG HTTP states
//*****************************************************************************
enum
{
					EMG_HTTP_STATE_WAIT_FOR_HEADER,	//==0
					EMG_HTTP_STATE_SEND_FILE,		//==1
					EMG_HTTP_STATE_CLOSE,			//==2
					EMG_HTTP_STATE_ERASE_FLASH,		//==3
					EMG_HTTP_STATE_UPLOAD_FILE,		//==4
					EMG_HTTP_STATE_S19_UPLOAD_FILE  //==5	//FSL added for mcf52259
};

//*****************************************************************************
// Max size of HTTP command, GET, POST, ...
//*****************************************************************************
#define HEADER_TYPE_SIZE		4

typedef struct
{
	unsigned char	header_string[HEADER_TYPE_SIZE+1];
	HEADER_TYPES	header_type;
} HEADER_STRUCTURE;

//*****************************************************************************
// FLASH Parameters 
//FSL Configurable in the processor.h file
//*****************************************************************************

// Start address for region of flash available for web page upload
#ifndef FLASH_START_ADDRESS
#define FLASH_START_ADDRESS					0x44020000
#endif
// End address for region of flash available for web page upload
#ifndef FLASH_END_ADDRESS
#define FLASH_END_ADDRESS					0x4403FFFF
#endif
// Flash erase page size
#ifndef FLASH_PAGE_SIZE
#define FLASH_PAGE_SIZE						0x0800
#endif
// Number of flash pages erased per task iteration
#ifndef PAGES_PER_SESSION
#define PAGES_PER_SESSION					0x08
#endif
// Address for flash region as seen by CPU
#ifndef FAT_FILE_BASE_ADDR
#define FAT_FILE_BASE_ADDR					0x00020000
#endif
//*****************************************************************************
// Function protoype declaration
//*****************************************************************************

extern void evb_specific_collect_sensor_data( void );
#ifdef MCF52259
extern void ParseS19(unsigned char *buffer);		//FSL added for mcf52259
#endif