//*****************************************************************************
// Copyright (c) 2006, Freescale Semiconductor
// For use on Freescale products only.
//
// File name :   	emg_flash_loader.c
// Project name: 	emg_HTTP web server for ColdFire
// Author:			Eric Gregori
//		   			
//
// Description : 	This is the flash driver for the ColdFire 5223X flash.
//
//*****************************************************************************
#include "common.h"
#include "ipport.h"
#include "tcpapp.h"
#include "menu.h"
#include "freescale_http_server.h"

extern void mcf5xxx_irq_disable( void );
extern void mcf5xxx_irq_enable( void );

int flash_erase( void *pio  );

//*****************************************************************************
// Fill out structure for EMG FFS DIRectory menu command
//*****************************************************************************
struct menu_op flash_erase_menu[] = 
				{
					"EMG FFS", stooges,"EMG FFS menu", NULL,
				};

//
// Flash drivers and downloading
//
// 15.4.3.2 Program, Erase, and Verify Sequences
// A command state machine is used to supervise the write sequencing of program, erase, and verify
// commands. To prepare for a command, the CFMUSTAT[CBEIF] flag should be tested to ensure that the
// address, data, and command buffers are empty. If CBEIF is set, the command write sequence can be
// started.
//
// This three-step command write sequence must be strictly followed. No intermediate writes to the CFM
// module are permitted between these three steps. The command write sequence is:
// 1. Write the 32-bit longword to be programmed to its location in the CFM array. The address and data
// will be stored in internal buffers. All address bits are valid for program commands. The value of
// the data written for verify and erase commands is ignored. For mass erase or verify, the address can
// be any location in the CFM array. For page erase, address bits [9:0] are ignored.
//
// NOTE
// The page erase command operates simultaneously on adjacent erase pages
// in two interleaved Flash physical blocks. Thus, a single erase page is
// effectively 2 Kbyte.
// 2. Write the program, erase, or verify command to CFMCMD, the command buffer. See
// Section 15.4.3.3, �Flash Valid Commands.�
// 3. Launch the command by writing a 1 to the CBEIF flag. This clears CBEIF. When command
// execution is complete, the Flash state machine sets the CCIF flag. The CBEIF flag is also set
// again, indicating that the address, data, and command buffers are ready for a new command
// sequence to begin.
// The Flash state machine flags errors in command write sequences by means of the ACCERR and PVIOL
// flags in the CFMUSTAT register. An erroneous command write sequence self-aborts and sets the
// appropriate flag. The ACCERR or PVIOL flags must be cleared before commencing another command
// write sequence.
void flash_init( void )
{
	// So, for fSYS = 66 MHz, writing 0x54 to CFMCLKD will set fCLK to 196.43 kHz which is a valid frequency
	// for the timing of program and erase operations.
	// WARNING
	// For proper program and erase operations, it is critical to set fCLK between
	// 150 kHz and 200 kHz. Array damage due to overstress can occur when fCLK
	// is less than 150 kHz. Incomplete programming and erasure can occur when
	// fCLK is greater than 200 kHz.
	// NOTE: Internal flash state machine operates at bus frequency not core frequency
#ifdef MCF5223x					//FSL added for mcf5223x @60MHz port
	MCF_CFM_CFMCLKD = 0x66;		//Note: this changed from original CVS version that used 0x54
#endif	
#ifdef MCF5282					//FSL added for mcf5282 @66MHz port
	MCF_CFM_CFMCLKD = 0x6A;
#endif	
#ifdef MCF52259					//FSL added for mcf52259 @80MHz core and 40MHz bus
	MCF_CFM_CFMCLKD = 0x68;		//FSL 40MHz/8/26=196.078KHz
#endif	
}

//*****************************************************************************
// Flash page erase function.
//
// Author: Eric Gregori
//		   
//*****************************************************************************
volatile void flash_page_erase( unsigned long *address, unsigned long data )
{

#ifdef MCF52259
	mcf5xxx_irq_disable();
	*address = data;
	MCF_CFM_CFMCMD = 0x40;
	MCF_CFM_CFMUSTAT = 0x80;
	
	while( !(MCF_CFM_CFMUSTAT & MCF_CFM_CFMUSTAT_CCIF))
	{};
		
	mcf5xxx_irq_enable();		
#endif	
#ifdef MCF5223x
	mcf5xxx_irq_disable();
	*address = data;
	MCF_CFM_CFMCMD = 0x40;
	MCF_CFM_CFMUSTAT = 0x80;
	
	while( !(MCF_CFM_CFMUSTAT & MCF_CFM_CFMUSTAT_CCIF))
	{};
		
	mcf5xxx_irq_enable();		
#endif	
#ifdef MCF5282
	mcf5xxx_irq_disable();
	*address = data;
	MCF_CFM_CFMCMD = 0x40;
	MCF_CFM_CFMUSTAT = 0x80;
	
	while( !(MCF_CFM_CFMUSTAT & MCF_CFM_CFMUSTAT_CCIF))
	{};
		
	mcf5xxx_irq_enable();		
#endif	
}

//*****************************************************************************
// Flash write function.
//
// Author: Eric Gregori
//		   
//*****************************************************************************
volatile void flash_write( unsigned long *address, unsigned long data )
{
#ifdef MCF52259
	mcf5xxx_irq_disable();
	*address = data;			//FSL address and data to write to flash
	MCF_CFM_CFMCMD = 0x20;		//FSL Word Program command
	MCF_CFM_CFMUSTAT = 0x80;	//FSL Start flash write state machine
	
	while( !(MCF_CFM_CFMUSTAT & MCF_CFM_CFMUSTAT_CCIF))	//FSL wait for state machine to complete
	{};
		
	mcf5xxx_irq_enable();		
#endif	
#ifdef MCF5223x
	mcf5xxx_irq_disable();
	*address = data;			//FSL address and data to write to flash
	MCF_CFM_CFMCMD = 0x20;		//FSL Word Program command
	MCF_CFM_CFMUSTAT = 0x80;	//FSL Start flash write state machine
	
	while( !(MCF_CFM_CFMUSTAT & MCF_CFM_CFMUSTAT_CCIF))	//FSL wait for state machine to complete
	{};
		
	mcf5xxx_irq_enable();		
#endif	
#ifdef MCF5282
	mcf5xxx_irq_disable();
	*address = data;
	MCF_CFM_CFMCMD = 0x20;
	MCF_CFM_CFMUSTAT = 0x80;
	
	while( !(MCF_CFM_CFMUSTAT & MCF_CFM_CFMUSTAT_CCIF))
	{};
		
	mcf5xxx_irq_enable();		
#endif	
}

//*****************************************************************************
// Flash test function, used to erase flash for demo
//
// Author: Eric Gregori
//		   
//*****************************************************************************
int flash_erase( void *pio  )
{
#ifdef MCF52259

	unsigned long	address;

	flash_init();
	for( address = FLASH_START_ADDRESS; address < FLASH_END_ADDRESS; address += FLASH_PAGE_SIZE )
		flash_page_erase( (unsigned long *)address, (unsigned long)0 );
#endif
#ifdef MCF5223x

	unsigned long	address;

	flash_init();
	for( address = FLASH_START_ADDRESS; address < FLASH_END_ADDRESS; address += FLASH_PAGE_SIZE )
		flash_page_erase( (unsigned long *)address, (unsigned long)0 );
#endif
#ifdef MCF5282

	unsigned long	address;

	flash_init();
	for( address = FLASH_START_ADDRESS; address < FLASH_END_ADDRESS; address += FLASH_PAGE_SIZE )
		flash_page_erase( (unsigned long *)address, (unsigned long)0 );
#endif
	return(0);
}