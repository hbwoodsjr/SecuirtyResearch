//*****************************************************************************
// Copyright (c) 2006, Freescale Semiconductor
// For use on Freescale products only.
//
// File name :   	emg_http.c
// Project name: 	emg_HTTP web server for ColdFire
// Author:			Eric Gregori
//		   			
//
// Description : 	HTTP/Web server with static and dynamic FFS support.
//					Dynamic HTML is supported via tokens in the HTML.
//					A key is used to support run time ( dynamic ) web page uploads.
//					Without the correct key, the download is rejected.
//					The web server supports multiple sessions as defined by EMG_HTTP_SESSION.
//					The web server supports 'GET', 'POST','EMG'.
//					EMG is a unique non-standard HTTP command to request a upload.
//					Uploading is done using the same server that serves up the web pages.
//					Long filenames are supported, along with subdirectories.
//
//*****************************************************************************
#include "ipport.h"
#include "tcpapp.h"
#include "msring.h"
#include "freescale_http_server.h"


//*****************************************************************************
// External Declarations
//*****************************************************************************
extern EMG_HTTP_SESSION 	freescale_http_sessions[];
extern const unsigned char 	*emg_static_ffs_ptrs[];
extern const unsigned short emg_static_ffs_len[];
extern const unsigned char 	emg_static_ffs_nof;
extern const unsigned long 	emg_static_ffs_type[];
extern const char 			*emg_static_ffs_filenames[];
extern void 				replace_with_sensor_data( char *body_buff, unsigned long length );
extern void 				collect_sensor_data( void );
extern volatile void 		flash_write( unsigned long *address, unsigned long data );
extern int					flash_ffs_lockout;		//FSL 0=dynamic flash file system present, 1=not present
extern const 				FORM_STRUCTURE forms[];
extern unsigned char BootloaderStatus;		//FSL added for S-Record upload routine for mcf52259
extern unsigned char S19FileDone;			//FSL added for S-Record upload routine for mcf52259
extern unsigned char FlashErased;			//FSL added for S-Record upload routine for mcf52259

//*****************************************************************************
// Local declarations
//*****************************************************************************
void emg_http_process( int i );
int  emg_http_connection( M_SOCK so );
void emg_http_delete( void );
void emg_http_remove( M_SOCK so );
void emg_http_read_header( int i, char *buffer );
void emg_process_header( int i, char *filename, int bytesread );
void emg_http_send_file( int session );
void emg_http_upload_file( int session, unsigned long *buffer );
void emg_http_erase_flash( int session, unsigned long *buffer );
void freescale_http_s19_upload_file( int session, unsigned char *buffer );	//FSL added for S-Record upload routine for mcf52259


//*****************************************************************************
// Ram used for sensor variable replacement
//*****************************************************************************
char scratch_ram_for_send[MAX_BYTES_TO_SEND];

//*****************************************************************************
// Global Variables
//*****************************************************************************
unsigned char		error_delay;


//*****************************************************************************
// Constant table defines acceptable HTTP commands
//*****************************************************************************
const HEADER_STRUCTURE header_table[] =
{
										{"GET",TYPE_GET},
										{"EMG",TYPE_UPLOAD},
										{"POST",TYPE_POST} 
};


//*****************************************************************************
// Upload password/key
//*****************************************************************************
const char key_string[] = "joshua";


//*****************************************************************************
// Keep Alive string for persistent connection
//*****************************************************************************
const char keep_alive_string[] = "Keep-Alive";


//*****************************************************************************
// int freescale_http_connection( M_SOCK s )   Written By Eric Gregori
//		   										
//
// This function is called when a connection is requested by the client.
// The socket parameter is the communication socket we should use to
// communicate with the client.
// The client is assigned 1 of the 4 possible freescale_http_session[] slots
// available, otherwise it is rejected.
//
// returns 1 on success, 0 on failure
//*****************************************************************************
int freescale_http_connection( M_SOCK s )
{
	int		i;
	int		found;
	
	// Walk the SESSION array looking for a invalid entry
	for( i=0, found=0; i<MAX_NUMBER_OF_SESSIONS; i++ )
	{
		if( freescale_http_sessions[i].valid != VALID_EMG_SESSION )
		{
			// Init session
			freescale_http_sessions[i].state  		= EMG_HTTP_STATE_WAIT_FOR_HEADER;
			freescale_http_sessions[i].socket 		= s;
			freescale_http_sessions[i].valid  		= VALID_EMG_SESSION;
			freescale_http_sessions[i].keep_alive  	= HTTP_KEEP_ALIVE_TIME;			
			found 									= 1;
#if HTTP_VERBOSE>2
			printf( "\nhttp %d started", i );
#endif			
			break;	
		}
	}
	
	return( found );
}

//*****************************************************************************
// freescale_http_delete() Written by Eric Gregori
//		   										
//
// Delete all sessions.  Only used for catastrophic failure and init
//*****************************************************************************
void freescale_http_delete( void )
{
	int		i;
	
	for( i=0; i<MAX_NUMBER_OF_SESSIONS; i++ )
		freescale_http_sessions[i].valid = INVALID_EMG_SESSION;
}

//*****************************************************************************
// Remove a session based on socket ID.
// Also, close the socket.
//
// Author: Eric Gregori
//		   
//*****************************************************************************
void freescale_http_remove( M_SOCK so )
{
	int		i,j;
	
	for( i=0; i<MAX_NUMBER_OF_SESSIONS; i++ )
	{
		if( freescale_http_sessions[i].valid == VALID_EMG_SESSION )
		{
			if( freescale_http_sessions[i].socket == so )
			{
//FSL invalidate the socket to make available for next client request
				freescale_http_sessions[i].valid = INVALID_EMG_SESSION;
                so->so_options |= SO_LINGER;
//FSL Linger closed transmit side but waits for final ACK on receive side
                so->linger = 1;  
				j = m_close( so );
				if( j>0 )
					printf( "\nFailure Closing Socket" );
#if HTTP_VERBOSE>2
				printf( "\nhttp closed %d", i );
#endif
			}
		}
	}	
}

//*****************************************************************************
// Process a single form assignment string.   vvvvvvvvv=ddddddddd0
//
// Author: Eric Gregori
//		   
// Note this is a weak implementation of a form lookup.  It works fine for our
// simple example but if many forms will be supported, a more robust approach is needed.
// The implementation below searches the *form_string until it finds "=".  It then
// checks the form[index].form_name[i] array to see that it is "0" as a weak
// validation we have found the correct form.  FSL approach is only looking for one
// of two possible forms that are implemented.
// Ex:  form_string = "led=LED1_TOGGLE"
//		forms[index].form_name[8] = "l","e","d",0,0,0,0,0
// 		So there are only 7 possible locations for the "=" to be in.
//		i.e. only unique form name lengths can be used.
//		FSL is using "led" and "serial" as form names.
//*****************************************************************************
void process_form( char *form_string ) 
{
	int		i, index;
	
	for( i=0, index=0; (forms[index].form_name[0] != 0); i++ )
	{
		if( (form_string[i] == '=') && (forms[index].form_name[i] == 0) )
		{
			// Call function, passing the function a pointer to &form_string[i+1]
			(forms[index].func)(&form_string[i+1]);		
			break;
		}
			
		if( forms[index].form_name[i] != form_string[i] )
		{
			i=0;
			index++;
			continue;
		}
	}
}

//*****************************************************************************
// Pre-process the filename string to act on form entries
// Form entries are identified with a '?'
//
// Author: Eric Gregori
//		   
//*****************************************************************************
void pre_process_filename( char *buffer )
{
	int		i, start, stop, j, k, index, next;
	
	// If no '?' is found, just return
	for( i=0, start=0; i<RECV_BUFFER_SIZE; i++ )
	{
		if( !buffer[i] )
			break;
	
		if( buffer[i] == '?' )
		{
			start = i;
			break;
		}
	}
	
	if( !start )
		return;
	
	// From start to buffer[i] == 0 is the full form string, it may contain multiple forms
	for( i=start, stop=0, start=0; i<RECV_BUFFER_SIZE; i++ )
	{
		if(buffer[i] == '?')
		{
			buffer[i] = 0;
		
			if( !start )
				start = i+1;
			else
			{
				stop = i;
				next = i+1;
			}
			
			continue;	
		}
		
		if( buffer[i] == 0 )
		{
			stop  = i;
			next  = 0;
		}
		
		if( stop )
		{			
			// Call Function
			process_form( &buffer[start]);
			
			if( !next )
				break; 
			else
			{
				start = 0;
				stop  = 0;
				i++;
			}
		}
	}
}

//*****************************************************************************
// Process the HTTP header.
//
// We currently support GET and EMG.
// GET is used to send a Web Page, EMG is used to upload runtime web pages.
//
// The default web page is the first web page in the file system.
// If a valid FFS is found in the dynamic region of flash, the dynamic
// region takes precendance over the static region.
//
// Long filenames are supported, and limited only by the FFS.
// A FFS revision number is supported for future FFS expansion/compatability.
// 
// For uploading, a key is used to protect the flash from non-authorized users.
// If the key is not valid, the upload is rejected.
//
// Author: Eric Gregori
//		   
//*****************************************************************************
void freescale_process_header( int session, char *buffer, int bytesread )
{
	int							i, k, j, found;
	int							charcount, dump;
	unsigned long				size;
	char						*filename;
	unsigned char				ch;
	volatile unsigned long		*fat_file_sys;
	volatile unsigned char		*fat_file_names;
	HEADER_TYPES 				ht;
	
	
	// Scan to /
	buffer[0] = 0;
	filename = buffer;
	for( i=0; i<bytesread; i++ )
	{
		if( buffer[i] == '/' )
		{
			filename = &buffer[++i];
			break;	
		}
	}
	
	ht = header_table[session].header_type;
	for( i=0; i<bytesread; i++ )
	{
		if( filename[i] == ' ' )
		{
			filename[i] = 0;
			break;
		}
	}

#if HTTP_VERBOSE>1	
	printf( "\nFile[%d] = %s\n", session, filename );
#endif

//FSL added TYPE_POST capability to allow upload of S19 S-Record via Web Browser
#ifdef MCF52259			//FSL devices ported too

	if( freescale_http_sessions[session].headertype == TYPE_POST )
	{		
		if( !filename[0] )
		{
			printf( "\nError with s-record file %s\n",filename );
			freescale_http_sessions[session].state = EMG_HTTP_STATE_CLOSE;
			return;	
		}
		freescale_http_sessions[session].state 		= EMG_HTTP_STATE_S19_UPLOAD_FILE;		
	}
#endif

	if( freescale_http_sessions[session].headertype == TYPE_GET )
	{
		collect_sensor_data( );
			
		if( filename[0] )
			pre_process_filename( filename );
		
		emg_web_open( session, filename );
		
		freescale_http_sessions[session].state = EMG_HTTP_STATE_SEND_FILE;			

	} // end of if TYPE_POST

	if( freescale_http_sessions[session].headertype == TYPE_UPLOAD )
	{		
		// Use filename as key.  Unless filename matches key, do not allow
		// upload
		for( j=0; filename[j]; j++ )
		{
			if( filename[j] != key_string[j] )
				break;
		}
		
		if( filename[j] )
		{
			printf( "\nInvalid Key" );
			freescale_http_sessions[session].state = EMG_HTTP_STATE_CLOSE;
			return;	
		}
		
		// Use file size to indicate the # of byte to download
		// After the filename, the next 4 bytes are the size
		i++;
		// i now points to the MSB byte
		ch = filename[i];
		size = ch;
		size <<= 8;
		ch = filename[i+1];
		size += ch;
		size <<= 8;
		ch = filename[i+2];
		size += ch;
		size <<= 8;
		ch = filename[i+3];
		size += ch;
		 
		freescale_http_sessions[session].file_size  = size;
		freescale_http_sessions[session].file_index = FLASH_START_ADDRESS;
		freescale_http_sessions[session].state 		= EMG_HTTP_STATE_ERASE_FLASH;	
	}
	else
	{
		// Pitch the rest of the header.
		// The header is complete when a blank line 0D0A0D0A is sent
		dump 		= bytesread;
		k    		= 0;
		found		= 0;
		charcount 	= 0;
		size 		= cticks;
		do
		{
			for( i=0; i<dump; i++ )
			{
#if HTTP_VERBOSE>1
				if( (buffer[i] == 0x0D) || (buffer[i] == 0x0A) )
					printf( "!" );
				else
					printf( "%c", buffer[i] );
#endif			
				if( (buffer[i]==0x0D) || (buffer[i]==0x0A) )
					charcount++;
				else
					charcount = 0;
		
				if( charcount == 4 )
					break;
				
				if( buffer[i] == keep_alive_string[k] )
				{
					k++;
					if( keep_alive_string[k] == 0 )
					{
						found = 1;
#if HTTP_VERBOSE>0
						printf( "\nKeep-Alive flag set" );
#endif
						k = 0;
					}					
				}
				else
					k = 0;
			}
			
//			printf( " %x", dump );
			if( charcount == 4 )
			{
#if HTTP_VERBOSE>1
				printf( "\nend of header " );
				if( found )
					printf( "keep-alive" );
#endif				
				break;
			}
			
			dump = m_recv( freescale_http_sessions[session].socket, (char *)buffer, RECV_BUFFER_SIZE );
		}		
		while( (cticks-size)<2);		

		if( found )
			freescale_http_sessions[session].keep_alive = HTTP_KEEP_ALIVE_TIME;
		else
			freescale_http_sessions[session].keep_alive = 0;
	}
}

//*****************************************************************************
// HTTP read header.
//
// The HTTP header must be smaller then a packet of MTU size.
// Process header up to filename.
//
// Author: Eric Gregori
//		   
//*****************************************************************************
void freescale_http_read_header( int session, char *buffer )
{
	HEADER_TYPES	i;
	int				length, j, k;


	if( freescale_http_sessions[session].keep_alive  ) 
	{
		freescale_http_sessions[session].keep_alive--;
	}

	// PARAM1: M_SOCK socket,
	// PARAM2: char * buffer
	// PARAM3: unsigned length
	//
	// RETURNS: number of bytes actually read, or -1 if error. 
	// int m_recv(M_SOCK so, char * buf, unsigned buflen)
	length = m_recv( freescale_http_sessions[session].socket, (char *)buffer, RECV_BUFFER_SIZE );
	
	if( length < 0 )
	{
		if( !freescale_http_sessions[session].keep_alive )
			freescale_http_sessions[session].state = EMG_HTTP_STATE_CLOSE;	
		return;
	}
	
	// Scan through the buffer looking for 
	for( i=NO_HEADER_FOUND; header_table[i].header_string[0]; i++ )
	{
		for( j=0, k=0; j<length; j++ )
		{
			if( buffer[j] == header_table[i].header_string[k] )
				k++;
		
			if( header_table[i].header_string[k] == 0 )
			{
#if HTTP_VERBOSE>3
				printf( "\n header[%d] = %s", session, &header_table[i].header_string[0] );
#endif				
				freescale_http_sessions[session].headertype = header_table[i].header_type;

				freescale_process_header( session , buffer, length );						
				return;								
			}
		}
	}
	
	// If we get here, then 
	//					We do not support the method 'GET', 'POST', 'EMG'
	// The only thing we can do is close the socket
	freescale_http_sessions[session].state = EMG_HTTP_STATE_CLOSE;	
}

//*****************************************************************************
// This function sends the file in chunks of MAX_BYTES_TO_SEND.
// As long as the freescale_http_sessions[session].state = EMG_HTTP_STATE_SEND_FILE more
// chunks are sent from the file on each pass through the task control block list.
// It is executed by the state machine.
// 
// Use a sliding window to process dynamic HTML tokens.
// Normally packet processing is done using Zero-Copy, only when a section
// contains a token, is it copied to temporary RAM. 
//
// Author: Eric Gregori
//		   
//*****************************************************************************
void freescale_http_send_file( int session )
{
	unsigned long		length, i, token_end;
	int					bytes_sent;
	char				*data;
	unsigned char		byte_read;
	unsigned char		override_protocol;


		override_protocol = 0;	
	
	// If it is a dynamic file type HTML or TEXT
	// Copy the file up to MAX_BYTES_TO_SEND, 
	// or to a DYNAMIC_REPLACE_TOKEN, DYNAMIC_COMPARE_TOKEN 
	if( (freescale_http_sessions[session].file_type == FILE_TYPE_DYANMIC1 ) ||
		(freescale_http_sessions[session].file_type == FILE_TYPE_DYANMIC2) )
	{
		// If the file is less then MAX_BYTES_TO_SEND
		// then we can handle it in a more efficient manner.
		if( freescale_http_sessions[session].file_size < MAX_BYTES_TO_SEND )
		{
			length = emg_web_read( session, scratch_ram_for_send, MAX_BYTES_TO_SEND );
			replace_with_sensor_data( scratch_ram_for_send, length );
		}
		else
		{
			// Scan the buffer from the end, looking for a token
			length = emg_web_read( session, scratch_ram_for_send, MAX_BYTES_TO_SEND );
			for( i=length; i; i-- )
			{
				if((scratch_ram_for_send[i] == DYNAMIC_REPLACE_TOKEN) ||
			   	   (scratch_ram_for_send[i] == DYNAMIC_COMPARE_TOKEN) )
				{
					replace_with_sensor_data( scratch_ram_for_send, i );
					if(scratch_ram_for_send[i] == DYNAMIC_EOS_TOKEN)
						i++;
					else
					i--;
					
					emg_web_rewind( session, (length-i) );
					length = i;
					break;					
				}			   	   
#if 0		
/* FSL #if out the following code as it was redundant because in the replace_with_sensor_data()
		the routine searches the buffer looking for TOKENS and if not found exits.  This
		is a waste of code/time.  So might as well only search the buffer when a TOKEN is
		found.
		Note that the code here searches the buffer from back to front and the
		replace_with_sesnor_data() searched the buffer front to back.  This seems to help
		reduce the amount of buffer to search for TOKEN and End of TOKE semicolon.
		Leaving the code here should there be a test case that shows it is needed.
*/				
			   	else if(scratch_ram_for_send[i] == DYNAMIC_EOS_TOKEN )
				{
					i++;
					replace_with_sensor_data( scratch_ram_for_send, i );
					
					emg_web_rewind( session, (length-i) );
					length = i;
					break;
				}
#endif				
			}	//end for
		}	//end else
	}	//end if
	else	//Not HTML or TEXT file type
	{
		length = emg_web_read( session, scratch_ram_for_send, MAX_BYTES_TO_SEND );		
	}

	if( length )	//FSL As long as greater than zero bytes, read then send data to client
	{		
		if( override_protocol )
		{
			scratch_ram_for_send[7] = '0';	
		}
		//FSL send the data to the client
		bytes_sent = m_send( freescale_http_sessions[session].socket, scratch_ram_for_send, length );
#if HTTP_VERBOSE>4
		printf( "\nses %d, bytes %d ", session, bytes_sent ); 
#endif

		tk_yield( );					//FSL Checks to see if other task(s) need to run

		if( bytes_sent >= 0)
		{
			error_delay = 0;	//FSL Reset the delay counter
		}
		else
		{
			if(( freescale_http_sessions[session].socket->error == EWOULDBLOCK ) || ( freescale_http_sessions[session].socket->error == ENP_RESOURCE ))  //FSL added test for ENP_RESOURCE system error
			{
				error_delay++;			//FSL Increment delay counter
				if( error_delay > 80 )	//FSL If delay counter expired, change http state to CLOSE
				{
					freescale_http_sessions[session].state = EMG_HTTP_STATE_CLOSE;					
					printf( "\n\nStack failed due to blocking" );
				}
			}
			
			// If socket reported a error, or would block,
			// Give some extra time to sleep.
			tk_sleep( 10 );		//FSL The sleep lets transmit buffers and heap space free up (hopefully)
		}		
	}		//end if (length)
	else	//length=0, no data to send so update session control
	{
#if HTTP_VERBOSE>2
		printf( "\n%d bytes sent[%d]", 	freescale_http_sessions[session].file_index, session );
#endif
		if( freescale_http_sessions[session].keep_alive  )	//FSL if keep-alive >0 then wait for header
		{
			freescale_http_sessions[session].state = EMG_HTTP_STATE_WAIT_FOR_HEADER;	//FSL change state from EMG_HTTP_STATE_SEND_FILE
		}
		else 												//FSL keep-alive = 0 (i.e. it timed out), close session
		{
			freescale_http_sessions[session].state = EMG_HTTP_STATE_CLOSE;				//FSL change state from EMG_HTTP_STATE_SEND_FILE
		}
	}	//end else	

}

//*****************************************************************************
// Process a S19_UPLOAD file.
// As packets are received they are sent ParseS19() function to be programmed
// to flash.
//
//FSL might be cool to enable sending to SRAM too.
//
// Packets are processed on a 32bit boundary.
// At the completion of a upload, a "complete" packet is sent for handshaking.
//
// Author: Eric Gregori
//		   
//			Modified by David Seymour
//*****************************************************************************
#define MAX_SREC_SEG_SIZE	80
#define B_INDEX				20

static unsigned char s19_buffer[B_INDEX][MAX_SREC_SEG_SIZE];
static unsigned long buffer_copy[MAX_ETH_PKT/4];
static int p_seg_length;
static int first_pass=TRUE;
static int bindex;
static int retry=0;

#ifdef MCF52259
void freescale_http_s19_upload_file( int session, unsigned char *buffer )
{
	volatile int	length, remaining_length, seg_length, parsing, j;
    volatile unsigned char c, type;
    unsigned char *ebuffer;
    
	// PARAM1: M_SOCK socket,
	// PARAM2: char * buffer
	//
	// RETURNS: nothing 
	// int m_recv(M_SOCK so, char * buf, unsigned buflen)
	length = m_recv( freescale_http_sessions[session].socket, (char *)buffer_copy, MAX_ETH_PKT );
	remaining_length = length;
	ebuffer = (unsigned char *)&buffer_copy;
	
	if( length < 0 )
	{
		if(first_pass)
		{
			asm(	nop);
			return;
		}
		
		if(retry++ > 100)
		{
			first_pass=TRUE;
			retry=0;
			S19FileDone = FALSE;
			FlashErased = FALSE;
			sprintf( (char *)ebuffer, "TIMEOUT:  S-Record Upload Failed" );	//FSL string copy text to buffer

	#if HTTP_VERBOSE>1
			printf( "\n%s", ebuffer );		
			printf( "\nHit enter to return to prompt" );
	#endif		
			
			j = strlen((char *)ebuffer)+1;
			for( length = 0; length < j; )	//FSL send buffer....if successful, exit for loop.  If unsuccessful re-try (re-loop)
			{
				length = m_send( freescale_http_sessions[session].socket, (char *)ebuffer, j );
				tk_sleep( 10 );
			}
		
			freescale_http_sessions[session].state = EMG_HTTP_STATE_CLOSE;		
		
			return;
			
		}
		else
		{
			if((BootloaderStatus == 3) && (S19FileDone == TRUE))		// S-Record reading done
			{
				first_pass=TRUE;
				retry=0;
				S19FileDone = FALSE;
				FlashErased = FALSE;
				sprintf( (char *)ebuffer, "S-Record Upload Complete" );	//FSL string copy text to buffer

		#if HTTP_VERBOSE>1
				printf( "\n%s", ebuffer );		
				printf( "\nHit enter to return to prompt" );
		#endif		
				
				j = strlen((char *)ebuffer)+1;
				for( length = 0; length < j; )	//FSL send buffer....if successful, exit for loop.  If unsuccessful re-try (re-loop)
				{
					length = m_send( freescale_http_sessions[session].socket, (char *)ebuffer, j );
					tk_sleep( 10 );
				}
			
				freescale_http_sessions[session].state = EMG_HTTP_STATE_CLOSE;		
				return;
				
			}
			tk_sleep(10);	// sleep some and wait for more data
			return;
		}
		
	}
	
#if HTTP_VERBOSE>1
	printf( "\nData size: 0x%x", length );
#endif

#if 0	
//FSL emg_web_write uses the web server to update dynamic flash file system.
	emg_web_write( session, ebuffer, length );	//FSL Open a file by initializing the web server session structure	
#else

	if(s19_buffer[0][0] == 'P')				// if partial segment present
	{
		for(j=0;j<MAX_SREC_SEG_SIZE;j++)
		{
		  if(j<MAX_SREC_SEG_SIZE-p_seg_length)
		  {
			s19_buffer[1][j] = s19_buffer[0][j];	// copy from segment 0 to segment 1 to free up segment 0 for future partial segment
		  }
		  else
		  {
		    if(*ebuffer != 'S')
		    {
				s19_buffer[1][j] = *(ebuffer)++;		//FSL get ASCII char from buffer
				remaining_length--;		//FSL decrement length counter
		    }
		    else
		    {
		    	s19_buffer[0][j] = 0;	// clear remaining buffer locations
		    }
		  }
		  s19_buffer[0][j] = 0;						// clear old partial buffer
		}
		s19_buffer[1][0] = 'S';	// flag segment 1 valid
		bindex += 1;			// increment S-Record segment index
	}

  do
  {
  	if(first_pass == TRUE)	
  	{
  		
		bindex = 1;			// reserve first array (s19_buffer[0][0]) for partial S-Record segment
		S19FileDone = FALSE;
		for(;;)				// Find 0x0d,0x0a,0x0d,0x0a,"S"
		{
			if( (*(ebuffer+0)==0x0d) & (*(ebuffer+1)==0x0a) & (*(ebuffer+2)==0x0d) & (*(ebuffer+3)==0x0a) & (*(ebuffer+4)=='S') )
			{
				ebuffer+=5;
				remaining_length-=5;
				break;
			}
			ebuffer++;
			remaining_length--;
			if(!remaining_length)	//FSL if length=0, close session and exit routine
			{
				asm(	halt);
				return;				//FSL exit routine
			}	
			 
		}	//end for loop
		first_pass=FALSE;
  	}
  	else
  	{
  		
		for(;;)		// Find "S"
		{
			c = *(ebuffer)++;		//FSL get ASCII char from buffer
			remaining_length--;		//FSL decrement length counter
			if(c == 'S')			//FSL if found "S" break from infinite loop
				break;
			if(!remaining_length)
			{
				parsing=FALSE;
				break;				//FSL exit for(;;)
			}	
		}	//end for loop
  	}
	
	if(!remaining_length)
	{
		break;				//FSL exit do while()
	}	
// Get type of S-record 
    type = *(ebuffer)++;
	remaining_length--;		//FSL decrement length counter
	parsing=TRUE;
  	
	for(;;)		// Copy S-Record segments to local buffer (s19_buff[][]) from Ethernet buffer
	{
		// Get length of S-Record segment	
		seg_length = (int)GetSpair(ebuffer);	// Note seg_length is length in byte pairs!
		if(seg_length*2 > remaining_length)		// partial S-Record segment in ebuffer
		{
			ebuffer = ebuffer - 2;	// backup pointer to "S" 
			remaining_length+=2;	// must add two to include the header bytes
			p_seg_length = MAX_SREC_SEG_SIZE - remaining_length;	// save partial segment length
			for(j=0;remaining_length--;j++)
			{
				s19_buffer[0][j] = *(ebuffer)++;	// store partial segment
			}
			s19_buffer[0][0] = 'P';					// flag segment as partical
			parsing=FALSE;	// exit parameter for do while loop.
			break;			// exit for(;;) loop
		}
		else									// complete S-Record segment in ebuffer
		{
			ebuffer = ebuffer - 2;	// back point up to "S" 
			remaining_length+=2;	// must add four to include the header bytes
			for(j=0;j<seg_length*2+4;j++)
			{
				s19_buffer[bindex][j] = *(ebuffer)++;	// copy S-Record segment
				remaining_length--;						// decrement length counter
			}
			bindex = bindex+1;		// increment bindex to fill next S-Record segment
			if(bindex>=20)
			{
				printf( "\nERROR: bindex overflow \n");
				asm(	halt);
				return;
			}
			if(remaining_length<=0)
				parsing=FALSE;	//exit parameter for do while loop.
			break;				// exit for(;;) loop
		}
	}	//end for loop
  }while(parsing);
	
	for(j=0;j<20;j++)
	{
		if(s19_buffer[j][0] == 'S')	// "S" indicates valid S-Record segment
		{
			ParseS19(&s19_buffer[j][0]);
//			printf("%s\n", &s19_buffer[j][0]);
			s19_buffer[j][0]=0;		// invalidate the S-Record segment to free it
		}
		bindex = 1;		// reserve first array (s19_buffer[0][0]) for partial S-Record segment
	}
	
#endif

#if 0	
//FSL if statement to determine when flashing of s19 file is complete
//FSL Probably can test for no more "S"'s in the s-record
//		flash_ffs_lockout = 0;		//FSL 0=dynamic flash file system present, 1=not present
	
		sprintf( (char *)ebuffer, "Upload Complete" );	//FSL string copy text to buffer

#if HTTP_VERBOSE>1
		printf( "\n%s", ebuffer );		
		printf( "\nHit enter to return to prompt" );
#endif		
		
		j = strlen((char *)ebuffer)+1;
		for( length = 0; length < j; )	//FSL send buffer....if successful, exit for loop.  If unsuccessful re-try (re-loop)
		{
			length = m_send( freescale_http_sessions[session].socket, (char *)ebuffer, j );
			tk_sleep( 10 );
		}
	
		freescale_http_sessions[session].state = EMG_HTTP_STATE_CLOSE;		
#endif 		
}
#endif

//*****************************************************************************
// Process a UPLOAD file.
// As packets are received they are sent to the flash writer.
// Packets are processed on a 32bit boundary.
// At the completion of a upload, a "complete" packet is sent for handshaking.
//
// Author: Eric Gregori
//		   
//*****************************************************************************
void freescale_http_upload_file( int session, unsigned long *buffer )
{
	int				length, j;

	// PARAM1: M_SOCK socket,
	// PARAM2: char * buffer
	//
	// RETURNS: number of bytes actually read, or -1 if error. 
	// int m_recv(M_SOCK so, char * buf, unsigned buflen)
	length = m_recv( freescale_http_sessions[session].socket, (char *)buffer, RECV_BUFFER_SIZE );
	
	if( length < 0 )
		return;
	
#if HTTP_VERBOSE>1
	printf( "\nData size: 0x%x", length );
#endif
	
	emg_web_write( session, buffer, length );	//FSL Open a file by initializing the web server session structure	
	
#if HTTP_VERBOSE>1
	printf( "  Remaining: 0x%x", freescale_http_sessions[session].file_size );
#endif
		
	if( freescale_http_sessions[session].file_size < 4 )
	{
//		flash_write( (unsigned long *)freescale_http_sessions[session].file_index, buffer[j] );	
		freescale_http_sessions[session].file_size = 0;
	}	
	
	if( (freescale_http_sessions[session].file_size == 0) ||
		(freescale_http_sessions[session].file_size & 0xF0000000) )
	{
		flash_ffs_lockout = 0;		//FSL 0=dynamic flash file system present, 1=not present
	
		sprintf( (char *)buffer, "Upload Complete" );	//FSL string copy text to buffer

#if HTTP_VERBOSE>1
		printf( "\n%s", buffer );		
		printf( "\nHit enter to return to prompt" );
#endif		
		
		j = strlen((char *)buffer)+1;
		for( length = 0; length < j; )	//FSL send buffer....if successful, exit for loop.  If unsuccessful re-try (re-loop)
		{
			length = m_send( freescale_http_sessions[session].socket, (char *)buffer, j );
			tk_sleep( 10 );
		}
	
		freescale_http_sessions[session].state = EMG_HTTP_STATE_CLOSE;		
	}
}


//*****************************************************************************
// Process erase flash state.
// Flash is erased in small chunks to avoid letting the TCP/IP connection idleing.
// Acks are sent after each chunk is erased.
//
// Author: Eric Gregori
//		   
//*****************************************************************************
void freescale_http_erase_flash( int session, unsigned long *buffer )
{
	unsigned long	address;
	unsigned long	end_address;
	unsigned long	length, j;

	
	if( freescale_http_sessions[session].file_size  >
  		emg_web_flash_parms((unsigned long)'size',session))
	{
		sprintf( (char *)buffer, "\n\nFile Too Big" );	//FSL string copy text to buffer
		printf( "%s", buffer );
		freescale_http_sessions[session].state = EMG_HTTP_STATE_CLOSE;
		j = strlen((char *)buffer)+1;
		for( length = 0; length < j; )	//FSL Send the text sring in "buffer"
		{	
			length = m_send( freescale_http_sessions[session].socket, (char *)buffer, j );	//FSL if m_send successful then the "length" (i.e. bytes sent) will break/terminate the for loop
			tk_sleep( 10 );
		}

		return;				
	}

	flash_ffs_lockout = 1;		//FSL 0=dynamic flash file system present, 1=not present
	address = emg_web_erase( session );

	sprintf( (char *)buffer, "Erasing Flash 0x%x block address", address&0x000FFFFF );	//FSL string copy text to buffer

#if HTTP_VERBOSE>1
	printf( "\n%s", buffer );
#endif

	j = strlen((char *)buffer)+1;
	for( length = 0; length < j; )	//FSL Send the text sring in "buffer"
	{
		length = m_send( freescale_http_sessions[session].socket, (char *)buffer, j );	//FSL if m_send successful then the "length" (i.e. bytes sent) will break/terminate the for loop
		tk_sleep( 10 );
	}

	if( address < emg_web_flash_parms((unsigned long)'endd',session) )
		freescale_http_sessions[session].file_index = address;		
	else
	{
		freescale_http_sessions[session].file_index = emg_web_flash_parms((unsigned long)'strt',session);
		freescale_http_sessions[session].state 		= EMG_HTTP_STATE_UPLOAD_FILE;	
		sprintf( (char *)buffer, "Erase Complete" );	//FSL string copy text to buffer

#if HTTP_VERBOSE>1
		printf( "\n%s", buffer );
#endif		
		
		j = strlen((char *)buffer)+1;
		for( length = 0; length < j; )	//FSL Send the text string in "buffer"
		{
			length = m_send( freescale_http_sessions[session].socket, (char *)buffer, j );	//FSL if m_send successful then the "length" (i.e. bytes sent) will break/terminate the for loop
			tk_sleep( 10 );
		}
	}	
}


//*****************************************************************************
// The HTTP server state machine.
// We allocate a RAM buffer here, and pass it down to conserver RAM.
// The buffer is long aligned to facilitate uploading, do not change.
// 
// Author: Eric Gregori
//		   
//*****************************************************************************
void freescale_http_process( int session )
{
	// Pass buffer to preserve RAM

	unsigned long	buffer[RECV_BUFFER_SIZE/4];

	if( freescale_http_sessions[session].valid == VALID_EMG_SESSION )
	{
		switch( freescale_http_sessions[session].state )
		{
			case EMG_HTTP_STATE_WAIT_FOR_HEADER:
				freescale_http_read_header( session, (char *)buffer );
				break;
				
			case EMG_HTTP_STATE_SEND_FILE:
				freescale_http_send_file( session );
				break;
				
			case EMG_HTTP_STATE_CLOSE:
				freescale_http_remove( freescale_http_sessions[session].socket );
				break;
				
			case EMG_HTTP_STATE_UPLOAD_FILE:
				freescale_http_upload_file( session, buffer );
				break;
#ifdef MCF52259				
			case EMG_HTTP_STATE_S19_UPLOAD_FILE:
				freescale_http_s19_upload_file( session, (unsigned char *)buffer );
				break;
#endif				
			case EMG_HTTP_STATE_ERASE_FLASH:
				freescale_http_erase_flash( session, buffer );
				break;
			
			default:
				// This cannot be good
				dprintf( "\nIllegal HTTP state" );
				freescale_http_sessions[session].valid = INVALID_EMG_SESSION;
				break;	
		}
	}	
}


//*****************************************************************************
// Dump the HTTP session array
// 
// Author: Eric Gregori
//		   
//*****************************************************************************
int	emg_http_sessions( void *pio  )
{
	unsigned long	i, fp, so; 
	

	ns_printf(pio, "\n\nHTTP sessions array Dump" );
	
	ns_printf( pio, "\n\nSTATE     VALID     KEEP_ALIVE     FILE_POINTER     SOCKET" );
	
	for( i=0; i<MAX_NUMBER_OF_SESSIONS; i++ )
	{
		switch( freescale_http_sessions[i].state )
		{
			case EMG_HTTP_STATE_WAIT_FOR_HEADER:
				ns_printf( pio, "\nWait for header     " );
				break;
				
			case EMG_HTTP_STATE_SEND_FILE:
				ns_printf( pio, "\nSend     " );
				break;
				
			case EMG_HTTP_STATE_CLOSE:
				ns_printf( pio, "\nClose     " );
				break;
				
			case EMG_HTTP_STATE_UPLOAD_FILE:
				ns_printf( pio, "\nUpload     " );
				break;
				
			case EMG_HTTP_STATE_ERASE_FLASH:
				ns_printf( pio, "\nErase     " );
				break;
			
			default:
				// This cannot be good
				ns_printf( pio, "\nInvalid     " );
				break;	
		}
	
		if( freescale_http_sessions[i].valid )
			ns_printf( pio, "Valid     " );
		else
			ns_printf( pio, "Not Valid     " );
		
		ns_printf( pio, "%d     ", freescale_http_sessions[i].keep_alive );
		
		fp = (unsigned long)freescale_http_sessions[i].file_pointer;
		so = (unsigned long)freescale_http_sessions[i].socket;
			
		ns_printf( pio, "0x%x     ", fp );
		ns_printf( pio, "0x%x     ", so );
	}
	
	ns_printf( pio, "\n\n" );
	
	return(0);
}
