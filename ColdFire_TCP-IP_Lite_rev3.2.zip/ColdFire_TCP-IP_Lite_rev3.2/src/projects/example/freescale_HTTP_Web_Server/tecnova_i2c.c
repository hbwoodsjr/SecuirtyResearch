/*********************************************************************
*
* SOURCE FILENAME:	I2C.c
*
* DATE CREATED:			1 June 2006
*
* PROGRAMMER:				Karl Kobel
*
* DESCRIPTION:  		I2C driver module
*
* Copyright (c) 2006 Tecnova.
* All rights reserved. 
* 
* Redistribution and use in source and binary forms, with or without modification, 
* are permitted provided that the following conditions are met:
*
* 1. Redistributions of source code must retain the above copyright notice,
*    this list of conditions and the following disclaimer.
* 2. Redistributions in binary form must reproduce the above copyright notice,
*    this list of conditions and the following disclaimer in the documentation
*    and/or other materials provided with the distribution.
* 3. The name of the author may not be used to endorse or promote products
*    derived from this software without specific prior written permission. 
*
* THIS SOFTWARE IS PROVIDED BY THE AUTHOR ``AS IS'' AND ANY EXPRESS OR IMPLIED 
* WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF 
* MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT 
* SHALL THE AUTHOR BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, 
* EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT 
* OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS 
* INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN 
* CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING 
* IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY 
* OF SUCH DAMAGE.
*
* Tecnova
* 1486 Saint Paul Avenue
* Gurnee, IL  60031-2129
* U.S.A.
 
* Telephone: +1.847.662.6260
* Facsimile: +1.847.336.7288
* Internet:  www.Tecnova.com
*
*********************************************************************/
#include "common.h"
#ifdef M52233DEMO
#include "MCF52235_I2C.h"			//DES is this needed for serial flash support???
#endif

/*********************************************************************
*
*							DEFINITIONS
*
*********************************************************************/

#define CLEAR						0
#define SET							1

#define I2C_TIMEOUT     500000

#define I2C_BUS_SPEED	0x19

#define MASTER_ADDRESS	0x70

#define TX_BUFFER_SIZE	512
#define RX_BUFFER_SIZE	512

/*********************************************************************
*
*							FUNCTION PROTOTYPES
*
*********************************************************************/

__declspec(interrupt) void _I2CISR(void);

/*********************************************************************
*
*							GLOBAL VARIABLES
*
*********************************************************************/

//unsigned char TxPacket[TX_BUFFER_SIZE];		// global transmit packet
unsigned char *TxPacketpositionptr;				// pointer to current location in transmit packet
unsigned int TxPacketBytes;

unsigned char TxBufferemptyflag;					// global flag for transmit functionality

//unsigned char RxPacket[RX_BUFFER_SIZE];		// global receive packet
unsigned char *RxPacketpositionptr;				// pointer to current location in receive packet 
unsigned int RxPacketBytes;

unsigned char RxBufferfullflag = 0, MasterRxFlag = 0;	// global flags for receive functionality
unsigned char TxCompleteflag = 0, RxCompleteflag = 0;	// global flags for ISR functionality

/*********************************************************************
*
*							STATIC VARIABLES
*
*********************************************************************/

/*********************************************************************
*
*							CODE
*
*********************************************************************/

/*********************************************************************
*
* FUNCTION:			I2C_Write
*
* ARGUMENTS:		unsigned char slaveAddress	- Slave address (the code will take care of avoiding the R/W bit
*								unsigned char* pbPacket			- Pointer to the data to write
*								unsigned int bNbytes				- The length of the data to write
*								unsigned char bWait					- Non-zero = wait for transmittion to complete
*
* RETURNS:			none
*
* DESCRIPTION:	Procedure which sends data on the I2C bus
*              
* RESTRICTIONS:	Puts the I2C module in master mode
*
*********************************************************************/
void I2C_Write(unsigned char slaveAddress, unsigned char* pbPacket, unsigned int bNbytes, unsigned char bWait)
{

#ifdef MCF5223x
	long i;
    

	TxPacketpositionptr = pbPacket;	// point to first Packet element
	TxPacketBytes = bNbytes;
	TxBufferemptyflag = CLEAR;
	MasterRxFlag = CLEAR;

	/* wait until bus is free */
	for(i = 0; i < I2C_TIMEOUT; i++)
	{
		if((MCF_I2C_I2SR & MCF_I2C_I2SR_IBB) == 0)
		{
			break;										
		}
	}

	MCF_GPIO_PORTTC &= ~MCF_GPIO_PORTTC_PORTTC3; // TURN HB LED ON
	
  /* Pin assignments for port AS 
         Pin AS3 : GPIO input 
         Pin AS2 : GPIO input 
         Pin AS1 : IIC serial data, SDA 
         Pin AS0 : IIC serial clock, SCL */
  MCF_GPIO_DDRAS = 0;
  MCF_GPIO_PASPAR = MCF_GPIO_PASPAR_PASPAR1(0x1) |
                    MCF_GPIO_PASPAR_PASPAR0(0x1);


	MCF_INTC0_ICR17 = MCF_INTC_ICR_IL(0x1);
	MCF_INTC0_IMRL &= ~MCF_INTC_IMRL_INT_MASK17;

	MCF_I2C_I2FDR = MCF_I2C_I2FDR_IC(I2C_BUS_SPEED);

	MCF_I2C_I2ADR = MCF_I2C_I2ADR_ADR(MASTER_ADDRESS);

	MCF_I2C_I2CR = MCF_I2C_I2CR_IEN;
	MCF_I2C_I2CR |= MCF_I2C_I2CR_IIEN;
	MCF_I2C_I2CR |= MCF_I2C_I2CR_MTX;
	MCF_I2C_I2CR |= MCF_I2C_I2CR_MSTA;
	
	MCF_I2C_I2DR = MCF_I2C_I2ADR_ADR(slaveAddress);
	
	if(bWait)
	{
		// wait while message is transmitted
		for(i = 0; i < I2C_TIMEOUT; i++)
		{
			if(TxBufferemptyflag != CLEAR)
			{
			    break;										
			}
		}
	}

	MCF_GPIO_PORTTC |= MCF_GPIO_PORTTC_PORTTC3; // TURN HB LED OFF
#endif
}
	
/*********************************************************************
*
* FUNCTION:			I2C_Read
*
* ARGUMENTS:		unsigned char slaveAddress	- Slave address (the code will take care of avoiding the R/W bit
*								unsigned char* pbPacket			- Pointer to the read data buffer
*								unsigned int bNbytes				- The length of the data to read
*
* RETURNS:			none
*
* DESCRIPTION:	Procedure which receives data on the I2C bus
*              
* RESTRICTIONS:	Puts the I2C module in master mode
*
*********************************************************************/
void I2C_Read(unsigned char slaveAddress, unsigned char* pbPacket, unsigned int bNbytes)
{

#ifdef MCF5223x

 	long i;
  	
	MCF_GPIO_PORTTC &= ~MCF_GPIO_PORTTC_PORTTC3; // TURN HB LED ON

	RxPacketpositionptr = pbPacket;		// point to first Packet element
	RxPacketBytes = bNbytes;
	RxBufferfullflag = CLEAR;
	
	MasterRxFlag = SET;
	TxCompleteflag = CLEAR;
	
	/* wait until bus is free */
	for(i = 0; i < I2C_TIMEOUT; i++)
	{
		if((MCF_I2C_I2SR & MCF_I2C_I2SR_IBB) == 0)
		{
 	    break;										
  	}
	}

  /* Pin assignments for port AS 
         Pin AS3 : GPIO input 
         Pin AS2 : GPIO input 
         Pin AS1 : IIC serial data, SDA 
         Pin AS0 : IIC serial clock, SCL */
  MCF_GPIO_DDRAS = 0;
  MCF_GPIO_PASPAR = MCF_GPIO_PASPAR_PASPAR1(0x1) |
                    MCF_GPIO_PASPAR_PASPAR0(0x1);


	MCF_INTC0_ICR17 = MCF_INTC_ICR_IL(0x1);
	MCF_INTC0_IMRL &= ~MCF_INTC_IMRL_INT_MASK17;

	MCF_I2C_I2FDR = MCF_I2C_I2FDR_IC(I2C_BUS_SPEED);

	MCF_I2C_I2ADR = MCF_I2C_I2ADR_ADR(MASTER_ADDRESS) | 0x01;

	MCF_I2C_I2CR = MCF_I2C_I2CR_IEN;
	MCF_I2C_I2CR |= MCF_I2C_I2CR_IIEN;
	MCF_I2C_I2CR |= MCF_I2C_I2CR_MTX;
	MCF_I2C_I2CR |= MCF_I2C_I2CR_MSTA;
	
	MCF_I2C_I2DR = MCF_I2C_I2ADR_ADR(slaveAddress) | 0x01;

	for(i = 0; i < I2C_TIMEOUT; i++)
	{
		if(RxBufferfullflag != CLEAR) 		        // while bus is busy
		{
			break;										
		}
	}

	MCF_GPIO_PORTTC |= MCF_GPIO_PORTTC_PORTTC3; // TURN HB LED OFF
#endif
}	
	
	
/*********************************************************************
*
* FUNCTION:		_I2CISR
*
* ARGUMENTS:	none
*
* RETURNS:		none
*
* DESCRIPTION:	Interrupt service routine for I2C module.
*              
* RESTRICTIONS:	The slave portion has not been tested
*
*********************************************************************/
__declspec(interrupt) void _I2CISR(void)
{
#ifdef MCF5223x

	volatile unsigned char dummyibdrRead;				// variable to allow dummy reads of IBDR
	
	MCF_I2C_I2SR &= ~MCF_I2C_I2SR_IIF;					// reset the interrupt
	if(MCF_I2C_I2CR & MCF_I2C_I2CR_MSTA)				// if module is in master mode
	{
		if(MCF_I2C_I2CR & MCF_I2C_I2CR_MTX)				// if module is to transmit
		{
			if(TxCompleteflag == SET) 							// if the last byte has been transmitted
			{
				TxCompleteflag = CLEAR;								// clear the ISR transmit complete flag
				MCF_I2C_I2CR &= ~MCF_I2C_I2CR_MSTA;		// send stop signal (clear MASTER bit)
				TxBufferemptyflag = SET;							// set the non-ISR transmit buffer empty flag
			}	
			else																		// last byte has not been transmitted
			{	
				if((MCF_I2C_I2CR & MCF_I2C_I2SR_RXAK) == 0)	// if the slave acknowledged last transfer
				{
					if(MasterRxFlag == SET)							// if the last transfer was an address and master is now to Rx
					{
						MCF_I2C_I2CR &= ~MCF_I2C_I2CR_MTX;	// switch to Rx mode
						dummyibdrRead = MCF_I2C_I2DR;   	// dummy read of IBDR register
					}
					else																// last transfer was to instruct other slave to receive
					{
						MCF_I2C_I2DR = *TxPacketpositionptr;// write next byte to IBDR
						TxPacketBytes--;
						if (TxPacketBytes == 0) 					// if the last data has been Tx'd
						{
							TxCompleteflag = SET;						// set the ISR transmit complete flag
						}
						else															// there is still data to be transmitted
						{
							TxPacketpositionptr++;					// move to next byte to Tx
						}
					}
				}
				else																	// slave did not acknowledge last transfer
				{
					MCF_I2C_I2CR &= ~MCF_I2C_I2CR_MSTA;	// send stop signal (clear MASTER bit)
				}
			}
		}
		else																			// module is to receive data
		{				
			RxPacketBytes--;
			if (RxPacketBytes == 0) 								// if the last data has been Tx'd
			{
				MCF_I2C_I2CR &= ~MCF_I2C_I2CR_MSTA;		// send stop signal (clear MASTER bit)
				RxCompleteflag = SET;									// set the ISR receive complete flag
			}
			else																		// last byte has not been received yet
			{
    		if (RxPacketBytes == 1) 						// if the second last byte has been received
				{
					MCF_I2C_I2CR |= MCF_I2C_I2CR_TXAK;	// disable active low acknowledge bit (signal to slave to stop Tx)
				}
				else																	// second last byte is still to be received
				{																			// do nothing here
				}
			}
			
			*RxPacketpositionptr = MCF_I2C_I2DR;		// read the data from the slave
			
			if (RxCompleteflag == SET)							// if the last byte of data has been received
			{
			  RxBufferfullflag = SET;								// set the receive buffer full flag
				RxCompleteflag = CLEAR;								// clear the ISR receive complete flag
			}
			else																		// there is still data to receive
			{
				RxPacketpositionptr++;								// increment the Rx packet position pointer
			}	
		}
	}						
	else																				// module is in slave mode
	{
		if(MCF_I2C_I2SR & MCF_I2C_I2SR_IAL)				// if module is now in slave mode because arbitration has been lost
		{
			MCF_I2C_I2SR |= MCF_I2C_I2SR_IAL;				// reset the abritration flag
			
			if(MCF_I2C_I2SR & MCF_I2C_I2SR_IAAS)		// if this module has been addressed as slave
			{
				if(MCF_I2C_I2SR & MCF_I2C_I2SR_SRW)		// if module is to transmit
				{
					MCF_I2C_I2CR |= MCF_I2C_I2CR_MTX;		// switch to Tx mode
					MCF_I2C_I2DR = *TxPacketpositionptr;// write next byte to IBDR
					TxPacketBytes--;
					if (TxPacketBytes == 0) 						// if the last data has been Tx'd
					{
						TxBufferemptyflag = SET;					// raise transmit complete flag
					}
					else																// last byte has not been transmitted
					{
						TxPacketpositionptr++;						// move to next byte to Tx
					}
				}
				else																	// module is to receive
				{
					MCF_I2C_I2CR &= ~MCF_I2C_I2CR_MTX; 	// switch to Rx mode
					dummyibdrRead = MCF_I2C_I2DR;				// dummy read of IBDR register
				}
			}
			else																		// module has not been addressed as a slave
			{																				// do nothing here
			}
		}
		else																			// arbitration was not lost
		{
			if(MCF_I2C_I2SR & MCF_I2C_I2SR_IAAS)		// if this module has been addressed as slave
			{
				if(MCF_I2C_I2SR & MCF_I2C_I2SR_SRW)		// if module is to transmit
				{
					MCF_I2C_I2CR |= MCF_I2C_I2CR_MTX;		// switch to Tx mode
					MCF_I2C_I2DR = *TxPacketpositionptr;// write next byte to IBDR
					TxPacketBytes--;
					if (TxPacketBytes == 0) 						// if the last data has been Tx'd
					{
						TxBufferemptyflag = SET;					// raise transmit complete flag
					}
					else																// last byte has not been transmitted
					{
						TxPacketpositionptr++;						// move to next byte to Tx
					}		
				}
				else																	// module is to receive
				{
					MCF_I2C_I2CR &= ~MCF_I2C_I2CR_MTX; 	// switch to Rx mode
					dummyibdrRead = MCF_I2C_I2DR;				// dummy read of IBDR register
				}
			}
			else																		// module has not been addressed as slave
			{
				if(MCF_I2C_I2SR & MCF_I2C_I2SR_SRW)		// if module is to transmit
				{
					if((MCF_I2C_I2SR & MCF_I2C_I2SR_RXAK) == 0)	// if the slave acknowledged last transfer
					{
						MCF_I2C_I2DR = *TxPacketpositionptr;// write next byte to IBDR
						TxPacketBytes--;
						if (TxPacketBytes == 0) 					// if the last data has been Tx'd
						{
							TxBufferemptyflag = SET;				// raise transmit complete flag
						}
						else															// last byte has not been transmitted
						{
							TxPacketpositionptr++;					// move to next byte to Tx
						}
					}
					else																// module is not to transmit
					{	
						MCF_I2C_I2CR &= ~MCF_I2C_I2CR_MTX;// switch to Rx mode
						dummyibdrRead = MCF_I2C_I2DR;			// dummy read of IBDR register
					}
				}
				else																	// module is to receive data
				{
					*RxPacketpositionptr = MCF_I2C_I2DR;// read IBDR register and store in current buffer location
        			RxPacketBytes--;
		        	if (RxPacketBytes == 0) 				// if the last packet has been received
					{
						RxBufferfullflag = SET;						// set flag

					}
					else																// last packet has yet to be received
					{
						RxPacketpositionptr++;						// move to next byte to transmit
					}
				}					
			}
		}
	}			
#endif
}


