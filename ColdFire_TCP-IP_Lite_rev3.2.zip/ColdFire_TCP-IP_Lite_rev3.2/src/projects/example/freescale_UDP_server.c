//*****************************************************************************
// Copyright (c) 2006, Freescale Semiconductor
// For use on Freescale products only.
//
// File name :   	freescale_UDP_client.c
// Author:			Eric Gregori
//		   			
//
// Description : 	UDP client
//*****************************************************************************
#include "ipport.h"
#include "tcpapp.h"
#include "msring.h"
#include "menu.h"
#include OSPORT_H
#include "ipport.h"
#include "libport.h"
#include "freescale_http_server.h"
#include "udp.h"

//*****************************************************************************
// Declare Task Object
//*****************************************************************************
TK_OBJECT(to_freescale);
TK_ENTRY(tk_freescale);
struct inet_taskinfo freescale_task = {
      									&to_freescale,
      									"FreeScale Task",
      									tk_freescale,
      									NET_PRIORITY,
      									0x800
									};

unsigned long 	data_to_send[250];

//*****************************************************************************
// Declare a Socket structure and communications queue "msring"
//*****************************************************************************

//*****************************************************************************
// Forward declaration RX callback
//*****************************************************************************
static int emg_udp_callback( PACKET pkt, void * data );


//*****************************************************************************
// 
//*****************************************************************************
static loop_cnt=0;
static int					average;					//FSL new
static unsigned long		start_cticks, bytes_rx;		//FSL new

void emg_process_udp_packet( host_ip, data, data_len )
{
	unsigned long	rate;

//	printf( "\nfrom: %lx	loop_cnt=%d", host_ip, loop_cnt++ );

//FSL new code from TCP Server
	if( data_len > 0 )
	{
		bytes_rx += data_len;
		if( bytes_rx > 1024*32 )
		{
			// cticks is in 1/200 seconds
			rate = (200*bytes_rx) / ((cticks-start_cticks));
			printf( "\ndata rate: %d Bytes per second", rate );
			bytes_rx = 0;
			start_cticks = cticks;
		}
	}
//FSL end code from TCP Server	
}

//*****************************************************************************
// int emg_udp_callback( PACKET, void *parm )
//
// PACKET is a pointer to the structure below.
//
// struct netbuf
// {
//   struct netbuf * next;   	/* queue link */
//   char   * nb_buff;    		/* beginning of raw buffer */
//   unsigned nb_blen;    		/* length of raw buffer */
//   char   * nb_prot;    		/* beginning of protocol/data */
//   unsigned nb_plen;    		/* length of protocol/data */
//   long     nb_tstamp;  		/* packet timestamp */
//   struct net *   net;  		/* the interface (net) it came in on, 0-n */
//   ip_addr  fhost;      		/* IP address asociated with packet */
//   unsigned short type; 		/* IP==0800 filled in by recever(rx) or net layer.(tx) */
//   unsigned inuse;      		/* use count, for cloning buffer */
//   unsigned flags;      		/* bitmask of the PKF_ defines */
//	 char *   m_data;        	/* pointer to TCP data in nb_buff */
//	 unsigned m_len;         	/* length of m_data */
//   struct netbuf * m_next; 	/* sockbuf que link */
//   struct ip_socopts *soxopts;/* socket options */
// };
//
//*****************************************************************************
int emg_udp_callback(PACKET pkt, void * parm)
{
   	struct 	 udp 		*pup;
   	unsigned int		data_len;
   	void			    *data;
   	ip_addr				host_ip;

	/* get pointer to UDP header */
   	pup = (struct udp *)pkt->nb_prot;
   	pup -= 1;
   	
   	data 	 = pkt->nb_prot;
   	data_len = pkt->nb_plen;
   	host_ip  = pkt->fhost;
   	emg_process_udp_packet( host_ip, data, data_len );
   	
   	udp_free( pkt );
   	return( 0 );
}


//*****************************************************************************
//
// void *udp_listen( ip_addr fhost, unshort fport, unshort * lport, void * ptr )
//
// Based on tftp_udplisten().
// Start a UDP listen on fhost & portS passed. 
// This is used by the tftp code to establish a receive endpoint prior
//
// Returns connection ID (socket or UDPCONN) if successful, else 
// returns NULL if not.
//
//* udp_open() - Create a UDP connection and enter it in the demux 
//* table. 
//*
//* 
//* PARAM1: ip_addr fhost
//* PARAM2: unshort fsock
//* PARAM3: unshort lsock
//* PARAM4: int (*handler)(PACKET, void * ); - callback
//* PARAM5: void * data
//*
//* RETURNS:  Returns a pointer to the connections structure for use as a 
//* handle if Success, else returns NULL.
//
//*****************************************************************************
void *emg_udp_listen( ip_addr fhost, unshort fport, unshort * lport )
{
	UDPCONN 	u;
	unshort 	tmpport;	// tmp holder for local port value
	void		*ptr;


	ptr = (void *)0;		// Data passed to callback

   	// first, get a local port for use on this connection
   	if(*lport == 0)   		// caller wants us to allocate one
    	tmpport = udp_socket();
   	else  					// use port passed
      tmpport = *lport;

   	u = udp_open( 0, 0, tmpport, emg_udp_callback, (void *)ptr);

   	if(u)
   	{
    	*lport = tmpport;   // return local port to caller */
      	return((void*)u);   // success
   	}
   	else
    	return NULL;      	// error
}


//*****************************************************************************
//
// UDP server init
//
//*****************************************************************************
void emg_init_udp_server( void )
{
	void		*ptr;


	ptr = (void *)0;		// Data passed to callback
	(void)udp_open( 0, 0, 0, emg_udp_callback, (void *)ptr);
}


//*****************************************************************************
//
// UDP client init
//
//*****************************************************************************
void emg_udp_client_cleanup( void )
{
	
}


//*****************************************************************************
// The application thread works on a "controlled polling" basis: 
// it wakes up periodically and polls for work.
//
// The task could aternativly be set up to use blocking sockets,
// in which case the loops below would only call the "xxx_check()"
// routines - suspending would be handled by the TCP code.
//
//
// FUNCTION: tk_emg_http_srv
// 
// PARAM1: n/a
//
// RETURNS: n/a
//
//*****************************************************************************
TK_ENTRY(tk_freescale)
{
	while (!iniche_net_ready)
    	TK_SLEEP(1);

	emg_init_udp_server();
      
	for (;;)
	{
//    	RX done by callback         	
      	tk_yield();          			

      	if (net_system_exit)
        	break;
   	}
   	TK_RETURN_OK();
}


//*****************************************************************************
// create_freescale_task() - Written by Eric Gregori
//		   			  		 
//
// Insert the FreeScale task into the RTOS.
//*****************************************************************************
void create_freescale_task( void )
{
	int e = 0;

   	e = TK_NEWTASK(&freescale_task);
   	if (e != 0)
   	{
      dprintf("freescale task create error\n");
      panic("create_apptasks");
   	}   	
}



