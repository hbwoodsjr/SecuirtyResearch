//*****************************************************************************
// Copyright (c) 2006, Freescale Semiconductor
// For use on Freescale products only.
//
// File name :   	freescale_RTOS.c
// Author:			Eric Gregori
//		   			
//
// Description : 	RTOS demos
//
//*****************************************************************************
#include "ipport.h"
#include "tcpapp.h"
#include "msring.h"
#include "menu.h"
#include OSPORT_H
#include "ipport.h"
#include "libport.h"
#include "udp.h"


//*****************************************************************************
// Declare Task Objects
//
// in osport.h
//
// struct inet_taskinfo {
//   TK_OBJECT_PTR(tk_ptr);  /* pointer to static task object */
//   char * name;            /* name of task */
//   TK_ENTRY_PTR(entry);    /* pointer to code to start task at */
//   int   priority;         /* priority of task */
//   int   stacksize;        /* size (bytes) of task's stack */
//};
//
// in tk_ntask.h
//
// #define  TK_OBJECT(name)      task *   name
// #define  TK_OBJECT_PTR(name)  task **  name
//
//*****************************************************************************
TK_OBJECT(to_freescale1);									// task *to_freescale
TK_ENTRY(tk_freescale1);									// task **tk_freescale
struct inet_taskinfo freescale_task1 = {
      									&to_freescale1,		// pointer to task object
      									"FreeScale Task1",  // task name
      									tk_freescale1,		// pointer to task code
      									NET_PRIORITY,       // Not used for NicheTask
      									0x400				// Stack size
									   };

TK_OBJECT(to_freescale2);									// task *to_freescale
TK_ENTRY(tk_freescale2);									// task **tk_freescale
struct inet_taskinfo freescale_task2 = {
      									&to_freescale2,		// pointer to task object
      									"FreeScale Task2",  // task name
      									tk_freescale2,		// pointer to task code
      									NET_PRIORITY,       // Not used for NicheTask
      									0x400				// Stack size
									   };

TK_OBJECT(to_freescale3);									// task *to_freescale
TK_ENTRY(tk_freescale3);									// task **tk_freescale
struct inet_taskinfo freescale_task3 = {
      									&to_freescale3,		// pointer to task object
      									"FreeScale Task3",  // task name
      									tk_freescale3,		// pointer to task code
      									NET_PRIORITY,       // Not used for NicheTask
      									0x400				// Stack size
									   };

TK_OBJECT(to_freescale4);									// task *to_freescale
TK_ENTRY(tk_freescale4);									// task **tk_freescale
struct inet_taskinfo freescale_task4 = {
      									&to_freescale4,		// pointer to task object
      									"FreeScale Task4",  // task name
      									tk_freescale4,		// pointer to task code
      									NET_PRIORITY,       // Not used for NicheTask
      									0x400				// Stack size
									   };


//*****************************************************************************
// Sample task for RTOS demo by Eric Gregori
//
// Each task simply blinks the LED.
// The task must pass control to the next task.
// The sleep function
//
// in tk_ntask.h
//
// #define  TK_SLEEP(tks)     tk_sleep(tks)
//
// void tk_sleep(long ticks)
// {
//   tk_cur->tk_flags &= ~TF_AWAKE;   /* put task to sleep */
//   tk_cur->tk_waketick = cticks + ticks;  /* set wake time */
//   tk_block();         <--------- Actual task switch
//   tk_wakeups++;       <--- This runs when the task wakes-up
//   tk_cur->tk_count++;
// }
//
//*****************************************************************************
TK_ENTRY(tk_freescale1)
{
	int 	i;

	// Wait for TCP/IP stack to init
	while (!iniche_net_ready)
    	TK_SLEEP(1);

	// Task's must not return, Infinite loops 
	for (;;)
	{
#if 1
		// Good
		TK_SLEEP(1100);
//		printf( "\nTask1" );
#else
		// Bad
		for( i=0; i<0xFFFF; i++ );
#endif

		LED0_TOGGLE;

      	if(net_system_exit)
        	break;
   	}
   	TK_RETURN_OK();
}


TK_ENTRY(tk_freescale2)
{
	int 	i;

	// Wait for TCP/IP stack to init
	while (!iniche_net_ready)
    	TK_SLEEP(1);

	// Task's must not return, Infinite loops 
	for (;;)
	{
#if 1
		// Good
		TK_SLEEP(1200);
//		printf( "\nTask2" );
#else
		// Bad
		for( i=0; i<0xFFFF; i++ );
#endif

		LED1_TOGGLE;

      	if(net_system_exit)
        	break;
   	}
   	TK_RETURN_OK();
}


TK_ENTRY(tk_freescale3)
{
	int 	i;

	// Wait for TCP/IP stack to init
	while (!iniche_net_ready)
    	TK_SLEEP(1);

	// Task's must not return, Infinite loops 
	for (;;)
	{
#if 1
		// Good
		TK_SLEEP(1300);
//		printf( "\nTask3" );
#else
		// Bad
		for( i=0; i<0xFFFF; i++ );
#endif

		LED2_TOGGLE;

      	if(net_system_exit)
        	break;
   	}
   	TK_RETURN_OK();
}


TK_ENTRY(tk_freescale4)
{
	int 	i;

	// Wait for TCP/IP stack to init
	while (!iniche_net_ready)
    	TK_SLEEP(1);

	// Task's must not return, Infinite loops 
	for (;;)
	{
#if 1
		// Good
		TK_SLEEP(1400);
//		printf( "\nTask4" );
#else
		// Bad
		for( i=0; i<0xFFFF; i++ );
#endif

		LED3_TOGGLE;

      	if(net_system_exit)
        	break;
   	}
   	TK_RETURN_OK();
}


//*****************************************************************************
// create_freescale_task() - Written by Eric Gregori
//		   			  		 
//
// Insert the FreeScale task into the RTOS.
//
// TK_NEWTASK inserts a task object into the object list
//*****************************************************************************
void create_freescale_task( void )
{
	int e = 0;

   	e = TK_NEWTASK(&freescale_task1);
   	if (e != 0)
   	{
      dprintf("freescale task create error\n");
      panic("create_apptasks");
   	}   	

   	e = TK_NEWTASK(&freescale_task2);
   	if (e != 0)
   	{
      dprintf("freescale task create error\n");
      panic("create_apptasks");
   	}   	

   	e = TK_NEWTASK(&freescale_task3);
   	if (e != 0)
   	{
      dprintf("freescale task create error\n");
      panic("create_apptasks");
   	}   	

   	e = TK_NEWTASK(&freescale_task4);
   	if (e != 0)
   	{
      dprintf("freescale task create error\n");
      panic("create_apptasks");
   	}   	
}

