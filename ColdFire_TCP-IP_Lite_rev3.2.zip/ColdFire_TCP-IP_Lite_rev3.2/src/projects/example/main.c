/* FILENAME: main.c
 *
 * Copyright 2005 By InterNiche Technologies Inc. All rights reserved
 *
 *
 * PORTABLE: NO
 */

#include "ipport.h"        /* from Interniche directory */
#include "osport.h"
uint32 start_time1,start_time2,delta_time1,delta_time2;

/* internal: */
#ifdef SUPERLOOP
void tk_yield(void);
#endif
void  kbdio(void);
void  dtrap();
int   packet_chk(void);

/* from linker file */
extern int  __heap_addr;
extern int  __heap_size;

extern   char *   prompt;
extern   int      TCPTV_MSL;          /* in ..\tcp\tcp_timr.h */
extern   u_char   mac_addr_fec[8];
extern   int      uart_yield;         /* in iuart.c */

extern   int   netmain_init(void);
extern   void  netmain(void);

extern	 void start_AD(void);
extern	 void init_adc (void);

extern __interrupt__ void fec_isr(void);
extern __interrupt__ void timer_isr(void);
extern __interrupt__ void core_wd(void);	//FSL core watchdog

extern u_long activehost;
extern struct net  netstatic[STATIC_NETS];   /* in ../ip/ipstart.c */

volatile u_long cticks = 0;		//FSL added "volatile" as task.c uses it in loop and interrupt could increment it
int memtrapsize = 0;
int min_cnt = 0;

#ifdef IPSEC
#ifndef IKE
int prep_ipsec(void);
#endif
#endif

void empty (void)
{
	
}

/********************************************************************/

int main (void)
{
	int      err;
	uint16 mymrdata, mymwdata;    	//temp variable for MII read/write data

   	mcf5xxx_irq_enable();           /* Let the interrupts fly... */

	LED_INIT();
	init_adc();
	start_AD();
	start_time2 = MCF_DTIM0_DTCN;
		empty();
	delta_time2 = MCF_DTIM0_DTCN - start_time2;
	while( !uart_flush(CONSOLE_UART) ){};
	printf("\n\nRunning ColdFire TCP/IP-Lite stack Revision 3.1\n");
	printf("\nCopyright 2008 by Freescale Semiconductor Inc.\n");
	printf("Use of this software is controlled by the agreement\n");
	printf("found in the project LICENSE.H file.\n");
	printf("Built on %s %s\n",__DATE__, __TIME__);
	while( !uart_flush(CONSOLE_UART) ){};

#ifdef SYS_SHUTDOWN
   	printf("\System shutdown in %d minutes\n", SYS_SHUTDOWN/60);
#endif

   /* The C lib already has a small heap in the program image (which
    * is why the printf already works) but we need more. So we
    * take what's left of the 16 megs on the card.
    */
   mheap_init((char *)&__heap_addr, (long)&__heap_size);  /* start, length */

#ifdef NPDEBUG
   printf("\nHeap size = %d bytes\n", (long)&__heap_size );
#endif

   port_prep = prep_evb;

   /* hardcode FEC IP address for now. We set it in netstatic, and
    * IP startup code will initialize net[] from it.
    */
#if (!AUTOIP)
	if( !POWERUP_CONFIG_DHCP_ENABLED )	//FSL SW1 for DHCP (M52233DEMO|M52235EVB)
	{	
		if( POWERUP_CONFIG_ALT_IP )		//FSL SW2 for alternate for DHCP (M52233DEMO|M52235EVB)
		{
   			netstatic[0].n_ipaddr = (0xC0A80062);		//FSL 0xC0A80162 == 192.168.0.98
		}
		else							//FSL default no switch used
		{
   			#if CLIENT
   				netstatic[0].n_ipaddr = (0xC0A80062);	//FSL Client IP 0xC0A80062=192.168.0.98
   			#else	//i.e. SERVER
   				netstatic[0].n_ipaddr = (0xC0A80064);	//FSL Server IP 0xC0A80064=192.168.0.100
   			#endif
		}
		
   		netstatic[0].n_defgw  = (0xC0A80001);	//0xC0A80101 == 192.168.0.1
   		netstatic[0].snmask   = (0xffffff00);	//0xffffff00 == 255.255.255.0
	}
#else	//FSL Auto IP configuration
		netstatic[0].n_ipaddr = (0xA9FE0001);	//FSL Server IP 0xA9FE0001=169.254.0.1
   		netstatic[0].n_defgw  = (0x00000000);	//0x00000000 == 0.0.0.0
   		netstatic[0].snmask   = (0xffff0000);	//0xffff0000 == 255.255.0.0
#endif
   
   printf( "\nIP Address  = %lx -> %u.%u.%u.%u", netstatic[0].n_ipaddr,
									PUSH_IPADDR(netstatic[0].n_ipaddr )); 
   printf( "\nMask        = %lx -> %u.%u.%u.%u", netstatic[0].snmask,
									PUSH_IPADDR(netstatic[0].snmask )); 
   printf( "\nGateway     = %lx -> %u.%u.%u.%u\n", netstatic[0].n_defgw,
									PUSH_IPADDR(netstatic[0].n_defgw )); 
   
   netstatic[0].mib.ifDescr = (u_char *)"Fast Ethernet Controller";

   /* We set the station's Ethernet physical (MAC) address
    * from the address already in use by dBUG. This prevents
    * ARP problems on the development server. Production systems
    * usually read this from flash or eprom.
    */

#ifdef NPDEBUG
   dprintf("MAC Address = %02X:%02X:%02X:%02X:%02X:%02X\n\n",
            mac_addr_fec[0], mac_addr_fec[1], mac_addr_fec[2],
            mac_addr_fec[3], mac_addr_fec[4], mac_addr_fec[5]);
#endif

   /* Heap memory saving trick - reduce the time a TCP socket
    * will linger in CLOSE_WAIT state. For systems with limited
    * heap space and a busy web server, this makes a big difference.
    */
   TCPTV_MSL = 2;    /* set low max seg lifetime default */

#ifdef NPDEBUG
   printf("Starting ints.\n");
#endif

   iniche_net_ready = TRUE;

	while( !uart_flush(CONSOLE_UART) ){};

#ifdef NPDEBUG
   printf("Calling netmain()...\n");
#endif
   netmain();     /* Start and run net tasks, no return. */
   USE_ARG(err);
   return 0;
}

/* FUNCTION: dtrap()
 *
 * Trap fatal errors
 *
 * PARAMS: none
 *
 * RETURNS: none
 *
 * Indicates error occurred and then returns to application
 */

void
dtrap()
{
   do
   {
//      asm { halt };	//FSL added "halt" for debugging purposes...leave commented out normally
   }while (0);
   
   printf("dtrap\n");

}


/* FUNCTION: timer_isr()
 *
 * Clock interrupt handler
 *
 * PARAMS: none
 *
 * RETURNS: none
 *
 * Increments the following counters:
 *    timer_ticks = raw system clock ticks
 *    timerct = number of system clock ticks in a ctick
 *    cticks  = number of clock ticks
 *    pit_counter = timer_ticks; used by profiler
 */

static long    timer_ticks = 0;
static int     timerct = 0;
static unshort pit_counter = 0;
#ifdef SYS_SHUTDOWN
static int     sys_shutdown = SYS_SHUTDOWN*1000;
#endif

__interrupt__
void
timer_isr()
{
   /* Clear interrupt at CSR */
   MCF_PIT_PCSR(0) |= MCF_PIT_PCSR_PIF;	

   ++timer_ticks;
   if (++timerct >= INTS_PER_CTICK)
   {
      cticks++;
      timerct = 0;
   }
   
#ifdef USE_PROFILER
   /* count all PIT ints for the profiler value */
   pit_counter++;
#endif   /* USE_PROFILER */

#ifdef SYS_SHUTDOWN
/* TODO: may want to call netexit(15) from the main loop
 *       to shutdown more gracefully */
   if (timer_ticks >= sys_shutdown)
   {
      exit(15);
   }
#endif
				//FSL Note..this is an example.  Probably better to place this code in 
				//FSL a task rather than this timer ISR as it is possible for the OS
				//FSL to hang but the timer ISR to live on.  Just copy and paste this 
				//FSL code into a task that runs regularly.
				//FSL add to a task to prevent run away code from happening
#if MCF5223x				
#if WD_TEST		//FSL code to play with WD Module ability to reset device if bus hangs
       MCF_SCM_CWCR |= (MCF_SCM_CWCR_CWTAVAL | MCF_SCM_CWCR_CWTIF); //Clear flags if set
       MCF_SCM_CWSR = 0x55; 	//step 1 to reset the core watchdog timeout counter
       MCF_SCM_CWSR = 0xAA;     //step 2 to reset the core watchdog timeout counter
#endif
#endif
}


//FSL core WD interrupt
__interrupt__
void
core_wd()
{
#if WD_TEST
   ADDRESS pc_on_stack;

//FSL note that stack pointer (a7) was modified by the "C" function   
   asm { move.l a7,d0 };			//FSL place stack pointer address in d0
   asm { add.l #36,d0 };			//FSL point to the start of the exception frame
   asm { move.l d0,pc_on_stack };	//FSL update variable
   asm { nop };
									//FSL PC is +4 from the base of the exception frame
   MCF_RCM_RCR = MCF_RCM_RCR_SOFTRST;	//FSL Issue software reset command
#endif   
}


/* FUNCTION: exit()
 *
 * Program exit
 *
 * PARAM1: code;     program exit code
 *
 * RETURNS: none
 */

void
exit(int code)
{
   printf("Exit, code %d. Push RESET button now.\n", code);
   while( !uart_flush(CONSOLE_UART) ){};	//FSL added to flush UART to enable seeing message before halting
   mcf5xxx_irq_disable();
   while (1)
      asm { halt };
}


static int crits = 0;
static int sysint;

void
ENTER_CRIT_SECTION(void * p)
{
   if(crits++ == 0)
   {
      sysint = asm_set_ipl(7);
   }
}

void
EXIT_CRIT_SECTION(void * p)
{
   if(--crits == 0)
   {
      asm_set_ipl(sysint);
   }
   if(crits < 0)
   {
      printf("negative crit section ct(%d)\n", crits);
      dtrap();
   }
}

/********************************************************************/
