/*
 * File:		Int_handlers.c
 * Purpose:		contains all intrrupt processes
 *
 * IMPORTANT. Read the following Freescale Semiconductor Software License 
 * Agreement:
 * http://www.freescale.com/files/disclaimer/LA_OPT1.html
 * 
 */
extern void asm_startmeup(void);
#include "common.h"

uint8	ephy_isr=0;

__interrupt__
void irq_handler (void)
{
	/*
	 * This is the catch all interrupt handler for all user defined
	 * interrupts.  To create specific handlers, create a new interrupt
	 * handler and change vectors.s to point to the new handler.
	 */
	printf("irq_handler\n");
}

/********************************************************************/

__interrupt__
void ethernet_handler (void)
{
}

#ifdef MCF5223x
/********************************************************************/
///EPHY ISR - Type of EPHY interrupt determined by MII read of PHY_REG_IR register
extern char * prompt;
extern tU08	gotlink;   	// FSL Global Variable For Determination if link is active (1=active)

__interrupt__
void ephy_handler (void)
{
  uint16 mymrdata, isr_read, reg0;
  
  printf( "\n\nePHY interrupt - " );
	
  //@@@@@@@@@@@@@@@@
  //STEP1: PHY interrupt flag clearing.	Read PHY_REG_IR to determine PHY interrupt
  // Need to read MII Inter. register 22 before clearing  EPHYIF
  //@@@@@@@@@@@@@@@@
  while ( !(fec_mii_read(FEC_PHY0, PHY_REG_IR, &isr_read)) )
  {
  	
  };

  printf( "\nPHY Specific Interrupt Control Register(16)= 0x%04x\n",isr_read);

  //@@@@@@@@@@@@@@@@
  //STEP2: Process PHY interrupt register 0x10 (PHY_REG_IR) contents
  //handlers for different interrupts	 flags
  //@@@@@@@@@@@@@@@@

   ephy_isr++;		//FSL can be used for debugging.

   while ( !(fec_mii_read(FEC_PHY0, PHY_REG_PSR, &mymrdata)) )
   {
     	
   };
   
   if(!(mymrdata&PHY_R17_LNK))		//FSL if Link up, print speed and duplex
   {
	   while ( !(fec_mii_read(FEC_PHY0, PHY_REG_IR, &mymrdata)) )	// must do step per reference manual
	   {
			
	   };

			
	   MCF_EPHY_EPHYSR = (uint8)(MCF_EPHY_EPHYSR_EPHYIF); 	//clear ephy interrupt
#if 0		 
 	   mcf5223x_ePHY_init();	//Establish new link
#else
       MCF_RCM_RCR = MCF_RCM_RCR_SOFTRST;	//Issue software reset command - registers to default settings
#endif
	   gotlink=1;
	   while ( !(fec_mii_read(FEC_PHY0, PHY_REG_IR, &mymrdata)) )	// must do step per reference manual
	   {
			
	   };
   }
   else						//FSL if Link down, print status
   {
     	printf(" Ethernet cable/link down\n");
     	gotlink=0;
		MCF_RCM_RCR = MCF_RCM_RCR_SOFTRST;	//Issue software reset command - registers to default settings
   }

exit_ephy_handler:
   printf(prompt);
   asm( nop);
}

#endif