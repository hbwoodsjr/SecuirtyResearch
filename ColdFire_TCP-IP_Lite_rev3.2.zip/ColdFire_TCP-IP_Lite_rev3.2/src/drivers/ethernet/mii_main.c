/*
 * File:		mii_main.c
 * Purpose:		Main process
 *
 */

#include "common.h"
#include "mii.h"

/********************************************************************/
void 
main (void)
{
	char ch;
	uint16 settings;
	
    /*
     * Initialize the MII interface
     */
    fec_mii_init(SYSTEM_CLOCK_MHZ);


	while(1)
	{
	    int i;
	    
	    for (i = 0; i < 4; i++)
        {
            if (!fec_mii_read(1, i, &settings))
                printf(" Error  ");
            else
                printf(" %#04x ", settings);
        }
        
        printf("\n");
        for (i = 0; i < 100000; i++);
	}
}
/********************************************************************/
