/*
 * File:		mcf53013_evb.h
 * Purpose:		Evaluation board definitions and memory map information
 *
 * Notes:
 */

#ifndef _MCF53013_EVB_H
#define _MCF53013_EVB_H

/********************************************************************/

#include "mcf5xxx.h"
#include "io.h"

/********************************************************************/

/*
 * Debug prints ON (#undef) or OFF (#define)
 */
#undef DEBUG

/********************************************************************/

/*
 * Include board specific header files
 */

/*
 * System Bus Clock Info
 */
#define SYSTEM_CLOCK      80            /* system bus frequency in MHz */
#define SYSTEM_PERIOD     1250000000    /* system bus period in ns */
#define SYS_CLK_KHZ	      80000      	/* this is a dummy define*/
#define SYS_CLK_MHZ		  SYSTEM_CLOCK	//FSL used by ifec.c

/*
 * Flash Info
 */
//#define AMD_FLASH_DEVICES   2
//#define AMD_FLASH_AM29LV128M_16BIT

/*
 * Serial Port Info
 */
#define TERMINAL_PORT       0          
#define TERMINAL_BAUD       19200	   
#undef  HARDWARE_FLOW_CONTROL          /* Flow control ON or OFF */

/*
 * SDRAM Timing Parameters
 */
#define SDRAM_BL           	8          /* # of beats in a burst */
#define SDRAM_TWR		    2  		   /* in clocks */
#define SDRAM_CASL		    3    	   /* in clocks */
#define SDRAM_TRCD		    2		   /* in ns */
#define SDRAM_TRP		    2		   /* in ns */
#define SDRAM_TRFC_SDR      66         /* ns; from mt48lc128m4a2 memory*/
#define SDRAM_TRFC_DDR      120  	   /* ns; from mt46v256m4 memory*/
#define SDRAM_TREFI		    7800	   /* in ns */

/*
 * SDRAM Memory Type
 */
 #define SDR                0
 #define DDR 		    	1	
 #define SDRAM_MODE         DDR 
 #define WIDTH32           	0
 #define WIDTH16           	1 
 #define SDRAM_MEM_PS       WIDTH16
 #define SDRAM_AMUX	    	1
								 
/*
 * Interrupt Priorities
 */
#define DMA_INTC_LVL        6
#define DMA_INTC_PRI        0
#define FEC0_INTC_LVL       5
#define FEC0_INTC_PRI       0
#define FEC1_INTC_LVL       5
#define FEC1_INTC_PRI       1
#define FEC_INTC_LVL(x)     ((x == 0) ? FEC0_INTC_LVL : FEC1_INTC_LVL)
#define FEC_INTC_PRI(x)     ((x == 0) ? FEC0_INTC_PRI : FEC1_INTC_PRI)
#define GPT0_INTC_LVL       3
#define GPT0_INTC_PRI       0

/*
 * DMA Task Priorities
 */
#define FEC0RX_DMA_PRI      6
#define FEC1RX_DMA_PRI      6
#define FECRX_DMA_PRI(x)    ((x == 0) ? FEC0RX_DMA_PRI : FEC1RX_DMA_PRI)
#define FEC0TX_DMA_PRI      5
#define FEC1TX_DMA_PRI      5
#define FECTX_DMA_PRI(x)    ((x == 0) ? FEC0TX_DMA_PRI : FEC1TX_DMA_PRI)

/*
 * Memory map definitions from linker command files
 */
extern uint8 __SDRAM[];
extern uint8 __SDRAM_SIZE[];
extern uint8 __CORE_SRAM[];
extern uint8 __CORE_SRAM_SIZE[];
extern uint8 __EXT_SRAM[];
extern uint8 __EXT_SRAM_SIZE[];
extern uint8 __BOOT_SRAM[];
extern uint8 __BOOT_SRAM_SIZE[];

/*
 * Memory Map Info
 */

#define SDRAM_ADDRESS       (uint32)__SDRAM
#define SDRAM_SIZE          (uint32)__SDRAM_SIZE

#define CORE_SRAM_ADDRESS   (uint32)__CORE_SRAM
#define CORE_SRAM_SIZE      (uint32)__CORE_SRAM_SIZE

#define EXT_SRAM_ADDRESS    (uint32)__EXT_SRAM
#define EXT_SRAM_SIZE       (uint32)__EXT_SRAM_SIZE

#define BOOT_SRAM_ADDRESS   (uint32)__BOOT_SRAM
#define BOOT_SRAM_SIZE      (uint32)__BOOT_SRAM_SIZE

/*
* SCC TIMER INIT
*/
//#define SCC_TIMER

/********************************************************************/
/*
 * Ethernet Port Info
 */
#define FEC_PHY(x)          ((x == 0) ? 0x5 : 0x1)		//FSL PHY Addresses board dependent
#define FEC_PHY0            FEC_PHY(ETH_PORT)

/*
 *	Interrupt Controller Definitions
 */
#define TIMER_NETWORK_LEVEL		3
#define FEC_LEVEL				4

/*
 *	Timer period info
 */
#define HAS_LEDS	1

/********************************************************************/
/********************************************************************/
/********************************************************************/
#ifdef HAS_LEDS /* { */
	static unsigned char LED3=1,LED2=1,LED1=1,LED0=1;

	#define LED0_TOGGLE     MCF_GPIO_PORT_TIMER = (uint8)(MCF_GPIO_PORT_TIMER ^ MCF_GPIO_PORT_TIMER_PORT_TIMER0)
	#define LED1_TOGGLE     MCF_GPIO_PORT_TIMER = (uint8)(MCF_GPIO_PORT_TIMER ^ MCF_GPIO_PORT_TIMER_PORT_TIMER1);
	#define LED2_TOGGLE     MCF_GPIO_PORT_TIMER = (uint8)(MCF_GPIO_PORT_TIMER ^ MCF_GPIO_PORT_TIMER_PORT_TIMER2);
	#define LED3_TOGGLE     MCF_GPIO_PORT_TIMER = (uint8)(MCF_GPIO_PORT_TIMER ^ MCF_GPIO_PORT_TIMER_PORT_TIMER3);

	#define LED0_ON     	MCF_GPIO_PORT_TIMER = (uint8)(MCF_GPIO_PORT_TIMER | MCF_GPIO_PORT_TIMER_PORT_TIMER0)
	#define LED1_ON		    MCF_GPIO_PORT_TIMER = (uint8)(MCF_GPIO_PORT_TIMER | MCF_GPIO_PORT_TIMER_PORT_TIMER1);
	#define LED2_ON         MCF_GPIO_PORT_TIMER = (uint8)(MCF_GPIO_PORT_TIMER | MCF_GPIO_PORT_TIMER_PORT_TIMER2);
	#define LED3_ON         MCF_GPIO_PORT_TIMER = (uint8)(MCF_GPIO_PORT_TIMER | MCF_GPIO_PORT_TIMER_PORT_TIMER3);

	#define LED0_OFF        MCF_GPIO_PORT_TIMER = (uint8)(MCF_GPIO_PORT_TIMER & ~MCF_GPIO_PORT_TIMER_PORT_TIMER0)
	#define LED1_OFF        MCF_GPIO_PORT_TIMER = (uint8)(MCF_GPIO_PORT_TIMER & ~MCF_GPIO_PORT_TIMER_PORT_TIMER1);
	#define LED2_OFF        MCF_GPIO_PORT_TIMER = (uint8)(MCF_GPIO_PORT_TIMER & ~MCF_GPIO_PORT_TIMER_PORT_TIMER2);
	#define LED3_OFF        MCF_GPIO_PORT_TIMER = (uint8)(MCF_GPIO_PORT_TIMER & ~MCF_GPIO_PORT_TIMER_PORT_TIMER3);

	#define LED_INIT()		Leds_Init()
#else  /* No LEDS  */
	#define LED_INIT()		void()
#endif

/********************************************************************/
/********************************************************************/
void Leds_Init();
void board_led_display(uint8 number);
/********************************************************************/
/********************************************************************/
#endif /* _MCF53013_EVB_H */
