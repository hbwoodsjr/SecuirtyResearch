/*
 * File:	mcf5301x.c
 * Purpose:	MCF5301x specific routines	
 *
 * Notes:		
 */

#include "common.h"

extern int d0_reset;
extern int d1_reset;

void FEC_ICR_init(void);				//FSL added function prototype
void FEC_IMR_init(void);				//FSL added function prototype
void processor_UART_ICR_init(int);		//FSL added function prototype
void processor_PIT_Timer_Init(void);	//FSL added function prototype

/********************************************************************/
extern int d0_reset;
extern int d1_reset;

/********************************************************************/
void
cpu_startup (void)
{
#ifdef DEBUG_PRINT
    /*
     * Determine cause(s) of reset
     */
    printf("\n\n");
    if (MCF_CCM_RSR & MCF_CCM_RSR_LOL)
    	printf("Loss of Lock Reset\n");
    if (MCF_CCM_RSR & MCF_CCM_RSR_WDRCORE)
        printf("Core Watchdog Timer Timeout Reset\n");
    if (MCF_CCM_RSR & MCF_CCM_RSR_EXT)
        printf("External Reset\n");
    if (MCF_CCM_RSR & MCF_CCM_RSR_POR)
        printf("Power-on Reset\n");
    if (MCF_CCM_RSR & MCF_CCM_RSR_LOC)
        printf("Loss of Clock Reset\n");
    if (MCF_CCM_RSR & MCF_CCM_RSR_SOFT)
        printf("Software Reset\n");
    
    /*
     * Print out the core integration information
     */
    mcf5xxx_interpret_d0d1(d0_reset,d1_reset);
#endif

    /* 
	 * Enable on-chip modules to access internal SRAM 
	 */
//	MCF_SCM_RAMBAR = ( MCF_SCM_RAMBAR_BA(SRAM_ADDRESS)
//		             | MCF_SCM_RAMBAR_BDE);
}
/********************************************************************/
/* FUNCTION: clock_c()
 * 
 * Disable timer interrupts
 *
 * PARAM1: none
 *
 * RETURNS: none
 */

void
clock_c()
{
   MCF_PIT_PCSR(0) &= ~( MCF_PIT_PCSR_PIE | MCF_PIT_PCSR_EN );

   printf("clock_c: disabling timer interrupts\n");
}

/********************************************************************/
/*
 * Pause for the specified number of micro-seconds.
 * Uses DTIM3 as a timer
 */
void
cpu_pause(int usecs)
{
    /* Enable the DMA Timer 3 */
    MCF_DTIM3_DTRR = (vuint32)(usecs - 1);
    MCF_DTIM3_DTER = MCF_DTIM_DTER_REF;
    MCF_DTIM3_DTMR = 0
        | MCF_DTIM_DTMR_PS(SYSTEM_CLOCK)
        | MCF_DTIM_DTMR_ORRI
        | MCF_DTIM_DTMR_FRR
        | MCF_DTIM_DTMR_CLK_DIV1
        | MCF_DTIM_DTMR_RST;

    while ((MCF_DTIM3_DTER & MCF_DTIM_DTER_REF) == 0) 
    {};
    
    /* Disable the timer */
    MCF_DTIM3_DTMR = 0;
}

/********************************************************************/
void
board_handle_interrupt (int vector)
{
    switch (vector)
    {
        case 68: /* Eport Interrupt 4 */
            printf("SW1\n");
            MCF_EPORT0_EPFR = (uint8)(0x01 << 4);
            break;
        case 69: /* Eport Interrupt 5 */
            printf("SW2\n");
            MCF_EPORT0_EPFR = (uint8)(0x01 << 5);
            break;
        case 71: /* Eport Interrupt 7 */
            printf("ABORT\n");
            MCF_EPORT0_EPFR = (uint8)(0x01 << 7);
            break;
        case 65: /* Eport Interrupt 1 */
        case 66: /* Eport Interrupt 2 */
        case 67: /* Eport Interrupt 3 */
        case 70: /* Eport Interrupt 6 */
        default:
            MCF_EPORT0_EPFR = (uint8)(0x01 << (vector - 64));
            printf("Edge Port Interrupt #%d\n",vector - 64);
            break;
    }
}

/********************************************************************/
void
cpu_handle_interrupt (int vector)
{
    if (vector < 64 || vector > 192)
        return;
    
    switch (vector)
    {
        case 65: /* Eport Interrupt 1 */
        case 66: /* Eport Interrupt 2 */
        case 67: /* Eport Interrupt 3 */
        case 68: /* Eport Interrupt 4 */
        case 69: /* Eport Interrupt 5 */
        case 70: /* Eport Interrupt 6 */
        case 71: /* Eport Interrupt 7 */

            /* 
             * Clear the interrupt source 
             * This clears the flag for edge triggered interrupts
             */
            MCF_EPORT0_EPFR = (uint8)(0x01 << (vector - 64));
            printf("Edge Port Interrupt #%d\n",vector - 64);
            break;  
        default:
            printf("User Defined Vector #%d\n",vector);
            break;
    }
}
/********************************************************************/
void 
enable_low_power(int lpmd)
{
 	switch (lpmd)
 	{
 		case RUN:  MCF_SCM_MWCR = 0x10; break;
 		case DOZE: MCF_SCM_MWCR = 0x90; break;
 		case WAIT: MCF_SCM_MWCR = 0xa0; break;
 		case STOP: MCF_SCM_MWCR = 0xb0; break; 			
 	}
}
/********************************************************************/
//processor specific FEC ICR initialization
void 
FEC_ICR_init(void)		
{
	uint32 i;
	
   /* Set up FEC interrupts (vectors 36 through 48) */
   for (i = 36; i < 49; i++)
   {
      /* Hook FEC interrupt to our ISR */
    /* //FSL - should be macro'ed */
	  MCF_INTC0_ICR(i) = MCF_INTC_ICR_IL(6);
   }
	
}

/********************************************************************/
//FSL configure the FEC IMRs in processor specific file
void 
FEC_IMR_init()			
{
	MCF_INTC0_IMRL &= 	~(MCF_INTC_IMRH_INT_MASK36); // TXF
	MCF_INTC0_IMRL &= 	~(MCF_INTC_IMRH_INT_MASK37); // TXB
	MCF_INTC0_IMRL &= 	~(MCF_INTC_IMRH_INT_MASK40); // RXF
	MCF_INTC0_IMRL &= 	~(MCF_INTC_IMRH_INT_MASK42); // MII
}

/********************************************************************/
//FSL configure the UART0 ICR and enable associtate IMR
void 
processor_UART_ICR_init(int dev)	
{
  if(dev == 2)
  {
	  MCF_INTC0_ICR28 = MCF_INTC_ICR_IL(2);
	  MCF_INTC0_IMRL &= ~(MCF_INTC_IMRL_INT_MASK28);
  }
  else if (dev == 1)
  {
	  MCF_INTC0_ICR27 = MCF_INTC_ICR_IL(2);
	  MCF_INTC0_IMRL &= ~(MCF_INTC_IMRL_INT_MASK27);
  }
  else		//FSL default to dev == 0
  {
	  MCF_INTC0_ICR26 = MCF_INTC_ICR_IL(2);
	  MCF_INTC0_IMRL &= ~(MCF_INTC_IMRL_INT_MASK26);
  }
	
}

/********************************************************************/
/*
 * Setup PIT Timer
 */
void 
PIT_Timer_Init(uint8 PCSR, uint16 PMR)
{

	/* Set tic for timers	*/

	MCF_PIT0_PCSR  = (uint16)(MCF_PIT_PCSR_PRE(PCSR));	/* Divide system clock/2 by 2^PCSR	*/
	MCF_INTC1_ICR43 = MCF_INTC_ICR_IL(TIMER_NETWORK_LEVEL);
	MCF_INTC1_IMRH &= ~MCF_INTC_IMRH_INT_MASK43;
	MCF_PIT0_PMR = PMR;						/* modulo count	*/
	MCF_PIT0_PCSR |= MCF_PIT_PCSR_HALTED | MCF_PIT_PCSR_OVW | 
					 MCF_PIT_PCSR_PIE | MCF_PIT_PCSR_PIF | 
					 MCF_PIT_PCSR_RLD | MCF_PIT_PCSR_EN;
}

/********************************************************************/
//FSL processor specific PIT config for 1 msec interrupt
void 
processor_PIT_Timer_Init()	
{

   PIT_Timer_Init(1,40000);		//FSL (40000/((sys_clk/2)/2^0))) = 1msec PIT interrupt @80MHz core
	
}

/********************************************************************/

