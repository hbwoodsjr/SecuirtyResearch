/*
 * File:    clock.c
 * Purpose: Driver for the on-chip Clock module
 *
 * Notes:   On Palladium default clock (Khz range) are provided by pll 
 *	    module. This module will ignore all write opertaions with 
 *	    no error response. so the same clock_pll will be used when 
 *	    actual PLL is used.         
 * 	
 */

#include "common.h"
#include "clock.h"

/********************************************************************/
/* Initialize the PLL
 * 
 * Parameters:
 *  fref    PLL reference clock frequency in KHz
 *  fsys    Desired PLL output frequency in KHz
 *  flags   Operating parameters
 *
 * Return Value:
 *  The resulting output system frequency
 */
int
clock_pll (int fsys, int flags)
{
    int fref, temp, fout, pfdr, busdiv;
    uint32 i;
        
    fref = FREF;    
  
  
    if (fsys == 0)
    {
        /* Return current PLL output */
        pfdr = (MCF_PLL_PCR & MCF_PLL_PCR_FBDIV(0x3F));
        busdiv = (MCF_PLL_PDR & MCF_PLL_PDR_OUTDIV2(0xF))>>4;       

        return ( fref * (pfdr + 1) / (busdiv+1));
    }
 
    
    /* Check bounds of requested system clock */
    if (fsys > MAX_FSYS)
        fsys = MAX_FSYS;
    
    if (fsys < MIN_FSYS)
    	fsys = MIN_FSYS;
        
   	/* Multiplying by 100 when calculating the temp value,
   	   and then dividing by 100 to calculate the pfdr allows
   	   for exact values without needing to include floating
   	   point libraries. */
    temp = 100 * fsys / fref;
    pfdr  = (BUSDIV) * temp / 100;
    	    	    	
    /* Determine the output frequency for selected values */
    fout = ( fref * pfdr / (BUSDIV));
    
    /*
     * Check to see if the SDRAM has already been initialized.
     * If it has then the SDRAM needs to be put into self refresh
     * mode before reprogramming the PLL.
     */
    if (MCF_SDRAMC_SDCR & MCF_SDRAMC_SDCR_REF)
    	/* Put SDRAM into self refresh mode */
    	MCF_SDRAMC_SDCR &= ~MCF_SDRAMC_SDCR_CKE;

    /* 
     * Initialize the PLL to generate the new system clock frequency. 
     * The device must be put into LIMP mode to reprogram the PLL. 
     */

    /* Enter LIMP mode */     
    clock_limp( DEFAULT_LPD );
     					
    /* Reprogram PLL for desired fsys */
    MCF_PLL_PDR = ( 0 
            | MCF_PLL_PDR_OUTDIV1 (BUSDIV/3 - 1)
    		| MCF_PLL_PDR_OUTDIV2 (BUSDIV   - 1) 
    		| MCF_PLL_PDR_OUTDIV3 (BUSDIV/2 - 1)
    		| MCF_PLL_PDR_OUTDIV4 (USBDIV   - 1) );
    
    
    
    //MCF_PLL_PCR = (0x00000017);   //For EVB 20 x (23+1) = 480 Mhz VCO 
	#ifdef PLL_EXPOSE_MODE
	MCF_PLL_PCR |= 0x00000017;   //For EVB 20 x (23+1) = 480 Mhz VCO 
	MCF_PLL_PTR |=  0x80001003 ;     
	MCF_CCM_MISCCR2 |= 0x0700 ;
	#else
	MCF_PLL_PCR = (0
             | MCF_PLL_PCR_FBDIV(pfdr - 1));
    #endif         
	
    /* Exit LIMP mode */
    clock_exit_limp();

    /*
     * Return the SDRAM to normal operation if it is in use. 
     */
    if (MCF_SDRAMC_SDCR & MCF_SDRAMC_SDCR_REF)
     /* Exit self refresh mode */
    MCF_SDRAMC_SDCR |= MCF_SDRAMC_SDCR_CKE;

    /* wait for DQS logic to relock */
	for(i=0; i<0x200; i++) {};

    return fout;
}
/********************************************************************/
/*
 * Initialize the Low Power Divider circuit
 * 
 * Parameters:
 *  div     Desired system frequency divider
 *
 * Return Value:
 *  The resulting output system frequency
 */
int
clock_limp (int div)
{
	uint32 temp;
    int sys_clock;  

    /* Check bounds of divider */
    if (div < MIN_LPD) 
    	div = MIN_LPD;
    if (div > MAX_LPD)
        div = MAX_LPD;
    
    sys_clock = (FREF/(3*(1 << div)));

    /* Save of the current value of the SSIDIV so we don't
       overwrite the value*/
    temp = (MCF_CCM_CDR & MCF_CCM_CDR_SSIDIV(0xFF) );       
      
    /* Apply the divider to the system clock */
    MCF_CCM_CDR = ( 0
    		   | MCF_CCM_CDR_LPDIV(div)
    		   | MCF_CCM_CDR_SSIDIV(temp) );
    
    MCF_CCM_MISCCR |= MCF_CCM_MISCCR_LIMP;
    
    return sys_clock;
}
/********************************************************************/
/*
 * Exit low power LIMP mode
 * 
 * Parameters:
 *  div     Desired system frequency divider
 *
 * Return Value:
 *  The resulting output system frequency
 */
int
clock_exit_limp (void)
{
    int fout;
    /* Exit LIMP mode */
    MCF_CCM_MISCCR &= ~(MCF_CCM_MISCCR_LIMP);

    /* Wait for PLL to lock */
    while ( !(MCF_CCM_MISCCR & MCF_CCM_MISCCR_PLL_LOCK )) { };
    	
    fout = get_sys_clock();
    return fout;
}
/********************************************************************/
/*
 * Get the value of the current system clock
 *
 * Parameters:
 *  none
 *
 * Return Value:
 *  The current output system frequency
 */
int
get_sys_clock (void)
{

	int divider; 
	int pfdr,refdiv,busdiv;
	
	/* Test to see if device is in LIMP mode */
	if (MCF_CCM_MISCCR & MCF_CCM_MISCCR_LIMP)
	{
		divider = MCF_CCM_CDR & MCF_CCM_CDR_LPDIV(0xF);
		return (FREF/(3*(1 << divider)));
	}
	else
	{
		pfdr   = (MCF_PLL_PCR & MCF_PLL_PCR_FBDIV(0x3F));
		refdiv = (1<<((MCF_PLL_PCR & MCF_PLL_PCR_REFDIV(0x7))>>8));		
        busdiv = (MCF_PLL_PDR & MCF_PLL_PDR_OUTDIV2(0xF))>>4;       

        return ( ((FREF * (pfdr + 1))/refdiv) / (busdiv+1));		
	}
}
/********************************************************************/
