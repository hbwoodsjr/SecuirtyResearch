/*
 * File:	mcf5301x.h
 * Purpose:	Register and bit definitions for the MCF5301x
 *
 * Notes:	
 *	
 */

#ifndef __MCF5301X_H__
#define __MCF5301X_H__

/********************************************************************/

#include "mcf5301x_aips.h"
#include "mcf5301x_ccm.h"
#include "mcf5301x_pll.h"
#include "mcf5301x_fbcs.h"
#include "mcf5301x_rngb.h"
#include "mcf5301x_gpio.h"
#include "mcf5301x_dspi.h"
#include "mcf5301x_eport.h"
#include "mcf5301x_fec.h"
#include "mcf5301x_uart.h"
#include "mcf5301x_sdramc.h"
#include "mcf5301x_scm.h"
#include "mcf5301x_intc.h"
#include "mcf5301x_rtc.h"
#include "mcf5301x_edma.h"
#include "mcf5301x_aips.h"
#include "mcf5301x_dtim.h"
#include "mcf5301x_pit.h"
#include "mcf5301x_iim.h"
#include "mcf5301x_xbs.h"
#include "mcf5301x_usb.h"
#include "mcf5301x_rtic.h"
#include "mcf5301x_mpu.h"
#include "mcf5301x_scc.h"
#include "mcf5301x_sdramc.h"
#include "mcf5301x_ssi.h"
#include "mcf5301x_sim.h"


/********************************************************************/

#define RUN   0 
#define DOZE  1
#define WAIT  2 
#define STOP  3 

void enable_low_power(int);

#endif /* __MCF5301X_H__ */
