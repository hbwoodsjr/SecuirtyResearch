/*
 * File:		sysinit.c
 * Purpose:		Reset configuration of the M53013EVB
 *
 * Notes:
 */

#include "common.h"

void enable_cache (void);
void fbcs_init(void);
void sdramc_init(void);
void gpio_init(void);
void eport_init(void);
void intc_init(void);
void intc0_init(void);
void intc1_init(void);
void scc_init(void);
void mcf53013_powerup_config( void );
void mcf53013_PHY_init(void);

/* Actual system clock frequency */
int sys_clk_khz;
int sys_clk_mhz;
uint8 powerup_config_flags = 0;

extern int poll_switches( void );
extern void mcf5xxx_wr_pc (uint32);


/********************************************************************/
void
mcf5301x_init (void)
{
    extern char __DATA_ROM[];
    extern char __DATA_RAM[];
    extern char __DATA_END[];
    extern char __BSS_START[];
    extern char __BSS_END[];
    extern uint32 VECTOR_TABLE[];
    extern uint32 __VECTOR_RAM[];
    extern uint32 __CORE_RAM[];

    static uint32 n;
    static uint8 *dp, *sp;
   
    /* configure to come out of LIMP Mode and Write into PLL registers */ 
    sys_clk_khz = clock_pll(SYS_CLK_KHZ,0);
    sys_clk_mhz = sys_clk_khz/1000;
    
    gpio_init();
    
    if ((ADDRESS)fbcs_init & (ADDRESS)(__CORE_SRAM)) 	//FSL test to see if running from SRAM
    {
    	fbcs_init();    	
    }
    else 		//FSL if not running in SRAM, implement the Self Modifying Code
    {
				//FSL Self modifying code to load RAM with fbcs_init() function
				//FSL and then it gets overwritten below.
				//FSL We need this for cases when we are running out of the same
				//FSL memory that we are configuring (this is bad) otherwise
				//FSL the system crashes.
		sp = (unsigned char *)fbcs_init;
		dp = (unsigned char *)__CORE_SRAM;
        for (n = (ADDRESS)fbcs_init; n < (ADDRESS)sdramc_init; n++)
        {
            *dp++ = *sp++;
        }
		mcf5xxx_wr_pc((ADDRESS)__CORE_SRAM);
	    	
    }
    
	sdramc_init();
 
     /* Copy the vector table to RAM */
    if (__VECTOR_RAM != VECTOR_TABLE)
    {
        for (n = 0; n < 256; n++)
            __VECTOR_RAM[n] = VECTOR_TABLE[n];
    }
    
   /* Don't want to reload the initilise variable from DATA_ROM expect for POR and External Reset condition */
    if(((MCF_CCM_RSR & MCF_CCM_RSR_POR) == 0x08) | ((MCF_CCM_RSR & MCF_CCM_RSR_EXT) == 0x04))
    {
    /* Move initialized data from ROM to RAM. */
    if (__DATA_ROM != __DATA_RAM)
       {
        dp = (uint8 *)__DATA_RAM;
        sp = (uint8 *)__DATA_ROM;
        n = __DATA_END - __DATA_RAM;
        while (n--)
            *dp++ = *sp++;
       }

   	if (__BSS_START != __BSS_END)
       {
        	sp = (uint8 *)__BSS_START;
	        n = __BSS_END - __BSS_START;
        	while (n--)
            	*sp++ = 0;
       }
    }

    mcf5xxx_wr_vbr((uint32)__VECTOR_RAM);

    uart_init(0);
    uart_init(1);
    uart_init(2);

	mcf53013_powerup_config();
	mcf53013_PHY_init();   

   // Enabling Interrupts after locating VBR
    intc_init();
	enable_cache();
 }
 
/*********************************************************************
* enable_cache - Enable cache and ACRs		                         *
**********************************************************************/
void enable_cache (void)
{
  if (CACHE)			//FSL if(1) then use cache....else use no-cache
  {						//FSL CACHE defined in processor.h
    asm {
        move.l   #0xF00FC060,d0		//Peripheral Space Masked starting at 0xF000_0000
        movec    d0,ACR0			//cache inhibit imprecise mode
        move.l   #0xa1000500,d0
        movec    d0,CACR			//default memory space cache on
    }
	
  }
  else				//FSL no cache
  {
    asm {
        move.l   #0x00000000,d0
        movec    d0,ACR0
        move.l   #0x00000000,d0
        movec    d0,CACR
    }
	
  }

#if 0
  if (CACHE)			//FSL if(1) then use cache....else use no-cache
  {						//FSL CACHE defined in processor.h
    asm {
        move.l   #0x4000C000,d0		//64K SDRAM starting at 0x4000_0000
        movec    d0,ACR0			//cache Flash
//        move.l   #0x4000c020,d0
//        movec    d0,ACR1			//do not cache DRAM because Ethernet cause cache coherency issues
        move.l   #0xa1000700,d0
        movec    d0,CACR			//default memory space cache off
    }
	
  }
  else				//FSL no cache
  {
    asm {
        move.l   #0x00000000,d0
        movec    d0,ACR0
        move.l   #0x00000000,d0
        movec    d0,CACR
    }
	
  }
#endif 

}
 
/********************************************************************/
void
gpio_init(void)
{
	/* Enable UART0/2 pins */
	MCF_GPIO_PAR_UART = (0
		| MCF_GPIO_PAR_UART_PAR_UCTS0(0x03)
		| MCF_GPIO_PAR_UART_PAR_URTS0(0x03)
		| MCF_GPIO_PAR_UART_PAR_URXD0
		| MCF_GPIO_PAR_UART_PAR_UTXD0
		| MCF_GPIO_PAR_UART_PAR_UTXD2
		| MCF_GPIO_PAR_UART_PAR_URXD2);
		
	/* Enable UART1 pins */
	MCF_GPIO_PAR_SSIH = (0
		| MCF_GPIO_PAR_SSIH_PAR_SSI_TXD(0x01)
		| MCF_GPIO_PAR_SSIH_PAR_SSI_RXD(0x01));
		
	/*Enable all chip select in CS mode*/
	MCF_GPIO_PAR_CS = (0
	     | MCF_GPIO_PAR_CS_PAR_CS5                
	     | MCF_GPIO_PAR_CS_PAR_CS4 
	     | MCF_GPIO_PAR_CS_PAR_CS1(0x03)
	     | MCF_GPIO_PAR_CS_PAR_CS0(0x03) );
	     

    /* Pin assignments for port BUSCTL 
           Pin BUSCTL3 : External bus output enable, /OE 
           Pin BUSCTL2 : External bus transfer acknowledge, /TA 
           Pin BUSCTL1 : External bus read/write, R/W 
           Pin BUSCTL0 : External bus transfer start, /TS 
    */

    /*     PDDR_BUSCTL[DDR3] = 0 
           PDDR_BUSCTL[DDR2] = 0 
           PDDR_BUSCTL[DDR1] = 0 
           PDDR_BUSCTL[DDR0] = 0 
    */
    MCF_GPIO_DDR_BUSCTL = 0;

    /*     PAR_BUSCTL[PAR_OE] = 1 
           PAR_BUSCTL[PAR_TA] = 1 
           PAR_BUSCTL[PAR_RWB] = 1 
           PAR_BUSCTL[PAR_TS] = %11 
    */
    MCF_GPIO_PAR_BUSCTL = MCF_GPIO_PAR_BUSCTL_PAR_OE      |
                          MCF_GPIO_PAR_BUSCTL_PAR_TA      |
                          MCF_GPIO_PAR_BUSCTL_PAR_RW     |
                          MCF_GPIO_PAR_BUSCTL_PAR_TS(0x3);

    /* Pin assignments for port BE 
           Pin BE3 : External bus byte enable BW/BWE3 
           Pin BE2 : External bus byte enable BW/BWE2 
           Pin BE1 : External bus byte enable BW/BWE1 
           Pin BE0 : External bus byte enable BW/BWE0 
    */

    /*     PDDR_BE[DDR3]   = 0  
           PDDR_BE[DDR2]   = 0  
           PDDR_BE[DDR1]   = 0  
           PDDR_BE[DDR0]   = 0  
    */
    MCF_GPIO_DDR_BS = 0;

    /*     PAR_BE[PAR_BE3] = 1  
           PAR_BE[PAR_BE2] = 1  
           PAR_BE[PAR_BE1] = 1  
           PAR_BE[PAR_BE0] = 1  
    */
    MCF_GPIO_PAR_BS = MCF_GPIO_PAR_BS_PAR_BS3 |
                      MCF_GPIO_PAR_BS_PAR_BS2 |
                      MCF_GPIO_PAR_BS_PAR_BS1 |
                      MCF_GPIO_PAR_BS_PAR_BS0;

    /* Pin assignments for port CS 
           Pin CS5 : Flex bus chip select /FB_CS5 
           Pin CS4 : Flex bus chip select /FB_CS4 
           Pin CS3 : Flex bus chip select /FB_CS3 
           Pin CS2 : Flex bus chip select /FB_CS2 
           Pin CS1 : Flex bus chip select /FB_CS1 
    */

    /*     PDDR_CS[DDR5]   = 0  
           PDDR_CS[DDR4]   = 0  
           PDDR_CS[DDR3]   = 0  
           PDDR_CS[DDR2]   = 0  
           PDDR_CS[DDR1]   = 0  
    */
    MCF_GPIO_DDR_CS = 0;

    /*     PDDR_FECI2C[DDR3] = 0 
           PDDR_FECI2C[DDR2] = 0 
           PDDR_FECI2C[DDR1] = 0 
           PDDR_FECI2C[DDR0] = 0 
    */
    MCF_GPIO_DDR_FECI2C = 0;

	/* Enable FEC RMII pin functions */
	MCF_GPIO_PAR_FEC = (MCF_GPIO_PAR_FEC_PAR_RMII0  |
			MCF_GPIO_PAR_FEC_PAR_7WIRE0 |
			MCF_GPIO_PAR_FEC_PAR_RMII1  |
			MCF_GPIO_PAR_FEC_PAR_7WIRE1);

    /*     PAR_FECI2C[PAR_MDC] = %11 
           PAR_FECI2C[PAR_MDIO] = %11 
           PAR_FECI2C[PAR_SCL] = 0 
           PAR_FECI2C[PAR_SDA] = 0 
    */
	MCF_GPIO_PAR_FECI2C = (MCF_GPIO_PAR_FECI2C_PAR_RMII1_MDIO |
			MCF_GPIO_PAR_FECI2C_PAR_RMII1_MDC  |
			MCF_GPIO_PAR_FECI2C_PAR_RMII0_MDIO | 
			MCF_GPIO_PAR_FECI2C_PAR_RMII0_MDC);
			

    /* Pin assignments for ports FECH and FECL */

    MCF_GPIO_DDR_FEC0 = 0;	

    /* Pin assignments for port TIMER 
           Pins are all GPIO outputs 
    */

    /*     PDDR_TIMER[DDR3] = 1 
           PDDR_TIMER[DDR2] = 1 
           PDDR_TIMER[DDR1] = 1 
           PDDR_TIMER[DDR0] = 1 
    MCF_GPIO_PDDR_TIMER = MCF_GPIO_PDDR_TIMER_PDDR_TIMER3 |
                          MCF_GPIO_PDDR_TIMER_PDDR_TIMER2 |
                          MCF_GPIO_PDDR_TIMER_PDDR_TIMER1 |
                          MCF_GPIO_PDDR_TIMER_PDDR_TIMER0;
    */

    /*     PAR_TIMER[PAR_T3IN] = 0 
           PAR_TIMER[PAR_T2IN] = 0 
           PAR_TIMER[PAR_T1IN] = 0 
           PAR_TIMER[PAR_T0IN] = 0 
    */
    MCF_GPIO_PAR_TIMER = 0;

    /* Pin assignments for port UART 
           Pin UART7 : GPIO input 
           Pin UART6 : GPIO input 
           Pin UART5 : UART 1 transmit data, U1TXD 
           Pin UART4 : UART 1 receive data, U1RXD 
           Pin UART3 : GPIO input 
           Pin UART2 : GPIO input 
           Pin UART1 : UART 0 transmit data, U0TXD 
           Pin UART0 : UART 0 receive data, U0RXD 
    */

    /*     PDDR_UART[DDR7] = 0  
           PDDR_UART[DDR6] = 0  
           PDDR_UART[DDR5] = 0  
           PDDR_UART[DDR4] = 0  
           PDDR_UART[DDR3] = 0  
           PDDR_UART[DDR2] = 0  
           PDDR_UART[DDR1] = 0  
           PDDR_UART[DDR0] = 0  
    */
    /*    MCF_GPIO_PDDR_UART = 0;

     PAR_UART[PAR_U1CTS] = 0 
           PAR_UART[PAR_U1RTS] = 0 
           PAR_UART[PAR_U1RXD] = %11 
           PAR_UART[PAR_U1TXD] = %11 
           PAR_UART[PAR_U0CTS] = 0 
           PAR_UART[PAR_U0RTS] = 0 
           PAR_UART[PAR_U0RXD] = 1 
           PAR_UART[PAR_U0TXD] = 1 

    MCF_GPIO_PAR_UART = MCF_GPIO_PAR_UART_PAR_URXD1(0x3) |
                        MCF_GPIO_PAR_UART_PAR_UTXD1(0x3) |
                        MCF_GPIO_PAR_UART_PAR_URXD0      |
                        MCF_GPIO_PAR_UART_PAR_UTXD0;
    */	     
}
/********************************************************************/
/* Flexbus is configured for CS0 and CS1 memory configuration */

void
fbcs_init (void)
{
  if(!(MCF_FBCS0_CSMR&MCF_FBCS_CSMR_V))		//FSL if CS0 Valid bit set...do not reinitialize chip selects
  {
    /* External MRAM */
    MCF_FBCS1_CSAR = MCF_FBCS_CSAR_BA(0xC0000000);
    
    MCF_FBCS1_CSCR = (MCF_FBCS_CSCR_PS_16
                    | MCF_FBCS_CSCR_AA
    		        | MCF_FBCS_CSCR_BEM
    		        | MCF_FBCS_CSCR_SBM
                    | MCF_FBCS_CSCR_WS(7));
    MCF_FBCS1_CSMR = (MCF_FBCS_CSMR_BAM_512K
                    | MCF_FBCS_CSMR_V);

    /* Boot FLASH connected to FBCS0 */
    MCF_FBCS0_CSAR = MCF_FBCS_CSAR_BA(0x00000000);
    MCF_FBCS0_CSCR = (MCF_FBCS_CSCR_PS_16
         		    | MCF_FBCS_CSCR_BEM
    		        | MCF_FBCS_CSCR_SBM
                    | MCF_FBCS_CSCR_AA
                    | MCF_FBCS_CSCR_WS(7));
    MCF_FBCS0_CSMR = (MCF_FBCS_CSMR_BAM_16M
                    | MCF_FBCS_CSMR_V);  	
  }
}
/********************************************************************/
void
sdramc_init (void)
{

	/*
	 * Check to see if the SDRAM has already been initialized
	 * by a run control tool
	 */
	 
	if (!(MCF_SDRAMC_SDCR & MCF_SDRAMC_SDCR_REF))
	{

		/* SDRAM chip select initialization */
		
		/* Initialize SDRAM chip select */
        MCF_SDRAMC_SDCS0 = (0
            | MCF_SDRAMC_SDCS_BA(SDRAM_ADDRESS)
            | MCF_SDRAMC_SDCS_CSSZ(MCF_SDRAMC_SDCS_CSSZ_64MBYTE)
            );
            

        /*
         * Basic configuration and initialization
         */

        MCF_SDRAMC_SDCFG1 = (0
			| MCF_SDRAMC_SDCFG1_SRD2RW(SDRAM_CASL + 1)
			| MCF_SDRAMC_SDCFG1_SWT2RD(SDRAM_TWR + 1)
			| MCF_SDRAMC_SDCFG1_RDLAT((SDRAM_CASL*2)+1)
			| MCF_SDRAMC_SDCFG1_ACT2RW(SDRAM_TRCD - 1)
			| MCF_SDRAMC_SDCFG1_PRE2ACT(SDRAM_TRP - 1)
			| MCF_SDRAMC_SDCFG1_REF2ACT(SDRAM_TRFC_DDR - 1)
			| MCF_SDRAMC_SDCFG1_WTLAT(3)
            );
	
		MCF_SDRAMC_SDCFG2 = (0
			| MCF_SDRAMC_SDCFG2_BRD2PRE(SDRAM_BL/2 + 1)
			| MCF_SDRAMC_SDCFG2_BWT2RW(SDRAM_BL/2 + SDRAM_TWR)
			| MCF_SDRAMC_SDCFG2_BRD2WT(SDRAM_CASL + (SDRAM_BL/2) - 1)
			| MCF_SDRAMC_SDCFG2_BL(SDRAM_BL-1)
            );


		/* 
         * Precharge and enable write to SDMR 
         */
        MCF_SDRAMC_SDCR = (0
			| MCF_SDRAMC_SDCR_MODE_EN
			| MCF_SDRAMC_SDCR_CKE
			| MCF_SDRAMC_SDCR_DDR
			| MCF_SDRAMC_SDCR_MUX(1)
			| MCF_SDRAMC_SDCR_RCNT((int)(((SDRAM_TREFI/(SYSTEM_PERIOD*64)) - 1) + 0.5))
			| MCF_SDRAMC_SDCR_DQS_OE(0xf)
			| MCF_SDRAMC_SDCR_PS_16
			| MCF_SDRAMC_SDCR_IPALL
            );            

        /*
         * Write mode register
         */
        // CL = 3, sequential, 8 beat burst
        MCF_SDRAMC_SDMR = (0
            | MCF_SDRAMC_SDMR_BNKAD_LMR
            | MCF_SDRAMC_SDMR_AD(0x33)
            | MCF_SDRAMC_SDMR_CMD
            );                                              

        /*
         * Execute a PALL command
         */
        MCF_SDRAMC_SDCR |= MCF_SDRAMC_SDCR_IPALL;

        /*
         * Perform two REF cycles
         */

         MCF_SDRAMC_SDCR |= MCF_SDRAMC_SDCR_IREF;
         MCF_SDRAMC_SDCR |= MCF_SDRAMC_SDCR_IREF;

        /*
         * Enable auto refresh and lock SDMR
         */
        MCF_SDRAMC_SDCR &= ~MCF_SDRAMC_SDCR_MODE_EN;
        MCF_SDRAMC_SDCR |= (0
            | MCF_SDRAMC_SDCR_REF
            | MCF_SDRAMC_SDCR_DQS_OE(0x3)
            );                                              

	}

}
/********************************************************************/ 
void intc_init()
{
  intc0_init();
  intc1_init();
  mcf5xxx_irq_enable();
}
/********************************************************************/ 
////initialize the timer for scc/////////
void scc_timer_init()
{
  MCF_SCC_TIMER_IV = 0xffffffff;
  MCF_SCC_TIMER_CTRL = MCF_SCC_TIMER_CTRL_STRT|MCF_SCC_TIMER_CTRL_LOAD;
}
 
/********************************************************************/
//intc_init1 function unmasks all the 64 interrupts of the interrupt controller and assign them a default priority level 1.//
void intc1_init ()
{
 MCF_INTC1_CIMR = 0x40;
 MCF_INTC1_ICR0  =0x01;                 
 MCF_INTC1_ICR1  =0x01; 
 MCF_INTC1_ICR2  =0x01; 
 MCF_INTC1_ICR3  =0x01; 
 MCF_INTC1_ICR4  =0x01; 
 MCF_INTC1_ICR5  =0x01; 
 MCF_INTC1_ICR6  =0x01; 
 MCF_INTC1_ICR7  =0x01; 
 MCF_INTC1_ICR8  =0x01; 
 MCF_INTC1_ICR9  =0x01; 
 MCF_INTC1_ICR10 =0x01; 
 MCF_INTC1_ICR11 =0x01; 
 MCF_INTC1_ICR12 =0x01; 
 MCF_INTC1_ICR13 =0x01; 
 MCF_INTC1_ICR14 =0x01; 
 MCF_INTC1_ICR15 =0x01; 
 MCF_INTC1_ICR16 =0x01; 
 MCF_INTC1_ICR17 =0x01; 
 MCF_INTC1_ICR18 =0x01; 
 MCF_INTC1_ICR19 =0x01; 
 MCF_INTC1_ICR20 =0x01; 
 MCF_INTC1_ICR21 =0x01; 
 MCF_INTC1_ICR22 =0x01; 
 MCF_INTC1_ICR23 =0x01; 
 MCF_INTC1_ICR24 =0x01; 
 MCF_INTC1_ICR25 =0x01; 
 MCF_INTC1_ICR26 =0x01; 
 MCF_INTC1_ICR27 =0x01; 
 MCF_INTC1_ICR28 =0x01; 
 MCF_INTC1_ICR29 =0x01; 
 MCF_INTC1_ICR30 =0x01; 
 MCF_INTC1_ICR31 =0x01; 
 MCF_INTC1_ICR32 =0x01; 
 MCF_INTC1_ICR33 =0x01; 
 MCF_INTC1_ICR34 =0x01; 
 MCF_INTC1_ICR35 =0x01; 
 MCF_INTC1_ICR36 =0x01; 
 MCF_INTC1_ICR37 =0x01; 
 MCF_INTC1_ICR38 =0x01; 
 MCF_INTC1_ICR39 =0x01; 
 MCF_INTC1_ICR40 =0x01; 
 MCF_INTC1_ICR41 =0x01; 
 MCF_INTC1_ICR42 =0x01; 
 MCF_INTC1_ICR43 =0x01; 
 MCF_INTC1_ICR44 =0x01; 
 MCF_INTC1_ICR45 =0x01; 
 MCF_INTC1_ICR46 =0x01; 
 MCF_INTC1_ICR47 =0x01; 
 MCF_INTC1_ICR48 =0x01; 
 MCF_INTC1_ICR49 =0x01; 
 MCF_INTC1_ICR50 =0x01; 
 MCF_INTC1_ICR51 =0x01; 
 MCF_INTC1_ICR52 =0x01; 
 MCF_INTC1_ICR53 =0x01; 
 MCF_INTC1_ICR54 =0x01; 
 MCF_INTC1_ICR55 =0x01; 
 MCF_INTC1_ICR56 =0x01; 
 MCF_INTC1_ICR57 =0x01; 
 MCF_INTC1_ICR58 =0x01; 
 MCF_INTC1_ICR59 =0x01; 
 MCF_INTC1_ICR60 =0x01; 
 MCF_INTC1_ICR61 =0x00; //for scc zerozizing int in security enabled longjing 
 MCF_INTC1_ICR62 =0x01; 
 MCF_INTC1_ICR63 =0x01; 
}

//intc_init0 function unmasks all the 64 interrupts of the interrupt controller and assign them a default priority level 1.//
void intc0_init()
{
 MCF_INTC0_CIMR = 0x40;
 MCF_INTC0_ICR0  =0x01;                 
 MCF_INTC0_ICR1  =0x01; 
 MCF_INTC0_ICR2  =0x01; 
 MCF_INTC0_ICR3  =0x01; 
 MCF_INTC0_ICR4  =0x01; 
 MCF_INTC0_ICR5  =0x01; 
 MCF_INTC0_ICR6  =0x01; 
 MCF_INTC0_ICR7  =0x01; 
 MCF_INTC0_ICR8  =0x01; 
 MCF_INTC0_ICR9  =0x01; 
 MCF_INTC0_ICR10 =0x01; 
 MCF_INTC0_ICR11 =0x01; 
 MCF_INTC0_ICR12 =0x01; 
 MCF_INTC0_ICR13 =0x01; 
 MCF_INTC0_ICR14 =0x01; 
 MCF_INTC0_ICR15 =0x01; 
 MCF_INTC0_ICR16 =0x01; 
 MCF_INTC0_ICR17 =0x01; 
 MCF_INTC0_ICR18 =0x01; 
 MCF_INTC0_ICR19 =0x01; 
 MCF_INTC0_ICR20 =0x01; 
 MCF_INTC0_ICR21 =0x01; 
 MCF_INTC0_ICR22 =0x01; 
 MCF_INTC0_ICR23 =0x01; 
 MCF_INTC0_ICR24 =0x01; 
 MCF_INTC0_ICR25 =0x01; 
//FSL MCF_INTC0_ICR26 =0x01;  //FSL UART0
//FSL MCF_INTC0_ICR27 =0x01;  //FSL UART1 
//FSL MCF_INTC0_ICR28 =0x01;  //FSL UART2 
 MCF_INTC0_ICR29 =0x01; 
 MCF_INTC0_ICR30 =0x01; 
 MCF_INTC0_ICR31 =0x01; 
 MCF_INTC0_ICR32 =0x01; 
 MCF_INTC0_ICR33 =0x01; 
 MCF_INTC0_ICR34 =0x01; 
 MCF_INTC0_ICR35 =0x01; 
 MCF_INTC0_ICR36 =0x01; 
 MCF_INTC0_ICR37 =0x01; 
 MCF_INTC0_ICR38 =0x01; 
 MCF_INTC0_ICR39 =0x01; 
 MCF_INTC0_ICR40 =0x01; 
 MCF_INTC0_ICR41 =0x01; 
 MCF_INTC0_ICR42 =0x01; 
 MCF_INTC0_ICR43 =0x01; 
 MCF_INTC0_ICR44 =0x01; 
 MCF_INTC0_ICR45 =0x01; 
 MCF_INTC0_ICR46 =0x01; 
 MCF_INTC0_ICR47 =0x01; 
 MCF_INTC0_ICR48 =0x01; 
 MCF_INTC0_ICR49 =0x01; 
 MCF_INTC0_ICR50 =0x01; 
 MCF_INTC0_ICR51 =0x01; 
 MCF_INTC0_ICR52 =0x01; 
 MCF_INTC0_ICR53 =0x01; 
 MCF_INTC0_ICR54 =0x01; 
 MCF_INTC0_ICR55 =0x01; 
 MCF_INTC0_ICR56 =0x01; 
 MCF_INTC0_ICR57 =0x01; 
 MCF_INTC0_ICR58 =0x01; 
 MCF_INTC0_ICR59 =0x01; 
 MCF_INTC0_ICR60 =0x01; 
 MCF_INTC0_ICR61 =0x01; 
 MCF_INTC0_ICR62 =0x01; 
 MCF_INTC0_ICR63 =0x01;
}

/********************************************************************/ 
// This function reads the switches at power-up, and sets a power-up
// config flag.
/********************************************************************/
void mcf53013_powerup_config( void )
{
	powerup_config_flags = poll_switches();
}

/********************************************************************/

void eport_init(void)
{
	/*
	 * Allow interrupts from IRQ7 (black button)
	 */

	/* Set IRQ7 to be level triggered */
	MCF_EPORT0_EPPAR = MCF_EPORT0_EPPAR_EPPA7(MCF_EPORT0_EPPAR_LEVEL);

	/* Enable EPORT interrupt 7 requests */
	MCF_EPORT0_EPIER = MCF_EPORT0_EPIER_EPIE7|MCF_EPORT0_EPIER_EPIE3;

}
/********************************************************************/
// Init external PHY - National Semiconductor DP83640
/********************************************************************/
int DUPLEX_phy_r17_dpm;
void mcf53013_PHY_init(void)
{
  	unsigned short		reg0;
  	int myctr;

	MCF_CCM_MISCCR |= MCF_CCM_MISCCR_FECM;		//FSL Set two RMII PHY mode
	
//FSL replace function call	fec_mii_init((SYSTEM_CLOCK));  with below MCF_FEC_MSCR macro
    /*
     * Configure MII interface speed. Must be <= 2.5MHz
     *
     * Desired MII clock is 2.5MHz
     * MII Speed Setting = System_Clock_Bus_Speed / (2.5MHz * 2)
     */
	MCF_FEC_MSCR(ETH_PORT) = MCF_FEC_MSCR_MII_SPEED((uint32)(SYS_CLK_MHZ/5)); 

	do
	{
		while(!(fec_mii_read(FEC_PHY0, PHY_REG_CR, &reg0)))		//FSL read PHY control register
		{
			reg0=0;
		};
		
	} while(reg0&PHY_R0_RESET);		//Test RESET bit...1=in reset, 0=reset complete
		
#if (!AUTO)
	if (BaseT==100)		//FSL BaseT set to 100mpbs
		reg0 |= 0x2000;								// 100Mbps
	else				//FSL BaseT defaults to 10mbps
		reg0 &= ~0x2000;							// 10Mbps

	if (DUPLEX==0)
		reg0 |= 0x0100;								// Full Duplex
	else		
		reg0 &= ~0x0100;							// Half Duplex

	while(!fec_mii_write( FEC_PHY0, PHY_REG_CR, reg0|0x0200 ))
	{
	};					//Force re-negotiation

#endif

	while(!(fec_mii_read(FEC_PHY0, 0x10, &reg0)))	// read PHY status register
	{
		reg0=0;
	};
	DUPLEX_phy_r17_dpm = (int)((reg0&0x0004)>>2);	// 1=full,0=half duplex...used in ifec.c
	
	myctr=0;
	printf("\n\nEthernet Link" );
	do		//FSL read PHY status register
	{
		fec_mii_read(FEC_PHY0, 0x10, &reg0);
		myctr++;
		if(myctr>333333)
		{
			printf("FAILED...check cable please\n\n" );
			return;
		}
	}while (!(reg0&(PHY_R1_LS)));		//FSL exit while loop when Link Status up
	
	printf("Established!\n\n");


}
/********************************************************************/