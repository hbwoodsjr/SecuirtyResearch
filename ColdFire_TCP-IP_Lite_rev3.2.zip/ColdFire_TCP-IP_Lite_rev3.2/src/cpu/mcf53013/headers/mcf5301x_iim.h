/*
 * File:    mcf5301x_iim.h
 * Purpose: Register and bit definitions
 */

#ifndef __MCF5301X_IIM_H__
#define __MCF5301X_IIM_H__

/*********************************************************************
*
* IC Identification Module (IIM)
*
*********************************************************************/

/* Register read/write macros */
#define MCF_IIM_SR                     (*(vuint8 *)(0xFC0C8000))                             /* Status Register */
#define MCF_IIM_SIMR                   (*(vuint8 *)(0xFC0C8004))                             /* Status Mask register */
#define MCF_IIM_ESR                    (*(vuint8 *)(0xFC0C8008))                             /* Module Error status Register */
#define MCF_IIM_EIMR                   (*(vuint8 *)(0xFC0C800C))                             /* Error IRQ mask register */
#define MCF_IIM_FCL                    (*(vuint8 *)(0xFC0C8010))                             /* Fuse Control register */
#define MCF_IIM_UA                     (*(vuint8 *)(0xFC0C8014))                             /* Upper Address register */
#define MCF_IIM_LA                     (*(vuint8 *)(0xFC0C8018))                             /* Lower Address register */
#define MCF_IIM_SDAT                   (*(vuint8 *)(0xFC0C801C))                             /* Explicit sense Data register */
#define MCF_IIM_PREG_P                 (*(vuint8 *)(0xFC0C8028))                             /* Program protection register */
#define MCF_IIM_DIVIDE                 (*(vuint8 *)(0xFC0C803C))                             /* Divide factor register */
#define MCF_IIM_FBAC0                  (*(vuint8 *)(0xFC0C8800))                             /* Bank 0 Protection Register */
#define MCF_IIM_ANATEST                (*(vuint8 *)(0xFC0C8804))                             /* Analog test select */
#define MCF_IIM_BGPTRIM                (*(vuint8 *)(0xFC0C8808))                             /* Band gap trim select */
#define MCF_IIM_AMPBR                  (*(vuint8 *)(0xFC0C880C))                             /* Bypass control */
#define MCF_IIM_DRVACR                 (*(vuint8 *)(0xFC0C8810))                             /* Driver amps control for terminal limit and alternate common mode */
#define MCF_IIM_SPKACR                 (*(vuint8 *)(0xFC0C8814))                             /* Speaker Ampilfier control register*/
#define MCF_IIM_HSHPACR                (*(vuint8 *)(0xFC0C8818))                             /* Handset and headphone control */
#define MCF_IIM_PISA_EN                (*(vuint8 *)(0xFC0C8870))                             /* Security block enable */
#define MCF_IIM_SAKRAM                 (*(vuint8 *)(0xFC0C8874))                             /* Self adjustment register for kram */
#define MCF_IIM_SATAG                  (*(vuint8 *)(0xFC0C8874))                             /* Self adjustment register for TAG register */
#define MCF_IIM_SACACHE                (*(vuint8 *)(0xFC0C887C))                             /* Self adjustmnet register for cache */
#define MCF_IIM_FBAC1                  (*(vuint8 *)(0xFC0C8C00))                             /* Fuse bank1 protection Register */
#define MCF_IIM_SASCCM                 (*(vuint8 *)(0xFC0C8C04))                             /* self adjustment register for SCCM */
#define MCF_IIM_DEVID                  (*(vuint8 *)(0xFC0C8C08))                             /* Device ID register */

/* Bit definitions and macros for MCF_IIM_SR */
#define MCF_IIM_SR_SNSD                (0x01)                                    /* sense cycle finished */
#define MCF_IIM_SR_PRGD                (0x02)                                    /* Program operation done */
#define MCF_IIM_SR_BUSY                (0x80)                                    /* IIM Busy with program or sense cycle */

/* Bit definitions and macros for MCF_IIM_SIMR */
#define MCF_IIM_SIMR_SNSDM             (0x01)                                    /* Mask SNSD IRQ */
#define MCF_IIM_SIMR_PRGDM             (0x02)                                    /* Mask PRGD IRQ */

/* Bit definitions and macros for MCF_IIM_ESR */
#define MCF_IIM_ESR_PARE               (0x02)                                    /* Parity error of cache */
#define MCF_IIM_ESR_SNSE               (0x04)                                    /* Sence Error */
#define MCF_IIM_ESR_RPE                (0x10)                                    /* Read protect error */
#define MCF_IIM_ESR_OPE                (0x20)                                    /* override protect error */
#define MCF_IIM_ESR_WPE                (0x40)                                    /* Write protect errror */

/* Bit definitions and macros for MCF_IIM_EIMR */
#define MCF_IIM_EIMR_PAREM             (0x02)                                    /* Parity error interrupt mask */
#define MCF_IIM_EIMR_SNSEM             (0x04)                                    /* sense cycle interrupt mask */
#define MCF_IIM_EIMR_RPEM              (0x10)                                    /* Read protect intrrupt mask */
#define MCF_IIM_EIMR_OPEM              (0x20)                                    /* override protect interrupt mask */
#define MCF_IIM_EIMR_WPEM              (0x40)                                    /* write protect interrupt mask */
#define MCF_IIM_EIMR_PRGEM             (0x80)                                    /* Program error interrupt mask */

/* Bit definitions and macros for MCF_IIM_FCL */
#define MCF_IIM_FCL_PRG                (0x01)                                    /* program cycle*/
#define MCF_IIM_FCL_ESNS1              (0x02)                                    /* Explict 1 sense cycle */
#define MCF_IIM_FCL_ESNS0              (0x04)                                    /* Explict 0 sense cylce */
#define MCF_IIM_FCL_ESNSN              (0x08)                                    /* Explict normal sence cycle*/
#define MCF_IIM_FCL_PRG_LENGTH(x)      (((x)&0x07)<<4)                           /* Program length */
#define MCF_IIM_FCL_DPC                (0x80)                                    /* Delayed programing cycle */

/* Bit definitions and macros for MCF_IIM_UA */
#define MCF_IIM_UA_A(x)                (((x)&0xFF)<<0)                           /* Upper address register A[13:8]*/

/* Bit definitions and macros for MCF_IIM_LA */
#define MCF_IIM_LA_A(x)                (((x)&0xFF)<<0)                           /* Lower address register A[7:0]*/

/* Bit definitions and macros for MCF_IIM_SDAT */
#define MCF_IIM_SDAT_D(x)              (((x)&0xFF)<<0)                           /* Sense DATA*/

/* Bit definitions and macros for MCF_IIM_PREG_P */
#define MCF_IIM_PREG_P_PRGP(x)         (((x)&0xFF)<<0)                           /* programed protection register */

/* Bit definitions and macros for MCF_IIM_DIVIDE */
#define MCF_IIM_DIVIDE_DIVIDE(x)       (((x)&0xFF)<<0)                           /* Divide register */

/* Bit definitions and macros for MCF_IIM_FBAC0 */
#define MCF_IIM_FBAC_FBESP            (0x08)                                    /* Fuse Bank sense protect */
#define MCF_IIM_FBAC_FBRP             (0x20)                                    /* Fuse bank read protect */
#define MCF_IIM_FBAC_FBOP             (0x40)                                    /* Fuse bank override protect */
#define MCF_IIM_FBAC_FBWP             (0x80)                                    /* Fuse bank write protect */

/* Bit definitions and macros for MCF_IIM_ANATEST */
#define MCF_IIM_ANATEST_ANATESTSEL(x)  (((x)&0x0F)<<0)                           /* codec analog test regoster */

/* Bit definitions and macros for MCF_IIM_BGPTRIM */
#define MCF_IIM_BGPTRIM_BGPTRIM(x)     (((x)&0x0F)<<0)
#define MCF_IIM_BGPTRIM_PMUTRIM(x)     (((x)&0x0F)<<4)

/* Bit definitions and macros for MCF_IIM_AMPBR */
#define MCF_IIM_AMPBR_SPK              (0x01)
#define MCF_IIM_AMPBR_HS               (0x02)
#define MCF_IIM_AMPBR_HP               (0x04)
#define MCF_IIM_AMPBR_MIC              (0x08)                                    /* MIC select*/

/* Bit definitions and macros for MCF_IIM_DRVACR */
#define MCF_IIM_DRVACR_THMLMT(x)       (((x)&0x03)<<0)
#define MCF_IIM_DRVACR_ACM             (0x04)

/* Bit definitions and macros for MCF_IIM_SPKACR */
#define MCF_IIM_SPKACR_HFOCL           (0x01)
#define MCF_IIM_SPKACR_OCL             (0x02)
#define MCF_IIM_SPKACR_HBC             (0x04)

/* Bit definitions and macros for MCF_IIM_HSHPACR */
#define MCF_IIM_HSHPACR_HPOCL          (0x01)
#define MCF_IIM_HSHPACR_HPHBC          (0x02)
#define MCF_IIM_HSHPACR_HSOCL          (0x04)
#define MCF_IIM_HSHPACR_HSHBC          (0x08)

/* Bit definitions and macros for MCF_IIM_PISA_EN */
#define MCF_IIM_PISA_EN_ROMCEN         (0x01)                                    /* ROMC enable */
#define MCF_IIM_PISA_EN_SCC1EN         (0x02)                                    /* SCC enable */
#define MCF_IIM_PISA_EN_RTICEN         (0x04)                                    /* RTIC Enable */
#define MCF_IIM_PISA_EN_BOOTINT        (0x08)                                    /* Boot from internal ROM */
#define MCF_IIM_PISA_EN_FASTSUPDIS     (0x20)                                    /* selcect supervisor acces during FAST mode*/
#define MCF_IIM_PISA_EN_JTAGEN         (0x40)                                    /* select jtag */
#define MCF_IIM_PISA_EN_ROMSEC         (0x80)                                    /* Select rom bist signature */

/* Bit definitions and macros for MCF_IIM_SAKRAM */
#define MCF_IIM_SAKRAM_SELFADJ(x)      (((x)&0x3F)<<0)                           /* Self Adjust */

/* Bit definitions and macros for MCF_IIM_SATAG */
#define MCF_IIM_SATAG_SELFADJ(x)       (((x)&0x3F)<<0)                           /* Self Adjust */

/* Bit definitions and macros for MCF_IIM_SACACHE */
#define MCF_IIM_SACACHE_SELFADJ(x)     (((x)&0x3F)<<0)                           /* Self Adjust */

/* Bit definitions and macros for MCF_IIM_FBAC1 */
#define MCF_IIM_FBAC1_FBESP            (0x08)                                    /* Fuse Bank sense protect */
#define MCF_IIM_FBAC1_FBRP             (0x20)                                    /* Fuse bank read protect */
#define MCF_IIM_FBAC1_FBOP             (0x40)                                    /* Fuse bank override protect */
#define MCF_IIM_FBAC1_FBWP             (0x80)                                    /* Fuse bank write protect */

/* Bit definitions and macros for MCF_IIM_SASCCM */
#define MCF_IIM_SASCCM_SELFADJ(x)      (((x)&0x3F)<<0)                           /* Self Adjust */

/* Bit definitions and macros for MCF_IIM_DEVID */
#define MCF_IIM_DEVID_ID(x)            (((x)&0x03)<<0)                           /* Device ID */



// reset value of registers
#define MCF_IIM_SR_RESET                     0x00                       /* Status Register */
#define MCF_IIM_SIMR_RESET                   0x00                       /* Status Mask register */
#define MCF_IIM_ESR_RESET                    0x00                       /* Module Error status Register */
#define MCF_IIM_EIMR_RESET                   0x00                       /* Error IRQ mask register */
#define MCF_IIM_FCL_RESET                    0x30                       /* Fuse Control register */
#define MCF_IIM_UA_RESET                     0x00                       /* Upper Address register */
#define MCF_IIM_LA_RESET                     0x00                       /* Lower Address register */
#define MCF_IIM_SDAT_RESET                   0x00                       /* Explicit sense Data register */
#define MCF_IIM_PREG_P_RESET                 0x00                       /* Program protection register */
#define MCF_IIM_DIVIDE_RESET                 0x42                       /* Divide factor register */


// read masks for registers
#define   MCF_IIM_SR_READ_MASK                0x00
#define   MCF_IIM_SIMR_READ_MASK              0x03
#define   MCF_IIM_ESR_READ_MASK               0x00
#define   MCF_IIM_EIMR_READ_MASK              0xFE
#define   MCF_IIM_UA_READ_MASK                0x3F
#define   MCF_IIM_LA_READ_MASK                0xFF
#define   MCF_IIM_SDAT_READ_MASK              0xFF
#define   MCF_IIM_DIVIDE_READ_MASK            0xFF
#define   MCF_IIM_PREG_P_READ_MASK            0xFF
#define   MCF_IIM_FCL_READ_MASK               0xF0

// write mask for registers
#define   MCF_IIM_FCL_WRITE_MASK              0xF0

/********************************************************************/

#endif /* __MCF5301X_IIM_H__ */











