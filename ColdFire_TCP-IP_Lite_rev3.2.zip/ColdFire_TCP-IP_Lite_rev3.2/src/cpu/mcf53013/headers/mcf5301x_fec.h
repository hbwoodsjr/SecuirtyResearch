/* Coldfire C Header File
 * Copyright Freescale Semiconductor Inc
 * All rights reserved.
 *
 * 2008/02/26 Revision: 0.1
 *
 * (c) Copyright UNIS, spol. s r.o. 1997-2008
 * UNIS, spol. s r.o.
 * Jundrovska 33
 * 624 00 Brno
 * Czech Republic
 * http      : www.processorexpert.com
 * mail      : info@processorexpert.com
 */

#ifndef __MCF53013_FEC_H__
#define __MCF53013_FEC_H__


/*********************************************************************
*
* Fast Ethernet Controller (FEC)
*
*********************************************************************/

/* Register read/write macros */
#define MCF_FEC_EIR(x)		(*(vuint32*)((0xFC030004)+((x)*0x4000)))
#define MCF_FEC_EIMR(x)		(*(vuint32*)((0xFC030008)+((x)*0x4000)))
#define MCF_FEC_RDAR(x)		(*(vuint32*)((0xFC030010)+((x)*0x4000)))
#define MCF_FEC_TDAR(x)		(*(vuint32*)((0xFC030014)+((x)*0x4000)))
#define MCF_FEC_ECR(x)		(*(vuint32*)((0xFC030024)+((x)*0x4000)))
#define MCF_FEC_MMFR(x)		(*(vuint32*)((0xFC030040)+((x)*0x4000)))
#define MCF_FEC_MSCR(x)		(*(vuint32*)((0xFC030044)+((x)*0x4000)))
#define MCF_FEC_MIBC(x)		(*(vuint32*)((0xFC030064)+((x)*0x4000)))
#define MCF_FEC_RCR(x)		(*(vuint32*)((0xFC030084)+((x)*0x4000)))
#define MCF_FEC_TCR(x)		(*(vuint32*)((0xFC0300C4)+((x)*0x4000)))
#define MCF_FEC_PALR(x)		(*(vuint32*)((0xFC0300E4)+((x)*0x4000)))
#define MCF_FEC_PAUR(x)		(*(vuint32*)((0xFC0300E8)+((x)*0x4000)))
#define MCF_FEC_OPD(x)		(*(vuint32*)((0xFC0300EC)+((x)*0x4000)))
#define MCF_FEC_IAUR(x)		(*(vuint32*)((0xFC030118)+((x)*0x4000)))
#define MCF_FEC_IALR(x)		(*(vuint32*)((0xFC03011C)+((x)*0x4000)))
#define MCF_FEC_GAUR(x)		(*(vuint32*)((0xFC030120)+((x)*0x4000)))
#define MCF_FEC_GALR(x)		(*(vuint32*)((0xFC030124)+((x)*0x4000)))
#define MCF_FEC_TFWR(x)		(*(vuint32*)((0xFC030144)+((x)*0x4000)))
#define MCF_FEC_FRBR(x)		(*(vuint32*)((0xFC03014C)+((x)*0x4000)))
#define MCF_FEC_FRSR(x)		(*(vuint32*)((0xFC030150)+((x)*0x4000)))
#define MCF_FEC_ERDSR(x)	(*(vuint32*)((0xFC030180)+((x)*0x4000)))
#define MCF_FEC_ETDSR(x)	(*(vuint32*)((0xFC030184)+((x)*0x4000)))
#define MCF_FEC_EMRBR(x)	(*(vuint32*)((0xFC030188)+((x)*0x4000)))

#define MCF_FEC_RMON_T_DROP(x)			(*(vuint32*)((0xFC030200)+((x)*0x4000)))
#define MCF_FEC_RMON_T_PACKETS(x)		(*(vuint32*)((0xFC030204)+((x)*0x4000)))
#define MCF_FEC_RMON_T_BC_PKT(x)		(*(vuint32*)((0xFC030208)+((x)*0x4000)))
#define MCF_FEC_RMON_T_MC_PKT(x)		(*(vuint32*)((0xFC03020C)+((x)*0x4000)))
#define MCF_FEC_RMON_T_CRC_ALIGN(x)		(*(vuint32*)((0xFC030210)+((x)*0x4000)))
#define MCF_FEC_RMON_T_UNDERSIZE(x)		(*(vuint32*)((0xFC030214)+((x)*0x4000)))
#define MCF_FEC_RMON_T_OVERSIZE(x)		(*(vuint32*)((0xFC030218)+((x)*0x4000)))
#define MCF_FEC_RMON_T_FRAG(x)			(*(vuint32*)((0xFC03021C)+((x)*0x4000)))
#define MCF_FEC_RMON_T_JAB(x)			(*(vuint32*)((0xFC030220)+((x)*0x4000)))
#define MCF_FEC_RMON_T_COL(x)			(*(vuint32*)((0xFC030224)+((x)*0x4000)))
#define MCF_FEC_RMON_T_P64(x)			(*(vuint32*)((0xFC030228)+((x)*0x4000)))
#define MCF_FEC_RMON_T_P65TO127(x)		(*(vuint32*)((0xFC03022C)+((x)*0x4000)))
#define MCF_FEC_RMON_T_P128TO255(x)		(*(vuint32*)((0xFC030230)+((x)*0x4000)))
#define MCF_FEC_RMON_T_P256TO511(x)		(*(vuint32*)((0xFC030234)+((x)*0x4000)))
#define MCF_FEC_RMON_T_P512TO1023(x)	(*(vuint32*)((0xFC030238)+((x)*0x4000)))
#define MCF_FEC_RMON_T_P1024TO2047(x)	(*(vuint32*)((0xFC03023C)+((x)*0x4000)))
#define MCF_FEC_RMON_T_P_GTE2048(x)		(*(vuint32*)((0xFC030240)+((x)*0x4000)))
#define MCF_FEC_RMON_T_OCTETS(x)		(*(vuint32*)((0xFC030244)+((x)*0x4000)))
#define MCF_FEC_IEEE_T_DROP(x)			(*(vuint32*)((0xFC030248)+((x)*0x4000)))
#define MCF_FEC_IEEE_T_FRAME_OK(x)		(*(vuint32*)((0xFC03024C)+((x)*0x4000)))
#define MCF_FEC_IEEE_T_1COL(x)			(*(vuint32*)((0xFC030250)+((x)*0x4000)))
#define MCF_FEC_IEEE_T_MCOL(x)			(*(vuint32*)((0xFC030254)+((x)*0x4000)))
#define MCF_FEC_IEEE_T_DEF(x)			(*(vuint32*)((0xFC030258)+((x)*0x4000)))
#define MCF_FEC_IEEE_T_LCOL(x)			(*(vuint32*)((0xFC03025C)+((x)*0x4000)))
#define MCF_FEC_IEEE_T_EXCOL(x)			(*(vuint32*)((0xFC030260)+((x)*0x4000)))
#define MCF_FEC_IEEE_T_MACERR(x)		(*(vuint32*)((0xFC030264)+((x)*0x4000)))
#define MCF_FEC_IEEE_T_CSERR(x)			(*(vuint32*)((0xFC030268)+((x)*0x4000)))
#define MCF_FEC_IEEE_T_SQE(x)			(*(vuint32*)((0xFC03026C)+((x)*0x4000)))
#define MCF_FEC_IEEE_T_FDXFC(x)			(*(vuint32*)((0xFC030270)+((x)*0x4000)))
#define MCF_FEC_IEEE_T_OCTETS_OK(x)		(*(vuint32*)((0xFC030274)+((x)*0x4000)))

#define MCF_FEC_RMON_R_DROP			(*(vuint32*)((0xFC030280)+((x)*0x4000)))
#define MCF_FEC_RMON_R_PACKETS		(*(vuint32*)((0xFC030284)+((x)*0x4000)))
#define MCF_FEC_RMON_R_BC_PKT		(*(vuint32*)((0xFC030288)+((x)*0x4000)))
#define MCF_FEC_RMON_R_MC_PKT		(*(vuint32*)((0xFC03028C)+((x)*0x4000)))
#define MCF_FEC_RMON_R_CRC_ALIGN	(*(vuint32*)((0xFC030290)+((x)*0x4000)))
#define MCF_FEC_RMON_R_UNDERSIZE	(*(vuint32*)((0xFC030294)+((x)*0x4000)))
#define MCF_FEC_RMON_R_OVERSIZE		(*(vuint32*)((0xFC030298)+((x)*0x4000)))
#define MCF_FEC_RMON_R_FRAG			(*(vuint32*)((0xFC03029C)+((x)*0x4000)))
#define MCF_FEC_RMON_R_JAB			(*(vuint32*)((0xFC0302A0)+((x)*0x4000)))
#define MCF_FEC_RMON_R_RESVD_0		(*(vuint32*)((0xFC0302A4)+((x)*0x4000)))
#define MCF_FEC_RMON_R_P64			(*(vuint32*)((0xFC0302A8)+((x)*0x4000)))
#define MCF_FEC_RMON_R_P65TO127		(*(vuint32*)((0xFC0302AC)+((x)*0x4000)))
#define MCF_FEC_RMON_R_P128TO255	(*(vuint32*)((0xFC0302B0)+((x)*0x4000)))
#define MCF_FEC_RMON_R_P256TO511	(*(vuint32*)((0xFC0302B4)+((x)*0x4000)))
#define MCF_FEC_RMON_R_P512TO1023	(*(vuint32*)((0xFC0302B8)+((x)*0x4000)))
#define MCF_FEC_RMON_R_P1024TO2047	(*(vuint32*)((0xFC0302BC)+((x)*0x4000)))
#define MCF_FEC_RMON_R_P_GTE2048	(*(vuint32*)((0xFC0302C0)+((x)*0x4000)))
#define MCF_FEC_RMON_R_OCTETS		(*(vuint32*)((0xFC0302C4)+((x)*0x4000)))
#define MCF_FEC_IEEE_R_DROP			(*(vuint32*)((0xFC0302C8)+((x)*0x4000)))
#define MCF_FEC_IEEE_R_FRAME_OK		(*(vuint32*)((0xFC0302CC)+((x)*0x4000)))
#define MCF_FEC_IEEE_R_CRC			(*(vuint32*)((0xFC0302D0)+((x)*0x4000)))
#define MCF_FEC_IEEE_R_ALIGN		(*(vuint32*)((0xFC0302D4)+((x)*0x4000)))
#define MCF_FEC_IEEE_R_MACERR		(*(vuint32*)((0xFC0302D8)+((x)*0x4000)))
#define MCF_FEC_IEEE_R_FDXFC		(*(vuint32*)((0xFC0302DC)+((x)*0x4000)))
#define MCF_FEC_IEEE_R_OCTETS_OK	(*(vuint32*)((0xFC0302E0)+((x)*0x4000)))

//FSL start copy from MCF52235_FEC.h 

/* Bit definitions and macros for MCF_FEC_EIR */
#define MCF_FEC_EIR_UN                       (0x80000)
#define MCF_FEC_EIR_RL                       (0x100000)
#define MCF_FEC_EIR_LC                       (0x200000)
#define MCF_FEC_EIR_EBERR                    (0x400000)
#define MCF_FEC_EIR_MII                      (0x800000)
#define MCF_FEC_EIR_RXB                      (0x1000000)
#define MCF_FEC_EIR_RXF                      (0x2000000)
#define MCF_FEC_EIR_TXB                      (0x4000000)
#define MCF_FEC_EIR_TXF                      (0x8000000)
#define MCF_FEC_EIR_GRA                      (0x10000000)
#define MCF_FEC_EIR_BABT                     (0x20000000)
#define MCF_FEC_EIR_BABR                     (0x40000000)
#define MCF_FEC_EIR_HBERR                    (0x80000000)
#define MCF_FEC_EIR_CLEAR_ALL                (0xFFFFFFFF)

/* Bit definitions and macros for MCF_FEC_EIMR */
#define MCF_FEC_EIMR_UN                      (0x80000)
#define MCF_FEC_EIMR_RL                      (0x100000)
#define MCF_FEC_EIMR_LC                      (0x200000)
#define MCF_FEC_EIMR_EBERR                   (0x400000)
#define MCF_FEC_EIMR_MII                     (0x800000)
#define MCF_FEC_EIMR_RXB                     (0x1000000)
#define MCF_FEC_EIMR_RXF                     (0x2000000)
#define MCF_FEC_EIMR_TXB                     (0x4000000)
#define MCF_FEC_EIMR_TXF                     (0x8000000)
#define MCF_FEC_EIMR_GRA                     (0x10000000)
#define MCF_FEC_EIMR_BABT                    (0x20000000)
#define MCF_FEC_EIMR_BABR                    (0x40000000)
#define MCF_FEC_EIMR_HBERR                   (0x80000000)
#define MCF_FEC_EIMR_MASK_ALL                (0)
#define MCF_FEC_EIMR_UNMASK_ALL              (0xFFFFFFFF)

/* Bit definitions and macros for MCF_FEC_RDAR */
#define MCF_FEC_RDAR_R_DES_ACTIVE            (0x1000000)

/* Bit definitions and macros for MCF_FEC_TDAR */
#define MCF_FEC_TDAR_X_DES_ACTIVE            (0x1000000)

/* Bit definitions and macros for MCF_FEC_ECR */
#define MCF_FEC_ECR_RESET                    (0x1)
#define MCF_FEC_ECR_ETHER_EN                 (0x2)

/* Bit definitions and macros for MCF_FEC_MMFR */
#define MCF_FEC_MMFR_DATA(x)                 (((x)&0xFFFF)<<0)
#define MCF_FEC_MMFR_TA(x)                   (((x)&0x3)<<0x10)
#define MCF_FEC_MMFR_TA_10                   (0x20000)
#define MCF_FEC_MMFR_RA(x)                   (((x)&0x1F)<<0x12)
#define MCF_FEC_MMFR_PA(x)                   (((x)&0x1F)<<0x17)
#define MCF_FEC_MMFR_OP(x)                   (((x)&0x3)<<0x1C)
#define MCF_FEC_MMFR_OP_READ                 (0x20000000)
#define MCF_FEC_MMFR_OP_WRITE                (0x10000000)
#define MCF_FEC_MMFR_ST(x)                   (((x)&0x3)<<0x1E)
#define MCF_FEC_MMFR_ST_01                   (0x40000000)

/* Bit definitions and macros for MCF_FEC_MSCR */
#define MCF_FEC_MSCR_MII_SPEED(x)            (((x)&0x3F)<<0x1)
#define MCF_FEC_MSCR_DIS_PREAMBLE            (0x80)

/* Bit definitions and macros for MCF_FEC_MIBC */
#define MCF_FEC_MIBC_MIB_IDLE                (0x40000000)
#define MCF_FEC_MIBC_MIB_DISABLE             (0x80000000)

/* Bit definitions and macros for MCF_FEC_RCR */
#define MCF_FEC_RCR_LOOP                     (0x1)
#define MCF_FEC_RCR_DRT                      (0x2)
#define MCF_FEC_RCR_MII_MODE                 (0x4)
#define MCF_FEC_RCR_PROM                     (0x8)
#define MCF_FEC_RCR_BC_REJ                   (0x10)
#define MCF_FEC_RCR_FCE                      (0x20)
#define MCF_FEC_RCR_MAX_FL(x)                (((x)&0x7FF)<<0x10)

/* Bit definitions and macros for MCF_FEC_TCR */
#define MCF_FEC_TCR_GTS                      (0x1)
#define MCF_FEC_TCR_HBC                      (0x2)
#define MCF_FEC_TCR_FDEN                     (0x4)
#define MCF_FEC_TCR_TFC_PAUSE                (0x8)
#define MCF_FEC_TCR_RFC_PAUSE                (0x10)

/* Bit definitions and macros for MCF_FEC_PALR */
#define MCF_FEC_PALR_PADDR1(x)               (((x)&0xFFFFFFFF)<<0)

/* Bit definitions and macros for MCF_FEC_PAUR */
#define MCF_FEC_PAUR_TYPE(x)                 (((x)&0xFFFF)<<0)
#define MCF_FEC_PAUR_PADDR2(x)               (((x)&0xFFFF)<<0x10)

/* Bit definitions and macros for MCF_FEC_OPD */
#define MCF_FEC_OPD_PAUSE_DUR(x)             (((x)&0xFFFF)<<0)
#define MCF_FEC_OPD_OPCODE(x)                (((x)&0xFFFF)<<0x10)

/* Bit definitions and macros for MCF_FEC_IAUR */
#define MCF_FEC_IAUR_IADDR1(x)               (((x)&0xFFFFFFFF)<<0)

/* Bit definitions and macros for MCF_FEC_IALR */
#define MCF_FEC_IALR_IADDR2(x)               (((x)&0xFFFFFFFF)<<0)

/* Bit definitions and macros for MCF_FEC_GAUR */
#define MCF_FEC_GAUR_GADDR1(x)               (((x)&0xFFFFFFFF)<<0)

/* Bit definitions and macros for MCF_FEC_GALR */
#define MCF_FEC_GALR_GADDR2(x)               (((x)&0xFFFFFFFF)<<0)

/* Bit definitions and macros for MCF_FEC_TFWR */
#define MCF_FEC_TFWR_X_WMRK(x)               (((x)&0x3)<<0)
#define MCF_FEC_TFWR_X_WMRK_64               (0)
#define MCF_FEC_TFWR_X_WMRK_128              (0x2)
#define MCF_FEC_TFWR_X_WMRK_192              (0x3)

/* Bit definitions and macros for MCF_FEC_FRBR */
#define MCF_FEC_FRBR_R_BOUND(x)              (((x)&0xFF)<<0x2)

/* Bit definitions and macros for MCF_FEC_FRSR */
#define MCF_FEC_FRSR_R_FSTART(x)             (((x)&0xFF)<<0x2)

/* Bit definitions and macros for MCF_FEC_ERDSR */
#define MCF_FEC_ERDSR_R_DES_START(x)         (((x)&0x3FFFFFFF)<<0x2)

/* Bit definitions and macros for MCF_FEC_ETSDR */
#define MCF_FEC_ETSDR_X_DES_START(x)         (((x)&0x3FFFFFFF)<<0x2)

/* Bit definitions and macros for MCF_FEC_EMRBR */
#define MCF_FEC_EMRBR_R_BUF_SIZE(x)          (((x)&0x7F)<<0x4)

/* Bit definitions and macros for MCF_FEC_RMON_T_DROP */
#define MCF_FEC_RMON_T_DROP_Value(x)         (((x)&0xFFFFFFFF)<<0)

/* Bit definitions and macros for MCF_FEC_RMON_T_PACKETS */
#define MCF_FEC_RMON_T_PACKETS_Value(x)      (((x)&0xFFFFFFFF)<<0)

/* Bit definitions and macros for MCF_FEC_RMON_T_BC_PKT */
#define MCF_FEC_RMON_T_BC_PKT_Value(x)       (((x)&0xFFFFFFFF)<<0)

/* Bit definitions and macros for MCF_FEC_RMON_T_MC_PKT */
#define MCF_FEC_RMON_T_MC_PKT_Value(x)       (((x)&0xFFFFFFFF)<<0)

/* Bit definitions and macros for MCF_FEC_RMON_T_CRC_ALIGN */
#define MCF_FEC_RMON_T_CRC_ALIGN_Value(x)    (((x)&0xFFFFFFFF)<<0)

/* Bit definitions and macros for MCF_FEC_RMON_T_UNDERSIZE */
#define MCF_FEC_RMON_T_UNDERSIZE_Value(x)    (((x)&0xFFFFFFFF)<<0)

/* Bit definitions and macros for MCF_FEC_RMON_T_OVERSIZE */
#define MCF_FEC_RMON_T_OVERSIZE_Value(x)     (((x)&0xFFFFFFFF)<<0)

/* Bit definitions and macros for MCF_FEC_RMON_T_FRAG */
#define MCF_FEC_RMON_T_FRAG_Value(x)         (((x)&0xFFFFFFFF)<<0)

/* Bit definitions and macros for MCF_FEC_RMON_T_JAB */
#define MCF_FEC_RMON_T_JAB_Value(x)          (((x)&0xFFFFFFFF)<<0)

/* Bit definitions and macros for MCF_FEC_RMON_T_COL */
#define MCF_FEC_RMON_T_COL_Value(x)          (((x)&0xFFFFFFFF)<<0)

/* Bit definitions and macros for MCF_FEC_RMON_T_P64 */
#define MCF_FEC_RMON_T_P64_Value(x)          (((x)&0xFFFFFFFF)<<0)

/* Bit definitions and macros for MCF_FEC_RMON_T_P65TO127 */
#define MCF_FEC_RMON_T_P65TO127_Value(x)     (((x)&0xFFFFFFFF)<<0)

/* Bit definitions and macros for MCF_FEC_RMON_T_P128TO255 */
#define MCF_FEC_RMON_T_P128TO255_Value(x)    (((x)&0xFFFFFFFF)<<0)

/* Bit definitions and macros for MCF_FEC_RMON_T_P256TO511 */
#define MCF_FEC_RMON_T_P256TO511_Value(x)    (((x)&0xFFFFFFFF)<<0)

/* Bit definitions and macros for MCF_FEC_RMON_T_P512TO1023 */
#define MCF_FEC_RMON_T_P512TO1023_Value(x)   (((x)&0xFFFFFFFF)<<0)

/* Bit definitions and macros for MCF_FEC_RMON_T_P1024TO2047 */
#define MCF_FEC_RMON_T_P1024TO2047_Value(x)  (((x)&0xFFFFFFFF)<<0)

/* Bit definitions and macros for MCF_FEC_RMON_T_P_GTE2048 */
#define MCF_FEC_RMON_T_P_GTE2048_Value(x)    (((x)&0xFFFFFFFF)<<0)

/* Bit definitions and macros for MCF_FEC_RMON_T_OCTETS */
#define MCF_FEC_RMON_T_OCTETS_Value(x)       (((x)&0xFFFFFFFF)<<0)

/* Bit definitions and macros for MCF_FEC_IEEE_T_DROP */
#define MCF_FEC_IEEE_T_DROP_Value(x)         (((x)&0xFFFFFFFF)<<0)

/* Bit definitions and macros for MCF_FEC_IEEE_T_FRAME_OK */
#define MCF_FEC_IEEE_T_FRAME_OK_Value(x)     (((x)&0xFFFFFFFF)<<0)

/* Bit definitions and macros for MCF_FEC_IEEE_T_1COL */
#define MCF_FEC_IEEE_T_1COL_Value(x)         (((x)&0xFFFFFFFF)<<0)

/* Bit definitions and macros for MCF_FEC_IEEE_T_MCOL */
#define MCF_FEC_IEEE_T_MCOL_Value(x)         (((x)&0xFFFFFFFF)<<0)

/* Bit definitions and macros for MCF_FEC_IEEE_T_DEF */
#define MCF_FEC_IEEE_T_DEF_Value(x)          (((x)&0xFFFFFFFF)<<0)

/* Bit definitions and macros for MCF_FEC_IEEE_T_LCOL */
#define MCF_FEC_IEEE_T_LCOL_Value(x)         (((x)&0xFFFFFFFF)<<0)

/* Bit definitions and macros for MCF_FEC_IEEE_T_EXCOL */
#define MCF_FEC_IEEE_T_EXCOL_Value(x)        (((x)&0xFFFFFFFF)<<0)

/* Bit definitions and macros for MCF_FEC_IEEE_T_MACERR */
#define MCF_FEC_IEEE_T_MACERR_Value(x)       (((x)&0xFFFFFFFF)<<0)

/* Bit definitions and macros for MCF_FEC_IEEE_T_CSERR */
#define MCF_FEC_IEEE_T_CSERR_Value(x)        (((x)&0xFFFFFFFF)<<0)

/* Bit definitions and macros for MCF_FEC_IEEE_T_SQE */
#define MCF_FEC_IEEE_T_SQE_Value(x)          (((x)&0xFFFFFFFF)<<0)

/* Bit definitions and macros for MCF_FEC_IEEE_T_FDXFC */
#define MCF_FEC_IEEE_T_FDXFC_Value(x)        (((x)&0xFFFFFFFF)<<0)

/* Bit definitions and macros for MCF_FEC_IEEE_T_OCTETS_OK */
#define MCF_FEC_IEEE_T_OCTETS_OK_Value(x)    (((x)&0xFFFFFFFF)<<0)

/* Bit definitions and macros for MCF_FEC_RMON_R_PACKETS */
#define MCF_FEC_RMON_R_PACKETS_Value(x)      (((x)&0xFFFFFFFF)<<0)

/* Bit definitions and macros for MCF_FEC_RMON_R_BC_PKT */
#define MCF_FEC_RMON_R_BC_PKT_Value(x)       (((x)&0xFFFFFFFF)<<0)

/* Bit definitions and macros for MCF_FEC_RMON_R_MC_PKT */
#define MCF_FEC_RMON_R_MC_PKT_Value(x)       (((x)&0xFFFFFFFF)<<0)

/* Bit definitions and macros for MCF_FEC_RMON_R_CRC_ALIGN */
#define MCF_FEC_RMON_R_CRC_ALIGN_Value(x)    (((x)&0xFFFFFFFF)<<0)

/* Bit definitions and macros for MCF_FEC_RMON_R_UNDERSIZE */
#define MCF_FEC_RMON_R_UNDERSIZE_Value(x)    (((x)&0xFFFFFFFF)<<0)

/* Bit definitions and macros for MCF_FEC_RMON_R_OVERSIZE */
#define MCF_FEC_RMON_R_OVERSIZE_Value(x)     (((x)&0xFFFFFFFF)<<0)

/* Bit definitions and macros for MCF_FEC_RMON_R_FRAG */
#define MCF_FEC_RMON_R_FRAG_Value(x)         (((x)&0xFFFFFFFF)<<0)

/* Bit definitions and macros for MCF_FEC_RMON_R_JAB */
#define MCF_FEC_RMON_R_JAB_Value(x)          (((x)&0xFFFFFFFF)<<0)

/* Bit definitions and macros for MCF_FEC_RMON_R_RESVD_0 */
#define MCF_FEC_RMON_R_RESVD_0_Value(x)      (((x)&0xFFFFFFFF)<<0)

/* Bit definitions and macros for MCF_FEC_RMON_R_P64 */
#define MCF_FEC_RMON_R_P64_Value(x)          (((x)&0xFFFFFFFF)<<0)

/* Bit definitions and macros for MCF_FEC_RMON_R_P65TO127 */
#define MCF_FEC_RMON_R_P65TO127_Value(x)     (((x)&0xFFFFFFFF)<<0)

/* Bit definitions and macros for MCF_FEC_RMON_R_P128TO255 */
#define MCF_FEC_RMON_R_P128TO255_Value(x)    (((x)&0xFFFFFFFF)<<0)

/* Bit definitions and macros for MCF_FEC_RMON_R_P256TO511 */
#define MCF_FEC_RMON_R_P256TO511_Value(x)    (((x)&0xFFFFFFFF)<<0)

/* Bit definitions and macros for MCF_FEC_RMON_R_P512TO1023 */
#define MCF_FEC_RMON_R_P512TO1023_Value(x)   (((x)&0xFFFFFFFF)<<0)

/* Bit definitions and macros for MCF_FEC_RMON_R_P1024TO2047 */
#define MCF_FEC_RMON_R_P1024TO2047_Value(x)  (((x)&0xFFFFFFFF)<<0)

/* Bit definitions and macros for MCF_FEC_RMON_R_P_GTE2048 */
#define MCF_FEC_RMON_R_P_GTE2048_Value(x)    (((x)&0xFFFFFFFF)<<0)

/* Bit definitions and macros for MCF_FEC_RMON_R_OCTETS */
#define MCF_FEC_RMON_R_OCTETS_Value(x)       (((x)&0xFFFFFFFF)<<0)

/* Bit definitions and macros for MCF_FEC_IEEE_R_DROP */
#define MCF_FEC_IEEE_R_DROP_Value(x)         (((x)&0xFFFFFFFF)<<0)

/* Bit definitions and macros for MCF_FEC_IEEE_R_FRAME_OK */
#define MCF_FEC_IEEE_R_FRAME_OK_Value(x)     (((x)&0xFFFFFFFF)<<0)

/* Bit definitions and macros for MCF_FEC_IEEE_R_CRC */
#define MCF_FEC_IEEE_R_CRC_Value(x)          (((x)&0xFFFFFFFF)<<0)

/* Bit definitions and macros for MCF_FEC_IEEE_R_ALIGN */
#define MCF_FEC_IEEE_R_ALIGN_Value(x)        (((x)&0xFFFFFFFF)<<0)

/* Bit definitions and macros for MCF_FEC_IEEE_R_MACERR */
#define MCF_FEC_IEEE_R_MACERR_Value(x)       (((x)&0xFFFFFFFF)<<0)

/* Bit definitions and macros for MCF_FEC_IEEE_R_FDXFC */
#define MCF_FEC_IEEE_R_FDXFC_Value(x)        (((x)&0xFFFFFFFF)<<0)

/* Bit definitions and macros for MCF_FEC_IEEE_R_OCTETS_OK */
#define MCF_FEC_IEEE_R_OCTETS_OK_Value(x)    (((x)&0xFFFFFFFF)<<0)

//FSL end copy from MCF52235_FEC.h


#endif /* __MCF53013_FEC_H__ */
