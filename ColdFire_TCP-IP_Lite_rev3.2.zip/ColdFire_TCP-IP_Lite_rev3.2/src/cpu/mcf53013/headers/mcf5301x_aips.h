/*
 * File:	mcf5301x_intc_iack.h
 * Purpose:	Register and bit definitions for the MCF5301x
 *
 * Notes:	
 *	
 */

#ifndef __MCF5301X_AIPS__
#define __MCF5301X_AIPS_

/*********************************************************************
*
* Interrupt Controller (INTC_IACK)
*
*********************************************************************/

/* Register read/write macros */
#define MCF_MPOT0            (*(vuint32    *)(0xFC000000))
#define MCF_MPOT1            (*(vuint32    *)(0xFC000004))
#define MCF_PACR0            (*(vuint32    *)(0xFC000020))
#define MCF_PACR1            (*(vuint32    *)(0xFC000024))
#define MCF_PACR2            (*(vuint32    *)(0xFC000028))
#define MCF_PACR3            (*(vuint32    *)(0xFC00002C))

#define MCF_OPACR0            (*(vuint32    *)(0xFC000040))
#define MCF_OPACR1            (*(vuint32    *)(0xFC000044))
#define MCF_OPACR2            (*(vuint32    *)(0xFC000048))
#define MCF_OPACR3            (*(vuint32    *)(0xFC00004C))


#endif /* __MCF5301X_INTC_IACK_H__ */
