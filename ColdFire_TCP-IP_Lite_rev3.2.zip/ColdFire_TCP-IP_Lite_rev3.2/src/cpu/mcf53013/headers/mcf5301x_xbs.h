/*
 * File:    
 * Purpose:
 */

#ifndef _MCF5301x_XBS_H_
#define _MCF5301x_XBS_H_

/*********************************************************************
*
* Cross-bar switch (XBS)
*
*********************************************************************/

/* Register read/write macros */
#define MCF_XBS_PRS1                     (*(vuint32*)(0xFC004100))
#define MCF_XBS_PRS4                     (*(vuint32*)(0xFC004400))
#define MCF_XBS_PRS7                     (*(vuint32*)(0xFC004700))

#define MCF_XBS_CRS1                     (*(vuint32*)(0xFC004110))
#define MCF_XBS_CRS4                     (*(vuint32*)(0xFC004410))
#define MCF_XBS_CRS7                     (*(vuint32*)(0xFC004710))

#define MCF_XBS_PRS(x)                   (*(vuint32*)(0xFC004100+((x-1)*0x100)))
#define MCF_XBS_CRS(x)                   (*(vuint32*)(0xFC004110+((x-1)*0x100)))

/* Bit definitions and macros for MCF_XBS_PRS */
#define MCF_XBS_PRS_M0(x)                (((x)&0x00000007)<<0)
#define MCF_XBS_PRS_M1(x)                (((x)&0x00000007)<<4)
#define MCF_XBS_PRS_M2(x)                (((x)&0x00000007)<<8)
#define MCF_XBS_PRS_M4(x)                (((x)&0x00000007)<<16)
#define MCF_XBS_PRS_M5(x)                (((x)&0x00000007)<<20)
#define MCF_XBS_PRS_M6(x)                (((x)&0x00000007)<<24)

/* Bit definitions and macros for MCF_XBS_CRS */
#define MCF_XBS_CRS_PARK(x)              (((x)&0x00000007)<<0)
#define MCF_XBS_CRS_PCTL(x)              (((x)&0x00000003)<<4)
#define MCF_XBS_CRS_ARB                  (0x00000100)
#define MCF_XBS_CRS_RO                   (0x80000000)

#define MCF_XBS_CRS_PCTL_PARK_FIELD      (0x00000000)
#define MCF_XBS_CRS_PCTL_PARK_ON_LAST    (0x00000010)
#define MCF_XBS_CRS_PCTL_PARK_NO_MASTER  (0x00000020)
#define MCF_XBS_CRS_PCTL_PARK_CORE       (0x00000000)

#define MCF_XBS_CRS_PCTL_PARK_EDMA       (0x00000001)
#define MCF_XBS_CRS_PCTL_PARK_FEC0       (0x00000002)
#define MCF_XBS_CRS_PCTL_PARK_FEC1       (0x00000003)
#define MCF_XBS_CRS_PCTL_PARK_SDHC       (0x00000004)
#define MCF_XBS_CRS_PCTL_PARK_USB_HOST   (0x00000005)
#define MCF_XBS_CRS_PCTL_PARK_USB_OTG    (0x00000006)

/********************************************************************/

#endif /* _MCF5301x_XBS_H_ */
