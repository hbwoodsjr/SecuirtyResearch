/*
 * File:    mcf5301x_rtc.h
 * Purpose: Register and bit definitions
 */

#ifndef __MCF5301X_RTC_H__
#define __MCF5301X_RTC_H__

/*********************************************************************
*
* Real Time Clock (RTC)
*
*********************************************************************/

/* Register read/write macros */
#define MCF_RTC_HOURMIN              (*(vuint32*)(0xFC0A8000))                             /* Hours and Minute Counter Registers */
#define MCF_RTC_SECONDS              (*(vuint32*)(0xFC0A8004))                             /* Seconds Counter Register */
#define MCF_RTC_ALRM_HM              (*(vuint32*)(0xFC0A8008))                             /* Hours and Minutes Alarm Register */
#define MCF_RTC_ALRM_SEC             (*(vuint32*)(0xFC0A800C))                             /* Seconds Alarm Register */
#define MCF_RTC_RTCCTL               (*(vuint32*)(0xFC0A8010))                             /* RTC Control Register */
#define MCF_RTC_RTCISR               (*(vuint32*)(0xFC0A8014))                             /* RTC Interrupt Status Register */
#define MCF_RTC_RTCIENR              (*(vuint32*)(0xFC0A8018))                             /* RTC Interrupt Enable Register */
#define MCF_RTC_STPWCH               (*(vuint32*)(0xFC0A801C))                             /* RTC StopWatch Minutes Register */
#define MCF_RTC_DAYR                 (*(vuint32*)(0xFC0A8020))                             /* RTC Days Counter */
#define MCF_RTC_ALRM_DAY             (*(vuint32*)(0xFC0A8024))                             /* Alarm Setting for Day */
#define MCF_RTC_TEST1                (*(vuint32*)(0xFC0A8028))                             /* Test Register 1 */
#define MCF_RTC_TEST2                (*(vuint32*)(0xFC0A802C))                             /* Test Register 2 */
#define MCF_RTC_TEST3                (*(vuint32*)(0xFC0A8030))                             /* Test Register 3 */
#define MCF_RTC_GEN_OSC_CLK          (*(vuint32*)(0xFC0A8034))                             /* RTC General Oscillator(prescaler) */
#define MCF_RTC_ANATEST              (*(vuint32*)(0xFC0A8038))                             /* RTC Analog test Register */

/* Bit definitions and macros for MCF_RTC_ANATEST */
#define MCF_RTC_ANATEST_32KHZ_OSC_EN     (0x00000008) 
#define MCF_RTC_ANATEST_32KHZ_OSC_BYPASS (0x00000010) 

/* Bit definitions and macros for MCF_RTC_HOURMIN */
#define MCF_RTC_HOURMIN_MINUTES(x)   (((x)&0x0000003F)<<0)                     /* Minutes Value */
#define MCF_RTC_HOURMIN_HOURS(x)     (((x)&0x0000001F)<<8)                     /* Hours Value */

/* Bit definitions and macros for MCF_RTC_SECONDS */
#define MCF_RTC_SECONDS_SECONDS(x)   (((x)&0x0000003F)<<0)                     /* Seconds value */

/* Bit definitions and macros for MCF_RTC_ALRM_HM */
#define MCF_RTC_ALRM_HM_MINUTES(x)   (((x)&0x0000003F)<<0)                     /* Minutes Alarm Setting */
#define MCF_RTC_ALRM_HM_HOURS(x)     (((x)&0x0000001F)<<8)                     /* Hours Alarm Setting */

/* Bit definitions and macros for MCF_RTC_ALRM_SEC */
#define MCF_RTC_ALRM_SEC_SECONDS(x)  (((x)&0x0000003F)<<0)                     /* Seconds Alarm Setting */

/* Bit definitions and macros for MCF_RTC_RTCCTL */
#define MCF_RTC_RTCCTL_SWR           (0x00000001)                              /* Software Reset */
#define MCF_RTC_RTCCTL_EN            (0x00000080)                              /* Enable/Disable Real Time Clock */

/* Bit definitions and macros for MCF_RTC_RTCISR */
#define MCF_RTC_RTCISR_SW            (0x00000001)                              /* Stop Watch interrupt flag */
#define MCF_RTC_RTCISR_MIN           (0x00000002)                              /* Minute interrupt flag */
#define MCF_RTC_RTCISR_ALM           (0x00000004)                              /* Alarm interrupt flag */
#define MCF_RTC_RTCISR_DAY           (0x00000008)                              /* Day interrupt flag */
#define MCF_RTC_RTCISR_1HZ           (0x00000010)                              /* 1 Hz interrupt flag */
#define MCF_RTC_RTCISR_HR            (0x00000020)                              /* Hour interrupt flag */
#define MCF_RTC_RTCISR_2HZ           (0x00000080)                              /* 2Hz interrupt flag */
#define MCF_RTC_RTCISR_SAM0          (0x00000100)                              /* Sampling TImer interrupt at SAM0 freq */
#define MCF_RTC_RTCISR_SAM1          (0x00000200)                              /* Sampling TImer interrupt at SAM1 freq */
#define MCF_RTC_RTCISR_SAM2          (0x00000400)                              /* Sampling TImer interrupt at SAM2 freq */
#define MCF_RTC_RTCISR_SAM3          (0x00000800)                              /* Sampling TImer interrupt at SAM3 freq */
#define MCF_RTC_RTCISR_SAM4          (0x00001000)                              /* Sampling TImer interrupt at SAM4 freq */
#define MCF_RTC_RTCISR_SAM5          (0x00002000)                              /* Sampling TImer interrupt at SAM5 freq */
#define MCF_RTC_RTCISR_SAM6          (0x00004000)                              /* Sampling TImer interrupt at SAM6 freq */
#define MCF_RTC_RTCISR_SAM7          (0x00008000)                              /* Sampling TImer interrupt at SAM7 freq */

/* Bit definitions and macros for MCF_RTC_RTCIENR */
#define MCF_RTC_RTCIENR_SW           (0x00000001)                              /* Stop Watch interrupt enable */
#define MCF_RTC_RTCIENR_MIN          (0x00000002)                              /* Minute interrupt enable */
#define MCF_RTC_RTCIENR_ALM          (0x00000004)                              /* Alarm interrupt enable */
#define MCF_RTC_RTCIENR_DAY          (0x00000008)                              /* Day interrupt enable */
#define MCF_RTC_RTCIENR_1HZ          (0x00000010)                              /* 1 Hz interrupt enable */
#define MCF_RTC_RTCIENR_HR           (0x00000020)                              /* Hour interrupt enable */
#define MCF_RTC_RTCIENR_2HZ          (0x00000080)                              /* 2Hz interrupt enable */
#define MCF_RTC_RTCIENR_SAM0         (0x00000100)                              /* Sampling TImer interrupt enable at SAM0 freq */
#define MCF_RTC_RTCIENR_SAM1         (0x00000200)                              /* Sampling TImer interrupt enable at SAM1 freq */
#define MCF_RTC_RTCIENR_SAM2         (0x00000400)                              /* Sampling TImer interrupt enable at SAM2 freq */
#define MCF_RTC_RTCIENR_SAM3         (0x00000800)                              /* Sampling TImer interrupt enable at SAM3 freq */
#define MCF_RTC_RTCIENR_SAM4         (0x00001000)                              /* Sampling TImer interrupt enable at SAM4 freq */
#define MCF_RTC_RTCIENR_SAM5         (0x00002000)                              /* Sampling TImer interrupt enable at SAM5 freq */
#define MCF_RTC_RTCIENR_SAM6         (0x00004000)                              /* Sampling TImer interrupt enable at SAM6 freq */
#define MCF_RTC_RTCIENR_SAM7         (0x00008000)                              /* Sampling TImer interrupt enable at SAM7 freq */
#define MCF_RTC_RTCIENR_ALL          (0x0000FFFF)

/* Bit definitions and macros for MCF_RTC_STPWCH */
#define MCF_RTC_STPWCH_CNT(x)        (((x)&0x0000003F)<<0)                     /* Minutes Countdown COunter */

/* Bit definitions and macros for MCF_RTC_DAYR */
#define MCF_RTC_DAYR_DAYS(x)         (((x)&0x0000FFFF)<<0)                     /* Days value */

/* Bit definitions and macros for MCF_RTC_ALRM_DAY */
#define MCF_RTC_ALRM_DAY_DAYSAL(x)   (((x)&0x0000FFFF)<<0)                     /* Day Alarm Setting */

/********************************************************************/

#endif /* __MCF5301X_RTC_H__ */
