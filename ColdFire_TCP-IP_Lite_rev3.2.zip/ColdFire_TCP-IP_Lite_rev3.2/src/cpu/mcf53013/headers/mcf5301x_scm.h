/*
 * File:    mcf5301x_scm.h
 * Purpose: Register and bit definitions
 */

#ifndef __MCF5301X_SCM_H__
#define __MCF5301X_SCM_H__

/*********************************************************************
*
* System Control Module (SCM)
*
*********************************************************************/

/* Register read/write macros */
#define MCF_SCM_MPR                        (*(vuint32*)(0xFC000000))
#define MCF_SCM_PACRA                      (*(vuint32*)(0xFC000020))
#define MCF_SCM_PACRB                      (*(vuint32*)(0xFC000024))
#define MCF_SCM_PACRC                      (*(vuint32*)(0xFC000028))
#define MCF_SCM_PACRD                      (*(vuint32*)(0xFC00002C))
#define MCF_SCM_OPACRA                     (*(vuint32*)(0xFC000040))
#define MCF_SCM_OPACRB                     (*(vuint32*)(0xFC000044))
#define MCF_SCM_OPACRC                     (*(vuint32*)(0xFC000048))
#define MCF_SCM_OPACRD                     (*(vuint32*)(0xFC00004C))
#define MCF_SCM_PCT                        (*(vuint16*)(0xFC040000))
#define MCF_SCM_PLREV                      (*(vuint16*)(0xFC040002))
#define MCF_SCM_PLAMC                      (*(vuint16*)(0xFC040004))
#define MCF_SCM_PLASC                      (*(vuint16*)(0xFC040006))
#define MCF_SCM_IOPMC                      (*(vuint32*)(0xFC040008))
#define MCF_SCM_MRSR                       (*(vuint8 *)(0xFC04000F))
#define MCF_SCM_MWCR                       (*(vuint8 *)(0xFC040013))
#define MCF_SCM_MSWCR                      (*(vuint16*)(0xFC040016))
#define MCF_SCM_MSWSR                      (*(vuint8 *)(0xFC04001B))
#define MCF_SCM_SCMISR                     (*(vuint8 *)(0xFC04001F))
#define MCF_SCM_BCR                        (*(vuint32*)(0xFC040024))
#define MCF_SCM_PPMRS                      (*(vuint8 *)(0xFC04002C))
#define MCF_SCM_PPMRC                      (*(vuint8 *)(0xFC04002D))
#define MCF_SCM_PPMRH                      (*(vuint32*)(0xFC040030))
#define MCF_SCM_PPMRL                      (*(vuint32*)(0xFC040034))
#define MCF_SCM_CFADR                      (*(vuint32*)(0xFC040070))
#define MCF_SCM_CFIER                      (*(vuint8 *)(0xFC040075))
#define MCF_SCM_CFLOC                      (*(vuint8 *)(0xFC040076))
#define MCF_SCM_CFATR                      (*(vuint8 *)(0xFC040077))
#define MCF_SCM_CFDTRH                      (*(vuint32*)(0xFC040078))
#define MCF_SCM_CFDTRL                     (*(vuint32*)(0xFC04007C))

/* Bit definitions and macros for MCF_SCM_MPR */
#define MCF_SCM_MPR_MPROT7(x)              (((x)&0x0000000F)<<0)
#define MCF_SCM_MPR_MPROT6(x)              (((x)&0x0000000F)<<4)
#define MCF_SCM_MPR_MPROT5(x)              (((x)&0x0000000F)<<8)
#define MCF_SCM_MPR_MPROT4(x)              (((x)&0x0000000F)<<12)
#define MCF_SCM_MPR_MPROT3(x)              (((x)&0x0000000F)<<16)
#define MCF_SCM_MPR_MPROT2(x)              (((x)&0x0000000F)<<20)
#define MCF_SCM_MPR_MPROT1(x)              (((x)&0x0000000F)<<24)
#define MCF_SCM_MPR_MPROT0(x)              (((x)&0x0000000F)<<28)
#define MCF_SCM_MPR_MPROT_MTR              (0x4)
#define MCF_SCM_MPR_MPROT_MTW              (0x2)
#define MCF_SCM_MPR_MPROT_MPL              (0x1)

/* Bit definitions and macros for MCF_SCM_PACRA */
#define MCF_SCM_PACRA_PACR7(x)             (((x)&0x0000000F)<<0)
#define MCF_SCM_PACRA_PACR6(x)             (((x)&0x0000000F)<<4)
#define MCF_SCM_PACRA_PACR5(x)             (((x)&0x0000000F)<<8)
#define MCF_SCM_PACRA_PACR4(x)             (((x)&0x0000000F)<<12)
#define MCF_SCM_PACRA_PACR3(x)             (((x)&0x0000000F)<<16)
#define MCF_SCM_PACRA_PACR2(x)             (((x)&0x0000000F)<<20)
#define MCF_SCM_PACRA_PACR1(x)             (((x)&0x0000000F)<<24)
#define MCF_SCM_PACRA_PACR0(x)             (((x)&0x0000000F)<<28)
#define MCF_SCM_PACRA_PACR_SP              (0x4)
#define MCF_SCM_PACRA_PACR_WP              (0x2)
#define MCF_SCM_PACRA_PACR_TP              (0x1)

/* Bit definitions and macros for MCF_SCM_PACRB */
#define MCF_SCM_PACRB_PACR15(x)            (((x)&0x0000000F)<<0)
#define MCF_SCM_PACRB_PACR14(x)            (((x)&0x0000000F)<<4)
#define MCF_SCM_PACRB_PACR13(x)            (((x)&0x0000000F)<<8)
#define MCF_SCM_PACRB_PACR12(x)            (((x)&0x0000000F)<<12)
#define MCF_SCM_PACRB_PACR11(x)            (((x)&0x0000000F)<<16)
#define MCF_SCM_PACRB_PACR10(x)            (((x)&0x0000000F)<<20)
#define MCF_SCM_PACRB_PACR9(x)             (((x)&0x0000000F)<<24)
#define MCF_SCM_PACRB_PACR8(x)             (((x)&0x0000000F)<<28)

/* Bit definitions and macros for MCF_SCM_PACRC */
#define MCF_SCM_PACRC_PACR23(x)            (((x)&0x0000000F)<<0)
#define MCF_SCM_PACRC_PACR22(x)            (((x)&0x0000000F)<<4)
#define MCF_SCM_PACRC_PACR21(x)            (((x)&0x0000000F)<<8)
#define MCF_SCM_PACRC_PACR20(x)            (((x)&0x0000000F)<<12)
#define MCF_SCM_PACRC_PACR19(x)            (((x)&0x0000000F)<<16)
#define MCF_SCM_PACRC_PACR18(x)            (((x)&0x0000000F)<<20)
#define MCF_SCM_PACRC_PACR17(x)            (((x)&0x0000000F)<<24)
#define MCF_SCM_PACRC_PACR16(x)            (((x)&0x0000000F)<<28)

/* Bit definitions and macros for MCF_SCM_PACRD */
#define MCF_SCM_PACRD_PACR31(x)            (((x)&0x0000000F)<<0)
#define MCF_SCM_PACRD_PACR30(x)            (((x)&0x0000000F)<<4)
#define MCF_SCM_PACRD_PACR29(x)            (((x)&0x0000000F)<<8)
#define MCF_SCM_PACRD_PACR28(x)            (((x)&0x0000000F)<<12)
#define MCF_SCM_PACRD_PACR27(x)            (((x)&0x0000000F)<<16)
#define MCF_SCM_PACRD_PACR26(x)            (((x)&0x0000000F)<<20)
#define MCF_SCM_PACRD_PACR25(x)            (((x)&0x0000000F)<<24)
#define MCF_SCM_PACRD_PACR24(x)            (((x)&0x0000000F)<<28)

/* Bit definitions and macros for MCF_SCM_OPACRA */
#define MCF_SCM_OPACRA_OPACR7(x)           (((x)&0x0000000F)<<0)
#define MCF_SCM_OPACRA_OPACR6(x)           (((x)&0x0000000F)<<4)
#define MCF_SCM_OPACRA_OPACR5(x)           (((x)&0x0000000F)<<8)
#define MCF_SCM_OPACRA_OPACR4(x)           (((x)&0x0000000F)<<12)
#define MCF_SCM_OPACRA_OPACR3(x)           (((x)&0x0000000F)<<16)
#define MCF_SCM_OPACRA_OPACR2(x)           (((x)&0x0000000F)<<20)
#define MCF_SCM_OPACRA_OPACR1(x)           (((x)&0x0000000F)<<24)
#define MCF_SCM_OPACRA_OPACR0(x)           (((x)&0x0000000F)<<28)
#define MCF_SCM_OPACRA_PACR_SP             (0x4)
#define MCF_SCM_OPACRA_PACR_WP             (0x2)
#define MCF_SCM_OPACRA_PACR_TP             (0x1)

/* Bit definitions and macros for MCF_SCM_OPACRB */
#define MCF_SCM_OPACRB_OPACR15(x)          (((x)&0x0000000F)<<0)
#define MCF_SCM_OPACRB_OPACR14(x)          (((x)&0x0000000F)<<4)
#define MCF_SCM_OPACRB_OPACR13(x)          (((x)&0x0000000F)<<8)
#define MCF_SCM_OPACRB_OPACR12(x)          (((x)&0x0000000F)<<12)
#define MCF_SCM_OPACRB_OPACR11(x)          (((x)&0x0000000F)<<16)
#define MCF_SCM_OPACRB_OPACR10(x)          (((x)&0x0000000F)<<20)
#define MCF_SCM_OPACRB_OPACR9(x)           (((x)&0x0000000F)<<24)
#define MCF_SCM_OPACRB_OPACR8(x)           (((x)&0x0000000F)<<28)

/* Bit definitions and macros for MCF_SCM_OPACRC */
#define MCF_SCM_OPACRC_OPACR23(x)          (((x)&0x0000000F)<<0)
#define MCF_SCM_OPACRC_OPACR22(x)          (((x)&0x0000000F)<<4)
#define MCF_SCM_OPACRC_OPACR21(x)          (((x)&0x0000000F)<<8)
#define MCF_SCM_OPACRC_OPACR20(x)          (((x)&0x0000000F)<<12)
#define MCF_SCM_OPACRC_OPACR19(x)          (((x)&0x0000000F)<<16)
#define MCF_SCM_OPACRC_OPACR18(x)          (((x)&0x0000000F)<<20)
#define MCF_SCM_OPACRC_OPACR17(x)          (((x)&0x0000000F)<<24)
#define MCF_SCM_OPACRC_OPACR16(x)          (((x)&0x0000000F)<<28)

/* Bit definitions and macros for MCF_SCM_OPACRD */
#define MCF_SCM_OPACRD_OPACR31(x)          (((x)&0x0000000F)<<0)
#define MCF_SCM_OPACRD_OPACR30(x)          (((x)&0x0000000F)<<4)
#define MCF_SCM_OPACRD_OPACR29(x)          (((x)&0x0000000F)<<8)
#define MCF_SCM_OPACRD_OPACR28(x)          (((x)&0x0000000F)<<12)
#define MCF_SCM_OPACRD_OPACR27(x)          (((x)&0x0000000F)<<16)
#define MCF_SCM_OPACRD_OPACR26(x)          (((x)&0x0000000F)<<20)
#define MCF_SCM_OPACRD_OPACR25(x)          (((x)&0x0000000F)<<24)
#define MCF_SCM_OPACRD_OPACR24(x)          (((x)&0x0000000F)<<28)

/* Bit definitions and macros for MCF_SCM_MRSR */
#define MCF_SCM_MRSR_SWTR                  (0x20)
#define MCF_SCM_MRSR_OFPLR                 (0x40)
#define MCF_SCM_MRSR_POR                   (0x80)

/* Bit definitions and macros for MCF_SCM_MWCR */
#define MCF_SCM_MWCR_PRILVL(x)             (((x)&0x0F)<<0)
#define MCF_SCM_MWCR_LPMD(x)               (((x)&0x03)<<4)
#define MCF_SCM_MWCR_ENBWCR                (0x80)
#define MCF_SCM_MWCR_LPMD_STOP             MCF_SCM_MWCR_LPMD(0x03)
#define MCF_SCM_MWCR_LPMD_WAIT             MCF_SCM_MWCR_LPMD(0x02)
#define MCF_SCM_MWCR_LPMD_DOZE             MCF_SCM_MWCR_LPMD(0x01)

/* Bit definitions and macros for MCF_SCM_MSWCR */
#define MCF_SCM_MSWCR_CWT(x)               (((x)&0x001F)<<0)
#define MCF_SCM_MSWCR_CWRI(x)              (((x)&0x0003)<<5)
#define MCF_SCM_MSWCR_CWE                  (0x0080)
#define MCF_SCM_MSWCR_CWR_WH               (0x0100)
#define MCF_SCM_MSWCR_RO                   (0x8000)
#define MCF_SCM_MSWCR_CWRI_INT             (0x0000)
#define MCF_SCM_MSWCR_CWRI_INT_THEN_RESET  (0x0020)
#define MCF_SCM_MSWCR_CWRI_RESET           (0x0040)
#define MCF_SCM_MSWCR_CWRI_WINDOW          (0x0060)

/* Bit definitions and macros for MCF_SCM_MSWSR */
#define MCF_SCM_MSWSR_CWSR(x)              (((x)&0xFF)<<0)

/* Bit definitions and macros for MCF_SCM_SCMISR */
#define MCF_SCM_SCMISR_CWIC                  (0x01)
#define MCF_SCM_SCMISR_CFEI                  (0x02)

/* Bit definitions and macros for MCF_SCM_BCR */
#define MCF_SCM_BCR_S1                     (0x00000002)
#define MCF_SCM_BCR_S4                     (0x00000010)
#define MCF_SCM_BCR_S6                     (0x00000040)
#define MCF_SCM_BCR_S7                     (0x00000080)
#define MCF_SCM_BCR_GBW                    (0x00000100)
#define MCF_SCM_BCR_GBR                    (0x00000200)

/* Bit definitions and macros for MCF_SCM_PPMRS */
#define MCF_SCM_PPMRS_PPMRS(x)             (((x)&0x7F)<<0)

/* Bit definitions and macros for MCF_SCM_PPMRC */
#define MCF_SCM_PPMRC_PPMRC(x)             (((x)&0x7F)<<0)

/* Bit definitions and macros for MCF_SCM_PPMRH */
#define MCF_SCM_PPMRH_CD(x)                (((x)&0xFFFFFFFF)<<0)
#define MCF_SCM_PPMRH_PIT0                 (0x00000001)
#define MCF_SCM_PPMRH_PIT1                 (0x00000002)
#define MCF_SCM_PPMRH_PIT2                 (0x00000004)
#define MCF_SCM_PPMRH_PIT3                 (0x00000008)
#define MCF_SCM_PPMRH_EPORT0               (0x00000010)
#define MCF_SCM_PPMRH_EPORT1               (0x00000020)
#define MCF_SCM_PPMRH_38                   (0x00000040)
#define MCF_SCM_PPMRH_CODEC                (0x00000080)
#define MCF_SCM_PPMRH_CIM                  (0x00000100)
#define MCF_SCM_PPMRH_PORTS                (0x00000200)
#define MCF_SCM_PPMRH_RTC                  (0x00000400)
#define MCF_SCM_PPMRH_SIM                  (0x00000800)
#define MCF_SCM_PPMRH_USB_OTG              (0x00001000)
#define MCF_SCM_PPMRH_USB_HOST             (0x00002000)
#define MCF_SCM_PPMRH_SDRAMC               (0x00004000)
#define MCF_SCM_PPMRH_SSI                  (0x00008000)
#define MCF_SCM_PPMRH_PLL                  (0x00010000)
#define MCF_SCM_PPMRH_RNGB                 (0x00020000)
#define MCF_SCM_PPMRH_IIM                  (0x00040000)
#define MCF_SCM_PPMRH_ESDHC                (0x00080000)
#define MCF_SCM_PPMRH_SCC1                 (0x00100000)
#define MCF_SCM_PPMRH_RTIC                 (0x00200000)
#define MCF_SCM_PPMRH_54                   (0x00400000)
#define MCF_SCM_PPMRH_55                   (0x00800000)
#define MCF_SCM_PPMRH_56                   (0x01000000)
#define MCF_SCM_PPMRH_57                   (0x02000000)
#define MCF_SCM_PPMRH_58                   (0x04000000)
#define MCF_SCM_PPMRH_59                   (0x08000000)
#define MCF_SCM_PPMRH_60                   (0x10000000)
#define MCF_SCM_PPMRH_61                   (0x20000000)
#define MCF_SCM_PPMRH_62                   (0x40000000)
#define MCF_SCM_PPMRH_63                   (0x80000000)

/* Bit definitions and macros for MCF_SCM_PPMRL */
#define MCF_SCM_PPMRL_CD(x)                (((x)&0xFFFFFFFF)<<0)
#define MCF_SCM_PPMRL_00                   (0x00000001)
#define MCF_SCM_PPMRL_GLB                  (0x00000002)
#define MCF_SCM_PPMRL_FLEXBUS              (0x00000004)
#define MCF_SCM_PPMRL_03                   (0x00000008)
#define MCF_SCM_PPMRL_04                   (0x00000010)
#define MCF_SCM_PPMRL_MPU                  (0x00000020)
#define MCF_SCM_PPMRL_06                   (0x00000040)
#define MCF_SCM_PPMRL_07                   (0x00000080)
#define MCF_SCM_PPMRL_08                   (0x00000001)
#define MCF_SCM_PPMRL_09                   (0x00000200)
#define MCF_SCM_PPMRL_10                   (0x00000400)
#define MCF_SCM_PPMRL_11                   (0x00000800)
#define MCF_SCM_PPMRL_FEC                  (0x00001000)
#define MCF_SCM_PPMRL_FEC1                 (0x00002000)
#define MCF_SCM_PPMRL_14                   (0x00004000)
#define MCF_SCM_PPMRL_15                   (0x00008000)
#define MCF_SCM_PPMRL_16                   (0x00010000)
#define MCF_SCM_PPMRL_DMA2                 (0x00020000)
#define MCF_SCM_PPMRL_INTC0                (0x00040000)
#define MCF_SCM_PPMRL_INTC1                (0x00080000)
#define MCF_SCM_PPMRL_20                   (0x00100000)
#define MCF_SCM_PPMRL_21                   (0x00200000)
#define MCF_SCM_PPMRL_I2C                  (0x00400000)
#define MCF_SCM_PPMRL_DSPI                 (0x00800000)
#define MCF_SCM_PPMRL_UART0                (0x01000000)
#define MCF_SCM_PPMRL_UART1                (0x02000000)
#define MCF_SCM_PPMRL_UART2                (0x04000000)
#define MCF_SCM_PPMRL_27                   (0x08000000)
#define MCF_SCM_PPMRL_TIMER0               (0x10000000)
#define MCF_SCM_PPMRL_TIMER1               (0x20000000)
#define MCF_SCM_PPMRL_TIMER2               (0x40000000)
#define MCF_SCM_PPMRL_TIMER3               (0x80000000)

/* Bit definitions and macros for MCF_SCM_CFADR */
#define MCF_SCM_CFADR_ADDR(x)              (((x)&0xFFFFFFFF)<<0)

/* Bit definitions and macros for MCF_SCM_CFIER */
#define MCF_SCM_CFIER_ECFEI                (0x01)

/* Bit definitions and macros for MCF_SCM_CFLOC */
#define MCF_SCM_CFLOC_LOC                  (0x80)

/* Bit definitions and macros for MCF_SCM_CFATR */
#define MCF_SCM_CFATR_TYPE                 (0x01)
#define MCF_SCM_CFATR_MODE                 (0x02)
#define MCF_SCM_CFATR_CACHE                (0x08)
#define MCF_SCM_CFATR_SIZE(x)              (((x)&0x07)<<4)
#define MCF_SCM_CFATR_WRITE                (0x80)

/* Bit definitions and macros for MCF_SCM_CFDTR */
#define MCF_SCM_CFDTR_CFDTR(x)             (((x)&0xFFFFFFFF)<<0)

/* Bit definitions and macros for MCF_SCM_CFDTR1 */
#define MCF_SCM_CFDTR1_CFDTR(x)            (((x)&0xFFFFFFFF)<<0)

/********************************************************************/

#endif /* __MCF5301X_SCM_H__ */
