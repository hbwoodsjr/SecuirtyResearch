/*
 * File:    mcf5301x_dspi.h
 * Purpose: Register and bit definitions
 */

#ifndef __MCF5301X_DSPI_H__
#define __MCF5301X_DSPI_H__

/*********************************************************************
*
* DSPI (DSPI)
*
*********************************************************************/

/* Register read/write macros */
#define MCF_DSPI_MCR                 (*(vuint32*)(0xFC05C000))
#define MCF_DSPI_TCR                 (*(vuint32*)(0xFC05C008))
#define MCF_DSPI_CTAR0               (*(vuint32*)(0xFC05C00C))
#define MCF_DSPI_CTAR1               (*(vuint32*)(0xFC05C010))
#define MCF_DSPI_CTAR2               (*(vuint32*)(0xFC05C014))
#define MCF_DSPI_CTAR3               (*(vuint32*)(0xFC05C018))
#define MCF_DSPI_CTAR4               (*(vuint32*)(0xFC05C01C))
#define MCF_DSPI_CTAR5               (*(vuint32*)(0xFC05C020))
#define MCF_DSPI_CTAR6               (*(vuint32*)(0xFC05C024))
#define MCF_DSPI_CTAR7               (*(vuint32*)(0xFC05C028))
#define MCF_DSPI_SR                  (*(vuint32*)(0xFC05C02C))
#define MCF_DSPI_RSER                (*(vuint32*)(0xFC05C030))
#define MCF_DSPI_PUSHR               (*(vuint32*)(0xFC05C034))
#define MCF_DSPI_POPR                (*(vuint32*)(0xFC05C038))
#define MCF_DSPI_TXFR0               (*(vuint32*)(0xFC05C03C))
#define MCF_DSPI_TXFR1               (*(vuint32*)(0xFC05C040))
#define MCF_DSPI_TXFR2               (*(vuint32*)(0xFC05C044))
#define MCF_DSPI_TXFR3               (*(vuint32*)(0xFC05C048))
#define MCF_DSPI_TXFR4               (*(vuint32*)(0xFC05C04C))
#define MCF_DSPI_TXFR5               (*(vuint32*)(0xFC05C050))
#define MCF_DSPI_TXFR6               (*(vuint32*)(0xFC05C054))
#define MCF_DSPI_TXFR7               (*(vuint32*)(0xFC05C058))
#define MCF_DSPI_TXFR8               (*(vuint32*)(0xFC05C05C))
#define MCF_DSPI_TXFR9               (*(vuint32*)(0xFC05C060))
#define MCF_DSPI_TXFR10              (*(vuint32*)(0xFC05C064))
#define MCF_DSPI_TXFR11              (*(vuint32*)(0xFC05C068))
#define MCF_DSPI_TXFR12              (*(vuint32*)(0xFC05C06C))
#define MCF_DSPI_TXFR13              (*(vuint32*)(0xFC05C070))
#define MCF_DSPI_TXFR14              (*(vuint32*)(0xFC05C074))
#define MCF_DSPI_TXFR15              (*(vuint32*)(0xFC05C078))
#define MCF_DSPI_RXFR0               (*(vuint32*)(0xFC05C07C))
#define MCF_DSPI_RXFR1               (*(vuint32*)(0xFC05C080))
#define MCF_DSPI_RXFR2               (*(vuint32*)(0xFC05C084))
#define MCF_DSPI_RXFR3               (*(vuint32*)(0xFC05C088))
#define MCF_DSPI_RXFR4               (*(vuint32*)(0xFC05C08C))
#define MCF_DSPI_RXFR5               (*(vuint32*)(0xFC05C090))
#define MCF_DSPI_RXFR6               (*(vuint32*)(0xFC05C094))
#define MCF_DSPI_RXFR7               (*(vuint32*)(0xFC05C098))
#define MCF_DSPI_RXFR8               (*(vuint32*)(0xFC05C09C))
#define MCF_DSPI_RXFR9               (*(vuint32*)(0xFC05C0A0))
#define MCF_DSPI_RXFR10              (*(vuint32*)(0xFC05C0A4))
#define MCF_DSPI_RXFR11              (*(vuint32*)(0xFC05C0A8))
#define MCF_DSPI_RXFR12              (*(vuint32*)(0xFC05C0AC))
#define MCF_DSPI_RXFR13              (*(vuint32*)(0xFC05C0B0))
#define MCF_DSPI_RXFR14              (*(vuint32*)(0xFC05C0B4))
#define MCF_DSPI_RXFR15              (*(vuint32*)(0xFC05C0B8))
#define MCF_DSPI_DSICR               (*(vuint32*)(0xFC05C0BC))
#define MCF_DSPI_SDR                 (*(vuint32*)(0xFC05C0C0))
#define MCF_DSPI_ASDR                (*(vuint32*)(0xFC05C0C4))
#define MCF_DSPI_COMPR               (*(vuint32*)(0xFC05C0C8))
#define MCF_DSPI_DDR                 (*(vuint32*)(0xFC05C0CC))

/* Bit definitions and macros for MCF_DSPI_MCR */
#define MCF_DSPI_MCR_HALT            (0x00000001)
#define MCF_DSPI_MCR_SMPL_PT(x)      (((x)&0x00000003)<<8)
#define MCF_DSPI_MCR_CLR_RXF         (0x00000400)
#define MCF_DSPI_MCR_CLR_TXF         (0x00000800)
#define MCF_DSPI_MCR_DIS_RXF         (0x00001000)
#define MCF_DSPI_MCR_DIS_TXF         (0x00002000)
#define MCF_DSPI_MCR_MDIS            (0x00004000)
#define MCF_DSPI_MCR_DOZE            (0x00008000)
#define MCF_DSPI_MCR_PCSIS0          (0x00010000)
#define MCF_DSPI_MCR_PCSIS1          (0x00020000)
#define MCF_DSPI_MCR_PCSIS2          (0x00040000)
#define MCF_DSPI_MCR_PCSIS3          (0x00080000)
#define MCF_DSPI_MCR_PCSIS4          (0x00100000)
#define MCF_DSPI_MCR_PCSIS5          (0x00200000)
#define MCF_DSPI_MCR_PCSIS6          (0x00400000)
#define MCF_DSPI_MCR_PCSIS7          (0x00800000)
#define MCF_DSPI_MCR_ROOE            (0x01000000)
#define MCF_DSPI_MCR_PCSSE           (0x02000000)
#define MCF_DSPI_MCR_MTFE            (0x04000000)
#define MCF_DSPI_MCR_FRZ             (0x08000000)
#define MCF_DSPI_MCR_DCONF(x)        (((x)&0x00000003)<<28)
#define MCF_DSPI_MCR_CONT_SCKE       (0x40000000)
#define MCF_DSPI_MCR_MSTR            (0x80000000)

/* Bit definitions and macros for MCF_DSPI_TCR */
#define MCF_DSPI_TCR_SPI_TCNT(x)     (((x)&0x0000FFFF)<<16)

/* Bit definitions and macros for MCF_DSPI_CTAR0 */
#define MCF_DSPI_CTAR0_BR(x)         (((x)&0x0000000F)<<0)
#define MCF_DSPI_CTAR0_DT(x)         (((x)&0x0000000F)<<4)
#define MCF_DSPI_CTAR0_ASC(x)        (((x)&0x0000000F)<<8)
#define MCF_DSPI_CTAR0_CSSSCK(x)     (((x)&0x0000000F)<<12)
#define MCF_DSPI_CTAR0_PBR(x)        (((x)&0x00000003)<<16)
#define MCF_DSPI_CTAR0_PDT(x)        (((x)&0x00000003)<<18)
#define MCF_DSPI_CTAR0_PASC(x)       (((x)&0x00000003)<<20)
#define MCF_DSPI_CTAR0_PCSSCK(x)     (((x)&0x00000003)<<22)
#define MCF_DSPI_CTAR0_LSBFE         (0x01000000)
#define MCF_DSPI_CTAR0_CPHA          (0x02000000)
#define MCF_DSPI_CTAR0_CPOL          (0x04000000)
#define MCF_DSPI_CTAR0_FMSZ(x)       (((x)&0x0000000F)<<27)
#define MCF_DSPI_CTAR0_DBR           (0x80000000)

/* Bit definitions and macros for MCF_DSPI_CTAR1 */
#define MCF_DSPI_CTAR1_BR(x)         (((x)&0x0000000F)<<0)
#define MCF_DSPI_CTAR1_DT(x)         (((x)&0x0000000F)<<4)
#define MCF_DSPI_CTAR1_ASC(x)        (((x)&0x0000000F)<<8)
#define MCF_DSPI_CTAR1_CSSSCK(x)     (((x)&0x0000000F)<<12)
#define MCF_DSPI_CTAR1_PBR(x)        (((x)&0x00000003)<<16)
#define MCF_DSPI_CTAR1_PDT(x)        (((x)&0x00000003)<<18)
#define MCF_DSPI_CTAR1_PASC(x)       (((x)&0x00000003)<<20)
#define MCF_DSPI_CTAR1_PCSSCK(x)     (((x)&0x00000003)<<22)
#define MCF_DSPI_CTAR1_LSBFE         (0x01000000)
#define MCF_DSPI_CTAR1_CPHA          (0x02000000)
#define MCF_DSPI_CTAR1_CPOL          (0x04000000)
#define MCF_DSPI_CTAR1_FMSZ(x)       (((x)&0x0000000F)<<27)
#define MCF_DSPI_CTAR1_DBR           (0x80000000)

/* Bit definitions and macros for MCF_DSPI_CTAR2 */
#define MCF_DSPI_CTAR2_BR(x)         (((x)&0x0000000F)<<0)
#define MCF_DSPI_CTAR2_DT(x)         (((x)&0x0000000F)<<4)
#define MCF_DSPI_CTAR2_ASC(x)        (((x)&0x0000000F)<<8)
#define MCF_DSPI_CTAR2_CSSSCK(x)     (((x)&0x0000000F)<<12)
#define MCF_DSPI_CTAR2_PBR(x)        (((x)&0x00000003)<<16)
#define MCF_DSPI_CTAR2_PDT(x)        (((x)&0x00000003)<<18)
#define MCF_DSPI_CTAR2_PASC(x)       (((x)&0x00000003)<<20)
#define MCF_DSPI_CTAR2_PCSSCK(x)     (((x)&0x00000003)<<22)
#define MCF_DSPI_CTAR2_LSBFE         (0x01000000)
#define MCF_DSPI_CTAR2_CPHA          (0x02000000)
#define MCF_DSPI_CTAR2_CPOL          (0x04000000)
#define MCF_DSPI_CTAR2_FMSZ(x)       (((x)&0x0000000F)<<27)
#define MCF_DSPI_CTAR2_DBR           (0x80000000)

/* Bit definitions and macros for MCF_DSPI_CTAR3 */
#define MCF_DSPI_CTAR3_BR(x)         (((x)&0x0000000F)<<0)
#define MCF_DSPI_CTAR3_DT(x)         (((x)&0x0000000F)<<4)
#define MCF_DSPI_CTAR3_ASC(x)        (((x)&0x0000000F)<<8)
#define MCF_DSPI_CTAR3_CSSSCK(x)     (((x)&0x0000000F)<<12)
#define MCF_DSPI_CTAR3_PBR(x)        (((x)&0x00000003)<<16)
#define MCF_DSPI_CTAR3_PDT(x)        (((x)&0x00000003)<<18)
#define MCF_DSPI_CTAR3_PASC(x)       (((x)&0x00000003)<<20)
#define MCF_DSPI_CTAR3_PCSSCK(x)     (((x)&0x00000003)<<22)
#define MCF_DSPI_CTAR3_LSBFE         (0x01000000)
#define MCF_DSPI_CTAR3_CPHA          (0x02000000)
#define MCF_DSPI_CTAR3_CPOL          (0x04000000)
#define MCF_DSPI_CTAR3_FMSZ(x)       (((x)&0x0000000F)<<27)
#define MCF_DSPI_CTAR3_DBR           (0x80000000)

/* Bit definitions and macros for MCF_DSPI_CTAR4 */
#define MCF_DSPI_CTAR4_BR(x)         (((x)&0x0000000F)<<0)
#define MCF_DSPI_CTAR4_DT(x)         (((x)&0x0000000F)<<4)
#define MCF_DSPI_CTAR4_ASC(x)        (((x)&0x0000000F)<<8)
#define MCF_DSPI_CTAR4_CSSSCK(x)     (((x)&0x0000000F)<<12)
#define MCF_DSPI_CTAR4_PBR(x)        (((x)&0x00000003)<<16)
#define MCF_DSPI_CTAR4_PDT(x)        (((x)&0x00000003)<<18)
#define MCF_DSPI_CTAR4_PASC(x)       (((x)&0x00000003)<<20)
#define MCF_DSPI_CTAR4_PCSSCK(x)     (((x)&0x00000003)<<22)
#define MCF_DSPI_CTAR4_LSBFE         (0x01000000)
#define MCF_DSPI_CTAR4_CPHA          (0x02000000)
#define MCF_DSPI_CTAR4_CPOL          (0x04000000)
#define MCF_DSPI_CTAR4_FMSZ(x)       (((x)&0x0000000F)<<27)
#define MCF_DSPI_CTAR4_DBR           (0x80000000)

/* Bit definitions and macros for MCF_DSPI_CTAR5 */
#define MCF_DSPI_CTAR5_BR(x)         (((x)&0x0000000F)<<0)
#define MCF_DSPI_CTAR5_DT(x)         (((x)&0x0000000F)<<4)
#define MCF_DSPI_CTAR5_ASC(x)        (((x)&0x0000000F)<<8)
#define MCF_DSPI_CTAR5_CSSSCK(x)     (((x)&0x0000000F)<<12)
#define MCF_DSPI_CTAR5_PBR(x)        (((x)&0x00000003)<<16)
#define MCF_DSPI_CTAR5_PDT(x)        (((x)&0x00000003)<<18)
#define MCF_DSPI_CTAR5_PASC(x)       (((x)&0x00000003)<<20)
#define MCF_DSPI_CTAR5_PCSSCK(x)     (((x)&0x00000003)<<22)
#define MCF_DSPI_CTAR5_LSBFE         (0x01000000)
#define MCF_DSPI_CTAR5_CPHA          (0x02000000)
#define MCF_DSPI_CTAR5_CPOL          (0x04000000)
#define MCF_DSPI_CTAR5_FMSZ(x)       (((x)&0x0000000F)<<27)
#define MCF_DSPI_CTAR5_DBR           (0x80000000)

/* Bit definitions and macros for MCF_DSPI_CTAR6 */
#define MCF_DSPI_CTAR6_BR(x)         (((x)&0x0000000F)<<0)
#define MCF_DSPI_CTAR6_DT(x)         (((x)&0x0000000F)<<4)
#define MCF_DSPI_CTAR6_ASC(x)        (((x)&0x0000000F)<<8)
#define MCF_DSPI_CTAR6_CSSSCK(x)     (((x)&0x0000000F)<<12)
#define MCF_DSPI_CTAR6_PBR(x)        (((x)&0x00000003)<<16)
#define MCF_DSPI_CTAR6_PDT(x)        (((x)&0x00000003)<<18)
#define MCF_DSPI_CTAR6_PASC(x)       (((x)&0x00000003)<<20)
#define MCF_DSPI_CTAR6_PCSSCK(x)     (((x)&0x00000003)<<22)
#define MCF_DSPI_CTAR6_LSBFE         (0x01000000)
#define MCF_DSPI_CTAR6_CPHA          (0x02000000)
#define MCF_DSPI_CTAR6_CPOL          (0x04000000)
#define MCF_DSPI_CTAR6_FMSZ(x)       (((x)&0x0000000F)<<27)
#define MCF_DSPI_CTAR6_DBR           (0x80000000)

/* Bit definitions and macros for MCF_DSPI_CTAR7 */
#define MCF_DSPI_CTAR7_BR(x)         (((x)&0x0000000F)<<0)
#define MCF_DSPI_CTAR7_DT(x)         (((x)&0x0000000F)<<4)
#define MCF_DSPI_CTAR7_ASC(x)        (((x)&0x0000000F)<<8)
#define MCF_DSPI_CTAR7_CSSSCK(x)     (((x)&0x0000000F)<<12)
#define MCF_DSPI_CTAR7_PBR(x)        (((x)&0x00000003)<<16)
#define MCF_DSPI_CTAR7_PDT(x)        (((x)&0x00000003)<<18)
#define MCF_DSPI_CTAR7_PASC(x)       (((x)&0x00000003)<<20)
#define MCF_DSPI_CTAR7_PCSSCK(x)     (((x)&0x00000003)<<22)
#define MCF_DSPI_CTAR7_LSBFE         (0x01000000)
#define MCF_DSPI_CTAR7_CPHA          (0x02000000)
#define MCF_DSPI_CTAR7_CPOL          (0x04000000)
#define MCF_DSPI_CTAR7_FMSZ(x)       (((x)&0x0000000F)<<27)
#define MCF_DSPI_CTAR7_DBR           (0x80000000)

/* Bit definitions and macros for MCF_DSPI_SR */
#define MCF_DSPI_SR_POPNXTPTR(x)     (((x)&0x0000000F)<<0)
#define MCF_DSPI_SR_RXCTR(x)         (((x)&0x0000000F)<<4)
#define MCF_DSPI_SR_TXNXTPTR(x)      (((x)&0x0000000F)<<8)
#define MCF_DSPI_SR_TXCTR(x)         (((x)&0x0000000F)<<12)
#define MCF_DSPI_SR_RFDF             (0x00020000)
#define MCF_DSPI_SR_RFQF             (0x00080000)
#define MCF_DSPI_SR_TFFF             (0x02000000)
#define MCF_DSPI_SR_TFUF             (0x08000000)
#define MCF_DSPI_SR_EQQF             (0x10000000)
#define MCF_DSPI_SR_TXRXS            (0x40000000)
#define MCF_DSPI_SR_TCF              (0x80000000)

/* Bit definitions and macros for MCF_DSPI_RSER */
#define MCF_DSPI_RSER_RFDF_DIRS      (0x00010000)
#define MCF_DSPI_RSER_RFDF_RE        (0x00020000)
#define MCF_DSPI_RSER_RFQF_RE        (0x00080000)
#define MCF_DSPI_RSER_TFFF_DIRS      (0x01000000)
#define MCF_DSPI_RSER_TFFF_RE        (0x02000000)
#define MCF_DSPI_RSER_TFUF_RE        (0x08000000)
#define MCF_DSPI_RSER_EQQF_RE        (0x10000000)
#define MCF_DSPI_RSER_TCF_RE         (0x80000000)

/* Bit definitions and macros for MCF_DSPI_PUSHR */
#define MCF_DSPI_PUSHR_TXDATA(x)     (((x)&0x0000FFFF)<<0)
#define MCF_DSPI_PUSHR_PCS0          (0x00010000)
#define MCF_DSPI_PUSHR_PCS1          (0x00020000)
#define MCF_DSPI_PUSHR_PCS2          (0x00040000)
#define MCF_DSPI_PUSHR_PCS3          (0x00080000)
#define MCF_DSPI_PUSHR_PCS4          (0x00100000)
#define MCF_DSPI_PUSHR_PCS5          (0x00200000)
#define MCF_DSPI_PUSHR_PCS6          (0x00400000)
#define MCF_DSPI_PUSHR_PCS7          (0x00800000)
#define MCF_DSPI_PUSHR_CTCNT         (0x04000000)
#define MCF_DSPI_PUSHR_EOQ           (0x08000000)
#define MCF_DSPI_PUSHR_CTAS(x)       (((x)&0x00000007)<<28)
#define MCF_DSPI_PUSHR_CONT          (0x80000000)

/* Bit definitions and macros for MCF_DSPI_POPR */
#define MCF_DSPI_POPR_RXDATA(x)      (((x)&0x0000FFFF)<<0)

/* Bit definitions and macros for MCF_DSPI_TXFR0 */
#define MCF_DSPI_TXFR0_TXCMD(x)      (((x)&0x0000FFFF)<<16)

/* Bit definitions and macros for MCF_DSPI_TXFR1 */
#define MCF_DSPI_TXFR1_TXCMD(x)      (((x)&0x0000FFFF)<<16)

/* Bit definitions and macros for MCF_DSPI_TXFR2 */
#define MCF_DSPI_TXFR2_TXCMD(x)      (((x)&0x0000FFFF)<<16)

/* Bit definitions and macros for MCF_DSPI_TXFR3 */
#define MCF_DSPI_TXFR3_TXCMD(x)      (((x)&0x0000FFFF)<<16)

/* Bit definitions and macros for MCF_DSPI_TXFR4 */
#define MCF_DSPI_TXFR4_TXCMD(x)      (((x)&0x0000FFFF)<<16)

/* Bit definitions and macros for MCF_DSPI_TXFR5 */
#define MCF_DSPI_TXFR5_TXCMD(x)      (((x)&0x0000FFFF)<<16)

/* Bit definitions and macros for MCF_DSPI_TXFR6 */
#define MCF_DSPI_TXFR6_TXCMD(x)      (((x)&0x0000FFFF)<<16)

/* Bit definitions and macros for MCF_DSPI_TXFR7 */
#define MCF_DSPI_TXFR7_TXCMD(x)      (((x)&0x0000FFFF)<<16)

/* Bit definitions and macros for MCF_DSPI_TXFR8 */
#define MCF_DSPI_TXFR8_TXCMD(x)      (((x)&0x0000FFFF)<<16)

/* Bit definitions and macros for MCF_DSPI_TXFR9 */
#define MCF_DSPI_TXFR9_TXCMD(x)      (((x)&0x0000FFFF)<<16)

/* Bit definitions and macros for MCF_DSPI_TXFR10 */
#define MCF_DSPI_TXFR10_TXCMD(x)     (((x)&0x0000FFFF)<<16)

/* Bit definitions and macros for MCF_DSPI_TXFR11 */
#define MCF_DSPI_TXFR11_TXCMD(x)     (((x)&0x0000FFFF)<<16)

/* Bit definitions and macros for MCF_DSPI_TXFR12 */
#define MCF_DSPI_TXFR12_TXCMD(x)     (((x)&0x0000FFFF)<<16)

/* Bit definitions and macros for MCF_DSPI_TXFR13 */
#define MCF_DSPI_TXFR13_TXCMD(x)     (((x)&0x0000FFFF)<<16)

/* Bit definitions and macros for MCF_DSPI_TXFR14 */
#define MCF_DSPI_TXFR14_TXCMD(x)     (((x)&0x0000FFFF)<<16)

/* Bit definitions and macros for MCF_DSPI_TXFR15 */
#define MCF_DSPI_TXFR15_TXCMD(x)     (((x)&0x0000FFFF)<<16)

/* Bit definitions and macros for MCF_DSPI_RXFR0 */
#define MCF_DSPI_RXFR0_RXDATA(x)     (((x)&0x0000FFFF)<<0)

/* Bit definitions and macros for MCF_DSPI_RXFR1 */
#define MCF_DSPI_RXFR1_RXDATA(x)     (((x)&0x0000FFFF)<<0)

/* Bit definitions and macros for MCF_DSPI_RXFR2 */
#define MCF_DSPI_RXFR2_RXDATA(x)     (((x)&0x0000FFFF)<<0)

/* Bit definitions and macros for MCF_DSPI_RXFR3 */
#define MCF_DSPI_RXFR3_RXDATA(x)     (((x)&0x0000FFFF)<<0)

/* Bit definitions and macros for MCF_DSPI_RXFR4 */
#define MCF_DSPI_RXFR4_RXDATA(x)     (((x)&0x0000FFFF)<<0)

/* Bit definitions and macros for MCF_DSPI_RXFR5 */
#define MCF_DSPI_RXFR5_RXDATA(x)     (((x)&0x0000FFFF)<<0)

/* Bit definitions and macros for MCF_DSPI_RXFR6 */
#define MCF_DSPI_RXFR6_RXDATA(x)     (((x)&0x0000FFFF)<<0)

/* Bit definitions and macros for MCF_DSPI_RXFR7 */
#define MCF_DSPI_RXFR7_RXDATA(x)     (((x)&0x0000FFFF)<<0)

/* Bit definitions and macros for MCF_DSPI_RXFR8 */
#define MCF_DSPI_RXFR8_RXDATA(x)     (((x)&0x0000FFFF)<<0)

/* Bit definitions and macros for MCF_DSPI_RXFR9 */
#define MCF_DSPI_RXFR9_RXDATA(x)     (((x)&0x0000FFFF)<<0)

/* Bit definitions and macros for MCF_DSPI_RXFR10 */
#define MCF_DSPI_RXFR10_RXDATA(x)    (((x)&0x0000FFFF)<<0)

/* Bit definitions and macros for MCF_DSPI_RXFR11 */
#define MCF_DSPI_RXFR11_RXDATA(x)    (((x)&0x0000FFFF)<<0)

/* Bit definitions and macros for MCF_DSPI_RXFR12 */
#define MCF_DSPI_RXFR12_RXDATA(x)    (((x)&0x0000FFFF)<<0)

/* Bit definitions and macros for MCF_DSPI_RXFR13 */
#define MCF_DSPI_RXFR13_RXDATA(x)    (((x)&0x0000FFFF)<<0)

/* Bit definitions and macros for MCF_DSPI_RXFR14 */
#define MCF_DSPI_RXFR14_RXDATA(x)    (((x)&0x0000FFFF)<<0)

/* Bit definitions and macros for MCF_DSPI_RXFR15 */
#define MCF_DSPI_RXFR15_RXDATA(x)    (((x)&0x0000FFFF)<<0)

/* Bit definitions and macros for MCF_DSPI_DSICR */
#define MCF_DSPI_DSICR_DPCS0         (0x00000001)
#define MCF_DSPI_DSICR_DPCS1         (0x00000002)
#define MCF_DSPI_DSICR_DPCS2         (0x00000004)
#define MCF_DSPI_DSICR_DPCS3         (0x00000008)
#define MCF_DSPI_DSICR_DPCS4         (0x00000010)
#define MCF_DSPI_DSICR_DPCS5         (0x00000020)
#define MCF_DSPI_DSICR_DPCS6         (0x00000040)
#define MCF_DSPI_DSICR_DPCS7         (0x00000080)
#define MCF_DSPI_DSICR_DSICTAS(x)    (((x)&0x00000007)<<12)
#define MCF_DSPI_DSICR_DCONT         (0x00008000)
#define MCF_DSPI_DSICR_CID           (0x00010000)
#define MCF_DSPI_DSICR_TRRE          (0x00020000)
#define MCF_DSPI_DSICR_TPOL          (0x00040000)
#define MCF_DSPI_DSICR_TXSSS         (0x00080000)
#define MCF_DSPI_DSICR_MTOCNT(x)     (((x)&0x0000003F)<<24)
#define MCF_DSPI_DSICR_MTOE          (0x80000000)

/* Bit definitions and macros for MCF_DSPI_SDR */
#define MCF_DSPI_SDR_SER_DATA(x)     (((x)&0x0000FFFF)<<0)

/* Bit definitions and macros for MCF_DSPI_ASDR */
#define MCF_DSPI_ASDR_ASER_DATA(x)   (((x)&0x0000FFFF)<<0)

/* Bit definitions and macros for MCF_DSPI_COMPR */
#define MCF_DSPI_COMPR_COMP_DATA(x)  (((x)&0x0000FFFF)<<0)

/* Bit definitions and macros for MCF_DSPI_DDR */
#define MCF_DSPI_DDR_DESER_DATA(x)   (((x)&0x0000FFFF)<<0)

/********************************************************************/

#endif /* __MCF5301X_DSPI_H__ */
