/*
 * File:    mcf5301x_pll.h
 * Purpose: Register and bit definitions
 */

#ifndef __MCF5301X_PLL_H__
#define __MCF5301X_PLL_H__

/*********************************************************************
*
* Phase Locked Loop (PLL)
*
*********************************************************************/

/* Register read/write macros */
#define MCF_PLL_PCR                 (*(vuint32*)(0xFC0C0000))
#define MCF_PLL_PDR                 (*(vuint32*)(0xFC0C0004))
#define MCF_PLL_PSR                 (*(vuint32*)(0xFC0C0008))
#define MCF_PLL_PTR                 (*(vuint32*)(0xFC0C000C))

/* Bit definitions and macros for MCF_PLL_PCR */
#define MCF_PLL_PCR_FBDIV(x)        (((x)&0x0000003F)<<0)
#define MCF_PLL_PCR_REFDIV(x)       (((x)&0x00000007)<<8)
#define MCF_PLL_PCR_LOL_EN          (0x00001000)
#define MCF_PLL_PCR_LOL_RE          (0x00002000)
#define MCF_PLL_PCR_LOL_IR          (0x00004000)
#define MCF_PLL_PCR_LOC_EN          (0x00010000)
#define MCF_PLL_PCR_LOC_RE          (0x00020000)
#define MCF_PLL_PCR_LOC_IR          (0x00040000)

/* Bit definitions and macros for MCF_PLL_PDR */
#define MCF_PLL_PDR_OUTDIV1(x)      (((x)&0x0000000F)<<0)
#define MCF_PLL_PDR_OUTDIV2(x)      (((x)&0x0000000F)<<4)
#define MCF_PLL_PDR_OUTDIV3(x)      (((x)&0x0000000F)<<8)
#define MCF_PLL_PDR_OUTDIV4(x)      (((x)&0x0000000F)<<12)

/* Bit definitions and macros for MCF_PLL_PSR */
#define MCF_PLL_PSR_PLL_MODE(x)     (((x)&0x00000007)<<0)
#define MCF_PLL_PSR_LOCK            (0x00000010)
#define MCF_PLL_PSR_LOCKS           (0x00000020)
#define MCF_PLL_PSR_LOLF            (0x00000040)
#define MCF_PLL_PSR_LOC             (0x00000100)
#define MCF_PLL_PSR_LOCF            (0x00000200)

/* Bit definitions and macros for MCF_PLL_PTR */
#define MCF_PLL_PTR_TEST_SELECT(x)  (((x)&0x0000007F)<<0)
#define MCF_PLL_PTR_NBIAS_ADJ(x)    (((x)&0x0000001F)<<8)
#define MCF_PLL_PTR_PBIAS_ADJ(x)    (((x)&0x0000001F)<<16)
#define MCF_PLL_PTR_TESTDIV(x)      (((x)&0x0000000F)<<24)
#define MCF_PLL_PTR_TM              (0x80000000)

/********************************************************************/

#endif /* __MCF5301X_PLL_H__ */
