/*
 * File:    longjing.hfg.h
 * Purpose: Register and bit definitions
 */
#ifndef __MCF5301X_RTIC_H__
#define __MCF5301X_RTIC_H__

/*********************************************************************
*
* RTIC
 (RTIC
)
*
*********************************************************************/

/* Register read/write macros */
#define MCF_RTIC_STATUS               (*(vuint32*)(0xFC0D4000))
#define MCF_RTIC_CMD                  (*(vuint32*)(0xFC0D4004))
#define MCF_RTIC_CTRL                 (*(vuint32*)(0xFC0D4008))
#define MCF_RTIC_DMA_THROTTLE         (*(vuint32*)(0xFC0D400C))
#define MCF_RTIC_MEMBLOCKA1           (*(vuint32*)(0xFC0D4010))
#define MCF_RTIC_MEMLENA1             (*(vuint32*)(0xFC0D4014))
#define MCF_RTIC_MEMBLOCKA2           (*(vuint32*)(0xFC0D4018))
#define MCF_RTIC_MEMLENA2             (*(vuint32*)(0xFC0D401C))
#define MCF_RTIC_MEMBLOCKB1           (*(vuint32*)(0xFC0D4030))
#define MCF_RTIC_MEMLENB1             (*(vuint32*)(0xFC0D4034))
#define MCF_RTIC_MEMBLOCKB2           (*(vuint32*)(0xFC0D4038))
#define MCF_RTIC_MEMLENB2             (*(vuint32*)(0xFC0D403C))
#define MCF_RTIC_MEMBLOCKC1           (*(vuint32*)(0xFC0D4050))
#define MCF_RTIC_MEMLENC1             (*(vuint32*)(0xFC0D4054))
#define MCF_RTIC_MEMBLOCKC2           (*(vuint32*)(0xFC0D4058))
#define MCF_RTIC_MEMLENC2             (*(vuint32*)(0xFC0D405C))
#define MCF_RTIC_MEMBLOCKD1           (*(vuint32*)(0xFC0D4070))
#define MCF_RTIC_MEMLEND1             (*(vuint32*)(0xFC0D4074))
#define MCF_RTIC_MEMBLOCKD2           (*(vuint32*)(0xFC0D4078))
#define MCF_RTIC_MEMLEND2             (*(vuint32*)(0xFC0D407C))
#define MCF_RTIC_FAULT                (*(vuint32*)(0xFC0D4090))
#define MCF_RTIC_WDOG                 (*(vuint32*)(0xFC0D4094))
#define MCF_RTIC_VERID                (*(vuint32*)(0xFC0D4098))
#define MCF_RTIC_HASHA_A              (*(vuint32*)(0xFC0D40A0))
#define MCF_RTIC_HASHA_B              (*(vuint32*)(0xFC0D40A4))
#define MCF_RTIC_HASHA_C              (*(vuint32*)(0xFC0D40A8))
#define MCF_RTIC_HASHA_D              (*(vuint32*)(0xFC0D40AC))
#define MCF_RTIC_HASHA_E              (*(vuint32*)(0xFC0D40B0))
#define MCF_RTIC_HASHA_F              (*(vuint32*)(0xFC0D40B4))
#define MCF_RTIC_HASHA_G              (*(vuint32*)(0xFC0D40B8))
#define MCF_RTIC_HASHA_H              (*(vuint32*)(0xFC0D40BC))
#define MCF_RTIC_HASHB_A              (*(vuint32*)(0xFC0D40C0))
#define MCF_RTIC_HASHB_B              (*(vuint32*)(0xFC0D40C4))
#define MCF_RTIC_HASHB_C              (*(vuint32*)(0xFC0D40C8))
#define MCF_RTIC_HASHB_D              (*(vuint32*)(0xFC0D40CC))
#define MCF_RTIC_HASHB_E              (*(vuint32*)(0xFC0D40D0))
#define MCF_RTIC_HASHB_F              (*(vuint32*)(0xFC0D40D4))
#define MCF_RTIC_HASHB_G              (*(vuint32*)(0xFC0D40D8))
#define MCF_RTIC_HASHB_H              (*(vuint32*)(0xFC0D40DC))
#define MCF_RTIC_HASHC_A              (*(vuint32*)(0xFC0D40E0))
#define MCF_RTIC_HASHC_B              (*(vuint32*)(0xFC0D40E4))
#define MCF_RTIC_HASHC_C              (*(vuint32*)(0xFC0D40E8))
#define MCF_RTIC_HASHC_D              (*(vuint32*)(0xFC0D40EC))
#define MCF_RTIC_HASHC_E              (*(vuint32*)(0xFC0D40F0))
#define MCF_RTIC_HASHC_F              (*(vuint32*)(0xFC0D40F4))
#define MCF_RTIC_HASHC_G              (*(vuint32*)(0xFC0D40F8))
#define MCF_RTIC_HASHC_H              (*(vuint32*)(0xFC0D40FC))
#define MCF_RTIC_HASHD_A              (*(vuint32*)(0xFC0D4100))
#define MCF_RTIC_HASHD_B              (*(vuint32*)(0xFC0D4104))
#define MCF_RTIC_HASHD_C              (*(vuint32*)(0xFC0D4108))
#define MCF_RTIC_HASHD_D              (*(vuint32*)(0xFC0D410C))
#define MCF_RTIC_HASHD_E              (*(vuint32*)(0xFC0D4110))
#define MCF_RTIC_HASHD_F              (*(vuint32*)(0xFC0D4114))
#define MCF_RTIC_HASHD_G              (*(vuint32*)(0xFC0D4118))
#define MCF_RTIC_HASHD_H              (*(vuint32*)(0xFC0D411C))

/* Bit definitions and macros for MCF_RTIC
_RTIC_STATUS */
#define MCF_RTIC_STATUS_BUSY                             (0x00000001)
#define MCF_RTIC_STATUS_HASHDONE                         (0x00000002)
#define MCF_RTIC_STATUS_SECVIO                           (0x00000004)
#define MCF_RTIC_STATUS_HASHERR                          (0x00000008)
#define MCF_RTIC_STATUS_MEM_INT_STS(x)                   (((x)&0x0000000F)<<4)
#define MCF_RTIC_STATUS_ADDERR(x)                        (((x)&0x0000000F)<<8)
#define MCF_RTIC_STATUS_LENERR(x)                        (((x)&0x0000000F)<<12)
#define MCF_RTIC_STATUS_WDERR                            (0x00010000)
#define MCF_RTIC_STATUS_ABH                              (0x00020000)
#define MCF_RTIC_STATUS_STATE(x)                         (((x)&0x00000003)<<25)

/* Bit definitions and macros for MCF_RTIC
_RTIC_CMD */
#define MCF_RTIC_CMD_CLRIRQ                              (0x00000001)
#define MCF_RTIC_CMD_SWRST                               (0x00000002)
#define MCF_RTIC_CMD_HASH_ONCE                           (0x00000004)
#define MCF_RTIC_CMD_RT_CHK                              (0x00000008)
#define MCF_RTIC_CMD_RT_DISABLE                          (0x00000010)

/* Bit definitions and macros for MCF_RTIC
_RTIC_CTRL */
#define MCF_RTIC_CTRL_IRQ_EN                             (0x00000001)
#define MCF_RTIC_CTRL_DMA_BURST_SIZE(x)                  (((x)&0x00000007)<<1)
#define MCF_RTIC_CTRL_HASH_ONCE_MEM_ENB(x)               (((x)&0x0000000F)<<4)
#define MCF_RTIC_CTRL_RUN_TIME_MEM_ENB(x)                (((x)&0x0000000F)<<8)
#define MCF_RTIC_CTRL_ALG_MEM_SEL(x)                     (((x)&0x0000000F)<<12)
#define MCF_RTIC_CTRL_MEM_BYTE_SWAP(x)                   (((x)&0x0000000F)<<16)
#define MCF_RTIC_CTRL_MEM_HALF_WORD_SWAP(x)              (((x)&0x0000000F)<<20)
#define MCF_RTIC_CTRL_MEM_HASH_RES_BYTE_SWP(x)           (((x)&0x0000000F)<<24)
#define MCF_RTIC_CTRL_RUN_TIME_MEM_UNLOCK(x)             (((x)&0x0000000F)<<28)

/* Bit definitions and macros for MCF_RTIC
_RTIC_DMA_THROTTLE */
#define MCF_RTIC_DMA_THROTTLE_RUN_TIME_MODE_DEL_BW_DMA_BU (((x)&0x0000FFFF)<<0)
#define MCF_RTIC_DMA_THROTTLE_HASH_ONCE_MODE_DMA_THRTLE (x(((x)&0x000000FF)<<16)

/* Bit definitions and macros for MCF_RTIC
_RTIC_MEMBLOCKA1 */
#define MCF_RTIC_MEMBLOCKA1_MEM_BLK_ADD(x)               (((x)&0xFFFFFFFF)<<0)

/* Bit definitions and macros for MCF_RTIC
_RTIC_MEMLENA1 */
#define MCF_RTIC_MEMLENA1_MEM_LEN(x)                     (((x)&0xFFFFFFFF)<<0)

/* Bit definitions and macros for MCF_RTIC
_RTIC_MEMLENA2 */
#define MCF_RTIC_MEMLENA2_MEM_LEN(x)                     (((x)&0xFFFFFFFF)<<0)

/* Bit definitions and macros for MCF_RTIC
_RTIC_MEMBLOCKB1 */
#define MCF_RTIC_MEMBLOCKB1_MEM_BLK_ADD(x)               (((x)&0xFFFFFFFF)<<0)

/* Bit definitions and macros for MCF_RTIC
_RTIC_MEMLENB1 */
#define MCF_RTIC_MEMLENB1_MEM_LEN(x)                     (((x)&0xFFFFFFFF)<<0)

/* Bit definitions and macros for MCF_RTIC
_RTIC_MEMBLOCKB2 */
#define MCF_RTIC_MEMBLOCKB2_MEM_BLK_ADD(x)               (((x)&0xFFFFFFFF)<<0)

/* Bit definitions and macros for MCF_RTIC
_RTIC_MEMLENB2 */
#define MCF_RTIC_MEMLENB2_MEM_LEN(x)                     (((x)&0xFFFFFFFF)<<0)

/* Bit definitions and macros for MCF_RTIC
_RTIC_MEMBLOCKC1 */
#define MCF_RTIC_MEMBLOCKC1_MEM_BLK_ADD(x)               (((x)&0xFFFFFFFF)<<0)

/* Bit definitions and macros for MCF_RTIC
_RTIC_MEMLENC1 */
#define MCF_RTIC_MEMLENC1_MEM_LEN(x)                     (((x)&0xFFFFFFFF)<<0)

/* Bit definitions and macros for MCF_RTIC
_RTIC_MEMBLOCKC2 */
#define MCF_RTIC_MEMBLOCKC2_MEM_BLK_ADD(x)               (((x)&0xFFFFFFFF)<<0)

/* Bit definitions and macros for MCF_RTIC
_RTIC_MEMLENC2 */
#define MCF_RTIC_MEMLENC2_MEM_LEN(x)                     (((x)&0xFFFFFFFF)<<0)

/* Bit definitions and macros for MCF_RTIC
_RTIC_MEMBLOCKD1 */
#define MCF_RTIC_MEMBLOCKD1_MEM_BLK_ADD(x)               (((x)&0xFFFFFFFF)<<0)

/* Bit definitions and macros for MCF_RTIC
_RTIC_MEMLEND1 */
#define MCF_RTIC_MEMLEND1_MEM_LEN(x)                     (((x)&0xFFFFFFFF)<<0)

/* Bit definitions and macros for MCF_RTIC
_RTIC_MEMBLOCKD2 */
#define MCF_RTIC_MEMBLOCKD2_MEM_BLK_ADD(x)               (((x)&0xFFFFFFFF)<<0)

/* Bit definitions and macros for MCF_RTIC
_RTIC_MEMLEND2 */
#define MCF_RTIC_MEMLEND2_MEM_LEN(x)                     (((x)&0xFFFFFFFF)<<0)

/* Bit definitions and macros for MCF_RTIC
_RTIC_FAULT */
#define MCF_RTIC_FAULT_FAULT_ADDR(x)                     (((x)&0xFFFFFFFF)<<0)

/* Bit definitions and macros for MCF_RTIC
_RTIC_WDOG */
#define MCF_RTIC_WDOG_WATCHDOG(x)                        (((x)&0xFFFFFFFF)<<0)

/* Bit definitions and macros for MCF_RTIC
_RTIC_VERID */
#define MCF_RTIC_VERID_MIN_REV(x)                        (((x)&0x000000FF)<<0)
#define MCF_RTIC_VERID_MAJ_REV(x)                        (((x)&0x000000FF)<<8)
#define MCF_RTIC_VERID_SHA1                              (0x00010000)
#define MCF_RTIC_VERID_SHA256                            (0x00020000)
#define MCF_RTIC_VERID_PE                                (0x01000000)
#define MCF_RTIC_VERID_MRL                               (0x02000000)

/* Bit definitions and macros for MCF_RTIC
_RTIC_HASHA_A */
#define MCF_RTIC_HASHA_A_MEM_A_HASH_RES(x)               (((x)&0xFFFFFFFF)<<0)

/* Bit definitions and macros for MCF_RTIC
_RTIC_HASHA_B */
#define MCF_RTIC_HASHA_B_MEM_A_HASH_RES(x)               (((x)&0xFFFFFFFF)<<0)

/* Bit definitions and macros for MCF_RTIC
_RTIC_HASHA_C */
#define MCF_RTIC_HASHA_C_MEM_A_HASH_RES(x)               (((x)&0xFFFFFFFF)<<0)

/* Bit definitions and macros for MCF_RTIC
_RTIC_HASHA_D */
#define MCF_RTIC_HASHA_D_MEM_A_HASH_RES(x)               (((x)&0xFFFFFFFF)<<0)

/* Bit definitions and macros for MCF_RTIC
_RTIC_HASHA_E */
#define MCF_RTIC_HASHA_E_MEM_A_HASH_RES(x)               (((x)&0xFFFFFFFF)<<0)

/* Bit definitions and macros for MCF_RTIC
_RTIC_HASHA_F */
#define MCF_RTIC_HASHA_F_MEM_A_HASH_RES(x)               (((x)&0xFFFFFFFF)<<0)

/* Bit definitions and macros for MCF_RTIC
_RTIC_HASHA_G */
#define MCF_RTIC_HASHA_G_MEM_A_HASH_RES(x)               (((x)&0xFFFFFFFF)<<0)

/* Bit definitions and macros for MCF_RTIC
_RTIC_HASHA_H */
#define MCF_RTIC_HASHA_H_MEM_A_HASH_RES(x)               (((x)&0xFFFFFFFF)<<0)

/* Bit definitions and macros for MCF_RTIC
_RTIC_HASHB_A */
#define MCF_RTIC_HASHB_A_MEM_B_HASH_RES(x)               (((x)&0xFFFFFFFF)<<0)

/* Bit definitions and macros for MCF_RTIC
_RTIC_HASHB_B */
#define MCF_RTIC_HASHB_B_MEM_B_HASH_RES(x)               (((x)&0xFFFFFFFF)<<0)

/* Bit definitions and macros for MCF_RTIC
_RTIC_HASHB_C */
#define MCF_RTIC_HASHB_C_MEM_B_HASH_RES(x)               (((x)&0xFFFFFFFF)<<0)

/* Bit definitions and macros for MCF_RTIC
_RTIC_HASHB_D */
#define MCF_RTIC_HASHB_D_MEM_B_HASH_RES(x)               (((x)&0xFFFFFFFF)<<0)

/* Bit definitions and macros for MCF_RTIC
_RTIC_HASHB_E */
#define MCF_RTIC_HASHB_E_MEM_B_HASH_RES(x)               (((x)&0xFFFFFFFF)<<0)

/* Bit definitions and macros for MCF_RTIC
_RTIC_HASHB_F */
#define MCF_RTIC_HASHB_F_MEM_B_HASH_RES(x)               (((x)&0xFFFFFFFF)<<0)

/* Bit definitions and macros for MCF_RTIC
_RTIC_HASHB_G */
#define MCF_RTIC_HASHB_G_MEM_B_HASH_RES(x)               (((x)&0xFFFFFFFF)<<0)

/* Bit definitions and macros for MCF_RTIC
_RTIC_HASHB_H */
#define MCF_RTIC_HASHB_H_MEM_B_HASH_RES(x)               (((x)&0xFFFFFFFF)<<0)

/* Bit definitions and macros for MCF_RTIC
_RTIC_HASHC_A */
#define MCF_RTIC_HASHC_A_MEM_C_HASH_RES(x)               (((x)&0xFFFFFFFF)<<0)

/* Bit definitions and macros for MCF_RTIC
_RTIC_HASHC_B */
#define MCF_RTIC_HASHC_B_MEM_C_HASH_RES(x)               (((x)&0xFFFFFFFF)<<0)

/* Bit definitions and macros for MCF_RTIC
_RTIC_HASHC_C */
#define MCF_RTIC_HASHC_C_MEM_C_HASH_RES(x)               (((x)&0xFFFFFFFF)<<0)

/* Bit definitions and macros for MCF_RTIC
_RTIC_HASHC_D */
#define MCF_RTIC_HASHC_D_MEM_C_HASH_RES(x)               (((x)&0xFFFFFFFF)<<0)

/* Bit definitions and macros for MCF_RTIC
_RTIC_HASHC_E */
#define MCF_RTIC_HASHC_E_MEM_C_HASH_RES(x)               (((x)&0xFFFFFFFF)<<0)

/* Bit definitions and macros for MCF_RTIC
_RTIC_HASHC_F */
#define MCF_RTIC_HASHC_F_MEM_C_HASH_RES(x)               (((x)&0xFFFFFFFF)<<0)

/* Bit definitions and macros for MCF_RTIC
_RTIC_HASHC_G */
#define MCF_RTIC_HASHC_G_MEM_C_HASH_RES(x)               (((x)&0xFFFFFFFF)<<0)

/* Bit definitions and macros for MCF_RTIC
_RTIC_HASHC_H */
#define MCF_RTIC_HASHC_H_MEM_C_HASH_RES(x)               (((x)&0xFFFFFFFF)<<0)

/* Bit definitions and macros for MCF_RTIC
_RTIC_HASHD_A */
#define MCF_RTIC_HASHD_A_MEM_D_HASH_RES(x)               (((x)&0xFFFFFFFF)<<0)

/* Bit definitions and macros for MCF_RTIC
_RTIC_HASHD_B */
#define MCF_RTIC_HASHD_B_MEM_C_HASH_RES(x)               (((x)&0xFFFFFFFF)<<0)

/* Bit definitions and macros for MCF_RTIC
_RTIC_HASHD_C */
#define MCF_RTIC_HASHD_C_MEM_C_HASH_RES(x)               (((x)&0xFFFFFFFF)<<0)

/* Bit definitions and macros for MCF_RTIC
_RTIC_HASHD_D */
#define MCF_RTIC_HASHD_D_MEM_C_HASH_RES(x)               (((x)&0xFFFFFFFF)<<0)

/* Bit definitions and macros for MCF_RTIC
_RTIC_HASHD_E */
#define MCF_RTIC_HASHD_E_MEM_C_HASH_RES(x)               (((x)&0xFFFFFFFF)<<0)

/* Bit definitions and macros for MCF_RTIC
_RTIC_HASHD_F */
#define MCF_RTIC_HASHD_F_MEM_C_HASH_RES(x)               (((x)&0xFFFFFFFF)<<0)

/* Bit definitions and macros for MCF_RTIC
_RTIC_HASHD_G */
#define MCF_RTIC_HASHD_G_MEM_C_HASH_RES(x)               (((x)&0xFFFFFFFF)<<0)

/* Bit definitions and macros for MCF_RTIC
_RTIC_HASHD_H */
#define MCF_RTIC_HASHD_H_MEM_C_HASH_RES(x)               (((x)&0xFFFFFFFF)<<0)

/********************************************************************/

#endif /* __LONGJING.HFG_H__ */
