/*
 * File:    mcf5301x_scc.h
 * Purpose: Register and bit definitions
 */

#ifndef __MCF5301X_SCC_H__
#define __MCF5301X_SCC_H__

/*********************************************************************
*
* SCC  (SCC)
*
*********************************************************************/

/* Register read/write macros */
#define MCF_SCC_RED_STRT                          (*(vuint32*)(0xFC0D0000))
#define MCF_SCC_BLACK_STRT                        (*(vuint32*)(0xFC0D0004))
#define MCF_SCC_LENGTH                            (*(vuint32*)(0xFC0D0008))
#define MCF_SCC_CTRL                              (*(vuint32*)(0xFC0D000C))
#define MCF_SCC_SC_STATUS                         (*(vuint32*)(0xFC0D0010))
#define MCF_SCC_ERR_STATUS                        (*(vuint32*)(0xFC0D0014))
#define MCF_SCC_INT_CTRL                          (*(vuint32*)(0xFC0D0018))
#define MCF_SCC_CONGFIG                           (*(vuint32*)(0xFC0D001C))
#define MCF_SCC_INIT_VEC0                         (*(vuint32*)(0xFC0D0020))
#define MCF_SCC_INIT_VEC1                         (*(vuint32*)(0xFC0D0024))
#define MCF_SCC_SMN_STATUS                        (*(vuint32*)(0xFC0D1000))
#define MCF_SCC_CMD                               (*(vuint32*)(0xFC0D1004))
#define MCF_SCC_SEQ_STRT                          (*(vuint32*)(0xFC0D1008))
#define MCF_SCC_SEQ_END                           (*(vuint32*)(0xFC0D100C))
#define MCF_SCC_SEQ_CHK                           (*(vuint32*)(0xFC0D1010))
#define MCF_SCC_BIT_COUNT                         (*(vuint32*)(0xFC0D1014))
#define MCF_SCC_BIT_BANK_INC_SIZE                 (*(vuint32*)(0xFC0D1018))
#define MCF_SCC_BIT_BANK_DEC                      (*(vuint32*)(0xFC0D101C))
#define MCF_SCC_CMP_SIZE                          (*(vuint32*)(0xFC0D1020))
#define MCF_SCC_PLAINTEXT_CHK                     (*(vuint32*)(0xFC0D1024))
#define MCF_SCC_CIPHERTEXT_CHK                    (*(vuint32*)(0xFC0D1028))
#define MCF_SCC_TIMER_IV                          (*(vuint32*)(0xFC0D102C))
#define MCF_SCC_TIMER_CTRL                        (*(vuint32*)(0xFC0D1030))
#define MCF_SCC_DBG_DETECTOR_STATUS               (*(vuint32*)(0xFC0D1034))
#define MCF_SCC_TIMER                             (*(vuint32*)(0xFC0D1038))

/* Bit definitions and macros for MCF_SCC_RED_STRT */
#define MCF_SCC_RED_STRT_RED_STRT(x)              (((x)&0x0000007F)<<0)

/* Bit definitions and macros for MCF_SCC_BLACK_STRT */
#define MCF_SCC_BLACK_STRT_BLACK_STRT(x)          (((x)&0x0000007F)<<0)

/* Bit definitions and macros for MCF_SCC_LENGTH */
#define MCF_SCC_LENGTH_LENGTH(x)                  (((x)&0x0000007F)<<0)

/* Bit definitions and macros for MCF_SCC_CTRL */
#define MCF_SCC_CTRL_CIPHER_MODE                  (0x00000001)
#define MCF_SCC_CTRL_CHAINING_MODE                (0x00000002)
#define MCF_SCC_CTRL_CIPHER_STRT                  (0x00000004)

/* Bit definitions and macros for MCF_SCC_SC_STATUS */
#define MCF_SCC_SC_STATUS_BUSY                    (0x00000001)
#define MCF_SCC_SC_STATUS_ZEROIZING               (0x00000002)
#define MCF_SCC_SC_STATUS_CIPHERING               (0x00000004)
#define MCF_SCC_SC_STATUS_SMN_BLK_ACCESS          (0x00000008)
#define MCF_SCC_SC_STATUS_ZEROIZE_FAIL            (0x00000010)
#define MCF_SCC_SC_STATUS_BAD_KEY                 (0x00000020)
#define MCF_SCC_SC_STATUS_INT_ERR                 (0x00000040)
#define MCF_SCC_SC_STATUS_SECRET_KEY              (0x00000080)
#define MCF_SCC_SC_STATUS_SCM_INT_STATUS          (0x00000100)
#define MCF_SCC_SC_STATUS_ZEROIZING_DONE          (0x00000200)
#define MCF_SCC_SC_STATUS_CIPHERING_DONE          (0x00000400)
#define MCF_SCC_SC_STATUS_BLK_ACCESS_REM          (0x00000800)
#define MCF_SCC_SC_STATUS_LENGTH_ERR              (0x00001000)

/* Bit definitions and macros for MCF_SCC_ERR_STATUS */
#define MCF_SCC_ERR_STATUS_BUSY                   (0x00000001)
#define MCF_SCC_ERR_STATUS_ZEROIZING              (0x00000002)
#define MCF_SCC_ERR_STATUS_CIPHERING              (0x00000004)
#define MCF_SCC_ERR_STATUS_SMN_BLK_ACCESS_STATUS  (0x00000008)
#define MCF_SCC_ERR_STATUS_ZEROIZING_FAILED       (0x00000010)
#define MCF_SCC_ERR_STATUS_BAD_KEY_STATUS         (0x00000020)
#define MCF_SCC_ERR_STATUS_INT_ERR_STATUS         (0x00000040)
#define MCF_SCC_ERR_STATUS_SEC_KEY_STATUS         (0x00000080)
#define MCF_SCC_ERR_STATUS_USR_ACCESS             (0x00000100)
#define MCF_SCC_ERR_STATUS_ILLEGAL_ADDR           (0x00000200)
#define MCF_SCC_ERR_STATUS_BYTE_ACCESS            (0x00000400)
#define MCF_SCC_ERR_STATUS_UNALIGNED_ACCESS       (0x00000800)
#define MCF_SCC_ERR_STATUS_ILLEGAL_MSTR           (0x00001000)
#define MCF_SCC_ERR_STATUS_CACHEABLE_ACCESS       (0x00002000)

/* Bit definitions and macros for MCF_SCC_INT_CTRL */
#define MCF_SCC_INT_CTRL_INT_MASK                 (0x00000001)
#define MCF_SCC_INT_CTRL_CLR_INT                  (0x00000002)
#define MCF_SCC_INT_CTRL_ZEROIZE_MEM              (0x00000004)

/* Bit definitions and macros for MCF_SCC_CONGFIG */
#define MCF_SCC_CONGFIG_BLK_SIZE(x)               (((x)&0x0000007F)<<0)
#define MCF_SCC_CONGFIG_RED_SIZE(x)               (((x)&0x000003FF)<<7)
#define MCF_SCC_CONGFIG_BLACK_SIZE(x)             (((x)&0x000003FF)<<17)
#define MCF_SCC_CONGFIG_VER_ID(x)                 (((x)&0x0000001F)<<27)

/* Bit definitions and macros for MCF_SCC_INIT_VEC0 */
#define MCF_SCC_INIT_VEC0_UPPER32(x)              (((x)&0xFFFFFFFF)<<0)

/* Bit definitions and macros for MCF_SCC_INIT_VEC1 */
#define MCF_SCC_INIT_VEC1_LOWER32(x)              (((x)&0xFFFFFFFF)<<0)

/* Bit definitions and macros for MCF_SCC_SMN_STATUS */
#define MCF_SCC_SMN_STATUS_STATE(x)               (((x)&0x0000001F)<<0)
#define MCF_SCC_SMN_STATUS_INT_BOOT               (0x00000020)
#define MCF_SCC_SMN_STATUS_ZEROIZE_FAIL           (0x00000040)
#define MCF_SCC_SMN_STATUS_DEBUG_ACTIVE           (0x00000080)
#define MCF_SCC_SMN_STATUS_SEC_POL_ERR            (0x00000100)
#define MCF_SCC_SMN_STATUS_ASC_ERR                (0x00000200)
#define MCF_SCC_SMN_STATUS_BIT_BANK_ERR           (0x00000400)
#define MCF_SCC_SMN_STATUS_PC_ERR                 (0x00000800)
#define MCF_SCC_SMN_STATUS_TIMER_ERR              (0x00001000)
#define MCF_SCC_SMN_STATUS_SOFT_ALARM             (0x00002000)
#define MCF_SCC_SMN_STATUS_SMN_IRQ                (0x00004000)
#define MCF_SCC_SMN_STATUS_SCM_ERR                (0x00008000)
#define MCF_SCC_SMN_STATUS_ILLEGAL_ACCESS         (0x00010000)
#define MCF_SCC_SMN_STATUS_BAD_KEY                (0x00020000)
#define MCF_SCC_SMN_STATUS_DEFAULT_KEY            (0x00040000)
#define MCF_SCC_SMN_STATUS_USR_ACCESS             (0x00080000)
#define MCF_SCC_SMN_STATUS_ILLEGAL_ADDR           (0x00100000)
#define MCF_SCC_SMN_STATUS_BYTE_ACCESS            (0x00200000)
#define MCF_SCC_SMN_STATUS_UNALIGNED_ACCESS       (0x00400000)
#define MCF_SCC_SMN_STATUS_SCAN_EXIT              (0x00800000)
#define MCF_SCC_SMN_STATUS_ILLEGAL_MSTR           (0x01000000)
#define MCF_SCC_SMN_STATUS_CACHE_ACCESS           (0x02000000)
#define MCF_SCC_SMN_STATUS_VER_ID(x)              (((x)&0x0000003F)<<26)

/* Bit definitions and macros for MCF_SCC_CMD */
#define MCF_SCC_CMD_SOFT_ALARM                    (0x00000001)
#define MCF_SCC_CMD_ENB_INT                       (0x00000002)
#define MCF_SCC_CMD_CLR_BIT_BNK                   (0x00000004)
#define MCF_SCC_CMD_CLR_INT                       (0x00000008)

/* Bit definitions and macros for MCF_SCC_SEQ_STRT */
#define MCF_SCC_SEQ_STRT_START_VALUE(x)           (((x)&0x0000FFFF)<<0)

/* Bit definitions and macros for MCF_SCC_SEQ_END */
#define MCF_SCC_SEQ_END_END_VALUE(x)              (((x)&0x0000FFFF)<<0)

/* Bit definitions and macros for MCF_SCC_SEQ_CHK */
#define MCF_SCC_SEQ_CHK_CHK_VALUE(x)              (((x)&0x0000FFFF)<<0)

/* Bit definitions and macros for MCF_SCC_BIT_COUNT */
#define MCF_SCC_BIT_COUNT_BIT_CNT(x)              (((x)&0x000007FF)<<0)

/* Bit definitions and macros for MCF_SCC_BIT_BANK_INC_SIZE */
#define MCF_SCC_BIT_BANK_INC_SIZE_INC_SIZE(x)     (((x)&0x000007FF)<<0)

/* Bit definitions and macros for MCF_SCC_BIT_BANK_DEC */
#define MCF_SCC_BIT_BANK_DEC_DEC_AMOUNT(x)        (((x)&0x000007FF)<<0)

/* Bit definitions and macros for MCF_SCC_CMP_SIZE */
#define MCF_SCC_CMP_SIZE_SIZE(x)                  (((x)&0x0000003F)<<0)

/* Bit definitions and macros for MCF_SCC_PLAINTEXT_CHK */
#define MCF_SCC_PLAINTEXT_CHK_PLAIN_TEXT(x)       (((x)&0xFFFFFFFF)<<0)

/* Bit definitions and macros for MCF_SCC_CIPHERTEXT_CHK */
#define MCF_SCC_CIPHERTEXT_CHK_CIPHER_TEXT(x)     (((x)&0xFFFFFFFF)<<0)

/* Bit definitions and macros for MCF_SCC_TIMER_IV */
#define MCF_SCC_TIMER_IV_IV(x)                    (((x)&0xFFFFFFFF)<<0)

/* Bit definitions and macros for MCF_SCC_TIMER_CTRL */
#define MCF_SCC_TIMER_CTRL_STRT                   (0x00000001)
#define MCF_SCC_TIMER_CTRL_LOAD                   (0x00000002)

/* Bit definitions and macros for MCF_SCC_DBG_DETECTOR_STATUS */
#define MCF_SCC_DBG_DETECTOR_STATUS_D1            (0x00000001)
#define MCF_SCC_DBG_DETECTOR_STATUS_D2            (0x00000002)
#define MCF_SCC_DBG_DETECTOR_STATUS_D3            (0x00000004)
#define MCF_SCC_DBG_DETECTOR_STATUS_D4            (0x00000008)
#define MCF_SCC_DBG_DETECTOR_STATUS_D5            (0x00000010)
#define MCF_SCC_DBG_DETECTOR_STATUS_D6            (0x00000020)
#define MCF_SCC_DBG_DETECTOR_STATUS_D7            (0x00000040)
#define MCF_SCC_DBG_DETECTOR_STATUS_D8            (0x00000080)
#define MCF_SCC_DBG_DETECTOR_STATUS_D9            (0x00000100)
#define MCF_SCC_DBG_DETECTOR_STATUS_D10           (0x00000200)
#define MCF_SCC_DBG_DETECTOR_STATUS_D11           (0x00000400)
#define MCF_SCC_DBG_DETECTOR_STATUS_D12           (0x00000800)

/* Bit definitions and macros for MCF_SCC_TIMER */
#define MCF_SCC_TIMER_TIMER(x)                    (((x)&0xFFFFFFFF)<<0)

/********************************************************************/

#endif /* __MCF5301X_SCC_H__ */
