/*
 * File:	mcf532x_sdramc.h
 * Purpose:	Register and bit definitions for the MCF532x
 *
 * Notes:	
 *
 * License:     All software covered by license agreement in -
 *              dbug/docs/Freescale_Software_License.pdf
 *	
 */

#ifndef __MCF532X_SDRAMC_H__
#define __MCF532X_SDRAMC_H__

/*********************************************************************
*
* SDRAM Controller (SDRAMC)
*
*********************************************************************/

/* Register read/write macros */
#define MCF_SDRAMC_SDMR                (*(vuint32   *)(0xFC0B8000))
#define MCF_SDRAMC_SDCR                (*(vuint32   *)(0xFC0B8004))
#define MCF_SDRAMC_SDCFG1              (*(vuint32   *)(0xFC0B8008))
#define MCF_SDRAMC_SDCFG2              (*(vuint32   *)(0xFC0B800C))
#define MCF_SDRAMC_SDDS                (*(vuint32   *)(0xFC0B8100))
#define MCF_SDRAMC_SDCS0               (*(vuint32   *)(0xFC0B8110))
#define MCF_SDRAMC_SDCS1               (*(vuint32   *)(0xFC0B8114))
#define MCF_SDRAMC_SDCS2               (*(vuint32   *)(0xFC0B8118))
#define MCF_SDRAMC_SDCS3               (*(vuint32   *)(0xFC0B811C))
#define MCF_SDRAMC_SDCS(x)             (*(vuint32   *)(0xFC0B8110+((x)*0x004)))

/* Bit definitions and macros for MCF_SDRAMC_SDMR */
#define MCF_SDRAMC_SDMR_CMD            (0x00010000)
#define MCF_SDRAMC_SDMR_AD(x)          (((x)&0x00000FFF)<<18)
#define MCF_SDRAMC_SDMR_BNKAD(x)       (((x)&0x00000003)<<30)
#define MCF_SDRAMC_SDMR_BNKAD_LMR      (0x00000000)
#define MCF_SDRAMC_SDMR_BNKAD_LEMR     (0x40000000)

/* Bit definitions and macros for MCF_SDRAMC_SDCR */
#define MCF_SDRAMC_SDCR_IPALL          (0x00000002)
#define MCF_SDRAMC_SDCR_IREF           (0x00000004)
#define MCF_SDRAMC_SDCR_DQS_OE(x)      (((x)&0x0000000F)<<8)
#define MCF_SDRAMC_SDCR_PS(x)          (((x)&0x00000003)<<12)
#define MCF_SDRAMC_SDCR_RCNT(x)        (((x)&0x0000003F)<<16)
#define MCF_SDRAMC_SDCR_MUX(x)         (((x)&0x00000003)<<24)
#define MCF_SDRAMC_SDCR_REF            (0x10000000)
#define MCF_SDRAMC_SDCR_DDR            (0x20000000)
#define MCF_SDRAMC_SDCR_CKE            (0x40000000)
#define MCF_SDRAMC_SDCR_MODE_EN        (0x80000000)
#define MCF_SDRAMC_SDCR_PS_16          (0x00002000)
#define MCF_SDRAMC_SDCR_PS_32          (0x00000000)

/* Bit definitions and macros for MCF_SDRAMC_SDCFG1 */
#define MCF_SDRAMC_SDCFG1_WTLAT(x)     (((x)&0x00000007)<<4)
#define MCF_SDRAMC_SDCFG1_REF2ACT(x)   (((x)&0x0000000F)<<8)
#define MCF_SDRAMC_SDCFG1_PRE2ACT(x)   (((x)&0x00000007)<<12)
#define MCF_SDRAMC_SDCFG1_ACT2RW(x)    (((x)&0x00000007)<<16)
#define MCF_SDRAMC_SDCFG1_RDLAT(x)     (((x)&0x0000000F)<<20)
#define MCF_SDRAMC_SDCFG1_SWT2RD(x)    (((x)&0x00000007)<<24)
#define MCF_SDRAMC_SDCFG1_SRD2RW(x)    (((x)&0x0000000F)<<28)

/* Bit definitions and macros for MCF_SDRAMC_SDCFG2 */
#define MCF_SDRAMC_SDCFG2_BL(x)        (((x)&0x0000000F)<<16)
#define MCF_SDRAMC_SDCFG2_BRD2WT(x)    (((x)&0x0000000F)<<20)
#define MCF_SDRAMC_SDCFG2_BWT2RW(x)    (((x)&0x0000000F)<<24)
#define MCF_SDRAMC_SDCFG2_BRD2PRE(x)   (((x)&0x0000000F)<<28)

/* Bit definitions and macros for MCF_SDRAMC_SDDS */
#define MCF_SDRAMC_SDDS_SB_D(x)        (((x)&0x00000003)<<0)
#define MCF_SDRAMC_SDDS_SB_S(x)        (((x)&0x00000003)<<2)
#define MCF_SDRAMC_SDDS_SB_A(x)        (((x)&0x00000003)<<4)
#define MCF_SDRAMC_SDDS_SB_C(x)        (((x)&0x00000003)<<6)
#define MCF_SDRAMC_SDDS_SB_E(x)        (((x)&0x00000003)<<8)

/* Bit definitions and macros for MCF_SDRAMC_SDCS */
#define MCF_SDRAMC_SDCS_CSSZ(x)        (((x)&0x0000001F)<<0)
#define MCF_SDRAMC_SDCS_BASE(x)        (((x)&0x00000FFF)<<20)
#define MCF_SDRAMC_SDCS_BA(x)          ((x)&0xFFF00000)
#define MCF_SDRAMC_SDCS_CSSZ_DIABLE    (0x00000000)
#define MCF_SDRAMC_SDCS_CSSZ_1MBYTE    (0x00000013)
#define MCF_SDRAMC_SDCS_CSSZ_2MBYTE    (0x00000014)
#define MCF_SDRAMC_SDCS_CSSZ_4MBYTE    (0x00000015)
#define MCF_SDRAMC_SDCS_CSSZ_8MBYTE    (0x00000016)
#define MCF_SDRAMC_SDCS_CSSZ_16MBYTE   (0x00000017)
#define MCF_SDRAMC_SDCS_CSSZ_32MBYTE   (0x00000018)
#define MCF_SDRAMC_SDCS_CSSZ_64MBYTE   (0x00000019)
#define MCF_SDRAMC_SDCS_CSSZ_128MBYTE  (0x0000001A)
#define MCF_SDRAMC_SDCS_CSSZ_256MBYTE  (0x0000001B)
#define MCF_SDRAMC_SDCS_CSSZ_512MBYTE  (0x0000001C)
#define MCF_SDRAMC_SDCS_CSSZ_1GBYTE    (0x0000001D)
#define MCF_SDRAMC_SDCS_CSSZ_2GBYTE    (0x0000001E)
#define MCF_SDRAMC_SDCS_CSSZ_4GBYTE    (0x0000001F)

/********************************************************************/

#endif /* __MCF532X_SDRAMC_H__ */
