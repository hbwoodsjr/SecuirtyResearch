/*
 * File:    mcf5301x_mpu.h
 * Purpose: Register and bit definitions
 */

#ifndef __MCF5301X_MPU_H__
#define __MCF5301X_MPU_H__

/*********************************************************************
*
* MPU  (MPU)
*
*********************************************************************/

/* Register read/write macros */
#define MCF_MPU_CESR           (*(vuint32*)(0xFC014000))
#define MCF_MPU_EAR0           (*(vuint32*)(0xFC014010))
#define MCF_MPU_EDR0           (*(vuint32*)(0xFC014014))
#define MCF_MPU_EAR1           (*(vuint32*)(0xFC014018))
#define MCF_MPU_EDR1           (*(vuint32*)(0xFC01401C))
#define MCF_MPU_EAR2           (*(vuint32*)(0xFC014020))
#define MCF_MPU_EDR2           (*(vuint32*)(0xFC014024))
#define MCF_MPU_EAR3           (*(vuint32*)(0xFC014028))
#define MCF_MPU_EDR3           (*(vuint32*)(0xFC01402C))
#define MCF_MPU_XEDR0          (*(vuint64*)(0xFC014030))
#define MCF_MPU_XEDR1          (*(vuint64*)(0xFC014038))
#define MCF_MPU_XEDR2          (*(vuint64*)(0xFC014040))
#define MCF_MPU_XEDR3          (*(vuint64*)(0xFC014048))
#define MCF_MPU_RGD0A          (*(vuint32*)(0xFC014400))
#define MCF_MPU_RGD0B          (*(vuint32*)(0xFC014404))
#define MCF_MPU_RGD0C          (*(vuint32*)(0xFC014408))
#define MCF_MPU_RGD0D          (*(vuint32*)(0xFC01440C))
#define MCF_MPU_RGD1A          (*(vuint32*)(0xFC014410))
#define MCF_MPU_RGD1B          (*(vuint32*)(0xFC014414))
#define MCF_MPU_RGD1C          (*(vuint32*)(0xFC014418))
#define MCF_MPU_RGD1D          (*(vuint32*)(0xFC01441C))
#define MCF_MPU_RGD2A          (*(vuint32*)(0xFC014420))
#define MCF_MPU_RGD2B          (*(vuint32*)(0xFC014424))
#define MCF_MPU_RGD2C          (*(vuint32*)(0xFC014428))
#define MCF_MPU_RGD2D          (*(vuint32*)(0xFC01442C))
#define MCF_MPU_RGD3A          (*(vuint32*)(0xFC014430))
#define MCF_MPU_RGD3B          (*(vuint32*)(0xFC014434))
#define MCF_MPU_RGD3C          (*(vuint32*)(0xFC014438))
#define MCF_MPU_RGD3D          (*(vuint32*)(0xFC01443C))
#define MCF_MPU_RGD4A          (*(vuint32*)(0xFC014440))
#define MCF_MPU_RGD4B          (*(vuint32*)(0xFC014444))
#define MCF_MPU_RGD4C          (*(vuint32*)(0xFC014448))
#define MCF_MPU_RGD4D          (*(vuint32*)(0xFC01444C))
#define MCF_MPU_RGD5A          (*(vuint32*)(0xFC014450))
#define MCF_MPU_RGD5B          (*(vuint32*)(0xFC014454))
#define MCF_MPU_RGD5C          (*(vuint32*)(0xFC014458))
#define MCF_MPU_RGD5D          (*(vuint32*)(0xFC01445C))
#define MCF_MPU_RGD6A          (*(vuint32*)(0xFC014460))
#define MCF_MPU_RGD6B          (*(vuint32*)(0xFC014464))
#define MCF_MPU_RGD6C          (*(vuint32*)(0xFC014468))
#define MCF_MPU_RGD6D          (*(vuint32*)(0xFC01446C))
#define MCF_MPU_RGD7A          (*(vuint32*)(0xFC014470))
#define MCF_MPU_RGD7B          (*(vuint32*)(0xFC014474))
#define MCF_MPU_RGD7C          (*(vuint32*)(0xFC014478))
#define MCF_MPU_RGD7D          (*(vuint32*)(0xFC01447C))
#define MCF_MPU_RGD8A          (*(vuint32*)(0xFC014480))
#define MCF_MPU_RGD8B          (*(vuint32*)(0xFC014484))
#define MCF_MPU_RGD8C          (*(vuint32*)(0xFC014488))
#define MCF_MPU_RGD8D          (*(vuint32*)(0xFC01448C))
#define MCF_MPU_RGD9A          (*(vuint32*)(0xFC014490))
#define MCF_MPU_RGD9B          (*(vuint32*)(0xFC014494))
#define MCF_MPU_RGD9C          (*(vuint32*)(0xFC014498))
#define MCF_MPU_RGD9D          (*(vuint32*)(0xFC0144AC))
#define MCF_MPU_RGDAA          (*(vuint32*)(0xFC0144A0))
#define MCF_MPU_RGDAB          (*(vuint32*)(0xFC0144A4))
#define MCF_MPU_RGDAC          (*(vuint32*)(0xFC0144A8))
#define MCF_MPU_RGDAD          (*(vuint32*)(0xFC0144AC))
#define MCF_MPU_RGDBA          (*(vuint32*)(0xFC0144B0))
#define MCF_MPU_RGDBB          (*(vuint32*)(0xFC0144B4))
#define MCF_MPU_RGDBC          (*(vuint32*)(0xFC0144B8))
#define MCF_MPU_RGDBD          (*(vuint32*)(0xFC0144BC))
#define MCF_MPU_RGDCA          (*(vuint32*)(0xFC0144C0))
#define MCF_MPU_RGDCB          (*(vuint32*)(0xFC0144C4))
#define MCF_MPU_RGDCC          (*(vuint32*)(0xFC0144C8))
#define MCF_MPU_RGDCD          (*(vuint32*)(0xFC0144CC))
#define MCF_MPU_RGDDA          (*(vuint32*)(0xFC0144D0))
#define MCF_MPU_RGDDB          (*(vuint32*)(0xFC0144D4))
#define MCF_MPU_RGDDC          (*(vuint32*)(0xFC0144D8))
#define MCF_MPU_RGDDD          (*(vuint32*)(0xFC0144DC))
#define MCF_MPU_RGDEA          (*(vuint32*)(0xFC0144E0))
#define MCF_MPU_RGDEB          (*(vuint32*)(0xFC0144E4))
#define MCF_MPU_RGDEC          (*(vuint32*)(0xFC0144E8))
#define MCF_MPU_RGDED          (*(vuint32*)(0xFC0144EC))
#define MCF_MPU_RGDFA          (*(vuint32*)(0xFC0144F0))
#define MCF_MPU_RGDFB          (*(vuint32*)(0xFC0144F4))
#define MCF_MPU_RGDFC          (*(vuint32*)(0xFC0144F8))
#define MCF_MPU_RGDFD          (*(vuint32*)(0xFC0144FC))
#define MCF_MPU_RGDAAC0        (*(vuint32*)(0xFC014800))
#define MCF_MPU_RGDAAC1        (*(vuint32*)(0xFC014804))
#define MCF_MPU_RGDAAC2        (*(vuint32*)(0xFC014808))
#define MCF_MPU_RGDAAC3        (*(vuint32*)(0xFC01480C))
#define MCF_MPU_RGDAAC4        (*(vuint32*)(0xFC014810))
#define MCF_MPU_RGDAAC5        (*(vuint32*)(0xFC014814))
#define MCF_MPU_RGDAAC6        (*(vuint32*)(0xFC014818))
#define MCF_MPU_RGDAAC7        (*(vuint32*)(0xFC01481C))
#define MCF_MPU_RGDAAC8        (*(vuint32*)(0xFC014820))
#define MCF_MPU_RGDAAC9        (*(vuint32*)(0xFC014824))
#define MCF_MPU_RGDAAC10       (*(vuint32*)(0xFC014828))
#define MCF_MPU_RGDAAC11       (*(vuint32*)(0xFC01482C))
#define MCF_MPU_RGDAAC12       (*(vuint32*)(0xFC014830))
#define MCF_MPU_RGDAAC13       (*(vuint32*)(0xFC014834))
#define MCF_MPU_RGDAAC14       (*(vuint32*)(0xFC014838))
#define MCF_MPU_RGDAAC15       (*(vuint32*)(0xFC01483C))

/* Bit definitions and macros for MCF_MPU_EAR0 */
#define MCF_MPU_EAR0_EADDR(x)  (((x)&0xFFFFFFFF)<<0)

/* Bit definitions and macros for MCF_MPU_EAR1 */
#define MCF_MPU_EAR1_EADDR(x)  (((x)&0xFFFFFFFF)<<0)

/* Bit definitions and macros for MCF_MPU_EAR2 */
#define MCF_MPU_EAR2_EADDR(x)  (((x)&0xFFFFFFFF)<<0)

/* Bit definitions and macros for MCF_MPU_EAR3 */
#define MCF_MPU_EAR3_EADDR(x)  (((x)&0xFFFFFFFF)<<0)

/********************************************************************/

#endif /* __MCF5301X_MPU_H__ */
