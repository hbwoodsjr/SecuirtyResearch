/*
 * File:    mcf5301x_rngb.h
 * Purpose: Register and bit definitions
 */

#ifndef __MCF5301X_RNGB_H__
#define __MCF5301X_RNGB_H__

/*********************************************************************
*
* Random Number Generator B (RNGB)
*
*********************************************************************/

/* Register read/write macros */
#define MCF_RNGB_VER_ID                      (*(vuint32*)(0xFC0C4000))                             /* Version ID Register */
#define MCF_RNGB_COMMAND                     (*(vuint32*)(0xFC0C4004))                             /* Command Register */
#define MCF_RNGB_CONTROL                     (*(vuint32*)(0xFC0C4008))                             /* Control Register */
#define MCF_RNGB_STATUS                      (*(vuint32*)(0xFC0C400C))                             /* Status Register */
#define MCF_RNGB_ERR_STATUS                  (*(vuint32*)(0xFC0C4010))                             /* Error Status Register */
#define MCF_RNGB_FIFO                        (*(vuint32*)(0xFC0C4014))                             /* FIFO Register */
#define MCF_RNGB_ENTROPY                     (*(vuint32*)(0xFC0C4018))                             /* Entropy Register */
#define MCF_RNGB_VERIF_CONTROL               (*(vuint32*)(0xFC0C4020))                             /* Verification Control register */
#define MCF_RNGB_XKEY_DATA                   (*(vuint32*)(0xFC0C4024))                             /* XKEY Data Register */
#define MCF_RNGB_OSC_CNT_CTL                 (*(vuint32*)(0xFC0C4028))                             /* Oscillator Counter Control Register */
#define MCF_RNGB_OSC_CNT                     (*(vuint32*)(0xFC0C402C))                             /* Oscillator Control Register */
#define MCF_RNGB_OSC_CNT_STAT                (*(vuint32*)(0xFC0C4030))                             /* Oscillator Counter Status Register */

/* Bit definitions and macros for MCF_RNGB_VER_ID */
#define MCF_RNGB_VER_ID_VER_MINOR(x)         (((x)&0x000000FF)<<0)                     /*  */
#define MCF_RNGB_VER_ID_VER_MAJOR(x)         (((x)&0x000000FF)<<8)                     /*  */
#define MCF_RNGB_VER_ID_RNG_TYP(x)           (((x)&0x0000000F)<<28)                    /*  */

/* Bit definitions and macros for MCF_RNGB_COMMAND */
#define MCF_RNGB_COMMAND_SELF_TEST           (0x00000001)
#define MCF_RNGB_COMMAND_SEED                (0x00000002)                              /* */
#define MCF_RNGB_COMMAND_CLR_INT             (0x00000010)                              /* */
#define MCF_RNGB_COMMAND_CLR_ERR             (0x00000020)                              /* */
#define MCF_RNGB_COMMAND_SW_RST              (0x00000040)                              /* */

/* Bit definitions and macros for MCF_RNGB_CONTROL */
#define MCF_RNGB_CONTROL_FIFO_UFLOW_RESP(x)  (((x)&0x00000007)<<0)                     /*  */
#define MCF_RNGB_CONTROL_AUTO_SEED           (0x00000010)                              /*  */
#define MCF_RNGB_CONTROL_MASK_DONE           (0x00000020)                              /*  */
#define MCF_RNGB_CONTROL_MASK_ERR            (0x00000040)                              /*  */
#define MCF_RNGB_CONTROL_VERIF_MODE          (0x00000100)                              /*  */
#define MCF_RNGB_CONTROL_CTL_ACC             (0x00000200)                              /*  */

/* Bit definitions and macros for MCF_RNGB_STATUS */
#define MCF_RNGB_STATUS_SEC_STATE            (0x00000001)                              /*  */
#define MCF_RNGB_STATUS_BUSY                 (0x00000002)                              /*  */
#define MCF_RNGB_STATUS_SLEEP                (0x00000004)                              /*  */
#define MCF_RNGB_STATUS_RESEED               (0x00000008)                              /*  */
#define MCF_RNGB_STATUS_ST_DONE              (0x00000010)                              /*  */
#define MCF_RNGB_STATUS_SEED_DONE            (0x00000020)                              /*  */
#define MCF_RNGB_STATUS_NEW_SEED_DONE        (0x00000040)                              /*  */
#define MCF_RNGB_STATUS_FIFO_LVL(x)          (((x)&0x00000007)<<8)                     /*  */
#define MCF_RNGB_STATUS_FIFO_SIZE(x)         (((x)&0x0000000F)<<12)                    /*  */
#define MCF_RNGB_STATUS_ERROR                (0x00010000)                              /*  */
#define MCF_RNGB_STATUS_ST_PF(x)             (((x)&0x00000003)<<22)                    /*  */
#define MCF_RNGB_STATUS_STAT_TEST_PF(x)      (((x)&0x000000FF)<<24)                    /*  */

/* Bit definitions and macros for MCF_RNGB_ERR_STATUS */
#define MCF_RNGB_ERR_STATUS_LFSR_ERR         (0x00000001)                              /*  */
#define MCF_RNGB_ERR_STATUS_OSC_ERR          (0x00000002)                              /*  */
#define MCF_RNGB_ERR_STATUS_ST_ERR           (0x00000004)                              /*  */
#define MCF_RNGB_ERR_STATUS_STAT_ERR         (0x00000008)                              /*  */
#define MCF_RNGB_ERR_STATUS_FIFO_ERR         (0x00000010)                              /*  */

/* Bit definitions and macros for MCF_RNGB_VERIF_CONTROL */
#define MCF_RNGB_VERIF_CONTROL_SH_CLK_OFF    (0x00000001)                              /* Shift Clocks Off */
#define MCF_RNGB_VERIF_CONTROL_FRC_SYS_CLK   (0x00000002)                              /* Force System Clock */
#define MCF_RNGB_VERIF_CONTROL_OSC_TEST      (0x00000004)                              /* Oscillator Frequency test */
#define MCF_RNGB_VERIF_CONTROL_FAKE_SEED     (0x00000008)                              /* For quicker simulation results */
#define MCF_RNGB_VERIF_CONTROL_RST_SHREG     (0x00000100)                              /* Reset Shift Registers */
#define MCF_RNGB_VERIF_CONTROL_RST_XKEY      (0x00000200)                              /* Reset XKEY register */

/* Bit definitions and macros for MCF_RNGB_OSC_CNT_CTL */
#define MCF_RNGB_OSC_CNT_CTL_CYCLES(x)       (((x)&0x0003FFFF)<<0)

/* Bit definitions and macros for MCF_RNGB_OSC_CNT */
#define MCF_RNGB_OSC_CNT_CLK_PULSES(x)       (((x)&0x000FFFFF)<<0)

/* Bit definitions and macros for MCF_RNGB_OSC_CNT_STAT */
#define MCF_RNGB_OSC_CNT_STAT_OSC_STAT       (0x00000001)

/********************************************************************/

#endif /* __MCF5301X_RNGB_H__ */
