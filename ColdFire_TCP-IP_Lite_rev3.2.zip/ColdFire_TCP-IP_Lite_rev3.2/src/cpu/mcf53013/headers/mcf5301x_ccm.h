/*
 * File:    mcf5301x_ccm.h
 * Purpose: Register and bit definitions
 */

#ifndef __MCF5301X_CCM_H__
#define __MCF5301X_CCM_H__

/*********************************************************************
*
* Chip Configuration Module (CCM)
*
*********************************************************************/

/* Register read/write macros */
#define MCF_CCM_RCR                    (*(vuint8 *)(0xFC0A0000))                             /* Reset Control Register */
#define MCF_CCM_RSR                    (*(vuint8 *)(0xFC0A0001))                             /* Reset Status Register */
#define MCF_CCM_RTR                    (*(vuint8 *)(0xFC0A0002))                             /* Reset Test register */
#define MCF_CCM_RSV1                   (*(vuint8 *)(0xFC0A0003))                             /* Reserved Register */
#define MCF_CCM_CCR                    (*(vuint16*)(0xFC0A0004))                             /* Chip Configuration Register */
#define MCF_CCM_RSV2                   (*(vuint8 *)(0xFC0A0006))                             /* Reserved Register */
#define MCF_CCM_LPCR                   (*(vuint8 *)(0xFC0A0007))                             /* Low Power Control Register */
#define MCF_CCM_RCON                   (*(vuint16*)(0xFC0A0008))                             /* Reset Configuration Register */
#define MCF_CCM_CIR                    (*(vuint16*)(0xFC0A000A))                             /* Chip Identification Register */
#define MCF_CCM_CTR                    (*(vuint16*)(0xFC0A000C))                             /* Chip Test Register */
#define MCF_CCM_RSV3                   (*(vuint16*)(0xFC0A000E))                             /* Reserved Register */
#define MCF_CCM_MISCCR                 (*(vuint16*)(0xFC0A0010))                             /* Miscellaneous Control Register */
#define MCF_CCM_CDR                    (*(vuint16*)(0xFC0A0012))                             /* Clock Divider Register */
#define MCF_CCM_UOCSR                  (*(vuint16*)(0xFC0A0014))                             /* USB OTG Control Status Register */
#define MCF_CCM_UHCSR                  (*(vuint16*)(0xFC0A0016))                             /* USB Host Control Status register */
#define MCF_CCM_CODCR                  (*(vuint16*)(0xFC0A001A))                             /* CODEC Control Register  */
#define MCF_CCM_MISCCR2                (*(vuint16*)(0xFC0A001C))                             /* Misc Control Register 2 */

/* Bit definitions and macros for MCF_CCM_RCR */
#define MCF_CCM_RCR_FRCRSTOUT          (0x40)                                    /* Assert RSTOUT pin */
#define MCF_CCM_RCR_SOFTRST            (0x80)                                    /* Request Soft Reset */

/* Bit definitions and macros for MCF_CCM_RSR */
#define MCF_CCM_RSR_LOL                (0x01)                                    /* Loss Of Lock Reset */
#define MCF_CCM_RSR_WDRCORE            (0x02)                                    /* Watch Dog Timer Core Reset*/
#define MCF_CCM_RSR_EXT                (0x04)                                    /* External Reset */
#define MCF_CCM_RSR_POR                (0x08)                                    /* Power On Reset */
#define MCF_CCM_RSR_LOC                (0x10)                                    /* Loss Of Clock Reset */
#define MCF_CCM_RSR_SOFT               (0x20)                                    /* Software Reset */

/* Bit definitions and macros for MCF_CCM_RTR */
#define MCF_CCM_RTR_FRCPOR             (0x80)                                    /* Force POR */

/* Bit definitions and macros for MCF_CCM_CCR */
#define MCF_CCM_CCR_MODE               (0x0001)                                  /* Master Mode or Functional Test Mode */
#define MCF_CCM_CCR_SDRMODE            (0x0002)                                  /* SDR or DDR */
#define MCF_CCM_CCR_OSCMODE            (0x0004)                                  /* Oscillator Bypass or crystal Oscillator Mode */
#define MCF_CCM_CCR_LOAD               (0x0008)                                  /* PAD driver strength */
#define MCF_CCM_CCR_BOOTPS             (0x0010)                                  /* Boot Port Size */
#define MCF_CCM_CCR_CSC                (0x0020)                                  /* Chip Select Configuration */
#define MCF_CCM_CCR_BOOTMOD(x)         (((x)&0x0003)<<6)                         /* Boot Mode Configuration */
#define MCF_CCM_CCR_FPLLEN             (0x0100)                                  /* Functional Mode PLL Enable */

/* Bit definitions and macros for MCF_CCM_LPCR */
#define MCF_CCM_LPCR_STPMD(x)          (((x)&0x03)<<3)                           /* STOP Mode Settings */
#define MCF_CCM_LPCR_FWKUP             (0x20)                                    /* Fast Wake Up */

/* Bit definitions and macros for MCF_CCM_RCON */
#define MCF_CCM_RCON_RMODE             (0x0001)                                  /* Master Mode or Functional Test Mode */
#define MCF_CCM_RCON_RSDRMODE          (0x0002)                                  /* SDR or DDR */
#define MCF_CCM_RCON_ROSCMODE          (0x0004)                                  /* Oscillator Bypass or crystal Oscillator Mode */
#define MCF_CCM_RCON_RLOAD             (0x0008)                                  /* PAD driver strength */
#define MCF_CCM_RCON_RBOOTPS           (0x0010)                                  /* Boot Port Size */
#define MCF_CCM_RCON_RCSC              (0x0020)                                  /* Chip Select Configuration */
#define MCF_CCM_RCON_FPLLEN            (0x0040)                                  /* Functional Mode PLL Enable */

/* Bit definitions and macros for MCF_CCM_CIR */
#define MCF_CCM_CIR_PRN(x)             (((x)&0x003F)<<0)                         /* part Revision number */
#define MCF_CCM_CIR_PIN(x)             (((x)&0x03FF)<<6)                         /* Part Identification Number */

/* Bit definitions and macros for MCF_CCM_CTR */
#define MCF_CCM_CTR_FRCSTOP            (0x0001)                                  /* Force STOP */
#define MCF_CCM_CTR_FRCDBG             (0x0004)                                  /* Force Debug */
#define MCF_CCM_CTR_PLVID              (0x0020)                                  /* PAD Low Voltage Inhibt Disable */
#define MCF_CCM_CTR_CLVD               (0x0040)                                  /* Core Low Voltage Inhibit Disable */
#define MCF_CCM_CTR_ETM                (0x0100)                                  /* Enter Test MOde */

/* Bit definitions and macros for MCF_CCM_MISCCR */
#define MCF_CCM_MISCCR_USBSRC          (0x0001)                                  /* USB Clock Source */
#define MCF_CCM_MISCCR_USBPUE          (0x0002)                                  /* USB Transceiver Pull Up Enable */
#define MCF_CCM_MISCCR_USBOOC          (0x0004)                                  /* USB OTG Overcurrent Sense Polarity */
#define MCF_CCM_MISCCR_USBHOC          (0x0008)                                  /* USB Host Overcurrent Sense Polarity */
#define MCF_CCM_MISCCR_SSISRC          (0x0010)                                  /* SSI Clock Source */
#define MCF_CCM_MISCCR_TIMDMA          (0x0020)                                  /* Timer DMA Mux selection */
#define MCF_CCM_MISCCR_BMT(x)          (((x)&0x0007)<<8)                         /* Bus Monitor Timing Field */
#define MCF_CCM_MISCCR_BME             (0x0800)                                  /* Extrnal Bus Monitor Enable */
#define MCF_CCM_MISCCR_LIMP            (0x1000)                                  /* Limp Mode Enable */
#define MCF_CCM_MISCCR_PLL_LOCK        (0x2000)                                  /* PLL Lock Status */
#define MCF_CCM_MISCCR_CDCSRC          (0x4000)                                  /* CODEC Clock Source */
#define MCF_CCM_MISCCR_FECM            (0x8000)                                  /* FEC Mode Of Operation */

/* Bit definitions and macros for MCF_CCM_CDR */
#define MCF_CCM_CDR_SSIDIV(x)          (((x)&0x00FF)<<0)                         /* SSI Baud Clock Divider */
#define MCF_CCM_CDR_LPDIV(x)           (((x)&0x000F)<<8)                         /* Low Power Clock Divider */

/* Bit definitions and macros for MCF_CCM_UOCSR */
#define MCF_CCM_UOCSR_XCVRPDE          (0x0001)                                  /* On-Chip Transceiver Pull Down Enable */
#define MCF_CCM_UOCSR_UOMIE            (0x0002)                                  /* OTG Misc Interrupt Enable */
#define MCF_CCM_UOCSR_WAKEUP           (0x0004)                                  /* OTG WakeUp Event */
#define MCF_CCM_UOCSR_PWRFLT           (0x0008)                                  /* VBUS Power Fault */
#define MCF_CCM_UOCSR_SESSEND          (0x0010)                                  /* Session End */
#define MCF_CCM_UOCSR_VBUSVLD          (0x0020)                                  /* VBUS Valid */
#define MCF_CCM_UOCSR_BVLD             (0x0040)                                  /* B-peripheral is valid */
#define MCF_CCM_UOCSR_AVLD             (0x0080)                                  /* A-peripheral is valid */
#define MCF_CCM_UOCSR_DPPU             (0x0100)                                  /* D+ Pull Up Control */
#define MCF_CCM_UOCSR_DCRVBUS          (0x0200)                                  /* Discharge VBUS */
#define MCF_CCM_UOCSR_CRGVBUS          (0x0400)                                  /* Charge VBUS */
#define MCF_CCM_UOCSR_DRVVBUS          (0x0800)                                  /* Drive VBUS */
#define MCF_CCM_UOCSR_DMPD             (0x1000)                                  /* D- Pull Down */
#define MCF_CCM_UOCSR_DPPD             (0x2000)                                  /* D+ Pull Down */

/* Bit definitions and macros for MCF_CCM_UHCSR */
#define MCF_CCM_UHCSR_XCVRPDE          (0x0001)                                  /* Transceiver Pull Down Enable */
#define MCF_CCM_UHCSR_UHMIE            (0x0002)                                  /* Host Misc Interrupt Enable */
#define MCF_CCM_UHCSR_WAKEUP           (0x0004)                                  /* Host WakeUp Event */
#define MCF_CCM_UHCSR_PWRFLT           (0x0008)                                  /* VBUS Power Fault */
#define MCF_CCM_UHCSR_DRVVBUS          (0x0010)                                  /* Drive VBUS */
#define MCF_CCM_UHCSR_PORT_IND_CTL(x)  (((x)&0x0003)<<14)                        /* Host Controller Port Indicator Signals */

/* Bit definitions and macros for MCF_CCM_CODCR */
#define MCF_CCM_CODCR_REG_EN           (0x0080)                                  /* Regulator Enable */
#define MCF_CCM_CODCR_BGR_EN           (0x8000)                                  /* Bandgap Enable */

/* Bit definitions and macros for MCF_CCM_MISCCR2 */
#define MCF_CCM_MISCCR2_DLY_PGM_ST     (0x0001)                                  /* FuseBox Delayed Program Start */
#define MCF_CCM_MISCCR2_PLL_MODE(x)    (((x)&0x0007)<<8)                         /* Control PLL mode duriong Functional Test Mode */
#define MCF_CCM_MISCCR2_RBOOT_DN       (0x8000)                                  /* ROM Boot Done */

/********************************************************************/

#endif /* __MCF5301X_CCM_H__ */
