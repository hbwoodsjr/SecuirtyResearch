/*
 * File:    mcf5301x_gpio.h
 * Purpose: Register and bit definitions
 */

#ifndef __MCF5301X_GPIO_H__
#define __MCF5301X_GPIO_H__

/*********************************************************************
*
* General Purpose I/O (GPIO)
*
*********************************************************************/

/* Register read/write macros */
#define MCF_GPIO_PORT_BUSCTL                     (*(vuint8 *)(0xFC0A4000))
#define MCF_GPIO_PORT_BS                         (*(vuint8 *)(0xFC0A4001))
#define MCF_GPIO_PORT_CS                         (*(vuint8 *)(0xFC0A4002))
#define MCF_GPIO_PORT_DSPI                       (*(vuint8 *)(0xFC0A4003))
#define MCF_GPIO_PORT_FEC0                       (*(vuint8 *)(0xFC0A4005))
#define MCF_GPIO_PORT_FECI2C                     (*(vuint8 *)(0xFC0A4006))
#define MCF_GPIO_PORT_SIMP1                      (*(vuint8 *)(0xFC0A4009))
#define MCF_GPIO_PORT_SIMP0                      (*(vuint8 *)(0xFC0A400A))
#define MCF_GPIO_PORT_TIMER                      (*(vuint8 *)(0xFC0A400B))
#define MCF_GPIO_PORT_UART                       (*(vuint8 *)(0xFC0A400C))
#define MCF_GPIO_PORT_DEBUG                      (*(vuint8 *)(0xFC0A400D))
#define MCF_GPIO_PORT_SDHC                       (*(vuint8 *)(0xFC0A400F))
#define MCF_GPIO_PORT_SSI                        (*(vuint8 *)(0xFC0A4010))
#define MCF_GPIO_DDR_BUSCTL                      (*(vuint8 *)(0xFC0A4014))
#define MCF_GPIO_DDR_BS                          (*(vuint8 *)(0xFC0A4015))
#define MCF_GPIO_DDR_CS                          (*(vuint8 *)(0xFC0A4016))
#define MCF_GPIO_DDR_DSPI                        (*(vuint8 *)(0xFC0A4017))
#define MCF_GPIO_DDR_FEC0                        (*(vuint8 *)(0xFC0A4019))
#define MCF_GPIO_DDR_FECI2C                      (*(vuint8 *)(0xFC0A401A))
#define MCF_GPIO_DDR_SIMP1                       (*(vuint8 *)(0xFC0A401D))
#define MCF_GPIO_DDR_SIMP0                       (*(vuint8 *)(0xFC0A401E))
#define MCF_GPIO_DDR_TIMER                       (*(vuint8 *)(0xFC0A401F))
#define MCF_GPIO_DDR_UART                        (*(vuint8 *)(0xFC0A4020))
#define MCF_GPIO_DDR_DEBUG                       (*(vuint8 *)(0xFC0A4021))
#define MCF_GPIO_DDR_SDHC                        (*(vuint8 *)(0xFC0A4023))
#define MCF_GPIO_DDR_SSI                         (*(vuint8 *)(0xFC0A4024))
#define MCF_GPIO_PORTP_BUSCTL                    (*(vuint8 *)(0xFC0A4028))
#define MCF_GPIO_PORTP_BS                        (*(vuint8 *)(0xFC0A4029))
#define MCF_GPIO_PORTP_CS                        (*(vuint8 *)(0xFC0A402A))
#define MCF_GPIO_PORTP_DSPI                      (*(vuint8 *)(0xFC0A402B))
#define MCF_GPIO_PORTP_FEC0                      (*(vuint8 *)(0xFC0A402D))
#define MCF_GPIO_PORTP_FECI2C                    (*(vuint8 *)(0xFC0A402E))
#define MCF_GPIO_PORTP_SIMP1                     (*(vuint8 *)(0xFC0A4031))
#define MCF_GPIO_PORTP_SIMP0                     (*(vuint8 *)(0xFC0A4032))
#define MCF_GPIO_PORTP_TIMER                     (*(vuint8 *)(0xFC0A4033))
#define MCF_GPIO_PORTP_UART                      (*(vuint8 *)(0xFC0A4034))
#define MCF_GPIO_PORTP_DEBUG                     (*(vuint8 *)(0xFC0A4035))
#define MCF_GPIO_PORTP_SDHC                      (*(vuint8 *)(0xFC0A4037))
#define MCF_GPIO_PORTP_SSI                       (*(vuint8 *)(0xFC0A4038))
#define MCF_GPIO_CLR_BUSCT                       (*(vuint8 *)(0xFC0A403C))
#define MCF_GPIO_CLR_BS                          (*(vuint8 *)(0xFC0A403D))
#define MCF_GPIO_CLR_CS                          (*(vuint8 *)(0xFC0A403E))
#define MCF_GPIO_CLR_DSPI                        (*(vuint8 *)(0xFC0A403F))
#define MCF_GPIO_CLR_FEC0                        (*(vuint8 *)(0xFC0A4041))
#define MCF_GPIO_CLR_FECI2                       (*(vuint8 *)(0xFC0A4042))
#define MCF_GPIO_CLR_SIMP1                       (*(vuint8 *)(0xFC0A4045))
#define MCF_GPIO_CLR_SIMP0                       (*(vuint8 *)(0xFC0A4046))
#define MCF_GPIO_CLR_TIMER                       (*(vuint8 *)(0xFC0A4047))
#define MCF_GPIO_CLR_UART                        (*(vuint8 *)(0xFC0A4048))
#define MCF_GPIO_CLR_DEBUG                       (*(vuint8 *)(0xFC0A4049))
#define MCF_GPIO_CLR_SDHC                        (*(vuint8 *)(0xFC0A404B))
#define MCF_GPIO_CLR_SSI                         (*(vuint8 *)(0xFC0A404C))
#define MCF_GPIO_PAR_BUSCTL                      (*(vuint8 *)(0xFC0A4050))
#define MCF_GPIO_PAR_BS                          (*(vuint8 *)(0xFC0A4051))
#define MCF_GPIO_PAR_CS                          (*(vuint8 *)(0xFC0A4052))
#define MCF_GPIO_PAR_DSPIH                       (*(vuint8 *)(0xFC0A4054))
#define MCF_GPIO_PAR_DSPIL                       (*(vuint8 *)(0xFC0A4055))
#define MCF_GPIO_PAR_FEC                         (*(vuint8 *)(0xFC0A4056))
#define MCF_GPIO_PAR_FECI2C                      (*(vuint8 *)(0xFC0A4057))
#define MCF_GPIO_PAR_IRQ0H                       (*(vuint8 *)(0xFC0A4058))
#define MCF_GPIO_PAR_IRQ0L                       (*(vuint8 *)(0xFC0A4059))
#define MCF_GPIO_PAR_IRQ1H                       (*(vuint8 *)(0xFC0A405A))
#define MCF_GPIO_PAR_IRQ1L                       (*(vuint8 *)(0xFC0A405B))
#define MCF_GPIO_PAR_SIMP1H                      (*(vuint8 *)(0xFC0A405C))
#define MCF_GPIO_PAR_SIMP1L                      (*(vuint8 *)(0xFC0A405D))
#define MCF_GPIO_PAR_SIMP0                       (*(vuint8 *)(0xFC0A405E))
#define MCF_GPIO_PAR_TIMER                       (*(vuint8 *)(0xFC0A405F))
#define MCF_GPIO_PAR_UART                        (*(vuint8 *)(0xFC0A4060))
#define MCF_GPIO_PAR_DEBUG                       (*(vuint8 *)(0xFC0A4062))
#define MCF_GPIO_PAR_SDHC                        (*(vuint8 *)(0xFC0A4063))
#define MCF_GPIO_PAR_SSIH                        (*(vuint8 *)(0xFC0A4064))
#define MCF_GPIO_PAR_SSIL                        (*(vuint8 *)(0xFC0A4065))
#define MCF_GPIO_MSCR1                           (*(vuint8 *)(0xFC0A4068))
#define MCF_GPIO_MSCR2                           (*(vuint8 *)(0xFC0A4069))
#define MCF_GPIO_MSCR3                           (*(vuint8 *)(0xFC0A406A))
#define MCF_GPIO_MSCR4_5                         (*(vuint8 *)(0xFC0A406B))
#define MCF_GPIO_SRCR_DSPI                       (*(vuint8 *)(0xFC0A406C))
#define MCF_GPIO_DSCR_FEC                        (*(vuint8 *)(0xFC0A406D))
#define MCF_GPIO_SRCR_I2C                        (*(vuint8 *)(0xFC0A406E))
#define MCF_GPIO_SRCR_EPORT                      (*(vuint8 *)(0xFC0A406F))
#define MCF_GPIO_SRCR_SIM                        (*(vuint8 *)(0xFC0A4070))
#define MCF_GPIO_SRCR_TIMER                      (*(vuint8 *)(0xFC0A4071))
#define MCF_GPIO_SRCR_UART                       (*(vuint8 *)(0xFC0A4072))
#define MCF_GPIO_SRCR_SDHC                       (*(vuint8 *)(0xFC0A4074))
#define MCF_GPIO_SRCR_SSI                        (*(vuint8 *)(0xFC0A4075))
#define MCF_GPIO_PCRH                            (*(vuint8 *)(0xFC0A4078))
#define MCF_GPIO_PCRL                            (*(vuint8 *)(0xFC0A4079))

/* Bit definitions and macros for MCF_GPIO_PORT_BUSCTL */
#define MCF_GPIO_PORT_BUSCTL_PORT_BUSCTL0        (0x01)
#define MCF_GPIO_PORT_BUSCTL_PORT_BUSCTL1        (0x02)
#define MCF_GPIO_PORT_BUSCTL_PORT_BUSCTL2        (0x04)
#define MCF_GPIO_PORT_BUSCTL_PORT_BUSCTL3        (0x08)

/* Bit definitions and macros for MCF_GPIO_PORT_BS */
#define MCF_GPIO_PORT_BS_PORT_BS0                (0x01)
#define MCF_GPIO_PORT_BS_PORT_BS1                (0x02)
#define MCF_GPIO_PORT_BS_PORT_BS2                (0x04)
#define MCF_GPIO_PORT_BS_PORT_BS3                (0x08)

/* Bit definitions and macros for MCF_GPIO_PORT_CS */
#define MCF_GPIO_PORT_CS_PORT_CS0                (0x01)
#define MCF_GPIO_PORT_CS_PORT_CS1                (0x02)
#define MCF_GPIO_PORT_CS_PORT_CS4                (0x10)
#define MCF_GPIO_PORT_CS_PORT_CS5                (0x20)

/* Bit definitions and macros for MCF_GPIO_PORT_DSPI */
#define MCF_GPIO_PORT_DSPI_PORT_DSPI0            (0x01)
#define MCF_GPIO_PORT_DSPI_PORT_DSPI1            (0x02)
#define MCF_GPIO_PORT_DSPI_PORT_DSPI2            (0x04)
#define MCF_GPIO_PORT_DSPI_PORT_DSPI3            (0x08)
#define MCF_GPIO_PORT_DSPI_PORT_DSPI4            (0x10)
#define MCF_GPIO_PORT_DSPI_PORT_DSPI5            (0x20)
#define MCF_GPIO_PORT_DSPI_PORT_DSPI6            (0x40)

/* Bit definitions and macros for MCF_GPIO_PORT_FEC0 */
#define MCF_GPIO_PORT_FEC0_PORT_FEC00            (0x01)
#define MCF_GPIO_PORT_FEC0_PORT_FEC01            (0x02)
#define MCF_GPIO_PORT_FEC0_PORT_FEC02            (0x04)
#define MCF_GPIO_PORT_FEC0_PORT_FEC03            (0x08)
#define MCF_GPIO_PORT_FEC0_PORT_FEC04            (0x10)
#define MCF_GPIO_PORT_FEC0_PORT_FEC05            (0x20)
#define MCF_GPIO_PORT_FEC0_PORT_FEC06            (0x40)

/* Bit definitions and macros for MCF_GPIO_PORT_FECI2C */
#define MCF_GPIO_PORT_FECI2C_PORT_FECI2C0        (0x01)
#define MCF_GPIO_PORT_FECI2C_PORT_FECI2C1        (0x02)
#define MCF_GPIO_PORT_FECI2C_PORT_FECI2C2        (0x04)
#define MCF_GPIO_PORT_FECI2C_PORT_FECI2C3        (0x08)
#define MCF_GPIO_PORT_FECI2C_PORT_FECI2C4        (0x10)
#define MCF_GPIO_PORT_FECI2C_PORT_FECI2C5        (0x20)

/* Bit definitions and macros for MCF_GPIO_PORT_TIMER */
#define MCF_GPIO_PORT_TIMER_PORT_TIMER0          (0x01)
#define MCF_GPIO_PORT_TIMER_PORT_TIMER1          (0x02)
#define MCF_GPIO_PORT_TIMER_PORT_TIMER2          (0x04)
#define MCF_GPIO_PORT_TIMER_PORT_TIMER3          (0x08)

/* Bit definitions and macros for MCF_GPIO_PORT_UART */
#define MCF_GPIO_PORT_UART_PORT_UART0            (0x01)
#define MCF_GPIO_PORT_UART_PORT_UART1            (0x02)
#define MCF_GPIO_PORT_UART_PORT_UART2            (0x04)
#define MCF_GPIO_PORT_UART_PORT_UART3            (0x08)
#define MCF_GPIO_PORT_UART_PORT_UART4            (0x10)
#define MCF_GPIO_PORT_UART_PORT_UART5            (0x20)

/* Bit definitions and macros for MCF_GPIO_PORT_DEBUG */
#define MCF_GPIO_PORT_DEBUG_PORT_DEBUG0          (0x01)

/* Bit definitions and macros for MCF_GPIO_PORT_SDHC */
#define MCF_GPIO_PORT_SDHC_PORT_SDHC0            (0x01)
#define MCF_GPIO_PORT_SDHC_PORT_SDHC1            (0x02)
#define MCF_GPIO_PORT_SDHC_PORT_SDHC2            (0x04)
#define MCF_GPIO_PORT_SDHC_PORT_SDHC3            (0x08)
#define MCF_GPIO_PORT_SDHC_PORT_SDHC4            (0x10)
#define MCF_GPIO_PORT_SDHC_PORT_SDHC5            (0x20)

/* Bit definitions and macros for MCF_GPIO_DDR_BUSCTL */
#define MCF_GPIO_DDR_BUSCTL_DDR_BUSCTL0          (0x01)
#define MCF_GPIO_DDR_BUSCTL_DDR_BUSCTL1          (0x02)
#define MCF_GPIO_DDR_BUSCTL_DDR_BUSCTL2          (0x04)
#define MCF_GPIO_DDR_BUSCTL_DDR_BUSCTL3          (0x08)

/* Bit definitions and macros for MCF_GPIO_DDR_BS */
#define MCF_GPIO_DDR_BS_DDR_BS0                  (0x01)
#define MCF_GPIO_DDR_BS_DDR_BS1                  (0x02)
#define MCF_GPIO_DDR_BS_DDR_BS2                  (0x04)
#define MCF_GPIO_DDR_BS_DDR_BS3                  (0x08)

/* Bit definitions and macros for MCF_GPIO_DDR_CS */
#define MCF_GPIO_DDR_CS_DDR_CS0                  (0x01)
#define MCF_GPIO_DDR_CS_DDR_CS1                  (0x02)
#define MCF_GPIO_DDR_CS_DDR_CS4                  (0x10)
#define MCF_GPIO_DDR_CS_DDR_CS5                  (0x20)

/* Bit definitions and macros for MCF_GPIO_DDR_DSPI */
#define MCF_GPIO_DDR_DSPI_DDR_DSPI0              (0x01)
#define MCF_GPIO_DDR_DSPI_DDR_DSPI1              (0x02)
#define MCF_GPIO_DDR_DSPI_DDR_DSPI2              (0x04)
#define MCF_GPIO_DDR_DSPI_DDR_DSPI3              (0x08)
#define MCF_GPIO_DDR_DSPI_DDR_DSPI4              (0x10)
#define MCF_GPIO_DDR_DSPI_DDR_DSPI5              (0x20)
#define MCF_GPIO_DDR_DSPI_DDR_DSPI6              (0x40)

/* Bit definitions and macros for MCF_GPIO_DDR_FEC0 */
#define MCF_GPIO_DDR_FEC0_DDR_FEC00              (0x01)
#define MCF_GPIO_DDR_FEC0_DDR_FEC01              (0x02)
#define MCF_GPIO_DDR_FEC0_DDR_FEC02              (0x04)
#define MCF_GPIO_DDR_FEC0_DDR_FEC03              (0x08)
#define MCF_GPIO_DDR_FEC0_DDR_FEC04              (0x10)
#define MCF_GPIO_DDR_FEC0_DDR_FEC05              (0x20)
#define MCF_GPIO_DDR_FEC0_DDR_FEC06              (0x40)

/* Bit definitions and macros for MCF_GPIO_DDR_FECI2C */
#define MCF_GPIO_DDR_FECI2C_DDR_FECI2C0          (0x01)
#define MCF_GPIO_DDR_FECI2C_DDR_FECI2C1          (0x02)
#define MCF_GPIO_DDR_FECI2C_DDR_FECI2C2          (0x04)
#define MCF_GPIO_DDR_FECI2C_DDR_FECI2C3          (0x08)
#define MCF_GPIO_DDR_FECI2C_DDR_FECI2C4          (0x10)
#define MCF_GPIO_DDR_FECI2C_DDR_FECI2C5          (0x20)

/* Bit definitions and macros for MCF_GPIO_DDR_TIMER */
#define MCF_GPIO_DDR_TIMER_DDR_TIMER0            (0x01)
#define MCF_GPIO_DDR_TIMER_DDR_TIMER1            (0x02)
#define MCF_GPIO_DDR_TIMER_DDR_TIMER2            (0x04)
#define MCF_GPIO_DDR_TIMER_DDR_TIMER3            (0x08)

/* Bit definitions and macros for MCF_GPIO_DDR_UART */
#define MCF_GPIO_DDR_UART_DDR_UART0              (0x01)
#define MCF_GPIO_DDR_UART_DDR_UART1              (0x02)
#define MCF_GPIO_DDR_UART_DDR_UART2              (0x04)
#define MCF_GPIO_DDR_UART_DDR_UART3              (0x08)
#define MCF_GPIO_DDR_UART_DDR_UART4              (0x10)
#define MCF_GPIO_DDR_UART_DDR_UART5              (0x20)

/* Bit definitions and macros for MCF_GPIO_DDR_DEBUG */
#define MCF_GPIO_DDR_DEBUG_DDR_DEBUG0            (0x01)

/* Bit definitions and macros for MCF_GPIO_DDR_SDHC */
#define MCF_GPIO_DDR_SDHC_DDR_SDHC0              (0x01)
#define MCF_GPIO_DDR_SDHC_DDR_SDHC1              (0x02)
#define MCF_GPIO_DDR_SDHC_DDR_SDHC2              (0x04)
#define MCF_GPIO_DDR_SDHC_DDR_SDHC3              (0x08)
#define MCF_GPIO_DDR_SDHC_DDR_SDHC4              (0x10)
#define MCF_GPIO_DDR_SDHC_DDR_SDHC5              (0x20)

/* Bit definitions and macros for MCF_GPIO_PORTP_BUSCTL */
#define MCF_GPIO_PORTP_BUSCTL_PORTP_BUSCTL0      (0x01)
#define MCF_GPIO_PORTP_BUSCTL_PORTP_BUSCTL1      (0x02)
#define MCF_GPIO_PORTP_BUSCTL_PORTP_BUSCTL2      (0x04)
#define MCF_GPIO_PORTP_BUSCTL_PORTP_BUSCTL3      (0x08)

/* Bit definitions and macros for MCF_GPIO_PORTP_BS */
#define MCF_GPIO_PORTP_BS_PORTP_BS0              (0x01)
#define MCF_GPIO_PORTP_BS_PORTP_BS1              (0x02)
#define MCF_GPIO_PORTP_BS_PORTP_BS2              (0x04)
#define MCF_GPIO_PORTP_BS_PORTP_BS3              (0x08)

/* Bit definitions and macros for MCF_GPIO_PORTP_CS */
#define MCF_GPIO_PORTP_CS_PORTP_CS0              (0x01)
#define MCF_GPIO_PORTP_CS_PORTP_CS1              (0x02)
#define MCF_GPIO_PORTP_CS_PORTP_CS4              (0x10)
#define MCF_GPIO_PORTP_CS_PORTP_CS5              (0x20)

/* Bit definitions and macros for MCF_GPIO_PORTP_DSPI */
#define MCF_GPIO_PORTP_DSPI_PORTP_DSPI0          (0x01)
#define MCF_GPIO_PORTP_DSPI_PORTP_DSPI1          (0x02)
#define MCF_GPIO_PORTP_DSPI_PORTP_DSPI2          (0x04)
#define MCF_GPIO_PORTP_DSPI_PORTP_DSPI3          (0x08)
#define MCF_GPIO_PORTP_DSPI_PORTP_DSPI4          (0x10)
#define MCF_GPIO_PORTP_DSPI_PORTP_DSPI5          (0x20)
#define MCF_GPIO_PORTP_DSPI_PORTP_DSPI6          (0x40)

/* Bit definitions and macros for MCF_GPIO_PORTP_FEC0 */
#define MCF_GPIO_PORTP_FEC0_PORTP_FEC00          (0x01)
#define MCF_GPIO_PORTP_FEC0_PORTP_FEC01          (0x02)
#define MCF_GPIO_PORTP_FEC0_PORTP_FEC02          (0x04)
#define MCF_GPIO_PORTP_FEC0_PORTP_FEC03          (0x08)
#define MCF_GPIO_PORTP_FEC0_PORTP_FEC04          (0x10)
#define MCF_GPIO_PORTP_FEC0_PORTP_FEC05          (0x20)
#define MCF_GPIO_PORTP_FEC0_PORTP_FEC06          (0x40)

/* Bit definitions and macros for MCF_GPIO_PORTP_FECI2C */
#define MCF_GPIO_PORTP_FECI2C_PORTP_FECI2C0      (0x01)
#define MCF_GPIO_PORTP_FECI2C_PORTP_FECI2C1      (0x02)
#define MCF_GPIO_PORTP_FECI2C_PORTP_FECI2C2      (0x04)
#define MCF_GPIO_PORTP_FECI2C_PORTP_FECI2C3      (0x08)
#define MCF_GPIO_PORTP_FECI2C_PORTP_FECI2C4      (0x10)
#define MCF_GPIO_PORTP_FECI2C_PORTP_FECI2C5      (0x20)

/* Bit definitions and macros for MCF_GPIO_PORTP_TIMER */
#define MCF_GPIO_PORTP_TIMER_PORTP_TIMER0        (0x01)
#define MCF_GPIO_PORTP_TIMER_PORTP_TIMER1        (0x02)
#define MCF_GPIO_PORTP_TIMER_PORTP_TIMER2        (0x04)
#define MCF_GPIO_PORTP_TIMER_PORTP_TIMER3        (0x08)

/* Bit definitions and macros for MCF_GPIO_PORTP_UART */
#define MCF_GPIO_PORTP_UART_PORTP_UART0          (0x01)
#define MCF_GPIO_PORTP_UART_PORTP_UART1          (0x02)
#define MCF_GPIO_PORTP_UART_PORTP_UART2          (0x04)
#define MCF_GPIO_PORTP_UART_PORTP_UART3          (0x08)
#define MCF_GPIO_PORTP_UART_PORTP_UART4          (0x10)
#define MCF_GPIO_PORTP_UART_PORTP_UART5          (0x20)

/* Bit definitions and macros for MCF_GPIO_PORTP_DEBUG */
#define MCF_GPIO_PORTP_DEBUG_PORTP_DEBUG0        (0x01)

/* Bit definitions and macros for MCF_GPIO_PORTP_SDHC */
#define MCF_GPIO_PORTP_SDHC_PORTP_SDHC0          (0x01)
#define MCF_GPIO_PORTP_SDHC_PORTP_SDHC1          (0x02)
#define MCF_GPIO_PORTP_SDHC_PORTP_SDHC2          (0x04)
#define MCF_GPIO_PORTP_SDHC_PORTP_SDHC3          (0x08)
#define MCF_GPIO_PORTP_SDHC_PORTP_SDHC4          (0x10)
#define MCF_GPIO_PORTP_SDHC_PORTP_SDHC5          (0x20)

/* Bit definitions and macros for MCF_GPIO_CLR_BUSCT */
#define MCF_GPIO_CLR_BUSCT_CLR_BUSCTL0           (0x01)
#define MCF_GPIO_CLR_BUSCT_CLR_BUSCTL1           (0x02)
#define MCF_GPIO_CLR_BUSCT_CLR_BUSCTL2           (0x04)
#define MCF_GPIO_CLR_BUSCT_CLR_BUSCTL3           (0x08)

/* Bit definitions and macros for MCF_GPIO_CLR_BS */
#define MCF_GPIO_CLR_BS_CLR_BS0                  (0x01)
#define MCF_GPIO_CLR_BS_CLR_BS1                  (0x02)
#define MCF_GPIO_CLR_BS_CLR_BS2                  (0x04)
#define MCF_GPIO_CLR_BS_CLR_BS3                  (0x08)

/* Bit definitions and macros for MCF_GPIO_CLR_CS */
#define MCF_GPIO_CLR_CS_CLR_CS0                  (0x01)
#define MCF_GPIO_CLR_CS_CLR_CS1                  (0x02)
#define MCF_GPIO_CLR_CS_CLR_CS4                  (0x10)
#define MCF_GPIO_CLR_CS_CLR_CS5                  (0x20)

/* Bit definitions and macros for MCF_GPIO_CLR_DSPI */
#define MCF_GPIO_CLR_DSPI_CLR_DSPI0              (0x01)
#define MCF_GPIO_CLR_DSPI_CLR_DSPI1              (0x02)
#define MCF_GPIO_CLR_DSPI_CLR_DSPI2              (0x04)
#define MCF_GPIO_CLR_DSPI_CLR_DSPI3              (0x08)
#define MCF_GPIO_CLR_DSPI_CLR_DSPI4              (0x10)
#define MCF_GPIO_CLR_DSPI_CLR_DSPI5              (0x20)
#define MCF_GPIO_CLR_DSPI_CLR_DSPI6              (0x40)

/* Bit definitions and macros for MCF_GPIO_CLR_FEC0 */
#define MCF_GPIO_CLR_FEC0_CLR_FEC00              (0x01)
#define MCF_GPIO_CLR_FEC0_CLR_FEC01              (0x02)
#define MCF_GPIO_CLR_FEC0_CLR_FEC02              (0x04)
#define MCF_GPIO_CLR_FEC0_CLR_FEC03              (0x08)
#define MCF_GPIO_CLR_FEC0_CLR_FEC04              (0x10)
#define MCF_GPIO_CLR_FEC0_CLR_FEC05              (0x20)
#define MCF_GPIO_CLR_FEC0_CLR_FEC06              (0x40)

/* Bit definitions and macros for MCF_GPIO_CLR_FECI2 */
#define MCF_GPIO_CLR_FECI2_CLR_FECI2C0           (0x01)
#define MCF_GPIO_CLR_FECI2_CLR_FECI2C1           (0x02)
#define MCF_GPIO_CLR_FECI2_CLR_FECI2C2           (0x04)
#define MCF_GPIO_CLR_FECI2_CLR_FECI2C3           (0x08)
#define MCF_GPIO_CLR_FECI2_CLR_FECI2C4           (0x10)
#define MCF_GPIO_CLR_FECI2_CLR_FECI2C5           (0x20)

/* Bit definitions and macros for MCF_GPIO_CLR_TIMER */
#define MCF_GPIO_CLR_TIMER_CLR_TIMER0            (0x01)
#define MCF_GPIO_CLR_TIMER_CLR_TIMER1            (0x02)
#define MCF_GPIO_CLR_TIMER_CLR_TIMER2            (0x04)
#define MCF_GPIO_CLR_TIMER_CLR_TIMER3            (0x08)

/* Bit definitions and macros for MCF_GPIO_CLR_UART */
#define MCF_GPIO_CLR_UART_CLR_UART0              (0x01)
#define MCF_GPIO_CLR_UART_CLR_UART1              (0x02)
#define MCF_GPIO_CLR_UART_CLR_UART2              (0x04)
#define MCF_GPIO_CLR_UART_CLR_UART3              (0x08)
#define MCF_GPIO_CLR_UART_CLR_UART4              (0x10)
#define MCF_GPIO_CLR_UART_CLR_UART5              (0x20)

/* Bit definitions and macros for MCF_GPIO_CLR_DEBUG */
#define MCF_GPIO_CLR_DEBUG_CLR_DEBUG0            (0x01)

/* Bit definitions and macros for MCF_GPIO_CLR_SDHC */
#define MCF_GPIO_CLR_SDHC_CLR_SDHC0              (0x01)
#define MCF_GPIO_CLR_SDHC_CLR_SDHC1              (0x02)
#define MCF_GPIO_CLR_SDHC_CLR_SDHC2              (0x04)
#define MCF_GPIO_CLR_SDHC_CLR_SDHC3              (0x08)
#define MCF_GPIO_CLR_SDHC_CLR_SDHC4              (0x10)
#define MCF_GPIO_CLR_SDHC_CLR_SDHC5              (0x20)

/* Bit definitions and macros for MCF_GPIO_PAR_BUSCTL */
#define MCF_GPIO_PAR_BUSCTL_PAR_TS(x)            (((x)&0x03)<<3)
#define MCF_GPIO_PAR_BUSCTL_PAR_RW               (0x20)
#define MCF_GPIO_PAR_BUSCTL_PAR_TA               (0x40)
#define MCF_GPIO_PAR_BUSCTL_PAR_OE               (0x80)

/* Bit definitions and macros for MCF_GPIO_PAR_BS */
#define MCF_GPIO_PAR_BS_PAR_BS0                  (0x01)
#define MCF_GPIO_PAR_BS_PAR_BS1                  (0x04)
#define MCF_GPIO_PAR_BS_PAR_BS2                  (0x10)
#define MCF_GPIO_PAR_BS_PAR_BS3                  (0x40)

/* Bit definitions and macros for MCF_GPIO_PAR_CS */
#define MCF_GPIO_PAR_CS_PAR_CS0(x)               (((x)&0x03)<<0)
#define MCF_GPIO_PAR_CS_PAR_CS1(x)               (((x)&0x03)<<2)
#define MCF_GPIO_PAR_CS_PAR_CS4                  (0x10)
#define MCF_GPIO_PAR_CS_PAR_CS5                  (0x40)

/* Bit definitions and macros for MCF_GPIO_PAR_DSPIH */
#define MCF_GPIO_PAR_DSPIH_PAR_PCS0(x)           (((x)&0x03)<<0)
#define MCF_GPIO_PAR_DSPIH_PAR_SCK(x)            (((x)&0x03)<<2)
#define MCF_GPIO_PAR_DSPIH_PAR_SOUT(x)           (((x)&0x03)<<4)
#define MCF_GPIO_PAR_DSPIH_PAR_SIN(x)            (((x)&0x03)<<6)

/* Bit definitions and macros for MCF_GPIO_PAR_DSPIL */
#define MCF_GPIO_PAR_DSPIL_PAR_PCS3(x)           (((x)&0x03)<<2)
#define MCF_GPIO_PAR_DSPIL_PAR_PCS2(x)           (((x)&0x03)<<4)
#define MCF_GPIO_PAR_DSPIL_PAR_PCS1              (0x40)

/* Bit definitions and macros for MCF_GPIO_PAR_FEC */
#define MCF_GPIO_PAR_FEC_PAR_RMII0               (0x01)
#define MCF_GPIO_PAR_FEC_PAR_7WIRE0              (0x04)
#define MCF_GPIO_PAR_FEC_PAR_RMII1               (0x10)
#define MCF_GPIO_PAR_FEC_PAR_7WIRE1              (0x40)

/* Bit definitions and macros for MCF_GPIO_PAR_FECI2C */
#define MCF_GPIO_PAR_FECI2C_PAR_I2C_SCL(x)       (((x)&0x03)<<0)
#define MCF_GPIO_PAR_FECI2C_PAR_I2C_SDA(x)       (((x)&0x03)<<2)
#define MCF_GPIO_PAR_FECI2C_PAR_RMII1_MDIO       (0x10)
#define MCF_GPIO_PAR_FECI2C_PAR_RMII1_MDC        (0x20)
#define MCF_GPIO_PAR_FECI2C_PAR_RMII0_MDIO       (0x40)
#define MCF_GPIO_PAR_FECI2C_PAR_RMII0_MDC        (0x80)

/* Bit definitions and macros for MCF_GPIO_PAR_IRQ0H */
#define MCF_GPIO_PAR_IRQ0H_PAR_IRQ0_4(x)         (((x)&0x03)<<0)
#define MCF_GPIO_PAR_IRQ0H_PAR_IRQ0_6(x)         (((x)&0x03)<<4)
#define MCF_GPIO_PAR_IRQ0H_PAR_IRQ0_7(x)         (((x)&0x03)<<6)

/* Bit definitions and macros for MCF_GPIO_PAR_IRQ0L */
#define MCF_GPIO_PAR_IRQ0L_PAR_IRQ0_1(x)         (((x)&0x03)<<2)

/* Bit definitions and macros for MCF_GPIO_PAR_IRQ1H */
#define MCF_GPIO_PAR_IRQ1H_PAR_IRQ1_4            (0x01)
#define MCF_GPIO_PAR_IRQ1H_PAR_IRQ1_5            (0x04)
#define MCF_GPIO_PAR_IRQ1H_PAR_IRQ1_6            (0x10)
#define MCF_GPIO_PAR_IRQ1H_PAR_IRQ1_7            (0x40)

/* Bit definitions and macros for MCF_GPIO_PAR_IRQ1L */
#define MCF_GPIO_PAR_IRQ1L_PAR_IRQ1_0            (0x01)
#define MCF_GPIO_PAR_IRQ1L_PAR_IRQ1_1            (0x04)
#define MCF_GPIO_PAR_IRQ1L_PAR_IRQ1_2            (0x10)
#define MCF_GPIO_PAR_IRQ1L_PAR_IRQ1_3            (0x40)

/* Bit definitions and macros for MCF_GPIO_PAR_SIMP1H */
#define MCF_GPIO_PAR_SIMP1H_PAR_SIMP1_PD(x)      (((x)&0x03)<<0)
#define MCF_GPIO_PAR_SIMP1H_PAR_SIMP1_RST(x)     (((x)&0x03)<<2)
#define MCF_GPIO_PAR_SIMP1H_PAR_SIMP1_VEN(x)     (((x)&0x03)<<4)
#define MCF_GPIO_PAR_SIMP1H_PAR_SIMP1_XMT_IO(x)  (((x)&0x03)<<6)

/* Bit definitions and macros for MCF_GPIO_PAR_SIMP1L */
#define MCF_GPIO_PAR_SIMP1L_PAR_SIMP1_CLK(x)     (((x)&0x03)<<6)

/* Bit definitions and macros for MCF_GPIO_PAR_SIMP0 */
#define MCF_GPIO_PAR_SIMP0_PAR_SIMP0_CLK         (0x01)
#define MCF_GPIO_PAR_SIMP0_PAR_SIMP0_PD          (0x02)
#define MCF_GPIO_PAR_SIMP0_PAR_SIMP0_RST         (0x04)
#define MCF_GPIO_PAR_SIMP0_PAR_SIMP0_VEN         (0x08)
#define MCF_GPIO_PAR_SIMP0_PAR_SIMP0_XMT_IO      (0x10)

/* Bit definitions and macros for MCF_GPIO_PAR_TIMER */
#define MCF_GPIO_PAR_TIMER_PAR_TIN0(x)           (((x)&0x03)<<0)
#define MCF_GPIO_PAR_TIMER_PAR_TIN1(x)           (((x)&0x03)<<2)
#define MCF_GPIO_PAR_TIMER_PAR_TIN2(x)           (((x)&0x03)<<4)
#define MCF_GPIO_PAR_TIMER_PAR_TIN3(x)           (((x)&0x03)<<6)
#define MCF_GPIO_PAR_TIMER_PAR_TIN3_GPIO           (0x00)
#define MCF_GPIO_PAR_TIMER_PAR_TIN3_TOUT3          (0x80)
#define MCF_GPIO_PAR_TIMER_PAR_TIN3_URXD2          (0x40)
#define MCF_GPIO_PAR_TIMER_PAR_TIN3_TIN3           (0xC0)
#define MCF_GPIO_PAR_TIMER_PAR_TIN2_GPIO           (0x00)
#define MCF_GPIO_PAR_TIMER_PAR_TIN2_TOUT2          (0x20)
#define MCF_GPIO_PAR_TIMER_PAR_TIN2_UTXD2          (0x10)
#define MCF_GPIO_PAR_TIMER_PAR_TIN2_TIN2           (0x30)
#define MCF_GPIO_PAR_TIMER_PAR_TIN1_GPIO           (0x00)
#define MCF_GPIO_PAR_TIMER_PAR_TIN1_TOUT1          (0x08)
#define MCF_GPIO_PAR_TIMER_PAR_TIN1_DACK1          (0x04)
#define MCF_GPIO_PAR_TIMER_PAR_TIN1_TIN1           (0x0C)
#define MCF_GPIO_PAR_TIMER_PAR_TIN0_GPIO           (0x00)
#define MCF_GPIO_PAR_TIMER_PAR_TIN0_TOUT0          (0x02)
#define MCF_GPIO_PAR_TIMER_PAR_TIN0_DREQ0          (0x01)
#define MCF_GPIO_PAR_TIMER_PAR_TIN0_TIN0           (0x03)

/* Bit definitions and macros for MCF_GPIO_PAR_UART */
#define MCF_GPIO_PAR_UART_PAR_UCTS0(x)           (((x)&0x03)<<0)
#define MCF_GPIO_PAR_UART_PAR_URTS0(x)           (((x)&0x03)<<2)
#define MCF_GPIO_PAR_UART_PAR_URXD0              (0x10)
#define MCF_GPIO_PAR_UART_PAR_UTXD0              (0x20)
#define MCF_GPIO_PAR_UART_PAR_URXD2              (0x40)
#define MCF_GPIO_PAR_UART_PAR_UTXD2              (0x80)

/* Bit definitions and macros for MCF_GPIO_PAR_DEBUG */
#define MCF_GPIO_PAR_DEBUG_PAR_ALLPST            (0x80)

/* Bit definitions and macros for MCF_GPIO_PAR_SDHC */
#define MCF_GPIO_PAR_SDHC_PAR_SDHC_CLK           (0x01)
#define MCF_GPIO_PAR_SDHC_PAR_SDHC_CMD           (0x02)
#define MCF_GPIO_PAR_SDHC_PAR_SDHC_DAT0          (0x04)
#define MCF_GPIO_PAR_SDHC_PAR_SDHC_DAT1          (0x08)
#define MCF_GPIO_PAR_SDHC_PAR_SDHC_DAT2          (0x10)
#define MCF_GPIO_PAR_SDHC_PAR_SDHC_DAT3          (0x20)

/* Bit definitions and macros for MCF_GPIO_PAR_SSIH */
#define MCF_GPIO_PAR_SSIH_PAR_SSI_MCLK(x)        (((x)&0x03)<<0)
#define MCF_GPIO_PAR_SSIH_PAR_SSI_FS(x)          (((x)&0x03)<<2)
#define MCF_GPIO_PAR_SSIH_PAR_SSI_TXD(x)         (((x)&0x03)<<4)
#define MCF_GPIO_PAR_SSIH_PAR_SSI_RXD(x)         (((x)&0x03)<<6)

/* Bit definitions and macros for MCF_GPIO_PAR_SSIL */
#define MCF_GPIO_PAR_SSIL_PAR_SSI_BCLK(x)        (((x)&0x03)<<6)

/* Bit definitions and macros for MCF_GPIO_MSCR1 */
#define MCF_GPIO_MSCR1_SRE1_0                    (0x20)
#define MCF_GPIO_MSCR1_SRE1_1                    (0x40)
#define MCF_GPIO_MSCR1_SRE1_2                    (0x80)

/* Bit definitions and macros for MCF_GPIO_MSCR2 */
#define MCF_GPIO_MSCR2_SRE2_0                    (0x20)
#define MCF_GPIO_MSCR2_SRE2_1                    (0x40)
#define MCF_GPIO_MSCR2_SRE2_2                    (0x80)

/* Bit definitions and macros for MCF_GPIO_MSCR3 */
#define MCF_GPIO_MSCR3_SRE3_0                    (0x20)
#define MCF_GPIO_MSCR3_SRE3_1                    (0x40)
#define MCF_GPIO_MSCR3_SRE3_2                    (0x80)

/* Bit definitions and macros for MCF_GPIO_MSCR4_5 */
#define MCF_GPIO_MSCR4_5_SRE5_0                  (0x04)
#define MCF_GPIO_MSCR4_5_SRE5_1                  (0x08)
#define MCF_GPIO_MSCR4_5_SRE5_2                  (0x10)
#define MCF_GPIO_MSCR4_5_SRE4_0                  (0x20)
#define MCF_GPIO_MSCR4_5_SRE4_1                  (0x40)
#define MCF_GPIO_MSCR4_5_SRE4_2                  (0x80)

/* Bit definitions and macros for MCF_GPIO_SRCR_DSPI */
#define MCF_GPIO_SRCR_DSPI_DSPI_SRE0             (0x01)
#define MCF_GPIO_SRCR_DSPI_DSPI_SRE1             (0x02)

/* Bit definitions and macros for MCF_GPIO_DSCR_FEC */
#define MCF_GPIO_DSCR_FEC_RMLL1_DSE0             (0x01)
#define MCF_GPIO_DSCR_FEC_RMLL1_DSE1             (0x02)
#define MCF_GPIO_DSCR_FEC_MLL0_DSE0              (0x04)
#define MCF_GPIO_DSCR_FEC_MLL0_DSE1              (0x08)
#define MCF_GPIO_DSCR_FEC_RMLL_REF_CLK_DSE0      (0x10)
#define MCF_GPIO_DSCR_FEC_RMLL_REF_CLK_DSE1      (0x20)

/* Bit definitions and macros for MCF_GPIO_SRCR_I2C */
#define MCF_GPIO_SRCR_I2C_I2C_SRE0               (0x01)
#define MCF_GPIO_SRCR_I2C_I2C_SRE1               (0x02)

/* Bit definitions and macros for MCF_GPIO_SRCR_EPORT */
#define MCF_GPIO_SRCR_EPORT_IRQ1_SRE0            (0x01)
#define MCF_GPIO_SRCR_EPORT_IRQ1_SRE1            (0x02)
#define MCF_GPIO_SRCR_EPORT_IRQ0_SRE0            (0x04)
#define MCF_GPIO_SRCR_EPORT_IRQ0_SRE1            (0x08)

/* Bit definitions and macros for MCF_GPIO_SRCR_SIM */
#define MCF_GPIO_SRCR_SIM_SIMP1_SRE0             (0x01)
#define MCF_GPIO_SRCR_SIM_SIMP1_SRE1             (0x02)
#define MCF_GPIO_SRCR_SIM_SIMP0_SRE0             (0x04)
#define MCF_GPIO_SRCR_SIM_SIMP0_SRE1             (0x08)

/* Bit definitions and macros for MCF_GPIO_SRCR_TIMER */
#define MCF_GPIO_SRCR_TIMER_TIMER_SRE0           (0x01)
#define MCF_GPIO_SRCR_TIMER_TIMER_SRE1           (0x02)

/* Bit definitions and macros for MCF_GPIO_SRCR_UART */
#define MCF_GPIO_SRCR_UART_UART0_SRE0            (0x01)
#define MCF_GPIO_SRCR_UART_UART0_SRE1            (0x02)
#define MCF_GPIO_SRCR_UART_UART2_SRE0            (0x04)
#define MCF_GPIO_SRCR_UART_UART2_SRE1            (0x08)

/* Bit definitions and macros for MCF_GPIO_SRCR_SDHC */
#define MCF_GPIO_SRCR_SDHC_SDHC_SRE0             (0x01)
#define MCF_GPIO_SRCR_SDHC_SDHC_SRE1             (0x02)

/* Bit definitions and macros for MCF_GPIO_SRCR_SSI */
#define MCF_GPIO_SRCR_SSI_SSI_SRE0               (0x01)
#define MCF_GPIO_SRCR_SSI_SSI_SRE1               (0x02)

/* Bit definitions and macros for MCF_GPIO_PCRH */
#define MCF_GPIO_PCRH_SSI_PUS                    (0x01)
#define MCF_GPIO_PCRH_SSI_PUE                    (0x02)
#define MCF_GPIO_PCRH_EPORT1_5_FEC_PUS           (0x04)
#define MCF_GPIO_PCRH_SIMP1_XMT_IO_PUS           (0x08)
#define MCF_GPIO_PCRH_SIMP1_XMT_IO_PUE           (0x10)
#define MCF_GPIO_PCRH_SIMP1_VEN_PUS              (0x20)
#define MCF_GPIO_PCRH_SIMP1_VEN_PUE              (0x40)
#define MCF_GPIO_PCRH_DSPI_PCS0_SS_B_PUE         (0x80)

/* Bit definitions and macros for MCF_GPIO_PCRL */
#define MCF_GPIO_PCRL_I2C_SDA_PUE                (0x01)
#define MCF_GPIO_PCRL_I2C_SCI_PUE                (0x02)
#define MCF_GPIO_PCRL_SDHC_CMD_PUE               (0x04)
#define MCF_GPIO_PCRL_SDHC_DAT0_PUE              (0x08)
#define MCF_GPIO_PCRL_SDHC_DAT1_PUE              (0x10)
#define MCF_GPIO_PCRL_SDHC_DAT2_PUE              (0x20)
#define MCF_GPIO_PCRL_SDHC_DAT3_PUS              (0x40)
#define MCF_GPIO_PCRL_SDHC_DAT3_PUE              (0x80)

/********************************************************************/

#endif /* __MCF5301X_GPIO_H__ */
