/*
 * File:		m5275evb.h
 * Purpose:		Evaluation board definitions and memory map information
 *
 * Notes:
 */

#ifndef __M5275EVB_H__
#define __M5275EVB_H__

/********************************************************************/

#include "mcf5xxx.h"
#include "mcf5275.h"
#include "io.h"

/********************************************************************/

/*
 * Debug prints ON (#undef) or OFF (#define)
 */
#undef DEBUG

/* 
 * System Bus Clock Info 
 */
#define REF_CLK_MHZ     (25)
#define REF_CLK_KHZ     (25000)
#define	SYS_CLK_MHZ		75		/* system bus frequency in MHz */
#define SYS_CLK_KHZ		75000	/* system bus frequency in kHz */
#define PERIOD			13		/* system bus period in ns */
/*
 * Ethernet Port Info - EVB dependent PHY address setting.
 */
#define FEC_PHY0            (0x01)	//FSL DIP switchs PHYAD[3-1]=0/open...addr=1
#define FEC_PHY1            (0x02)  //FSL DIP switch PHYAD[3-1]=0001, addr=2
 
#define FEC_PHYADDR0        (0x00)
#define FEC_PHYADDR1        (0x01)

#define FEC_CH0             (0x00)
#define FEC_CH1             (0x01)
/* 
 * Memory map definitions from linker command files 
 */
extern uint8 __IPSBAR[];
extern uint8 __SDRAM[];
extern uint8 __SDRAM_SIZE[];
extern uint8 __SRAM[];
extern uint8 __SRAM_SIZE[];
extern uint8 __EXT_SRAM[];
extern uint8 __EXT_SRAM_SIZE[];
extern uint8 __EXT_FLASH[];
extern uint8 __EXT_FLASH_SIZE[];

/* 
 * Memory Map Info 
 */
#define IPSBAR_ADDRESS			(uint32)__IPSBAR

#define SDRAM_ADDRESS			(uint32)__SDRAM
#define SDRAM_SIZE				(uint32)__SDRAM_SIZE

#define SRAM_ADDRESS			(uint32)__SRAM
#define SRAM_SIZE				(uint32)__SRAM_SIZE

#define EXT_SRAM_ADDRESS		(uint32)__EXT_SRAM
#define EXT_SRAM_SIZE			(uint32)__EXT_SRAM_SIZE

#define EXT_FLASH_ADDRESS		(uint32)__EXT_FLASH
#define EXT_FLASH_SIZE			(uint32)__EXT_FLASH_SIZE

/*
 *	Interrupt Controller Definitions
 */
#define TIMER_NETWORK_LEVEL		3
#define FEC_LEVEL				4

/*
 *	Timer period info
 */
#define TIMER_NETWORK_PERIOD	1000000000/0x10000	/* 1 sec / max timeout */


/*
 *  SDRAM Timing Parameters
 */  

#define SDRAM_BL		8		/* # of beats in a burst */
#define SDRAM_TWR		15  	/* in ns */
#define SDRAM_DBL_CASL	4 		/* double the CASL in clocks */
#define SDRAM_TRCD		20		/* in ns */
#define SDRAM_TRP		20		/* in ns */
#define SDRAM_TRFC		75		/* in ns */
#define SDRAM_TREFI		7800	/* in ns */

/********************************************************************/
/*
 * LED Info
 */
#undef HAS_LEDS
#define HAS_LEDS 1

/********************************************************************/
#ifdef HAS_LEDS		//FSL updated the LED definitions to work with m5275evb
					//FSL m5275evb has 8 LEDs so I added them into MACRO below so two LEDs toggle for each MACRO call
static unsigned char LED3=1,LED2=1,LED1=1,LED0=1;
					
	#define LED0_TOGGLE     MCF_GPIO_PODR_TIMERL = (uint8)(MCF_GPIO_PODR_TIMERL ^ (MCF_GPIO_PODR_TIMERL_PODR_TIMERL1 | MCF_GPIO_PODR_TIMERL_PODR_TIMERL0))
	#define LED1_TOGGLE     MCF_GPIO_PODR_TIMERL = (uint8)(MCF_GPIO_PODR_TIMERL ^ (MCF_GPIO_PODR_TIMERL_PODR_TIMERL3 | MCF_GPIO_PODR_TIMERL_PODR_TIMERL2))
	#define LED2_TOGGLE     MCF_GPIO_PODR_TIMERH = (uint8)(MCF_GPIO_PODR_TIMERH ^ (MCF_GPIO_PODR_TIMERH_PODR_TIMERH1 | MCF_GPIO_PODR_TIMERH_PODR_TIMERH0))
	#define LED3_TOGGLE     MCF_GPIO_PODR_TIMERH = (uint8)(MCF_GPIO_PODR_TIMERH ^ (MCF_GPIO_PODR_TIMERH_PODR_TIMERH3 | MCF_GPIO_PODR_TIMERH_PODR_TIMERH2))

	#define LED0_ON     	MCF_GPIO_PODR_TIMERH = (uint8)(MCF_GPIO_PODR_TIMERH | MCF_GPIO_PODR_TIMERH_PODR_TIMERH0)
	#define LED1_ON		    MCF_GPIO_PODR_TIMERH = (uint8)(MCF_GPIO_PODR_TIMERH | MCF_GPIO_PODR_TIMERH_PODR_TIMERH1)
	#define LED2_ON         MCF_GPIO_PODR_TIMERH = (uint8)(MCF_GPIO_PODR_TIMERH | MCF_GPIO_PODR_TIMERH_PODR_TIMERH2)
	#define LED3_ON         MCF_GPIO_PODR_TIMERH = (uint8)(MCF_GPIO_PODR_TIMERH | MCF_GPIO_PODR_TIMERH_PODR_TIMERH3)

	#define LED0_OFF        MCF_GPIO_PODR_TIMERH = (uint8)(MCF_GPIO_PODR_TIMERH & ~MCF_GPIO_PODR_TIMERH_PODR_TIMERH0)
	#define LED1_OFF        MCF_GPIO_PODR_TIMERH = (uint8)(MCF_GPIO_PODR_TIMERH & ~MCF_GPIO_PODR_TIMERH_PODR_TIMERH1)
	#define LED2_OFF        MCF_GPIO_PODR_TIMERH = (uint8)(MCF_GPIO_PODR_TIMERH & ~MCF_GPIO_PODR_TIMERH_PODR_TIMERH2)
	#define LED3_OFF        MCF_GPIO_PODR_TIMERH = (uint8)(MCF_GPIO_PODR_TIMERH & ~MCF_GPIO_PODR_TIMERH_PODR_TIMERH3)

	#define LED_INIT()		Leds_Init()
#else  /* No LEDS  */
	#define LED0_TOGGLE     /*MCF_GPIO_PORTTC = (uint8)(MCF_GPIO_PORTTC ^ MCF_GPIO_PORTTC_PORTTC0)*/
	#define LED1_TOGGLE     /*MCF_GPIO_PORTTC = (uint8)(MCF_GPIO_PORTTC ^ MCF_GPIO_PORTTC_PORTTC1)*/;
	#define LED2_TOGGLE     /*MCF_GPIO_PORTTC = (uint8)(MCF_GPIO_PORTTC ^ MCF_GPIO_PORTTC_PORTTC2)*/;
	#define LED3_TOGGLE     /*MCF_GPIO_PORTTC = (uint8)(MCF_GPIO_PORTTC ^ MCF_GPIO_PORTTC_PORTTC3)*/;

	#define LED0_ON     	/*MCF_GPIO_PORTTC = (uint8)(MCF_GPIO_PORTTC | MCF_GPIO_PORTTC_PORTTC0)*/
	#define LED1_ON		    /*MCF_GPIO_PORTTC = (uint8)(MCF_GPIO_PORTTC | MCF_GPIO_PORTTC_PORTTC1)*/;
	#define LED2_ON         /*MCF_GPIO_PORTTC = (uint8)(MCF_GPIO_PORTTC | MCF_GPIO_PORTTC_PORTTC2)*/;
	#define LED3_ON         /*MCF_GPIO_PORTTC = (uint8)(MCF_GPIO_PORTTC | MCF_GPIO_PORTTC_PORTTC3)*/;

	#define LED0_OFF        /*MCF_GPIO_PORTTC = (uint8)(MCF_GPIO_PORTTC & ~MCF_GPIO_PORTTC_PORTTC0)*/
	#define LED1_OFF        /*MCF_GPIO_PORTTC = (uint8)(MCF_GPIO_PORTTC & ~MCF_GPIO_PORTTC_PORTTC1)*/;
	#define LED2_OFF        /*MCF_GPIO_PORTTC = (uint8)(MCF_GPIO_PORTTC & ~MCF_GPIO_PORTTC_PORTTC2)*/;
	#define LED3_OFF        /*MCF_GPIO_PORTTC = (uint8)(MCF_GPIO_PORTTC & ~MCF_GPIO_PORTTC_PORTTC3)*/;
	#define LED_INIT()		/*void()*/
	#define RXLED_TOGGLE     /*MCF_GPIO_PORTLD = (uint8)(MCF_GPIO_PORTLD ^ MCF_GPIO_PORTLD_PORTLD5)*/;
	#define TXLED_TOGGLE     /*MCF_GPIO_PORTLD = (uint8)(MCF_GPIO_PORTLD ^ MCF_GPIO_PORTLD_PORTLD6)*/;
	#define ACTLED_TOGGLE    /*MCF_GPIO_PORTLD = (uint8)(MCF_GPIO_PORTLD ^ MCF_GPIO_PORTLD_PORTLD0)*/;
#endif

/********************************************************************/
void Leds_Init();
void board_led_display(uint8 number);
void evb_specific_collect_sensor_data( void );

/********************************************************************/

#endif /* __M5275EVB_H__ */
