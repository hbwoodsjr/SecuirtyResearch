/*
 * File:		m5275evb.c
 * Purpose:		Source to EVB specific routines
 *
 * Notes:
 */
/********************************************************************/
#include "common.h"
//FSL added below extern's
extern uint32	html_vars[];
extern uint8	html_vars_flags[];
extern uint32	hit_counter;

void evb_specific_collect_sensor_data( void );		//FSL added function prototype

/********************************************************************/
/*
 * Setup LED on the EVB
 */
void
Leds_Init(void){
//user LEDs
    /* Enable signals as GPIO */		//FSL Note the M5275EVB has 8 LEDs
    MCF_GPIO_PODR_TIMERH	= 0xF;		//FSL bit0=LED0, bit1=LED1, bit2=LED2, bit3=LED3;1=ON, 0=OFF
    MCF_GPIO_PDDR_TIMERH	= 0xF;		//FSL 1=output direction, 0=input direction
    MCF_GPIO_PODR_TIMERL	= 0xF;		//FSL bit0=LED0, bit1=LED1, bit2=LED2, bit3=LED3;1=ON, 0=OFF
    MCF_GPIO_PDDR_TIMERL	= 0xF;		//FSL 1=output direction, 0=input direction
    MCF_GPIO_PAR_TIMER		= 0x0;		//FSL T[3:0]OUT set to GPIO function
    
	return;
}

/********************************************************************/
/* 
 * Display the lower 4 bits of 'number' on the 4 LEDs connected to 
 * TIN[3:0]
 *
 *  LED: LED4 LED3 LED2 LED1
 *  PIN: TIN3 TIN2 TIN1 TIN0
 *  BIT:    3    2    1    0
 */
void
board_led_display(uint8 number)
{
    /* Set output values */
    return;
}
/********************************************************************/


/********************************************************************/
// Poll switch status
/********************************************************************/
int poll_switches( void )
{
	int		map;

	map = 0;

    
    return( map );
}
/********************************************************************/


/*********************************************************************
* init_adc - Analog-to-Digital Converter (ADC)                       *
**********************************************************************/
void init_adc (void)
{
	return;
}


void start_AD( void )
{
	return;
}


short read_AD( int channel )
{
	return(0);
}


void evb_specific_collect_sensor_data( void )
{
	html_vars[0] 		= 0;
	html_vars_flags[0] 	= 1;

	html_vars[1] 		= poll_switches();
	html_vars_flags[1] 	= 1;

	html_vars[2]		= hit_counter++;
	html_vars_flags[2] 	= 1;

	html_vars[3]		= read_AD(0);
	html_vars_flags[3] 	= 1;

	html_vars[4]		= read_AD(1);;
	html_vars_flags[4] 	= 1;

	html_vars[5]		= 0;
	html_vars_flags[5] 	= 1;

	html_vars[6]		= 0;
	html_vars_flags[6] 	= 1;

	html_vars[7]		= read_AD(4);
	html_vars_flags[7] 	= 1;

	html_vars[8]		= read_AD(5);
	html_vars_flags[8] 	= 1;

	html_vars[9]		= read_AD(6);
	html_vars_flags[9] 	= 1;

	html_vars[10]		= 0;
	html_vars_flags[10] = 1;

	html_vars[11]		= 0;
	html_vars_flags[11] = 1;

	html_vars[12]		= 0;
	html_vars_flags[12] = 1;

	html_vars[13]		= 0;
	html_vars_flags[13] = 1;
}