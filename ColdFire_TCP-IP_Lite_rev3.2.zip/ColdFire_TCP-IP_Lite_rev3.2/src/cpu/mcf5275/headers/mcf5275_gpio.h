/*
 * File:	mcf5275_gpio.h
 * Purpose:	Register and bit definitions for the MCF5275
 *
 * Notes:	
 *	
 */

#ifndef __MCF5275_GPIO_H__
#define __MCF5275_GPIO_H__

/*********************************************************************
*
* General Purpose I/O (GPIO)
*
*********************************************************************/

/* Register read/write macros */
#define MCF_GPIO_PODR_BUSCTL      (*(vuint8 *)(void*)(&__IPSBAR[0x100004]))
#define MCF_GPIO_PODR_ADDR        (*(vuint8 *)(void*)(&__IPSBAR[0x100005]))
#define MCF_GPIO_PODR_CS          (*(vuint8 *)(void*)(&__IPSBAR[0x100008]))
#define MCF_GPIO_PODR_FEC0H       (*(vuint8 *)(void*)(&__IPSBAR[0x10000A]))
#define MCF_GPIO_PODR_FEC0L       (*(vuint8 *)(void*)(&__IPSBAR[0x10000B]))
#define MCF_GPIO_PODR_FECI2C      (*(vuint8 *)(void*)(&__IPSBAR[0x10000C]))
#define MCF_GPIO_PODR_QSPI        (*(vuint8 *)(void*)(&__IPSBAR[0x10000D]))
#define MCF_GPIO_PODR_SDRAM       (*(vuint8 *)(void*)(&__IPSBAR[0x10000E]))
#define MCF_GPIO_PODR_TIMERH      (*(vuint8 *)(void*)(&__IPSBAR[0x10000F]))
#define MCF_GPIO_PODR_TIMERL      (*(vuint8 *)(void*)(&__IPSBAR[0x100010]))
#define MCF_GPIO_PODR_UARTL       (*(vuint8 *)(void*)(&__IPSBAR[0x100011]))
#define MCF_GPIO_PODR_FEC1H       (*(vuint8 *)(void*)(&__IPSBAR[0x100012]))
#define MCF_GPIO_PODR_FEC1L       (*(vuint8 *)(void*)(&__IPSBAR[0x100013]))
#define MCF_GPIO_PODR_BS          (*(vuint8 *)(void*)(&__IPSBAR[0x100014]))
#define MCF_GPIO_PODR_IRQ         (*(vuint8 *)(void*)(&__IPSBAR[0x100015]))
#define MCF_GPIO_PODR_USBH        (*(vuint8 *)(void*)(&__IPSBAR[0x100016]))
#define MCF_GPIO_PODR_USBL        (*(vuint8 *)(void*)(&__IPSBAR[0x100017]))
#define MCF_GPIO_PODR_UARTH       (*(vuint8 *)(void*)(&__IPSBAR[0x100018]))
#define MCF_GPIO_PDDR_BUSCTL      (*(vuint8 *)(void*)(&__IPSBAR[0x100020]))
#define MCF_GPIO_PDDR_ADDR        (*(vuint8 *)(void*)(&__IPSBAR[0x100021]))
#define MCF_GPIO_PDDR_CS          (*(vuint8 *)(void*)(&__IPSBAR[0x100024]))
#define MCF_GPIO_PDDR_FEC0H       (*(vuint8 *)(void*)(&__IPSBAR[0x100026]))
#define MCF_GPIO_PDDR_FEC0L       (*(vuint8 *)(void*)(&__IPSBAR[0x100027]))
#define MCF_GPIO_PDDR_FECI2C      (*(vuint8 *)(void*)(&__IPSBAR[0x100028]))
#define MCF_GPIO_PDDR_QSPI        (*(vuint8 *)(void*)(&__IPSBAR[0x100029]))
#define MCF_GPIO_PDDR_SDRAM       (*(vuint8 *)(void*)(&__IPSBAR[0x10002A]))
#define MCF_GPIO_PDDR_TIMERH      (*(vuint8 *)(void*)(&__IPSBAR[0x10002B]))
#define MCF_GPIO_PDDR_TIMERL      (*(vuint8 *)(void*)(&__IPSBAR[0x10002C]))
#define MCF_GPIO_PDDR_UARTL       (*(vuint8 *)(void*)(&__IPSBAR[0x10002D]))
#define MCF_GPIO_PDDR_FEC1H       (*(vuint8 *)(void*)(&__IPSBAR[0x10002E]))
#define MCF_GPIO_PDDR_FEC1L       (*(vuint8 *)(void*)(&__IPSBAR[0x10002F]))
#define MCF_GPIO_PDDR_BS          (*(vuint8 *)(void*)(&__IPSBAR[0x100030]))
#define MCF_GPIO_PDDR_IRQ         (*(vuint8 *)(void*)(&__IPSBAR[0x100031]))
#define MCF_GPIO_PDDR_USBH        (*(vuint8 *)(void*)(&__IPSBAR[0x100032]))
#define MCF_GPIO_PDDR_USBL        (*(vuint8 *)(void*)(&__IPSBAR[0x100033]))
#define MCF_GPIO_PDDR_UARTH       (*(vuint8 *)(void*)(&__IPSBAR[0x100034]))
#define MCF_GPIO_PPDSDR_BUSCTL    (*(vuint8 *)(void*)(&__IPSBAR[0x10003C]))
#define MCF_GPIO_PPDSDR_ADDR      (*(vuint8 *)(void*)(&__IPSBAR[0x10003D]))
#define MCF_GPIO_PPDSDR_CS        (*(vuint8 *)(void*)(&__IPSBAR[0x100040]))
#define MCF_GPIO_PPDSDR_FEC0H     (*(vuint8 *)(void*)(&__IPSBAR[0x100042]))
#define MCF_GPIO_PPDSDR_FEC0L     (*(vuint8 *)(void*)(&__IPSBAR[0x100043]))
#define MCF_GPIO_PPDSDR_FECI2C    (*(vuint8 *)(void*)(&__IPSBAR[0x100044]))
#define MCF_GPIO_PPDSDR_QSPI      (*(vuint8 *)(void*)(&__IPSBAR[0x100045]))
#define MCF_GPIO_PPDSDR_SDRAM     (*(vuint8 *)(void*)(&__IPSBAR[0x100046]))
#define MCF_GPIO_PPDSDR_TIMERH    (*(vuint8 *)(void*)(&__IPSBAR[0x100047]))
#define MCF_GPIO_PPDSDR_TIMERL    (*(vuint8 *)(void*)(&__IPSBAR[0x100048]))
#define MCF_GPIO_PPDSDR_UARTL     (*(vuint8 *)(void*)(&__IPSBAR[0x100049]))
#define MCF_GPIO_PPDSDR_FEC1H     (*(vuint8 *)(void*)(&__IPSBAR[0x10004A]))
#define MCF_GPIO_PPDSDR_FEC1L     (*(vuint8 *)(void*)(&__IPSBAR[0x10004B]))
#define MCF_GPIO_PPDSDR_BS        (*(vuint8 *)(void*)(&__IPSBAR[0x10004C]))
#define MCF_GPIO_PPDSDR_IRQ       (*(vuint8 *)(void*)(&__IPSBAR[0x10004D]))
#define MCF_GPIO_PPDSDR_USBH      (*(vuint8 *)(void*)(&__IPSBAR[0x10004E]))
#define MCF_GPIO_PPDSDR_USBL      (*(vuint8 *)(void*)(&__IPSBAR[0x10004F]))
#define MCF_GPIO_PPDSDR_UARTH     (*(vuint8 *)(void*)(&__IPSBAR[0x100050]))
#define MCF_GPIO_PCLRR_BUSCTL     (*(vuint8 *)(void*)(&__IPSBAR[0x100058]))
#define MCF_GPIO_PCLRR_ADDR       (*(vuint8 *)(void*)(&__IPSBAR[0x100059]))
#define MCF_GPIO_PCLRR_CS         (*(vuint8 *)(void*)(&__IPSBAR[0x10005C]))
#define MCF_GPIO_PCLRR_FEC0H      (*(vuint8 *)(void*)(&__IPSBAR[0x10005E]))
#define MCF_GPIO_PCLRR_FEC0L      (*(vuint8 *)(void*)(&__IPSBAR[0x10005F]))
#define MCF_GPIO_PCLRR_FECI2C     (*(vuint8 *)(void*)(&__IPSBAR[0x100060]))
#define MCF_GPIO_PCLRR_QSPI       (*(vuint8 *)(void*)(&__IPSBAR[0x100061]))
#define MCF_GPIO_PCLRR_SDRAM      (*(vuint8 *)(void*)(&__IPSBAR[0x100062]))
#define MCF_GPIO_PCLRR_TIMERH     (*(vuint8 *)(void*)(&__IPSBAR[0x100063]))
#define MCF_GPIO_PCLRR_TIMERL     (*(vuint8 *)(void*)(&__IPSBAR[0x100064]))
#define MCF_GPIO_PCLRR_UARTL      (*(vuint8 *)(void*)(&__IPSBAR[0x100065]))
#define MCF_GPIO_PCLRR_FEC1H      (*(vuint8 *)(void*)(&__IPSBAR[0x100066]))
#define MCF_GPIO_PCLRR_FEC1L      (*(vuint8 *)(void*)(&__IPSBAR[0x100067]))
#define MCF_GPIO_PCLRR_BS         (*(vuint8 *)(void*)(&__IPSBAR[0x100068]))
#define MCF_GPIO_PCLRR_IRQ        (*(vuint8 *)(void*)(&__IPSBAR[0x100069]))
#define MCF_GPIO_PCLRR_USBH       (*(vuint8 *)(void*)(&__IPSBAR[0x10006A]))
#define MCF_GPIO_PCLRR_USBL       (*(vuint8 *)(void*)(&__IPSBAR[0x10006B]))
#define MCF_GPIO_PCLRR_UARTH      (*(vuint8 *)(void*)(&__IPSBAR[0x10006C]))
#define MCF_GPIO_PAR_ADDR         (*(vuint8 *)(void*)(&__IPSBAR[0x100070]))
#define MCF_GPIO_PAR_CS           (*(vuint8 *)(void*)(&__IPSBAR[0x100071]))
#define MCF_GPIO_PAR_BUSCTL       (*(vuint16*)(void*)(&__IPSBAR[0x100072]))
#define MCF_GPIO_PAR_IRQ          (*(vuint16*)(void*)(&__IPSBAR[0x100074]))
#define MCF_GPIO_PAR_USB          (*(vuint16*)(void*)(&__IPSBAR[0x100076]))
#define MCF_GPIO_PAR_FEC0HL       (*(vuint8 *)(void*)(&__IPSBAR[0x100078]))
#define MCF_GPIO_PAR_FEC1HL       (*(vuint8 *)(void*)(&__IPSBAR[0x100079]))
#define MCF_GPIO_PAR_TIMER        (*(vuint16*)(void*)(&__IPSBAR[0x10007A]))
#define MCF_GPIO_PAR_UART         (*(vuint16*)(void*)(&__IPSBAR[0x10007C]))
#define MCF_GPIO_PAR_QSPI         (*(vuint16*)(void*)(&__IPSBAR[0x10007E]))
#define MCF_GPIO_PAR_SDRAM        (*(vuint16*)(void*)(&__IPSBAR[0x100080]))
#define MCF_GPIO_PAR_FECI2C       (*(vuint16*)(void*)(&__IPSBAR[0x100082]))
#define MCF_GPIO_PAR_BS           (*(vuint8 *)(void*)(&__IPSBAR[0x100084]))

/* Bit definitions and macros for MCF_GPIO_PODR_BUSCTL */
#define MCF_GPIO_PODR_BUSCTL_PODR_BUSCTL0        (0x01)
#define MCF_GPIO_PODR_BUSCTL_PODR_BUSCTL1        (0x02)
#define MCF_GPIO_PODR_BUSCTL_PODR_BUSCTL2        (0x04)
#define MCF_GPIO_PODR_BUSCTL_PODR_BUSCTL3        (0x08)
#define MCF_GPIO_PODR_BUSCTL_PODR_BUSCTL4        (0x10)
#define MCF_GPIO_PODR_BUSCTL_PODR_BUSCTL5        (0x20)
#define MCF_GPIO_PODR_BUSCTL_PODR_BUSCTL6        (0x40)
#define MCF_GPIO_PODR_BUSCTL_PODR_BUSCTL7        (0x80)

/* Bit definitions and macros for MCF_GPIO_PODR_ADDR */
#define MCF_GPIO_PODR_ADDR_PODR_ADDR5            (0x20)
#define MCF_GPIO_PODR_ADDR_PODR_ADDR6            (0x40)
#define MCF_GPIO_PODR_ADDR_PODR_ADDR7            (0x80)

/* Bit definitions and macros for MCF_GPIO_PODR_CS */
#define MCF_GPIO_PODR_CS_PODR_CS1                (0x02)
#define MCF_GPIO_PODR_CS_PODR_CS2                (0x04)
#define MCF_GPIO_PODR_CS_PODR_CS3                (0x08)
#define MCF_GPIO_PODR_CS_PODR_CS4                (0x10)
#define MCF_GPIO_PODR_CS_PODR_CS5                (0x20)
#define MCF_GPIO_PODR_CS_PODR_CS6                (0x40)
#define MCF_GPIO_PODR_CS_PODR_CS7                (0x80)

/* Bit definitions and macros for MCF_GPIO_PODR_FEC0H */
#define MCF_GPIO_PODR_FEC0H_PODR_FEC0H0          (0x01)
#define MCF_GPIO_PODR_FEC0H_PODR_FEC0H1          (0x02)
#define MCF_GPIO_PODR_FEC0H_PODR_FEC0H2          (0x04)
#define MCF_GPIO_PODR_FEC0H_PODR_FEC0H3          (0x08)
#define MCF_GPIO_PODR_FEC0H_PODR_FEC0H4          (0x10)
#define MCF_GPIO_PODR_FEC0H_PODR_FEC0H5          (0x20)
#define MCF_GPIO_PODR_FEC0H_PODR_FEC0H6          (0x40)
#define MCF_GPIO_PODR_FEC0H_PODR_FEC0H7          (0x80)

/* Bit definitions and macros for MCF_GPIO_PODR_FEC0L */
#define MCF_GPIO_PODR_FEC0L_PODR_FEC0L0          (0x01)
#define MCF_GPIO_PODR_FEC0L_PODR_FEC0L1          (0x02)
#define MCF_GPIO_PODR_FEC0L_PODR_FEC0L2          (0x04)
#define MCF_GPIO_PODR_FEC0L_PODR_FEC0L3          (0x08)
#define MCF_GPIO_PODR_FEC0L_PODR_FEC0L4          (0x10)
#define MCF_GPIO_PODR_FEC0L_PODR_FEC0L5          (0x20)
#define MCF_GPIO_PODR_FEC0L_PODR_FEC0L6          (0x40)
#define MCF_GPIO_PODR_FEC0L_PODR_FEC0L7          (0x80)

/* Bit definitions and macros for MCF_GPIO_PODR_FECI2C */
#define MCF_GPIO_PODR_FECI2C_PODR_FECI2C0        (0x01)
#define MCF_GPIO_PODR_FECI2C_PODR_FECI2C1        (0x02)
#define MCF_GPIO_PODR_FECI2C_PODR_FECI2C2        (0x04)
#define MCF_GPIO_PODR_FECI2C_PODR_FECI2C3        (0x08)
#define MCF_GPIO_PODR_FECI2C_PODR_FECI2C4        (0x10)
#define MCF_GPIO_PODR_FECI2C_PODR_FECI2C5        (0x20)

/* Bit definitions and macros for MCF_GPIO_PODR_QSPI */
#define MCF_GPIO_PODR_QSPI_PODR_QSPI0            (0x01)
#define MCF_GPIO_PODR_QSPI_PODR_QSPI1            (0x02)
#define MCF_GPIO_PODR_QSPI_PODR_QSPI2            (0x04)
#define MCF_GPIO_PODR_QSPI_PODR_QSPI3            (0x08)
#define MCF_GPIO_PODR_QSPI_PODR_QSPI4            (0x10)
#define MCF_GPIO_PODR_QSPI_PODR_QSPI5            (0x20)
#define MCF_GPIO_PODR_QSPI_PODR_QSPI6            (0x40)

/* Bit definitions and macros for MCF_GPIO_PODR_SDRAM */
#define MCF_GPIO_PODR_SDRAM_PODR_SDRAM0          (0x01)
#define MCF_GPIO_PODR_SDRAM_PODR_SDRAM1          (0x02)
#define MCF_GPIO_PODR_SDRAM_PODR_SDRAM2          (0x04)
#define MCF_GPIO_PODR_SDRAM_PODR_SDRAM3          (0x08)
#define MCF_GPIO_PODR_SDRAM_PODR_SDRAM4          (0x10)
#define MCF_GPIO_PODR_SDRAM_PODR_SDRAM5          (0x20)
#define MCF_GPIO_PODR_SDRAM_PODR_SDRAM6          (0x40)
#define MCF_GPIO_PODR_SDRAM_PODR_SDRAM7          (0x80)

/* Bit definitions and macros for MCF_GPIO_PODR_TIMERH */
#define MCF_GPIO_PODR_TIMERH_PODR_TIMERH0        (0x01)
#define MCF_GPIO_PODR_TIMERH_PODR_TIMERH1        (0x02)
#define MCF_GPIO_PODR_TIMERH_PODR_TIMERH2        (0x04)
#define MCF_GPIO_PODR_TIMERH_PODR_TIMERH3        (0x08)

/* Bit definitions and macros for MCF_GPIO_PODR_TIMERL */
#define MCF_GPIO_PODR_TIMERL_PODR_TIMERL0        (0x01)
#define MCF_GPIO_PODR_TIMERL_PODR_TIMERL1        (0x02)
#define MCF_GPIO_PODR_TIMERL_PODR_TIMERL2        (0x04)
#define MCF_GPIO_PODR_TIMERL_PODR_TIMERL3        (0x08)

/* Bit definitions and macros for MCF_GPIO_PODR_UARTL */
#define MCF_GPIO_PODR_UARTL_PODR_UARTL0          (0x01)
#define MCF_GPIO_PODR_UARTL_PODR_UARTL1          (0x02)
#define MCF_GPIO_PODR_UARTL_PODR_UARTL2          (0x04)
#define MCF_GPIO_PODR_UARTL_PODR_UARTL3          (0x08)
#define MCF_GPIO_PODR_UARTL_PODR_UARTL4          (0x10)
#define MCF_GPIO_PODR_UARTL_PODR_UARTL5          (0x20)
#define MCF_GPIO_PODR_UARTL_PODR_UARTL6          (0x40)
#define MCF_GPIO_PODR_UARTL_PODR_UARTL7          (0x80)

/* Bit definitions and macros for MCF_GPIO_PODR_FEC1H */
#define MCF_GPIO_PODR_FEC1H_PODR_FEC1H0          (0x01)
#define MCF_GPIO_PODR_FEC1H_PODR_FEC1H1          (0x02)
#define MCF_GPIO_PODR_FEC1H_PODR_FEC1H2          (0x04)
#define MCF_GPIO_PODR_FEC1H_PODR_FEC1H3          (0x08)
#define MCF_GPIO_PODR_FEC1H_PODR_FEC1H4          (0x10)
#define MCF_GPIO_PODR_FEC1H_PODR_FEC1H5          (0x20)
#define MCF_GPIO_PODR_FEC1H_PODR_FEC1H6          (0x40)
#define MCF_GPIO_PODR_FEC1H_PODR_FEC1H7          (0x80)

/* Bit definitions and macros for MCF_GPIO_PODR_FEC1L */
#define MCF_GPIO_PODR_FEC1L_PODR_FEC1L0          (0x01)
#define MCF_GPIO_PODR_FEC1L_PODR_FEC1L1          (0x02)
#define MCF_GPIO_PODR_FEC1L_PODR_FEC1L2          (0x04)
#define MCF_GPIO_PODR_FEC1L_PODR_FEC1L3          (0x08)
#define MCF_GPIO_PODR_FEC1L_PODR_FEC1L4          (0x10)
#define MCF_GPIO_PODR_FEC1L_PODR_FEC1L5          (0x20)
#define MCF_GPIO_PODR_FEC1L_PODR_FEC1L6          (0x40)
#define MCF_GPIO_PODR_FEC1L_PODR_FEC1L7          (0x80)

/* Bit definitions and macros for MCF_GPIO_PODR_BS */
#define MCF_GPIO_PODR_BS_PODR_BS2                (0x04)
#define MCF_GPIO_PODR_BS_PODR_BS3                (0x08)

/* Bit definitions and macros for MCF_GPIO_PODR_IRQ */
#define MCF_GPIO_PODR_IRQ_PODR_IRQ(x)            (((x)&0x7F)<<1)

/* Bit definitions and macros for MCF_GPIO_PODR_USBH */
#define MCF_GPIO_PODR_USBH_PODR_USBH0            (0x01)

/* Bit definitions and macros for MCF_GPIO_PODR_USBL */
#define MCF_GPIO_PODR_USBL_PODR_USBL0            (0x01)
#define MCF_GPIO_PODR_USBL_PODR_USBL1            (0x02)
#define MCF_GPIO_PODR_USBL_PODR_USBL2            (0x04)
#define MCF_GPIO_PODR_USBL_PODR_USBL3            (0x08)
#define MCF_GPIO_PODR_USBL_PODR_USBL4            (0x10)
#define MCF_GPIO_PODR_USBL_PODR_USBL5            (0x20)
#define MCF_GPIO_PODR_USBL_PODR_USBL6            (0x40)
#define MCF_GPIO_PODR_USBL_PODR_USBL7            (0x80)

/* Bit definitions and macros for MCF_GPIO_PODR_UARTH */
#define MCF_GPIO_PODR_UARTH_PODR_UART0           (0x01)
#define MCF_GPIO_PODR_UARTH_PODR_UART1           (0x02)
#define MCF_GPIO_PODR_UARTH_PODR_UART2           (0x04)
#define MCF_GPIO_PODR_UARTH_PODR_UART3           (0x08)

/* Bit definitions and macros for MCF_GPIO_PDDR_BUSCTL */
#define MCF_GPIO_PDDR_BUSCTL_PDDR_BUSCTL0        (0x01)
#define MCF_GPIO_PDDR_BUSCTL_PDDR_BUSCTL1        (0x02)
#define MCF_GPIO_PDDR_BUSCTL_PDDR_BUSCTL2        (0x04)
#define MCF_GPIO_PDDR_BUSCTL_PDDR_BUSCTL3        (0x08)
#define MCF_GPIO_PDDR_BUSCTL_PDDR_BUSCTL4        (0x10)
#define MCF_GPIO_PDDR_BUSCTL_PDDR_BUSCTL5        (0x20)
#define MCF_GPIO_PDDR_BUSCTL_PDDR_BUSCTL6        (0x40)
#define MCF_GPIO_PDDR_BUSCTL_PDDR_BUSCTL7        (0x80)

/* Bit definitions and macros for MCF_GPIO_PDDR_ADDR */
#define MCF_GPIO_PDDR_ADDR_PDDR_ADDR5            (0x20)
#define MCF_GPIO_PDDR_ADDR_PDDR_ADDR6            (0x40)
#define MCF_GPIO_PDDR_ADDR_PDDR_ADDR7            (0x80)

/* Bit definitions and macros for MCF_GPIO_PDDR_CS */
#define MCF_GPIO_PDDR_CS_PDDR_CS1                (0x02)
#define MCF_GPIO_PDDR_CS_PDDR_CS2                (0x04)
#define MCF_GPIO_PDDR_CS_PDDR_CS3                (0x08)
#define MCF_GPIO_PDDR_CS_PDDR_CS4                (0x10)
#define MCF_GPIO_PDDR_CS_PDDR_CS5                (0x20)
#define MCF_GPIO_PDDR_CS_PDDR_CS6                (0x40)
#define MCF_GPIO_PDDR_CS_PDDR_CS7                (0x80)

/* Bit definitions and macros for MCF_GPIO_PDDR_FEC0H */
#define MCF_GPIO_PDDR_FEC0H_PDDR_FEC0H0          (0x01)
#define MCF_GPIO_PDDR_FEC0H_PDDR_FEC0H1          (0x02)
#define MCF_GPIO_PDDR_FEC0H_PDDR_FEC0H2          (0x04)
#define MCF_GPIO_PDDR_FEC0H_PDDR_FEC0H3          (0x08)
#define MCF_GPIO_PDDR_FEC0H_PDDR_FEC0H4          (0x10)
#define MCF_GPIO_PDDR_FEC0H_PDDR_FEC0H5          (0x20)
#define MCF_GPIO_PDDR_FEC0H_PDDR_FEC0H6          (0x40)
#define MCF_GPIO_PDDR_FEC0H_PDDR_FEC0H7          (0x80)

/* Bit definitions and macros for MCF_GPIO_PDDR_FEC0L */
#define MCF_GPIO_PDDR_FEC0L_PDDR_FEC0L0          (0x01)
#define MCF_GPIO_PDDR_FEC0L_PDDR_FEC0L1          (0x02)
#define MCF_GPIO_PDDR_FEC0L_PDDR_FEC0L2          (0x04)
#define MCF_GPIO_PDDR_FEC0L_PDDR_FEC0L3          (0x08)
#define MCF_GPIO_PDDR_FEC0L_PDDR_FEC0L4          (0x10)
#define MCF_GPIO_PDDR_FEC0L_PDDR_FEC0L5          (0x20)
#define MCF_GPIO_PDDR_FEC0L_PDDR_FEC0L6          (0x40)
#define MCF_GPIO_PDDR_FEC0L_PDDR_FEC0L7          (0x80)

/* Bit definitions and macros for MCF_GPIO_PDDR_FECI2C */
#define MCF_GPIO_PDDR_FECI2C_PDDR_FECI2C0        (0x01)
#define MCF_GPIO_PDDR_FECI2C_PDDR_FECI2C1        (0x02)
#define MCF_GPIO_PDDR_FECI2C_PDDR_FECI2C2        (0x04)
#define MCF_GPIO_PDDR_FECI2C_PDDR_FECI2C3        (0x08)
#define MCF_GPIO_PDDR_FECI2C_PDDR_FECI2C4        (0x10)
#define MCF_GPIO_PDDR_FECI2C_PDDR_FECI2C5        (0x20)

/* Bit definitions and macros for MCF_GPIO_PDDR_QSPI */
#define MCF_GPIO_PDDR_QSPI_PDDR_QSPI0            (0x01)
#define MCF_GPIO_PDDR_QSPI_PDDR_QSPI1            (0x02)
#define MCF_GPIO_PDDR_QSPI_PDDR_QSPI2            (0x04)
#define MCF_GPIO_PDDR_QSPI_PDDR_QSPI3            (0x08)
#define MCF_GPIO_PDDR_QSPI_PDDR_QSPI4            (0x10)
#define MCF_GPIO_PDDR_QSPI_PDDR_QSPI5            (0x20)
#define MCF_GPIO_PDDR_QSPI_PDDR_QSPI6            (0x40)

/* Bit definitions and macros for MCF_GPIO_PDDR_SDRAM */
#define MCF_GPIO_PDDR_SDRAM_PDDR_SDRAM0          (0x01)
#define MCF_GPIO_PDDR_SDRAM_PDDR_SDRAM1          (0x02)
#define MCF_GPIO_PDDR_SDRAM_PDDR_SDRAM2          (0x04)
#define MCF_GPIO_PDDR_SDRAM_PDDR_SDRAM3          (0x08)
#define MCF_GPIO_PDDR_SDRAM_PDDR_SDRAM4          (0x10)
#define MCF_GPIO_PDDR_SDRAM_PDDR_SDRAM5          (0x20)
#define MCF_GPIO_PDDR_SDRAM_PDDR_SDRAM6          (0x40)
#define MCF_GPIO_PDDR_SDRAM_PDDR_SDRAM7          (0x80)

/* Bit definitions and macros for MCF_GPIO_PDDR_TIMERH */
#define MCF_GPIO_PDDR_TIMERH_PDDR_TIMERH0        (0x01)
#define MCF_GPIO_PDDR_TIMERH_PDDR_TIMERH1        (0x02)
#define MCF_GPIO_PDDR_TIMERH_PDDR_TIMERH2        (0x04)
#define MCF_GPIO_PDDR_TIMERH_PDDR_TIMERH3        (0x08)

/* Bit definitions and macros for MCF_GPIO_PDDR_TIMERL */
#define MCF_GPIO_PDDR_TIMERL_PDDR_TIMERL0        (0x01)
#define MCF_GPIO_PDDR_TIMERL_PDDR_TIMERL1        (0x02)
#define MCF_GPIO_PDDR_TIMERL_PDDR_TIMERL2        (0x04)
#define MCF_GPIO_PDDR_TIMERL_PDDR_TIMERL3        (0x08)

/* Bit definitions and macros for MCF_GPIO_PDDR_UARTL */
#define MCF_GPIO_PDDR_UARTL_PDDR_UARTL0          (0x01)
#define MCF_GPIO_PDDR_UARTL_PDDR_UARTL1          (0x02)
#define MCF_GPIO_PDDR_UARTL_PDDR_UARTL2          (0x04)
#define MCF_GPIO_PDDR_UARTL_PDDR_UARTL3          (0x08)
#define MCF_GPIO_PDDR_UARTL_PDDR_UARTL4          (0x10)
#define MCF_GPIO_PDDR_UARTL_PDDR_UARTL5          (0x20)
#define MCF_GPIO_PDDR_UARTL_PDDR_UARTL6          (0x40)
#define MCF_GPIO_PDDR_UARTL_PDDR_UARTL7          (0x80)

/* Bit definitions and macros for MCF_GPIO_PDDR_FEC1H */
#define MCF_GPIO_PDDR_FEC1H_PDDR_FEC1H0          (0x01)
#define MCF_GPIO_PDDR_FEC1H_PDDR_FEC1H1          (0x02)
#define MCF_GPIO_PDDR_FEC1H_PDDR_FEC1H2          (0x04)
#define MCF_GPIO_PDDR_FEC1H_PDDR_FEC1H3          (0x08)
#define MCF_GPIO_PDDR_FEC1H_PDDR_FEC1H4          (0x10)
#define MCF_GPIO_PDDR_FEC1H_PDDR_FEC1H5          (0x20)
#define MCF_GPIO_PDDR_FEC1H_PDDR_FEC1H6          (0x40)
#define MCF_GPIO_PDDR_FEC1H_PDDR_FEC1H7          (0x80)

/* Bit definitions and macros for MCF_GPIO_PDDR_FEC1L */
#define MCF_GPIO_PDDR_FEC1L_PDDR_FEC1L0          (0x01)
#define MCF_GPIO_PDDR_FEC1L_PDDR_FEC1L1          (0x02)
#define MCF_GPIO_PDDR_FEC1L_PDDR_FEC1L2          (0x04)
#define MCF_GPIO_PDDR_FEC1L_PDDR_FEC1L3          (0x08)
#define MCF_GPIO_PDDR_FEC1L_PDDR_FEC1L4          (0x10)
#define MCF_GPIO_PDDR_FEC1L_PDDR_FEC1L5          (0x20)
#define MCF_GPIO_PDDR_FEC1L_PDDR_FEC1L6          (0x40)
#define MCF_GPIO_PDDR_FEC1L_PDDR_FEC1L7          (0x80)

/* Bit definitions and macros for MCF_GPIO_PDDR_BS */
#define MCF_GPIO_PDDR_BS_PDDR_BS2                (0x04)
#define MCF_GPIO_PDDR_BS_PDDR_BS3                (0x08)

/* Bit definitions and macros for MCF_GPIO_PDDR_IRQ */
#define MCF_GPIO_PDDR_IRQ_PDDR_IRQ(x)            (((x)&0x7F)<<1)

/* Bit definitions and macros for MCF_GPIO_PDDR_USBH */
#define MCF_GPIO_PDDR_USBH_PDDR_USBH0            (0x01)

/* Bit definitions and macros for MCF_GPIO_PDDR_USBL */
#define MCF_GPIO_PDDR_USBL_PDDR_USBL0            (0x01)
#define MCF_GPIO_PDDR_USBL_PDDR_USBL1            (0x02)
#define MCF_GPIO_PDDR_USBL_PDDR_USBL2            (0x04)
#define MCF_GPIO_PDDR_USBL_PDDR_USBL3            (0x08)
#define MCF_GPIO_PDDR_USBL_PDDR_USBL4            (0x10)
#define MCF_GPIO_PDDR_USBL_PDDR_USBL5            (0x20)
#define MCF_GPIO_PDDR_USBL_PDDR_USBL6            (0x40)
#define MCF_GPIO_PDDR_USBL_PDDR_USBL7            (0x80)

/* Bit definitions and macros for MCF_GPIO_PDDR_UARTH */
#define MCF_GPIO_PDDR_UARTH_PDDR_UART0           (0x01)
#define MCF_GPIO_PDDR_UARTH_PDDR_UART1           (0x02)
#define MCF_GPIO_PDDR_UARTH_PDDR_UART2           (0x04)
#define MCF_GPIO_PDDR_UARTH_PDDR_UART3           (0x08)

/* Bit definitions and macros for MCF_GPIO_PPDSDR_BUSCTL */
#define MCF_GPIO_PPDSDR_BUSCTL_PPDSDR_BUSCTL0    (0x01)
#define MCF_GPIO_PPDSDR_BUSCTL_PPDSDR_BUSCTL1    (0x02)
#define MCF_GPIO_PPDSDR_BUSCTL_PPDSDR_BUSCTL2    (0x04)
#define MCF_GPIO_PPDSDR_BUSCTL_PPDSDR_BUSCTL3    (0x08)
#define MCF_GPIO_PPDSDR_BUSCTL_PPDSDR_BUSCTL4    (0x10)
#define MCF_GPIO_PPDSDR_BUSCTL_PPDSDR_BUSCTL5    (0x20)
#define MCF_GPIO_PPDSDR_BUSCTL_PPDSDR_BUSCTL6    (0x40)
#define MCF_GPIO_PPDSDR_BUSCTL_PPDSDR_BUSCTL7    (0x80)

/* Bit definitions and macros for MCF_GPIO_PPDSDR_ADDR */
#define MCF_GPIO_PPDSDR_ADDR_PPDSDR_ADDR5        (0x20)
#define MCF_GPIO_PPDSDR_ADDR_PPDSDR_ADDR6        (0x40)
#define MCF_GPIO_PPDSDR_ADDR_PPDSDR_ADDR7        (0x80)

/* Bit definitions and macros for MCF_GPIO_PPDSDR_CS */
#define MCF_GPIO_PPDSDR_CS_PPDSDR_CS1            (0x02)
#define MCF_GPIO_PPDSDR_CS_PPDSDR_CS2            (0x04)
#define MCF_GPIO_PPDSDR_CS_PPDSDR_CS3            (0x08)
#define MCF_GPIO_PPDSDR_CS_PPDSDR_CS4            (0x10)
#define MCF_GPIO_PPDSDR_CS_PPDSDR_CS5            (0x20)
#define MCF_GPIO_PPDSDR_CS_PPDSDR_CS6            (0x40)
#define MCF_GPIO_PPDSDR_CS_PPDSDR_CS7            (0x80)

/* Bit definitions and macros for MCF_GPIO_PPDSDR_FEC0H */
#define MCF_GPIO_PPDSDR_FEC0H_PPDSDR_FEC0H0      (0x01)
#define MCF_GPIO_PPDSDR_FEC0H_PPDSDR_FEC0H1      (0x02)
#define MCF_GPIO_PPDSDR_FEC0H_PPDSDR_FEC0H2      (0x04)
#define MCF_GPIO_PPDSDR_FEC0H_PPDSDR_FEC0H3      (0x08)
#define MCF_GPIO_PPDSDR_FEC0H_PPDSDR_FEC0H4      (0x10)
#define MCF_GPIO_PPDSDR_FEC0H_PPDSDR_FEC0H5      (0x20)
#define MCF_GPIO_PPDSDR_FEC0H_PPDSDR_FEC0H6      (0x40)
#define MCF_GPIO_PPDSDR_FEC0H_PPDSDR_FEC0H7      (0x80)

/* Bit definitions and macros for MCF_GPIO_PPDSDR_FEC0L */
#define MCF_GPIO_PPDSDR_FEC0L_PPDSDR_FEC0L0      (0x01)
#define MCF_GPIO_PPDSDR_FEC0L_PPDSDR_FEC0L1      (0x02)
#define MCF_GPIO_PPDSDR_FEC0L_PPDSDR_FEC0L2      (0x04)
#define MCF_GPIO_PPDSDR_FEC0L_PPDSDR_FEC0L3      (0x08)
#define MCF_GPIO_PPDSDR_FEC0L_PPDSDR_FEC0L4      (0x10)
#define MCF_GPIO_PPDSDR_FEC0L_PPDSDR_FEC0L5      (0x20)
#define MCF_GPIO_PPDSDR_FEC0L_PPDSDR_FEC0L6      (0x40)
#define MCF_GPIO_PPDSDR_FEC0L_PPDSDR_FEC0L7      (0x80)

/* Bit definitions and macros for MCF_GPIO_PPDSDR_FECI2C */
#define MCF_GPIO_PPDSDR_FECI2C_PPDSDR_FECI2C0    (0x01)
#define MCF_GPIO_PPDSDR_FECI2C_PPDSDR_FECI2C1    (0x02)
#define MCF_GPIO_PPDSDR_FECI2C_PPDSDR_FECI2C2    (0x04)
#define MCF_GPIO_PPDSDR_FECI2C_PPDSDR_FECI2C3    (0x08)
#define MCF_GPIO_PPDSDR_FECI2C_PPDSDR_FECI2C4    (0x10)
#define MCF_GPIO_PPDSDR_FECI2C_PPDSDR_FECI2C5    (0x20)

/* Bit definitions and macros for MCF_GPIO_PPDSDR_QSPI */
#define MCF_GPIO_PPDSDR_QSPI_PPDSDR_QSPI0        (0x01)
#define MCF_GPIO_PPDSDR_QSPI_PPDSDR_QSPI1        (0x02)
#define MCF_GPIO_PPDSDR_QSPI_PPDSDR_QSPI2        (0x04)
#define MCF_GPIO_PPDSDR_QSPI_PPDSDR_QSPI3        (0x08)
#define MCF_GPIO_PPDSDR_QSPI_PPDSDR_QSPI4        (0x10)
#define MCF_GPIO_PPDSDR_QSPI_PPDSDR_QSPI5        (0x20)
#define MCF_GPIO_PPDSDR_QSPI_PPDSDR_QSPI6        (0x40)

/* Bit definitions and macros for MCF_GPIO_PPDSDR_SDRAM */
#define MCF_GPIO_PPDSDR_SDRAM_PPDSDR_SDRAM0      (0x01)
#define MCF_GPIO_PPDSDR_SDRAM_PPDSDR_SDRAM1      (0x02)
#define MCF_GPIO_PPDSDR_SDRAM_PPDSDR_SDRAM2      (0x04)
#define MCF_GPIO_PPDSDR_SDRAM_PPDSDR_SDRAM3      (0x08)
#define MCF_GPIO_PPDSDR_SDRAM_PPDSDR_SDRAM4      (0x10)
#define MCF_GPIO_PPDSDR_SDRAM_PPDSDR_SDRAM5      (0x20)
#define MCF_GPIO_PPDSDR_SDRAM_PPDSDR_SDRAM6      (0x40)
#define MCF_GPIO_PPDSDR_SDRAM_PPDSDR_SDRAM7      (0x80)

/* Bit definitions and macros for MCF_GPIO_PPDSDR_TIMERH */
#define MCF_GPIO_PPDSDR_TIMERH_PPDSDR_TIMERH0    (0x01)
#define MCF_GPIO_PPDSDR_TIMERH_PPDSDR_TIMERH1    (0x02)
#define MCF_GPIO_PPDSDR_TIMERH_PPDSDR_TIMERH2    (0x04)
#define MCF_GPIO_PPDSDR_TIMERH_PPDSDR_TIMERH3    (0x08)

/* Bit definitions and macros for MCF_GPIO_PPDSDR_TIMERL */
#define MCF_GPIO_PPDSDR_TIMERL_PPDSDR_TIMERL0    (0x01)
#define MCF_GPIO_PPDSDR_TIMERL_PPDSDR_TIMERL1    (0x02)
#define MCF_GPIO_PPDSDR_TIMERL_PPDSDR_TIMERL2    (0x04)
#define MCF_GPIO_PPDSDR_TIMERL_PPDSDR_TIMERL3    (0x08)

/* Bit definitions and macros for MCF_GPIO_PPDSDR_UARTL */
#define MCF_GPIO_PPDSDR_UARTL_PPDSDR_UARTL0      (0x01)
#define MCF_GPIO_PPDSDR_UARTL_PPDSDR_UARTL1      (0x02)
#define MCF_GPIO_PPDSDR_UARTL_PPDSDR_UARTL2      (0x04)
#define MCF_GPIO_PPDSDR_UARTL_PPDSDR_UARTL3      (0x08)
#define MCF_GPIO_PPDSDR_UARTL_PPDSDR_UARTL4      (0x10)
#define MCF_GPIO_PPDSDR_UARTL_PPDSDR_UARTL5      (0x20)
#define MCF_GPIO_PPDSDR_UARTL_PPDSDR_UARTL6      (0x40)
#define MCF_GPIO_PPDSDR_UARTL_PPDSDR_UARTL7      (0x80)

/* Bit definitions and macros for MCF_GPIO_PPDSDR_FEC1H */
#define MCF_GPIO_PPDSDR_FEC1H_PPDSDR_FEC1H0      (0x01)
#define MCF_GPIO_PPDSDR_FEC1H_PPDSDR_FEC1H1      (0x02)
#define MCF_GPIO_PPDSDR_FEC1H_PPDSDR_FEC1H2      (0x04)
#define MCF_GPIO_PPDSDR_FEC1H_PPDSDR_FEC1H3      (0x08)
#define MCF_GPIO_PPDSDR_FEC1H_PPDSDR_FEC1H4      (0x10)
#define MCF_GPIO_PPDSDR_FEC1H_PPDSDR_FEC1H5      (0x20)
#define MCF_GPIO_PPDSDR_FEC1H_PPDSDR_FEC1H6      (0x40)
#define MCF_GPIO_PPDSDR_FEC1H_PPDSDR_FEC1H7      (0x80)

/* Bit definitions and macros for MCF_GPIO_PPDSDR_FEC1L */
#define MCF_GPIO_PPDSDR_FEC1L_PPDSDR_FEC1L0      (0x01)
#define MCF_GPIO_PPDSDR_FEC1L_PPDSDR_FEC1L1      (0x02)
#define MCF_GPIO_PPDSDR_FEC1L_PPDSDR_FEC1L2      (0x04)
#define MCF_GPIO_PPDSDR_FEC1L_PPDSDR_FEC1L3      (0x08)
#define MCF_GPIO_PPDSDR_FEC1L_PPDSDR_FEC1L4      (0x10)
#define MCF_GPIO_PPDSDR_FEC1L_PPDSDR_FEC1L5      (0x20)
#define MCF_GPIO_PPDSDR_FEC1L_PPDSDR_FEC1L6      (0x40)
#define MCF_GPIO_PPDSDR_FEC1L_PPDSDR_FEC1L7      (0x80)

/* Bit definitions and macros for MCF_GPIO_PPDSDR_BS */
#define MCF_GPIO_PPDSDR_BS_PPDSDR_BS2            (0x04)
#define MCF_GPIO_PPDSDR_BS_PPDSDR_BS3            (0x08)

/* Bit definitions and macros for MCF_GPIO_PPDSDR_IRQ */
#define MCF_GPIO_PPDSDR_IRQ_PPDSDR_IRQ(x)        (((x)&0x7F)<<1)

/* Bit definitions and macros for MCF_GPIO_PPDSDR_USBH */
#define MCF_GPIO_PPDSDR_USBH_PPDSDR_USBH0        (0x01)

/* Bit definitions and macros for MCF_GPIO_PPDSDR_USBL */
#define MCF_GPIO_PPDSDR_USBL_PPDSDR_USBL0        (0x01)
#define MCF_GPIO_PPDSDR_USBL_PPDSDR_USBL1        (0x02)
#define MCF_GPIO_PPDSDR_USBL_PPDSDR_USBL2        (0x04)
#define MCF_GPIO_PPDSDR_USBL_PPDSDR_USBL3        (0x08)
#define MCF_GPIO_PPDSDR_USBL_PPDSDR_USBL4        (0x10)
#define MCF_GPIO_PPDSDR_USBL_PPDSDR_USBL5        (0x20)
#define MCF_GPIO_PPDSDR_USBL_PPDSDR_USBL6        (0x40)
#define MCF_GPIO_PPDSDR_USBL_PPDSDR_USBL7        (0x80)

/* Bit definitions and macros for MCF_GPIO_PPDSDR_UARTH */
#define MCF_GPIO_PPDSDR_UARTH_PPDSDR_UART0       (0x01)
#define MCF_GPIO_PPDSDR_UARTH_PPDSDR_UART1       (0x02)
#define MCF_GPIO_PPDSDR_UARTH_PPDSDR_UART2       (0x04)
#define MCF_GPIO_PPDSDR_UARTH_PPDSDR_UART3       (0x08)

/* Bit definitions and macros for MCF_GPIO_PCLRR_BUSCTL */
#define MCF_GPIO_PCLRR_BUSCTL_PCLRR_BUSCTL0      (0x01)
#define MCF_GPIO_PCLRR_BUSCTL_PCLRR_BUSCTL1      (0x02)
#define MCF_GPIO_PCLRR_BUSCTL_PCLRR_BUSCTL2      (0x04)
#define MCF_GPIO_PCLRR_BUSCTL_PCLRR_BUSCTL3      (0x08)
#define MCF_GPIO_PCLRR_BUSCTL_PCLRR_BUSCTL4      (0x10)
#define MCF_GPIO_PCLRR_BUSCTL_PCLRR_BUSCTL5      (0x20)
#define MCF_GPIO_PCLRR_BUSCTL_PCLRR_BUSCTL6      (0x40)
#define MCF_GPIO_PCLRR_BUSCTL_PCLRR_BUSCTL7      (0x80)

/* Bit definitions and macros for MCF_GPIO_PCLRR_ADDR */
#define MCF_GPIO_PCLRR_ADDR_PCLRR_ADDR5          (0x20)
#define MCF_GPIO_PCLRR_ADDR_PCLRR_ADDR6          (0x40)
#define MCF_GPIO_PCLRR_ADDR_PCLRR_ADDR7          (0x80)

/* Bit definitions and macros for MCF_GPIO_PCLRR_CS */
#define MCF_GPIO_PCLRR_CS_PCLRR_CS1              (0x02)
#define MCF_GPIO_PCLRR_CS_PCLRR_CS2              (0x04)
#define MCF_GPIO_PCLRR_CS_PCLRR_CS3              (0x08)
#define MCF_GPIO_PCLRR_CS_PCLRR_CS4              (0x10)
#define MCF_GPIO_PCLRR_CS_PCLRR_CS5              (0x20)
#define MCF_GPIO_PCLRR_CS_PCLRR_CS6              (0x40)
#define MCF_GPIO_PCLRR_CS_PCLRR_CS7              (0x80)

/* Bit definitions and macros for MCF_GPIO_PCLRR_FEC0H */
#define MCF_GPIO_PCLRR_FEC0H_PCLRR_FEC0H0        (0x01)
#define MCF_GPIO_PCLRR_FEC0H_PCLRR_FEC0H1        (0x02)
#define MCF_GPIO_PCLRR_FEC0H_PCLRR_FEC0H2        (0x04)
#define MCF_GPIO_PCLRR_FEC0H_PCLRR_FEC0H3        (0x08)
#define MCF_GPIO_PCLRR_FEC0H_PCLRR_FEC0H4        (0x10)
#define MCF_GPIO_PCLRR_FEC0H_PCLRR_FEC0H5        (0x20)
#define MCF_GPIO_PCLRR_FEC0H_PCLRR_FEC0H6        (0x40)
#define MCF_GPIO_PCLRR_FEC0H_PCLRR_FEC0H7        (0x80)

/* Bit definitions and macros for MCF_GPIO_PCLRR_FEC0L */
#define MCF_GPIO_PCLRR_FEC0L_PCLRR_FEC0L0        (0x01)
#define MCF_GPIO_PCLRR_FEC0L_PCLRR_FEC0L1        (0x02)
#define MCF_GPIO_PCLRR_FEC0L_PCLRR_FEC0L2        (0x04)
#define MCF_GPIO_PCLRR_FEC0L_PCLRR_FEC0L3        (0x08)
#define MCF_GPIO_PCLRR_FEC0L_PCLRR_FEC0L4        (0x10)
#define MCF_GPIO_PCLRR_FEC0L_PCLRR_FEC0L5        (0x20)
#define MCF_GPIO_PCLRR_FEC0L_PCLRR_FEC0L6        (0x40)
#define MCF_GPIO_PCLRR_FEC0L_PCLRR_FEC0L7        (0x80)

/* Bit definitions and macros for MCF_GPIO_PCLRR_FECI2C */
#define MCF_GPIO_PCLRR_FECI2C_PCLRR_FECI2C0      (0x01)
#define MCF_GPIO_PCLRR_FECI2C_PCLRR_FECI2C1      (0x02)
#define MCF_GPIO_PCLRR_FECI2C_PCLRR_FECI2C2      (0x04)
#define MCF_GPIO_PCLRR_FECI2C_PCLRR_FECI2C3      (0x08)
#define MCF_GPIO_PCLRR_FECI2C_PCLRR_FECI2C4      (0x10)
#define MCF_GPIO_PCLRR_FECI2C_PCLRR_FECI2C5      (0x20)

/* Bit definitions and macros for MCF_GPIO_PCLRR_QSPI */
#define MCF_GPIO_PCLRR_QSPI_PCLRR_QSPI0          (0x01)
#define MCF_GPIO_PCLRR_QSPI_PCLRR_QSPI1          (0x02)
#define MCF_GPIO_PCLRR_QSPI_PCLRR_QSPI2          (0x04)
#define MCF_GPIO_PCLRR_QSPI_PCLRR_QSPI3          (0x08)
#define MCF_GPIO_PCLRR_QSPI_PCLRR_QSPI4          (0x10)
#define MCF_GPIO_PCLRR_QSPI_PCLRR_QSPI5          (0x20)
#define MCF_GPIO_PCLRR_QSPI_PCLRR_QSPI6          (0x40)

/* Bit definitions and macros for MCF_GPIO_PCLRR_SDRAM */
#define MCF_GPIO_PCLRR_SDRAM_PCLRR_SDRAM0        (0x01)
#define MCF_GPIO_PCLRR_SDRAM_PCLRR_SDRAM1        (0x02)
#define MCF_GPIO_PCLRR_SDRAM_PCLRR_SDRAM2        (0x04)
#define MCF_GPIO_PCLRR_SDRAM_PCLRR_SDRAM3        (0x08)
#define MCF_GPIO_PCLRR_SDRAM_PCLRR_SDRAM4        (0x10)
#define MCF_GPIO_PCLRR_SDRAM_PCLRR_SDRAM5        (0x20)
#define MCF_GPIO_PCLRR_SDRAM_PCLRR_SDRAM6        (0x40)
#define MCF_GPIO_PCLRR_SDRAM_PCLRR_SDRAM7        (0x80)

/* Bit definitions and macros for MCF_GPIO_PCLRR_TIMERH */
#define MCF_GPIO_PCLRR_TIMERH_PCLRR_TIMERH0      (0x01)
#define MCF_GPIO_PCLRR_TIMERH_PCLRR_TIMERH1      (0x02)
#define MCF_GPIO_PCLRR_TIMERH_PCLRR_TIMERH2      (0x04)
#define MCF_GPIO_PCLRR_TIMERH_PCLRR_TIMERH3      (0x08)

/* Bit definitions and macros for MCF_GPIO_PCLRR_TIMERL */
#define MCF_GPIO_PCLRR_TIMERL_PCLRR_TIMERL0      (0x01)
#define MCF_GPIO_PCLRR_TIMERL_PCLRR_TIMERL1      (0x02)
#define MCF_GPIO_PCLRR_TIMERL_PCLRR_TIMERL2      (0x04)
#define MCF_GPIO_PCLRR_TIMERL_PCLRR_TIMERL3      (0x08)

/* Bit definitions and macros for MCF_GPIO_PCLRR_UARTL */
#define MCF_GPIO_PCLRR_UARTL_PCLRR_UARTL0        (0x01)
#define MCF_GPIO_PCLRR_UARTL_PCLRR_UARTL1        (0x02)
#define MCF_GPIO_PCLRR_UARTL_PCLRR_UARTL2        (0x04)
#define MCF_GPIO_PCLRR_UARTL_PCLRR_UARTL3        (0x08)
#define MCF_GPIO_PCLRR_UARTL_PCLRR_UARTL4        (0x10)
#define MCF_GPIO_PCLRR_UARTL_PCLRR_UARTL5        (0x20)
#define MCF_GPIO_PCLRR_UARTL_PCLRR_UARTL6        (0x40)
#define MCF_GPIO_PCLRR_UARTL_PCLRR_UARTL7        (0x80)

/* Bit definitions and macros for MCF_GPIO_PCLRR_FEC1H */
#define MCF_GPIO_PCLRR_FEC1H_PCLRR_FEC1H0        (0x01)
#define MCF_GPIO_PCLRR_FEC1H_PCLRR_FEC1H1        (0x02)
#define MCF_GPIO_PCLRR_FEC1H_PCLRR_FEC1H2        (0x04)
#define MCF_GPIO_PCLRR_FEC1H_PCLRR_FEC1H3        (0x08)
#define MCF_GPIO_PCLRR_FEC1H_PCLRR_FEC1H4        (0x10)
#define MCF_GPIO_PCLRR_FEC1H_PCLRR_FEC1H5        (0x20)
#define MCF_GPIO_PCLRR_FEC1H_PCLRR_FEC1H6        (0x40)
#define MCF_GPIO_PCLRR_FEC1H_PCLRR_FEC1H7        (0x80)

/* Bit definitions and macros for MCF_GPIO_PCLRR_FEC1L */
#define MCF_GPIO_PCLRR_FEC1L_PCLRR_FEC1L0        (0x01)
#define MCF_GPIO_PCLRR_FEC1L_PCLRR_FEC1L1        (0x02)
#define MCF_GPIO_PCLRR_FEC1L_PCLRR_FEC1L2        (0x04)
#define MCF_GPIO_PCLRR_FEC1L_PCLRR_FEC1L3        (0x08)
#define MCF_GPIO_PCLRR_FEC1L_PCLRR_FEC1L4        (0x10)
#define MCF_GPIO_PCLRR_FEC1L_PCLRR_FEC1L5        (0x20)
#define MCF_GPIO_PCLRR_FEC1L_PCLRR_FEC1L6        (0x40)
#define MCF_GPIO_PCLRR_FEC1L_PCLRR_FEC1L7        (0x80)

/* Bit definitions and macros for MCF_GPIO_PCLRR_BS */
#define MCF_GPIO_PCLRR_BS_PCLRR_BS2              (0x04)
#define MCF_GPIO_PCLRR_BS_PCLRR_BS3              (0x08)

/* Bit definitions and macros for MCF_GPIO_PCLRR_IRQ */
#define MCF_GPIO_PCLRR_IRQ_PCLRR_IRQ(x)          (((x)&0x7F)<<1)

/* Bit definitions and macros for MCF_GPIO_PCLRR_USBH */
#define MCF_GPIO_PCLRR_USBH_PCLRR_USBH0          (0x01)

/* Bit definitions and macros for MCF_GPIO_PCLRR_USBL */
#define MCF_GPIO_PCLRR_USBL_PCLRR_USBL0          (0x01)
#define MCF_GPIO_PCLRR_USBL_PCLRR_USBL1          (0x02)
#define MCF_GPIO_PCLRR_USBL_PCLRR_USBL2          (0x04)
#define MCF_GPIO_PCLRR_USBL_PCLRR_USBL3          (0x08)
#define MCF_GPIO_PCLRR_USBL_PCLRR_USBL4          (0x10)
#define MCF_GPIO_PCLRR_USBL_PCLRR_USBL5          (0x20)
#define MCF_GPIO_PCLRR_USBL_PCLRR_USBL6          (0x40)
#define MCF_GPIO_PCLRR_USBL_PCLRR_USBL7          (0x80)

/* Bit definitions and macros for MCF_GPIO_PCLRR_UARTH */
#define MCF_GPIO_PCLRR_UARTH_PCLRR_UART0         (0x01)
#define MCF_GPIO_PCLRR_UARTH_PCLRR_UART1         (0x02)
#define MCF_GPIO_PCLRR_UARTH_PCLRR_UART2         (0x04)
#define MCF_GPIO_PCLRR_UARTH_PCLRR_UART3         (0x08)

/* Bit definitions and macros for MCF_GPIO_PAR_ADDR */
#define MCF_GPIO_PAR_ADDR_PAR_ADDR21             (0x20)
#define MCF_GPIO_PAR_ADDR_PAR_ADDR22             (0x40)
#define MCF_GPIO_PAR_ADDR_PAR_ADDR23             (0x80)

/* Bit definitions and macros for MCF_GPIO_PAR_CS */
#define MCF_GPIO_PAR_CS_PAR_CS1                  (0x02)
#define MCF_GPIO_PAR_CS_PAR_CS2                  (0x04)
#define MCF_GPIO_PAR_CS_PAR_CS3                  (0x08)
#define MCF_GPIO_PAR_CS_PAR_CS4                  (0x10)
#define MCF_GPIO_PAR_CS_PAR_CS5                  (0x20)
#define MCF_GPIO_PAR_CS_PAR_CS6                  (0x40)
#define MCF_GPIO_PAR_CS_PAR_CS7                  (0x80)

/* Bit definitions and macros for MCF_GPIO_PAR_BUSCTL */
#define MCF_GPIO_PAR_BUSCTL_PAR_TIP(x)           (((x)&0x0003)<<0)
#define MCF_GPIO_PAR_BUSCTL_PAR_TS(x)            (((x)&0x0003)<<2)
#define MCF_GPIO_PAR_BUSCTL_PAR_TSIZ0(x)         (((x)&0x0003)<<4)
#define MCF_GPIO_PAR_BUSCTL_PAR_TSIZ1(x)         (((x)&0x0003)<<6)
#define MCF_GPIO_PAR_BUSCTL_PAR_RWB              (0x0200)
#define MCF_GPIO_PAR_BUSCTL_PAR_TEA(x)           (((x)&0x0003)<<10)
#define MCF_GPIO_PAR_BUSCTL_PAR_TA               (0x1000)
#define MCF_GPIO_PAR_BUSCTL_PAR_OE               (0x2000)
#define MCF_GPIO_PAR_BUSCTL_PAR_TEA_GPIO         (0x0000)
#define MCF_GPIO_PAR_BUSCTL_PAR_TEA_DREQ1        (0x0800)
#define MCF_GPIO_PAR_BUSCTL_PAR_TEA_TEA          (0x0C00)
#define MCF_GPIO_PAR_BUSCTL_PAR_TSIZ1_GPIO       (0x0000)
#define MCF_GPIO_PAR_BUSCTL_PAR_TSIZ1_DACK1      (0x0080)
#define MCF_GPIO_PAR_BUSCTL_PAR_TSIZ1_TSIZ1      (0x00C0)
#define MCF_GPIO_PAR_BUSCTL_PAR_TSIZ0_GPIO       (0x0000)
#define MCF_GPIO_PAR_BUSCTL_PAR_TSIZ0_DACK0      (0x0020)
#define MCF_GPIO_PAR_BUSCTL_PAR_TSIZ0_TSIZ0      (0x0030)
#define MCF_GPIO_PAR_BUSCTL_PAR_TS_GPIO          (0x0000)
#define MCF_GPIO_PAR_BUSCTL_PAR_TS_DACK2         (0x0008)
#define MCF_GPIO_PAR_BUSCTL_PAR_TS_TS            (0x000C)
#define MCF_GPIO_PAR_BUSCTL_PAR_TIP_GPIO         (0x0000)
#define MCF_GPIO_PAR_BUSCTL_PAR_TIP_DREQ0        (0x0002)
#define MCF_GPIO_PAR_BUSCTL_PAR_TIP_TEA          (0x0003)

/* Bit definitions and macros for MCF_GPIO_PAR_IRQ */
#define MCF_GPIO_PAR_IRQ_PAR_IRQ1                (0x0002)
#define MCF_GPIO_PAR_IRQ_PAR_IRQ2(x)             (((x)&0x0003)<<2)
#define MCF_GPIO_PAR_IRQ_PAR_IRQ3(x)             (((x)&0x0003)<<4)
#define MCF_GPIO_PAR_IRQ_PAR_IRQ4(x)             (((x)&0x0003)<<6)
#define MCF_GPIO_PAR_IRQ_PAR_IRQ5                (0x0100)
#define MCF_GPIO_PAR_IRQ_PAR_IRQ6                (0x0200)
#define MCF_GPIO_PAR_IRQ_PAR_IRQ7                (0x0400)

/* Bit definitions and macros for MCF_GPIO_PAR_USB */
#define MCF_GPIO_PAR_USB_PAR_UTXEN               (0x0001)
#define MCF_GPIO_PAR_USB_PAR_UTP                 (0x0002)
#define MCF_GPIO_PAR_USB_PAR_UTN                 (0x0004)
#define MCF_GPIO_PAR_USB_PAR_USSP                (0x0008)
#define MCF_GPIO_PAR_USB_PAR_URX                 (0x0010)
#define MCF_GPIO_PAR_USB_PAR_URP                 (0x0020)
#define MCF_GPIO_PAR_USB_PAR_URN                 (0x0040)
#define MCF_GPIO_PAR_USB_PAR_UCLK                (0x0080)
#define MCF_GPIO_PAR_USB_PAR_USPD                (0x0100)

/* Bit definitions and macros for MCF_GPIO_PAR_FEC0HL */
#define MCF_GPIO_PAR_FEC0HL_PAR_FEC0L            (0x40)
#define MCF_GPIO_PAR_FEC0HL_PAR_FEC0H            (0x80)

/* Bit definitions and macros for MCF_GPIO_PAR_FEC1HL */
#define MCF_GPIO_PAR_FEC1HL_PAR_FEC1L            (0x40)
#define MCF_GPIO_PAR_FEC1HL_PAR_FEC1H            (0x80)

/* Bit definitions and macros for MCF_GPIO_PAR_TIMER */
#define MCF_GPIO_PAR_TIMER_PAR_T0OUT(x)          (((x)&0x0003)<<0)
#define MCF_GPIO_PAR_TIMER_PAR_T0IN(x)           (((x)&0x0003)<<2)
#define MCF_GPIO_PAR_TIMER_PAR_T1OUT(x)          (((x)&0x0003)<<4)
#define MCF_GPIO_PAR_TIMER_PAR_T1IN(x)           (((x)&0x0003)<<6)
#define MCF_GPIO_PAR_TIMER_PAR_T2OUT(x)          (((x)&0x0003)<<8)
#define MCF_GPIO_PAR_TIMER_PAR_T2IN(x)           (((x)&0x0003)<<10)
#define MCF_GPIO_PAR_TIMER_PAR_T3OUT(x)          (((x)&0x0003)<<12)
#define MCF_GPIO_PAR_TIMER_PAR_T3IN(x)           (((x)&0x0003)<<14)
#define MCF_GPIO_PAR_TIMER_PAR_T3IN_GPIO         (0x0000)
#define MCF_GPIO_PAR_TIMER_PAR_T3IN_QSPI         (0x4000)
#define MCF_GPIO_PAR_TIMER_PAR_T3IN_UART2        (0x8000)
#define MCF_GPIO_PAR_TIMER_PAR_T3IN_T3IN         (0xC000)
#define MCF_GPIO_PAR_TIMER_PAR_T2IN_GPIO         (0x0000)
#define MCF_GPIO_PAR_TIMER_PAR_T2IN_T2OUT        (0x1000)
#define MCF_GPIO_PAR_TIMER_PAR_T2IN_DMA          (0x2000)
#define MCF_GPIO_PAR_TIMER_PAR_T2IN_T2IN         (0x3000)
#define MCF_GPIO_PAR_TIMER_PAR_T1IN_GPIO         (0x0000)
#define MCF_GPIO_PAR_TIMER_PAR_T1IN_T1OUT        (0x0400)
#define MCF_GPIO_PAR_TIMER_PAR_T1IN_DMA          (0x0800)
#define MCF_GPIO_PAR_TIMER_PAR_T1IN_T1IN         (0x0C00)
#define MCF_GPIO_PAR_TIMER_PAR_T0IN_GPIO         (0x0000)
#define MCF_GPIO_PAR_TIMER_PAR_T0IN_DMA          (0x0200)
#define MCF_GPIO_PAR_TIMER_PAR_T0IN_T0IN         (0x0300)
#define MCF_GPIO_PAR_TIMER_PAR_T3OUT_GPIO        (0x0000)
#define MCF_GPIO_PAR_TIMER_PAR_T3OUT_QSPI        (0x0040)
#define MCF_GPIO_PAR_TIMER_PAR_T3OUT_UART2       (0x0080)
#define MCF_GPIO_PAR_TIMER_PAR_T3OUT_T3OUT       (0x00C0)
#define MCF_GPIO_PAR_TIMER_PAR_T2OUT_GPIO        (0x0000)
#define MCF_GPIO_PAR_TIMER_PAR_T2OUT_DMA         (0x0020)
#define MCF_GPIO_PAR_TIMER_PAR_T2OUT_T2OUT       (0x0030)
#define MCF_GPIO_PAR_TIMER_PAR_T1OUT_GPIO        (0x0000)
#define MCF_GPIO_PAR_TIMER_PAR_T1OUT_DMA         (0x0008)
#define MCF_GPIO_PAR_TIMER_PAR_T1OUT_T1OUT       (0x000C)
#define MCF_GPIO_PAR_TIMER_PAR_T0OUT_GPIO        (0x0000)
#define MCF_GPIO_PAR_TIMER_PAR_T0OUT_DMA         (0x0002)
#define MCF_GPIO_PAR_TIMER_PAR_T0OUT_T0OUT       (0x0003)

/* Bit definitions and macros for MCF_GPIO_PAR_UART */
#define MCF_GPIO_PAR_UART_PAR_U2CTS_GPIO         (0x0000)
#define MCF_GPIO_PAR_UART_PAR_U2CTS_UART2        (0x0800)
#define MCF_GPIO_PAR_UART_PAR_U2CTS_UART1        (0x0C00)
#define MCF_GPIO_PAR_UART_PAR_U2RTS_GPIO         (0x0000)
#define MCF_GPIO_PAR_UART_PAR_U2RTS_UART2        (0x0200)
#define MCF_GPIO_PAR_UART_PAR_U2RTS_UART1        (0x0300)

/* Bit definitions and macros for MCF_GPIO_PAR_QSPI */
#define MCF_GPIO_PAR_QSPI_PAR_DOUT               (0x0002)
#define MCF_GPIO_PAR_QSPI_PAR_DIN(x)             (((x)&0x0003)<<2)
#define MCF_GPIO_PAR_QSPI_PAR_SCK(x)             (((x)&0x0003)<<4)
#define MCF_GPIO_PAR_QSPI_PAR_PCS0               (0x0080)
#define MCF_GPIO_PAR_QSPI_PAR_PCS1               (0x0200)
#define MCF_GPIO_PAR_QSPI_PAR_PCS2(x)            (((x)&0x0003)<<10)
#define MCF_GPIO_PAR_QSPI_PAR_PCS3(x)            (((x)&0x0003)<<12)
#define MCF_GPIO_PAR_QSPI_PAR_PCS3_GPIO          (0x0000)
#define MCF_GPIO_PAR_QSPI_PAR_PCS3_DACK3         (0x1000)
#define MCF_GPIO_PAR_QSPI_PAR_PCS3_PWM3          (0x2000)
#define MCF_GPIO_PAR_QSPI_PAR_PCS3_QSPI          (0x3000)
#define MCF_GPIO_PAR_QSPI_PAR_PCS2_GPIO          (0x0000)
#define MCF_GPIO_PAR_QSPI_PAR_PCS2_DACK2         (0x0400)
#define MCF_GPIO_PAR_QSPI_PAR_PCS2_PWM2          (0x0800)
#define MCF_GPIO_PAR_QSPI_PAR_PCS2_QSPI          (0x0C00)
#define MCF_GPIO_PAR_QSPI_PAR_SCK_GPIO           (0x0000)
#define MCF_GPIO_PAR_QSPI_PAR_SCK_I2C            (0x0020)
#define MCF_GPIO_PAR_QSPI_PAR_SCK_QSPI           (0x0030)
#define MCF_GPIO_PAR_QSPI_PAR_DIN_GPIO           (0x0000)
#define MCF_GPIO_PAR_QSPI_PAR_DIN_I2C            (0x0080)
#define MCF_GPIO_PAR_QSPI_PAR_DIN_QSPI           (0x00C0)

/* Bit definitions and macros for MCF_GPIO_PAR_SDRAM */
#define MCF_GPIO_PAR_SDRAM_PAR_SDQS(x)           (((x)&0x0003)<<0)
#define MCF_GPIO_PAR_SDRAM_PAR_SCKE              (0x0004)
#define MCF_GPIO_PAR_SDRAM_PAR_SDWE              (0x0008)
#define MCF_GPIO_PAR_SDRAM_PAR_SCAS              (0x0010)
#define MCF_GPIO_PAR_SDRAM_PAR_SRAS              (0x0020)
#define MCF_GPIO_PAR_SDRAM_PAR_SDCS0(x)          (((x)&0x0003)<<6)
#define MCF_GPIO_PAR_SDRAM_PAR_SDCS1(x)          (((x)&0x0003)<<8)
#define MCF_GPIO_PAR_SDRAM_PAR_SDCS1_GPIO        (0x0000)
#define MCF_GPIO_PAR_SDRAM_PAR_SDCS1_CS3         (0x0200)
#define MCF_GPIO_PAR_SDRAM_PAR_SDCS1_SDCS1       (0x0300)
#define MCF_GPIO_PAR_SDRAM_PAR_SDCS0_GPIO        (0x0000)
#define MCF_GPIO_PAR_SDRAM_PAR_SDCS0_CS2         (0x0080)
#define MCF_GPIO_PAR_SDRAM_PAR_SDCS0_SDCS0       (0x00C0)
#define MCF_GPIO_PAR_SDRAM_PAR_SDQS_GPIO         (0x0000)
#define MCF_GPIO_PAR_SDRAM_PAR_SDQS_SDQS         (0x0003)

/* Bit definitions and macros for MCF_GPIO_PAR_FECI2C */
#define MCF_GPIO_PAR_FECI2C_PAR_SCL(x)           (((x)&0x0003)<<0)
#define MCF_GPIO_PAR_FECI2C_PAR_SDA(x)           (((x)&0x0003)<<2)
#define MCF_GPIO_PAR_FECI2C_PAR_MDC1             (0x0020)
#define MCF_GPIO_PAR_FECI2C_PAR_MDIO1            (0x0080)
#define MCF_GPIO_PAR_FECI2C_PAR_MDC0(x)          (((x)&0x0003)<<8)
#define MCF_GPIO_PAR_FECI2C_PAR_MDIO0(x)         (((x)&0x0003)<<10)
#define MCF_GPIO_PAR_FECI2C_PAR_MDIO0_GPIO       (0x0000)
#define MCF_GPIO_PAR_FECI2C_PAR_MDIO0_UART2      (0x0400)
#define MCF_GPIO_PAR_FECI2C_PAR_MDIO0_I2C        (0x0800)
#define MCF_GPIO_PAR_FECI2C_PAR_MDIO0_FEC        (0x0C00)
#define MCF_GPIO_PAR_FECI2C_PAR_MDC0_GPIO        (0x0000)
#define MCF_GPIO_PAR_FECI2C_PAR_MDC0_UART2       (0x0100)
#define MCF_GPIO_PAR_FECI2C_PAR_MDC0_I2C         (0x0200)
#define MCF_GPIO_PAR_FECI2C_PAR_MDC0_FEC         (0x0300)
#define MCF_GPIO_PAR_FECI2C_PAR_SDA_GPIO         (0x0000)
#define MCF_GPIO_PAR_FECI2C_PAR_SDA_UART2        (0x0008)
#define MCF_GPIO_PAR_FECI2C_PAR_SDA_I2C          (0x000C)
#define MCF_GPIO_PAR_FECI2C_PAR_SCL_GPIO         (0x0000)
#define MCF_GPIO_PAR_FECI2C_PAR_SCL_UART2        (0x0002)
#define MCF_GPIO_PAR_FECI2C_PAR_SCL_I2C          (0x0003)

/* Bit definitions and macros for MCF_GPIO_PAR_BS */
#define MCF_GPIO_PAR_BS_PAR_BS(x)                (((x)&0x03)<<2)
#define MCF_GPIO_PAR_BS_PAR_BS_GPIO              (0x00)
#define MCF_GPIO_PAR_BS_PAR_BS_BS                (0x0C)

/********************************************************************/

#endif /* __MCF5275_GPIO_H__ */
