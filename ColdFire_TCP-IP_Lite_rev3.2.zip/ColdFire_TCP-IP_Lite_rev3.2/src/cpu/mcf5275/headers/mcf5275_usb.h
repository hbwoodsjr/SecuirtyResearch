/*
 * File:	mcf5275_usb.h
 * Purpose:	Register and bit definitions for the MCF5275
 *
 * Notes:	
 *	
 */

#ifndef __MCF5275_USB_H__
#define __MCF5275_USB_H__

/*********************************************************************
*
* Universal Serial Bus (USB)
*
*********************************************************************/

/* Register read/write macros */
#define MCF_USB_FRAME         (*(vuint32*)(void*)(&__IPSBAR[0x1C0000]))
#define MCF_USB_SPEC          (*(vuint32*)(void*)(&__IPSBAR[0x1C0004]))
#define MCF_USB_SR            (*(vuint32*)(void*)(&__IPSBAR[0x1C0008]))
#define MCF_USB_CR            (*(vuint32*)(void*)(&__IPSBAR[0x1C000C]))
#define MCF_USB_DAR           (*(vuint32*)(void*)(&__IPSBAR[0x1C0010]))
#define MCF_USB_DDR           (*(vuint32*)(void*)(&__IPSBAR[0x1C0014]))
#define MCF_USB_ISR           (*(vuint32*)(void*)(&__IPSBAR[0x1C0018]))
#define MCF_USB_IMR           (*(vuint32*)(void*)(&__IPSBAR[0x1C001C]))
#define MCF_USB_MCR           (*(vuint32*)(void*)(&__IPSBAR[0x1C0020]))
#define MCF_USB_EP0SR         (*(vuint32*)(void*)(&__IPSBAR[0x1C0030]))
#define MCF_USB_EP1SR         (*(vuint32*)(void*)(&__IPSBAR[0x1C0060]))
#define MCF_USB_EP2SR         (*(vuint32*)(void*)(&__IPSBAR[0x1C0090]))
#define MCF_USB_EP3SR         (*(vuint32*)(void*)(&__IPSBAR[0x1C00C0]))
#define MCF_USB_EPnSR(x)      (*(vuint32*)(void*)(&__IPSBAR[0x1C0030+((x)*0x030)]))
#define MCF_USB_EP0ISR        (*(vuint32*)(void*)(&__IPSBAR[0x1C0034]))
#define MCF_USB_EP1ISR        (*(vuint32*)(void*)(&__IPSBAR[0x1C0064]))
#define MCF_USB_EP2ISR        (*(vuint32*)(void*)(&__IPSBAR[0x1C0094]))
#define MCF_USB_EP3ISR        (*(vuint32*)(void*)(&__IPSBAR[0x1C00C4]))
#define MCF_USB_EPnISR(x)     (*(vuint32*)(void*)(&__IPSBAR[0x1C0034+((x)*0x030)]))
#define MCF_USB_EP0IMR        (*(vuint32*)(void*)(&__IPSBAR[0x1C0038]))
#define MCF_USB_EP1IMR        (*(vuint32*)(void*)(&__IPSBAR[0x1C0068]))
#define MCF_USB_EP2IMR        (*(vuint32*)(void*)(&__IPSBAR[0x1C0098]))
#define MCF_USB_EP3IMR        (*(vuint32*)(void*)(&__IPSBAR[0x1C00C8]))
#define MCF_USB_EPnIMR(x)     (*(vuint32*)(void*)(&__IPSBAR[0x1C0038+((x)*0x030)]))
#define MCF_USB_EP0FDR        (*(vuint32*)(void*)(&__IPSBAR[0x1C003C]))
#define MCF_USB_EP1FDR        (*(vuint32*)(void*)(&__IPSBAR[0x1C006C]))
#define MCF_USB_EP2FDR        (*(vuint32*)(void*)(&__IPSBAR[0x1C009C]))
#define MCF_USB_EP3FDR        (*(vuint32*)(void*)(&__IPSBAR[0x1C00CC]))
#define MCF_USB_EPnFDR(x)     (*(vuint32*)(void*)(&__IPSBAR[0x1C003C+((x)*0x030)]))
#define MCF_USB_EP0FSR        (*(vuint32*)(void*)(&__IPSBAR[0x1C0040]))
#define MCF_USB_EP1FSR        (*(vuint32*)(void*)(&__IPSBAR[0x1C0070]))
#define MCF_USB_EP2FSR        (*(vuint32*)(void*)(&__IPSBAR[0x1C00A0]))
#define MCF_USB_EP3FSR        (*(vuint32*)(void*)(&__IPSBAR[0x1C00D0]))
#define MCF_USB_EPnFSR(x)     (*(vuint32*)(void*)(&__IPSBAR[0x1C0040+((x)*0x030)]))
#define MCF_USB_EP0FCR        (*(vuint32*)(void*)(&__IPSBAR[0x1C0044]))
#define MCF_USB_EP1FCR        (*(vuint32*)(void*)(&__IPSBAR[0x1C0074]))
#define MCF_USB_EP2FCR        (*(vuint32*)(void*)(&__IPSBAR[0x1C00A4]))
#define MCF_USB_EP3FCR        (*(vuint32*)(void*)(&__IPSBAR[0x1C00D4]))
#define MCF_USB_EPnFCR(x)     (*(vuint32*)(void*)(&__IPSBAR[0x1C0044+((x)*0x030)]))
#define MCF_USB_EP0LRFP       (*(vuint32*)(void*)(&__IPSBAR[0x1C0048]))
#define MCF_USB_EP1LRFP       (*(vuint32*)(void*)(&__IPSBAR[0x1C0078]))
#define MCF_USB_EP2LRFP       (*(vuint32*)(void*)(&__IPSBAR[0x1C00A8]))
#define MCF_USB_EP3LRFP       (*(vuint32*)(void*)(&__IPSBAR[0x1C00D8]))
#define MCF_USB_EPnLRFP(x)    (*(vuint32*)(void*)(&__IPSBAR[0x1C0048+((x)*0x030)]))
#define MCF_USB_EP0LWFP       (*(vuint32*)(void*)(&__IPSBAR[0x1C003C]))
#define MCF_USB_EP1LWFP       (*(vuint32*)(void*)(&__IPSBAR[0x1C006C]))
#define MCF_USB_EP2LWFP       (*(vuint32*)(void*)(&__IPSBAR[0x1C009C]))
#define MCF_USB_EP3LWFP       (*(vuint32*)(void*)(&__IPSBAR[0x1C00CC]))
#define MCF_USB_EPnLWFP(x)    (*(vuint32*)(void*)(&__IPSBAR[0x1C003C+((x)*0x030)]))
#define MCF_USB_EP0FAR        (*(vuint32*)(void*)(&__IPSBAR[0x1C0050]))
#define MCF_USB_EP1FAR        (*(vuint32*)(void*)(&__IPSBAR[0x1C0080]))
#define MCF_USB_EP2FAR        (*(vuint32*)(void*)(&__IPSBAR[0x1C00B0]))
#define MCF_USB_EP3FAR        (*(vuint32*)(void*)(&__IPSBAR[0x1C00E0]))
#define MCF_USB_EPnFAR(x)     (*(vuint32*)(void*)(&__IPSBAR[0x1C0050+((x)*0x030)]))
#define MCF_USB_EP0FRP        (*(vuint32*)(void*)(&__IPSBAR[0x1C0054]))
#define MCF_USB_EP1FRP        (*(vuint32*)(void*)(&__IPSBAR[0x1C0084]))
#define MCF_USB_EP2FRP        (*(vuint32*)(void*)(&__IPSBAR[0x1C00B4]))
#define MCF_USB_EP3FRP        (*(vuint32*)(void*)(&__IPSBAR[0x1C00E4]))
#define MCF_USB_EPnFRP(x)     (*(vuint32*)(void*)(&__IPSBAR[0x1C0054+((x)*0x030)]))
#define MCF_USB_EP0FWP        (*(vuint32*)(void*)(&__IPSBAR[0x1C0058]))
#define MCF_USB_EP1FWP        (*(vuint32*)(void*)(&__IPSBAR[0x1C0088]))
#define MCF_USB_EP2FWP        (*(vuint32*)(void*)(&__IPSBAR[0x1C00B8]))
#define MCF_USB_EP3FWP        (*(vuint32*)(void*)(&__IPSBAR[0x1C00E8]))
#define MCF_USB_EPnFWP(x)     (*(vuint32*)(void*)(&__IPSBAR[0x1C0058+((x)*0x030)]))

/* Bit definitions and macros for MCF_USB_FRAME */
#define MCF_USB_FRAME_FRAME(x)         (((x)&0x000007FF)<<0)
#define MCF_USB_FRAME_MATCH(x)         (((x)&0x000003FF)<<16)

/* Bit definitions and macros for MCF_USB_SPEC */
#define MCF_USB_SPEC_SPEC(x)           (((x)&0x00000FFF)<<0)
#define MCF_USB_SPEC_RELEASE(x)        (((x)&0x0000000F)<<12)

/* Bit definitions and macros for MCF_USB_SR */
#define MCF_USB_SR_ALTSET(x)           (((x)&0x00000007)<<0)
#define MCF_USB_SR_INTF(x)             (((x)&0x00000003)<<3)
#define MCF_USB_SR_CFG(x)              (((x)&0x00000003)<<5)
#define MCF_USB_SR_SUSP                (0x00000080)
#define MCF_USB_SR_RST                 (0x00000100)

/* Bit definitions and macros for MCF_USB_CR */
#define MCF_USB_CR_RESUME              (0x00000001)
#define MCF_USB_CR_USBRST              (0x00000004)
#define MCF_USB_CR_USBENA              (0x00000008)
#define MCF_USB_CR_USBSPD              (0x00000010)
#define MCF_USB_CR_CE                  (0x00000020)
#define MCF_USB_CR_CO                  (0x00000040)

/* Bit definitions and macros for MCF_USB_DAR */
#define MCF_USB_DAR_DADR(x)            (((x)&0x000007FF)<<0)
#define MCF_USB_DAR_BSY                (0x40000000)
#define MCF_USB_DAR_CFG                (0x80000000)

/* Bit definitions and macros for MCF_USB_DDR */
#define MCF_USB_DDR_DDAT(x)            (((x)&0x000000FF)<<0)

/* Bit definitions and macros for MCF_USB_ISR */
#define MCF_USB_ISR_CC                 (0x00000001)
#define MCF_USB_ISR_FM                 (0x00000002)
#define MCF_USB_ISR_SUSP               (0x00000004)
#define MCF_USB_ISR_RES                (0x00000008)
#define MCF_USB_ISR_RSTR               (0x00000010)
#define MCF_USB_ISR_RSTP               (0x00000020)
#define MCF_USB_ISR_SOF                (0x00000040)
#define MCF_USB_ISR_MSOF               (0x00000080)

/* Bit definitions and macros for MCF_USB_IMR */
#define MCF_USB_IMR_CC                 (0x00000001)
#define MCF_USB_IMR_FM                 (0x00000002)
#define MCF_USB_IMR_SUSP               (0x00000004)
#define MCF_USB_IMR_RES                (0x00000008)
#define MCF_USB_IMR_RSTR               (0x00000010)
#define MCF_USB_IMR_RSTP               (0x00000020)
#define MCF_USB_IMR_SOF                (0x00000040)
#define MCF_USB_IMR_MSOF               (0x00000080)

/* Bit definitions and macros for MCF_USB_MCR */
#define MCF_USB_MCR_MEMC(x)            (((x)&0x00000003)<<24)

/* Bit definitions and macros for MCF_USB_EPnSR */
#define MCF_USB_EPnSR_FS               (0x00000001)
#define MCF_USB_EPnSR_FL               (0x00000002)
#define MCF_USB_EPnSR_ZLPS             (0x00000004)
#define MCF_USB_EPnSR_TYP(x)           (((x)&0x00000003)<<3)
#define MCF_USB_EPnSR_MAX(x)           (((x)&0x00000003)<<5)
#define MCF_USB_EPnSR_DIR              (0x00000080)
#define MCF_USB_EPnSR_SIP              (0x00000100)
#define MCF_USB_EPnSR_BYTE_COUNT(x)    (((x)&0x00000FFF)<<16)

/* Bit definitions and macros for MCF_USB_EPnISR */
#define MCF_USB_EPnISR_EOF             (0x00000001)
#define MCF_USB_EPnISR_DR              (0x00000002)
#define MCF_USB_EPnISR_EOT             (0x00000004)
#define MCF_USB_EPnISR_MDR             (0x00000008)
#define MCF_USB_EPnISR_FL              (0x00000010)
#define MCF_USB_EPnISR_FH              (0x00000020)
#define MCF_USB_EPnISR_FE              (0x00000040)
#define MCF_USB_EPnISR_FM              (0x00000080)
#define MCF_USB_EPnISR_FF              (0x00000100)

/* Bit definitions and macros for MCF_USB_EPnIMR */
#define MCF_USB_EPnIMR_EOF             (0x00000001)
#define MCF_USB_EPnIMR_DR              (0x00000002)
#define MCF_USB_EPnIMR_EOT             (0x00000004)
#define MCF_USB_EPnIMR_MDR             (0x00000008)
#define MCF_USB_EPnIMR_FL              (0x00000010)
#define MCF_USB_EPnIMR_FH              (0x00000020)
#define MCF_USB_EPnIMR_FE              (0x00000040)
#define MCF_USB_EPnIMR_FM              (0x00000080)
#define MCF_USB_EPnIMR_FF              (0x00000100)

/* Bit definitions and macros for MCF_USB_EPnFSR */
#define MCF_USB_EPnFSR_EMPTY           (0x00010000)
#define MCF_USB_EPnFSR_ALARM           (0x00020000)
#define MCF_USB_EPnFSR_FULL            (0x00040000)
#define MCF_USB_EPnFSR_FR              (0x00080000)
#define MCF_USB_EPnFSR_OF              (0x00100000)
#define MCF_USB_EPnFSR_UF              (0x00200000)
#define MCF_USB_EPnFSR_RXW             (0x00400000)
#define MCF_USB_EPnFSR_F3              (0x01000000)
#define MCF_USB_EPnFSR_F2              (0x02000000)
#define MCF_USB_EPnFSR_F1              (0x04000000)
#define MCF_USB_EPnFSR_F0              (0x08000000)

/* Bit definitions and macros for MCF_USB_EPnFCR */
#define MCF_USB_EPnFCR_GR(x)           (((x)&0x00000007)<<24)
#define MCF_USB_EPnFCR_FRAME           (0x08000000)
#define MCF_USB_EPnFCR_WFR             (0x20000000)

/* Bit definitions and macros for MCF_USB_EPnLRFP */
#define MCF_USB_EPnLRFP_LRFP(x)        (((x)&0x00000FFF)<<0)

/* Bit definitions and macros for MCF_USB_EPnLWFP */
#define MCF_USB_EPnLWFP_LWFP(x)        (((x)&0x00000FFF)<<0)

/* Bit definitions and macros for MCF_USB_EPnFAR */
#define MCF_USB_EPnFAR_ALRM(x)         (((x)&0x00000FFF)<<0)

/* Bit definitions and macros for MCF_USB_EPnFRP */
#define MCF_USB_EPnFRP_RP(x)           (((x)&0x00000FFF)<<0)

/* Bit definitions and macros for MCF_USB_EPnFWP */
#define MCF_USB_EPnFWP_WP(x)           (((x)&0x00000FFF)<<0)

/********************************************************************/

#endif /* __MCF5275_USB_H__ */
