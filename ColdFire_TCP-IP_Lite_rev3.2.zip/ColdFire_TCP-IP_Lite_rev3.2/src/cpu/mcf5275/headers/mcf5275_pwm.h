/*
 * File:	mcf5275_pwm.h
 * Purpose:	Register and bit definitions for the MCF5275
 *
 * Notes:	
 *	
 */

#ifndef __MCF5275_PWM_H__
#define __MCF5275_PWM_H__

/*********************************************************************
*
* Pulse Width Modulation (PWM)
*
*********************************************************************/

/* Register read/write macros */
#define MCF_PWM_PWME          (*(vuint8 *)(void*)(&__IPSBAR[0x001D0000]))
#define MCF_PWM_PWMPOL        (*(vuint8 *)(void*)(&__IPSBAR[0x001D0001]))
#define MCF_PWM_PWMCLK        (*(vuint8 *)(void*)(&__IPSBAR[0x001D0002]))
#define MCF_PWM_PWMPRCLK      (*(vuint8 *)(void*)(&__IPSBAR[0x001D0003]))
#define MCF_PWM_PWMCAE        (*(vuint8 *)(void*)(&__IPSBAR[0x001D0004]))
#define MCF_PWM_PWMCTL        (*(vuint8 *)(void*)(&__IPSBAR[0x001D0005]))
#define MCF_PWM_PWMSCLA       (*(vuint8 *)(void*)(&__IPSBAR[0x001D0008]))
#define MCF_PWM_PWMSCLB       (*(vuint8 *)(void*)(&__IPSBAR[0x001D0009]))
#define MCF_PWM_PWMCNT0       (*(vuint8 *)(void*)(&__IPSBAR[0x001D000C]))
#define MCF_PWM_PWMCNT1       (*(vuint8 *)(void*)(&__IPSBAR[0x001D000D]))
#define MCF_PWM_PWMCNT2       (*(vuint8 *)(void*)(&__IPSBAR[0x001D000E]))
#define MCF_PWM_PWMCNT3       (*(vuint8 *)(void*)(&__IPSBAR[0x001D000F]))
#define MCF_PWM_PWMCNTn(x)    (*(vuint8 *)(void*)(&__IPSBAR[0x001D000C+((x)*0x001)]))
#define MCF_PWM_PWMPER0       (*(vuint8 *)(void*)(&__IPSBAR[0x001D0012]))
#define MCF_PWM_PWMPER1       (*(vuint8 *)(void*)(&__IPSBAR[0x001D0013]))
#define MCF_PWM_PWMPER2       (*(vuint8 *)(void*)(&__IPSBAR[0x001D0014]))
#define MCF_PWM_PWMPER3       (*(vuint8 *)(void*)(&__IPSBAR[0x001D0015]))
#define MCF_PWM_PWMPERn(x)    (*(vuint8 *)(void*)(&__IPSBAR[0x001D0012+((x)*0x001)]))
#define MCF_PWM_PWMDTY0       (*(vuint8 *)(void*)(&__IPSBAR[0x001D0018]))
#define MCF_PWM_PWMDTY1       (*(vuint8 *)(void*)(&__IPSBAR[0x001D0019]))
#define MCF_PWM_PWMDTY2       (*(vuint8 *)(void*)(&__IPSBAR[0x001D001A]))
#define MCF_PWM_PWMDTY3       (*(vuint8 *)(void*)(&__IPSBAR[0x001D001B]))
#define MCF_PWM_PWMDTYn(x)    (*(vuint8 *)(void*)(&__IPSBAR[0x001D0018+((x)*0x001)]))

/* Bit definitions and macros for MCF_PWM_PWME */
#define MCF_PWM_PWME_PWME0          (0x01)
#define MCF_PWM_PWME_PWME1          (0x02)
#define MCF_PWM_PWME_PWME2          (0x04)
#define MCF_PWM_PWME_PWME3          (0x08)

/* Bit definitions and macros for MCF_PWM_PWMPOL */
#define MCF_PWM_PWMPOL_PPOL0        (0x01)
#define MCF_PWM_PWMPOL_PPOL1        (0x02)
#define MCF_PWM_PWMPOL_PPOL2        (0x04)
#define MCF_PWM_PWMPOL_PPOL3        (0x08)

/* Bit definitions and macros for MCF_PWM_PWMCLK */
#define MCF_PWM_PWMCLK_PCLK0        (0x01)
#define MCF_PWM_PWMCLK_PCLK1        (0x02)
#define MCF_PWM_PWMCLK_PCLK2        (0x04)
#define MCF_PWM_PWMCLK_PCLK3        (0x08)

/* Bit definitions and macros for MCF_PWM_PWMPRCLK */
#define MCF_PWM_PWMPRCLK_PCKA(x)    (((x)&0x07)<<0)
#define MCF_PWM_PWMPRCLK_PCKB(x)    (((x)&0x07)<<4)

/* Bit definitions and macros for MCF_PWM_PWMCAE */
#define MCF_PWM_PWMCAE_CAE0         (0x01)
#define MCF_PWM_PWMCAE_CAE1         (0x02)
#define MCF_PWM_PWMCAE_CAE2         (0x04)
#define MCF_PWM_PWMCAE_CAE3         (0x08)

/* Bit definitions and macros for MCF_PWM_PWMCTL */
#define MCF_PWM_PWMCTL_PFRZ         (0x04)
#define MCF_PWM_PWMCTL_PSWAI        (0x08)
#define MCF_PWM_PWMCTL_CON01        (0x10)
#define MCF_PWM_PWMCTL_CON23        (0x20)

/********************************************************************/

#endif /* __MCF5275_PWM_H__ */
