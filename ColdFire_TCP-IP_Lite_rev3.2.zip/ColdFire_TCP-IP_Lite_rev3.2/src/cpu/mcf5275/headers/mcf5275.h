/*
 * File:	mcf5275.h
 * Purpose:	Register and bit definitions for the MCF5275
 *
 * Notes:	
 *	
 */

#ifndef __MCF5275_H__
#define __MCF5275_H__

/*********************************************************************/

#include "mcf5275_ccm.h"
#include "mcf5275_cs.h"
#include "mcf5275_dma.h"
#include "mcf5275_eport.h"
#include "mcf5275_fec.h"
#include "mcf5275_gpio.h"
#include "mcf5275_i2c.h"
#include "mcf5275_intc0.h"
#include "mcf5275_intc1.h"
#include "mcf5275_mdha.h"
#include "mcf5275_pit.h"
#include "mcf5275_fmpll.h"
#include "mcf5275_pwm.h"
#include "mcf5275_qspi.h"
#include "mcf5275_rcm.h"
#include "mcf5275_rng.h"
#include "mcf5275_scm.h"
#include "mcf5275_sdramc.h"
#include "mcf5275_skha.h"
#include "mcf5275_sram.h"
#include "mcf5275_timer.h"
#include "mcf5275_uart.h"
#include "mcf5275_usb.h"
#include "mcf5275_wtm.h"

/********************************************************************/

#endif /* __MCF5275_H__ */
