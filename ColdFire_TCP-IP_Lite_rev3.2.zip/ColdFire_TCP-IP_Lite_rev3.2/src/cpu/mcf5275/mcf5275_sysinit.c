/*********************************************************************
 *
 * Copyright:
 *	2005 FREESCALE, INC. All Rights Reserved.  
 *  You are hereby granted a copyright license to use, modify, and
 *  distribute the SOFTWARE so long as this entire notice is
 *  retained without alteration in any modified and/or redistributed
 *  versions, and that such modified versions are clearly identified
 *  as such. No licenses are granted by implication, estoppel or
 *  otherwise under any patents or trademarks of Motorola, Inc. This 
 *  software is provided on an "AS IS" basis and without warranty.
 *
 *  To the maximum extent permitted by applicable law, FREESCALE 
 *  DISCLAIMS ALL WARRANTIES WHETHER EXPRESS OR IMPLIED, INCLUDING 
 *  IMPLIED WARRANTIES OF MERCHANTABILITY OR FITNESS FOR A PARTICULAR
 *  PURPOSE AND ANY WARRANTY AGAINST INFRINGEMENT WITH REGARD TO THE 
 *  SOFTWARE (INCLUDING ANY MODIFIED VERSIONS THEREOF) AND ANY 
 *  ACCOMPANYING WRITTEN MATERIALS.
 * 
 *  To the maximum extent permitted by applicable law, IN NO EVENT
 *  SHALL FREESCALE BE LIABLE FOR ANY DAMAGES WHATSOEVER (INCLUDING 
 *  WITHOUT LIMITATION, DAMAGES FOR LOSS OF BUSINESS PROFITS, BUSINESS 
 *  INTERRUPTION, LOSS OF BUSINESS INFORMATION, OR OTHER PECUNIARY
 *  LOSS) ARISING OF THE USE OR INABILITY TO USE THE SOFTWARE.   
 * 
 *  Freescale assumes no responsibility for the maintenance and support
 *  of this software
 ********************************************************************/

/*
 * File:		mcf5275_sysinit.c
 * Purpose:		Reset configuration of the M5275EVB
 */

#include "common.h"

/********************************************************************/

void mcf5275_wtm_init(void);
void mcf5275_pll_init(void);
void mcf5275_scm_init(void);
void mcf5275_gpio_init(void);
void mcf5275_cs_init(void);
void mcf5275_sdram_init(void);
void mcf5275_PHY_init(void);

/* Actual system clock frequency */
int sys_clk_khz;
int sys_clk_mhz;

/********************************************************************/
void
sysinit(void)
{
	extern char __DATA_ROM[];
	extern char __DATA_RAM[];
	extern char __DATA_END[];
	extern char __BSS_START[];
	extern char __BSS_END[];
	extern uint32 VECTOR_TABLE[];
	extern uint32 __VECTOR_RAM[];
	register uint32 n;
	register uint8 *dp, *sp;

 	sys_clk_khz = SYS_CLK_KHZ;
 	sys_clk_mhz = SYS_CLK_MHZ;

	mcf5275_wtm_init();
	mcf5275_pll_init();
	mcf5275_gpio_init();
	mcf5275_scm_init();
 	uart_init(0);
 	uart_init(1);
	mcf5275_cs_init();
	mcf5275_sdram_init();
	mcf5275_PHY_init();
	
	/* Turn Instruction Cache ON */
/*	mcf5xxx_wr_cacr(0
		| MCF5XXX_CACR_CENB
		| MCF5XXX_CACR_CINV
		| MCF5XXX_CACR_DISD
		| MCF5XXX_CACR_CEIB
		| MCF5XXX_CACR_CLNF_00);
*/		
}
/********************************************************************/
void 
mcf5275_wtm_init(void)
{
	/*
	 * Disable Software Watchdog Timer
	 */
	MCF_WTM_WCR = 0;
}
/********************************************************************/
void 
mcf5275_pll_init(void)
{
	uint32 temp;
	/*
	 * Multiply 25Mhz reference crystal to acheive system clock of 150Mhz
	 */
	
	MCF_FMPLL_SYNCR = MCF_FMPLL_SYNCR_MFD(1) | MCF_FMPLL_SYNCR_RFD(0);
	
	while (!(MCF_FMPLL_SYNSR & MCF_FMPLL_SYNSR_LOCK))
	{
		
	};
}
/********************************************************************/
void
mcf5275_scm_init(void)
{
	/* 
	 * Enable on-chip modules to access internal SRAM 
	 */
	MCF_SCM_RAMBAR = (0 
		| MCF_SCM_RAMBAR_BA(SRAM_ADDRESS>>16)
		| MCF_SCM_RAMBAR_BDE);
}
/********************************************************************/
void 
mcf5275_gpio_init(void)
{
	uint8 temp;
	
	/* 
	 * Initialize PAR to enable SDRAM signals 
	 */	
	MCF_GPIO_PAR_SDRAM = 0x03FF;

    /* Pin assignments for port FECI2C 
           Pin FEC0_MDIO  : FEC0 Ethernet management data, FEC0_MDIO 
           Pin FEC0_MDC   : FEC0 Ethernet management data clock, FEC0_MDC 
           Pin FEC1_MDIO  : FEC1 Ethernet management data, FEC1_MDIO 
           Pin FEC1_MDC   : FEC1 Ethernet management data clock, FEC1_MDC 
           Pin SDA        : GPIO input 
           Pin SCL        : GPIO input 
    */

    /*     PDDR_FECI2C[DDFECI2C5] = 0 
           PDDR_FECI2C[DDFECI2C4] = 0 
           PDDR_FECI2C[DDFECI2C3] = 0 
           PDDR_FECI2C[DDFECI2C2] = 0 
           PDDR_FECI2C[DDFECI2C1] = 0 
           PDDR_FECI2C[DDFECI2C0] = 0 
    */
    MCF_GPIO_PDDR_FECI2C = 0;

    /*     PAR_FECI2C[PAR_MDIO0] = %11 
           PAR_FECI2C[PAR_MDC0] = %11 
           PAR_FECI2C[PAR_MDIO1] = 1 
           PAR_FECI2C[PAR_MDC1] = 1 
           PAR_FECI2C[PAR_SDA] = 0 
           PAR_FECI2C[PAR_SCL] = 0 
    */
    MCF_GPIO_PAR_FECI2C = MCF_GPIO_PAR_FECI2C_PAR_MDIO0(0x3) |
                          MCF_GPIO_PAR_FECI2C_PAR_MDC0(0x3)  |
                          MCF_GPIO_PAR_FECI2C_PAR_MDIO1      |
                          MCF_GPIO_PAR_FECI2C_PAR_MDC1;

    /* Pin assignments for port FEC0L 
           Pins are FEC0 Ethernet 7-wire or MII-mode functions 
    */

    /* Pin assignments for port FEC0H 
           Pins are FEC0 Ethernet additional MII-mode functions 
    */

    /*     PAR_FEC0[PAR_FEC0H] = 1 
           PAR_FEC0[PAR_FEC0L] = 1 
    */
    MCF_GPIO_PAR_FEC0HL = MCF_GPIO_PAR_FEC0HL_PAR_FEC0H |
                          MCF_GPIO_PAR_FEC0HL_PAR_FEC0L;

    /* Pin assignments for port FEC1L 
           Pins are FEC1 Ethernet 7-wire or MII-mode functions 
    */

    /* Pin assignments for port FEC1H 
           Pins are FEC1 Ethernet additional MII-mode functions 
    */

    /*     PAR_FEC1[PAR_FEC1H] = 1 
           PAR_FEC1[PAR_FEC1L] = 1 
    */
    MCF_GPIO_PAR_FEC1HL = MCF_GPIO_PAR_FEC1HL_PAR_FEC1H |
                          MCF_GPIO_PAR_FEC1HL_PAR_FEC1L;

	/* 
	 * Set Port UA to initialize URXD0/URXD1/URXD2 UTXD0/UTXD1/UTXD2 
	 */
	MCF_GPIO_PAR_UART = 0x30CC;		

}

/********************************************************************/
void
mcf5275_sdram_init(void)
{

	/* Initialize DDR on the M5275EVB board */
	
	/*
	 * Check to see if the SDRAM has already been initialized
	 * by a run control tool
	 */
	if (!(MCF_SDRAMC_SDCR & MCF_SDRAMC_SDCR_REF))
	{

		/* Initialize SDRAM chip select */
        MCF_SDRAMC_SDBAR0 = (0
            | MCF_SDRAMC_SDBARn_BASE(SDRAM_ADDRESS)
            );
            
		MCF_SDRAMC_SDMR0 = (0
			| MCF_SDRAMC_SDMRn_BAM_32M
			| MCF_SDRAMC_SDMRn_V
			);            

		/* Initialize timing parameters */
		MCF_SDRAMC_SDCFG1 = 0x83711630;
		MCF_SDRAMC_SDCFG2 = 0x46770000;		
            
		/* Enable clock and write to SDMR */
		MCF_SDRAMC_SDCR = (0
			| MCF_SDRAMC_SDCR_MODE_EN
			| MCF_SDRAMC_SDCR_CKE
   		 	);
   	   		
   		/* Set IPALL bit */ 	
		MCF_SDRAMC_SDCR |= MCF_SDRAMC_SDCR_IPALL;		   		 	
   		 	
		/* Dummy write to SDRAM to issue PALL */
		*(uint32 *)(SDRAM_ADDRESS) = 0xA5A59696;
		
		
		/* Write extended mode register */
		MCF_SDRAMC_SDMR = (0
			| MCF_SDRAMC_SDMR_BNKAD_LEMR
			| MCF_SDRAMC_SDMR_AD(0x0)
			| MCF_SDRAMC_SDMR_CMD        
            );
                    
		/* Dummy write to SDRAM to issue LEMR */
		*(uint32 *)(SDRAM_ADDRESS) = 0xA5A59696;
        
		/* Write mode register and reset DLL */
        MCF_SDRAMC_SDMR = 0x058D0000;
                         
		/* Dummy write to SDRAM to issue LMR */
		*(uint32 *)(SDRAM_ADDRESS) = 0xA5A59696;
		
		/* Clear SDMR CMD bit to stop issuing LMR/LEMR commands */
		MCF_SDRAMC_SDMR &= ~(MCF_SDRAMC_SDMR_CMD);    
    		
		/* Execute a PALL command */
		MCF_SDRAMC_SDCR |= MCF_SDRAMC_SDCR_IPALL;
				
		/* Dummy write to SDRAM to issue PALL */
		*(uint32 *)(SDRAM_ADDRESS) = 0xA5A59696;
 		
 		/* Clear IPALL bit to stop issuing PALL commands */
 		MCF_SDRAMC_SDCR &= ~(MCF_SDRAMC_SDCR_IPALL);
 		 
			/* Perform two REF cycles */
		MCF_SDRAMC_SDCR |= MCF_SDRAMC_SDCR_IREF;
		
		/* Dummy write to SDRAM to issue first REF */
		*(uint32 *)(SDRAM_ADDRESS) = 0xA5A59696;

		/* Dummy write to SDRAM to issue second REF */
		*(uint32 *)(SDRAM_ADDRESS) = 0xA5A59696;
	
		/* Write mode register and clear reset DLL */
        MCF_SDRAMC_SDMR = 0x018D0000;
				
		/* Dummy write to SDRAM to issue LMR */
		*(uint32 *)(SDRAM_ADDRESS) = 0xA5A59696;
		
		/* Clear SDMR CMD bit to stop issuing LMR/LEMR commands */
		MCF_SDRAMC_SDMR &= ~(MCF_SDRAMC_SDMR_CMD);
		
		MCF_SDRAMC_SDCR &= ~MCF_SDRAMC_SDCR_MODE_EN;		 
		
		/* Enable auto refresh and lock SDMR */
		MCF_SDRAMC_SDCR = (0
			| MCF_SDRAMC_SDCR_CKE
			| MCF_SDRAMC_SDCR_REF
			| MCF_SDRAMC_SDCR_MUX(1)
			| MCF_SDRAMC_SDCR_RCNT((SDRAM_TREFI/(PERIOD*64)) - 1 + 1) /* 1 added to round up */
			| MCF_SDRAMC_SDCR_DQS_OE(0x3) 
            );
            
	}
}
/********************************************************************/
void
mcf5275_cs_init(void)
{
	/* 
	 * ChipSelect 1 - External SRAM 
	 */
	MCF_CS_CSAR1 = MCF_CS_CSAR_BA(EXT_SRAM_ADDRESS);
	MCF_CS_CSCR1 = (0
		| MCF_CS_CSCR_IWS(6)
		| MCF_CS_CSCR_AA
		| MCF_CS_CSCR_PS_32);
	
	MCF_CS_CSMR1 = MCF_CS_CSMR_BAM_1M | MCF_CS_CSMR_V;
    
    /* 
	 * ChipSelect 0 - External Flash 
	 */ 
	MCF_CS_CSAR0 = MCF_CS_CSAR_BA(EXT_FLASH_ADDRESS);
	MCF_CS_CSCR0 = (0
		| MCF_CS_CSCR_IWS(6)
		| MCF_CS_CSCR_AA
		| MCF_CS_CSCR_PS_16);
	MCF_CS_CSMR0 = MCF_CS_CSMR_BAM_2M | MCF_CS_CSMR_V;
}

/********************************************************************/
// Init PHY
/********************************************************************/
void mcf5275_PHY_init(void)
{
  	unsigned short		reg0;
  	int i;

//FSL replace function call	fec_mii_init((SYSTEM_CLOCK));  with below MCF_FEC_MSCR macro
    /*
     * Configure MII interface speed. Must be <= 2.5MHz
     *
     * Desired MII clock is 2.5MHz
     * MII Speed Setting = System_Clock_Bus_Speed / (2.5MHz * 2)
     */
    MCF_FEC_MSCR(ETH_PORT) = MCF_FEC_MSCR_MII_SPEED((uint32)(SYS_CLK_MHZ/2));

#if 1		//FSL testing various PHY initializations

   while(!(fec_mii_read(FEC_PHY0, PHY_REG_CR, &reg0)))		//FSL read PHY control register
   {
	reg0=0;
   };
   reg0 &= PHY_R0_DPLX;		//FSL See what the duplex setting request is.
   
   while(!(fec_mii_read(FEC_PHY0, PHY_REG_TxCR, &reg0)))		//FSL read PHY control register
   {
	reg0=0;
   };
   reg0 = (reg0>>2)&7;		//FSL See what the duplex setting Really is in Tx PHY register.
   

#if 0		//FSL Powering down then up seemed to have same result as just doing RESET
	while(!(fec_mii_read(FEC_PHY0, PHY_REG_CR, &reg0)))		//FSL read PHY control register
	{
		reg0=0;
	};
	reg0 |= PHY_R0_PD|PHY_R0_DT;		//FSL Power down and disable transmitter
	while(!fec_mii_write(FEC_PHY0, PHY_REG_CR, reg0 ))
	{
	};	
 
	while(!(fec_mii_read(FEC_PHY0, PHY_REG_CR, &reg0)))		//FSL read PHY control register
	{
		reg0=0;
	};
	reg0 &= ~(PHY_R0_PD|PHY_R0_DT);		//FSL Power up and enable transmitter
	while(!fec_mii_write(FEC_PHY0, PHY_REG_CR, reg0 ))
	{
	};	
 
 
   	while(!fec_mii_write(FEC_PHY0, PHY_REG_CR, PHY_R0_RESET ))	//FSL reset
	{
	};	

#endif


#if 1 
	while(!(fec_mii_read(FEC_PHY0, PHY_REG_ID1, &reg0)))		
	{
	};		//FSL read ID1 register
    
	while(!(fec_mii_read(FEC_PHY0, PHY_REG_ANAR, &reg0)))		
	{
	};		//FSL read Auto-negotiation Advertisement register
    
	while(!(fec_mii_read(FEC_PHY0, PHY_REG_CR, &reg0)))		
	{
		reg0=0;
	};		//FSL read PHY control register

	reg0 |= PHY_R0_ANE;	//FSL enable autonegotiation

#if (!AUTO)				//FSL When not autonegotiating, Duplex should be set to half.
	reg0 &= ~PHY_R0_ANE;	//FSL disable autonegotiation
	
	if (BaseT==100)		//FSL BaseT set to 100mpbs
		reg0 |= 0x2000;								// 100Mbps
	else				//FSL BaseT defaults to 10mbps
		reg0 &= ~0x2000;							// 10Mbps

	if (DUPLEX==0)
		reg0 |= 0x0100;								// Full Duplex
	else		
		reg0 &= ~0x0100;							// Half Duplex

	while(!fec_mii_write(FEC_PHY0, PHY_REG_CR, reg0 ))
	{
	};					//Update control register

	while(!fec_mii_write(FEC_PHY0, PHY_REG_CR, reg0|PHY_R0_RAN ))
	{
	};					//Force re-negotiation

#endif

#endif

	do		//FSL read PHY status register
	{
		fec_mii_read(FEC_PHY0, PHY_REG_SR, &reg0);
	}while (!(reg0&(PHY_R1_LS)));		//FSL exit while loop when Link Status up

   while(!(fec_mii_read(FEC_PHY0, PHY_REG_CR, &reg0)))		//FSL read PHY control register
   {
	reg0=0;
   };
   reg0 &= PHY_R0_DPLX;		//FSL See what the duplex setting is.
   
   while(!(fec_mii_read(FEC_PHY0, PHY_REG_TxCR, &reg0)))	//FSL read PHY control register
   {
	reg0=0;
   };
   reg0 = (reg0>>2)&7;		//FSL See what the duplex setting is in Tx PHY register.
/* //FSL since waiting for "link-up" setting above, do not need delay loop   	
	i=1000000;		//FSL delay loop (need > 2ms delay before doing SW Reset)
	do
	{
		asm (	nop);
	} while (i--);
*/	

#else

		while(!fec_mii_read(FEC_PHY0, PHY_REG_CR, &reg0))
		{
		};				//FSL read PHY Control Register
		
		
#if (!AUTO)
	if (BaseT==100)		//FSL BaseT set to 100mpbs
		reg0 |= 0x2000;								// 100Mbps
	else				//FSL BaseT defaults to 10mbps
		reg0 &= ~0x2000;							// 10Mbps

	if (DUPLEX==0)
		reg0 |= 0x0100;								// Full Duplex
	else		
		reg0 &= ~0x0100;							// Half Duplex

#endif
	while(!fec_mii_write( FEC_PHY0, PHY_REG_CR, reg0|0x0200 ))
	{
	};					//Force re-negotiation
	

#endif
}
/********************************************************************/
