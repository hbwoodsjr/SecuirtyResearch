/*
 * File:		sysinit.c
 * Purpose:		Reset configuration of the M52259EVB
 *
 * Notes:
 */

#include "common.h"

/********************************************************************/

void mcf52259_init(void);
void mcf52259_wtm_init(void);
void mcf52259_pll_init(void);
void mcf52259_scm_init(void);
void mcf52259_ccm_init(void);
void mcf52259_mb_init(void);
void mcf52259_gpio_init(void);
void mcf52259_ePHY_init(void);
void mcf52259_powerup_config(void);
void mcf52259_wtm_config(void);

//extern int SoftEthernetNegotiation( int seconds );		//FSL commented out
extern int poll_switches( void );
extern void Bootloader_Main(void);

uint8	powerup_config_flags = 0;

/********************************************************************/
void
mcf52259_init(void)
{

	MCF_GPIO_PDDPAR = 0x0F;		//enable pst[0..3]
		
	/*
	 * Set Port UA to initialize URXD0/UTXD0
	 */
    MCF_GPIO_PUAPAR = 0
        | MCF_GPIO_PUAPAR_URXD0_URXD0
        | MCF_GPIO_PUAPAR_UTXD0_UTXD0;

    MCF_GPIO_PUBPAR = 0
        | MCF_GPIO_PUBPAR_URXD1_URXD1
        | MCF_GPIO_PUBPAR_UTXD1_UTXD1;

	/* Set real time clock freq */

//FSL when RTC running, update the below line of code
//	MCF_CLOCK_RTCDR = 25000000;
	
	mcf52259_wtm_init();
	mcf52259_pll_init();
	mcf52259_scm_init();
	mcf52259_ccm_init();
	mcf52259_gpio_init();
#ifdef M52259EVB
	mcf52259_mb_init();
#endif
    uart_init(0);
    uart_init(1);

	mcf52259_powerup_config();
	mcf52259_ePHY_init();
	Bootloader_Main();			//DES added for Ethernet S-Record upload capability
//	mcf52259_wtm_config();		//FSL added this function...reference M52233DEMO code
}

static uint8 x_cwcr=0;
static uint8 x_cwsr=0;

/********************************************************************/
void
mcf52259_wtm_init(void)
{
	/*
	 * Disable Software Watchdog Timer
	 */
	MCF_SCM_CWCR = 0;
			
}
/********************************************************************/
void
mcf52259_pll_init(void)
{
#ifdef M52259EVB
	/* The PLL pre-divider affects this!!! The pre-divider is 6
	 * So external OSC of 48MHz is divided by 6 to give a PLL CLK of 8MHz
	 * Setting the MFD=3 yields a 10x multiplication of the PLL CLK
	 * Therefore the 8MHz times 10x is 80MHz Fsystem
	 */

	MCF_CLOCK_SYNCR &= ~(MCF_CLOCK_SYNCR_PLLEN);	//disable PLL to program PLL registers
	MCF_CLOCK_SYNCR = MCF_CLOCK_SYNCR_MFD(3) | MCF_CLOCK_SYNCR_CLKSRC| MCF_CLOCK_SYNCR_PLLMODE | MCF_CLOCK_SYNCR_PLLEN ;

	while (!(MCF_CLOCK_SYNSR & MCF_CLOCK_SYNSR_LOCK))
	{
	}
#endif
#ifdef M52259DEMO
/*Required if booting with internal relaxation oscillator on, crystal off, & pll off, clkmod[1:0]=00 & xtal=1 */

	MCF_CLOCK_OCLR = 0xC0;    //turn on crystal
	MCF_CLOCK_CCLR = 0x00;    //switch to crystal 
    MCF_CLOCK_OCHR = 0x00;    //turn off relaxation osc

/*---------------------------------------------------------------------------------*/


	/* The PLL pre divider - 48MHz / 6 = 8MHz */
	MCF_CLOCK_CCHR =0x05;
	 
	 
	/* The PLL pre-divider affects this! 
	 * Multiply 48Mhz reference crystal /CCHR by 10 to acheive system clock of 80Mhz
	 */

	MCF_CLOCK_SYNCR &= ~(MCF_CLOCK_SYNCR_PLLEN);

    MCF_CLOCK_SYNCR |= MCF_CLOCK_SYNCR_CLKSRC | MCF_CLOCK_SYNCR_PLLMODE;
	
	//80
	MCF_CLOCK_SYNCR |= MCF_CLOCK_SYNCR_MFD(3) | MCF_CLOCK_SYNCR_RFD(0);
	//64
	//MCF_CLOCK_SYNCR = MCF_CLOCK_SYNCR_MFD(2) | MCF_CLOCK_SYNCR_RFD(0);
	//16
	//MCF_CLOCK_SYNCR = MCF_CLOCK_SYNCR_MFD(2) | MCF_CLOCK_SYNCR_RFD(2);
	//8
	//MCF_CLOCK_SYNCR = MCF_CLOCK_SYNCR_MFD(2) | MCF_CLOCK_SYNCR_RFD(3);
	//1
	//MCF_CLOCK_SYNCR = MCF_CLOCK_SYNCR_MFD(2) | MCF_CLOCK_SYNCR_RFD(6);
	
	MCF_CLOCK_SYNCR |= MCF_CLOCK_SYNCR_PLLEN;

	
	while (!(MCF_CLOCK_SYNSR & MCF_CLOCK_SYNSR_LOCK))
	{
	}

#endif	
}

/********************************************************************/
void
mcf52259_scm_init(void)
{
	/*
	 * Enable on-chip modules to access internal SRAM
	 */
	MCF_SCM_RAMBAR = (0
		| MCF_SCM_RAMBAR_BA(SRAM_ADDRESS)
		| MCF_SCM_RAMBAR_BDE);
}

/********************************************************************/
void
mcf52259_ccm_init(void)
{

}

/********************************************************************/
#ifdef M52259EVB
void
mcf52259_mb_init(void)
{
		static int i;
		static int8 j;
		static int tempi;
		
	/*
	 * Enable MiniBus CS0 for MRAM access
	 */

	MCF_MB_CSAR(0) = (0
		| MCF_MB_CSAR_BA(MRAM_ADDRESS));

	MCF_MB_CSCR(0) = (0
		| MCF_MB_CSCR_SWS(0)
		| MCF_MB_CSCR_SWSEN(0)
		| MCF_MB_CSCR_ASET(0)		//FSL was 3
		| MCF_MB_CSCR_RDAH(0)		//FSL was 3
		| MCF_MB_CSCR_WRAH(0)		//FSL was 3
		| MCF_MB_CSCR_WS(1)			//FSL was 20
		| MCF_MB_CSCR_MUX(0)
		| MCF_MB_CSCR_AA(1)
		| MCF_MB_CSCR_PS(1)
		| MCF_MB_CSCR_BSTR(0)
		| MCF_MB_CSCR_BSTW(0));

	MCF_MB_CSMR(0) = (0
		| MCF_MB_CSMR_BAM(0x007f)
		| MCF_MB_CSMR_V(1));

#if 0	//FSL This is test code to write and read memory block continuously.
  while(1) 
  {
		for(i=0,j=0; i<0x80000; i++) 
		{
			(*(vuint8 *)(0x80000000 + i)) = j++;		//write
		}

		for(i=0; i<0x80000; i++) 
		{
			tempi = (*(vuint8 *)(0x80000000 + i));	//read
		}
	
  }
#endif
 
}
#endif
/********************************************************************/

tU08	gotlink;   						/**<Global Variable For Determination if
                                      * link is active (1=active)
                                      * defined in "main.c" */
                                      
void
mcf52259_gpio_init(void)
{
    /* 
     * Allow interrupts from ABORT, SW1, SW2, and SW3 (IRQ[7,1,3,5]) 
     */
     
	 MCF_GPIO_PNQPAR = 0x0000;		//FSL set NQ pins to GPIO mode
	 
#if MCF52259		//FSL created for MiniBus config and USB pin config
	 MCF_GPIO_PASPAR = 0x10;		//Enable ALE pin function
	 MCF_GPIO_PTEPAR = 0xff;		//Enable MB_A[7:0]
	 MCF_GPIO_PTFPAR = 0xff;		//Enable MB_A[15:8]
	 MCF_GPIO_PTGPAR = 0xff;		//Enable MB_A[19:16], CS, OE, RW
	 MCF_GPIO_PTHPAR = 0x5555;		//Enable MB_D[7:0]

#endif	

}

/********************************************************************/
// Init external PHY - National Semiconductor DP83640
/********************************************************************/
int DUPLEX_phy_r17_dpm;
void mcf52259_ePHY_init(void)
{
	uint32 		myctr; 					//generic counter variable
  	uint16		reg0;


	MCF_GPIO_PTIPAR = 0xff;		//Enable all pins to Ethernet function
	MCF_GPIO_PTJPAR = 0xff;		//Enable all pins to Ethernet function
	MCF_GPIO_PNQPAR = MCF_GPIO_PNQPAR_IRQ3_FEC_MDIO | MCF_GPIO_PNQPAR_IRQ5_FEC_MDC;	//Enable MII pins
	
//FSL replace function call	fec_mii_init((SYSTEM_CLOCK));  with below MCF_FEC_MSCR macro
    /*
     * Configure MII interface speed. Must be <= 2.5MHz
     *
     * Desired MII clock is 2.5MHz
     * MII Speed Setting = System_Clock_Bus_Speed / (2.5MHz * 2)
     */
	MCF_FEC_MSCR = MCF_FEC_MSCR_MII_SPEED((uint32)(SYS_CLK_MHZ/5)); 
#if 1
	do
	{
		while(!(fec_mii_read(FEC_PHY0, PHY_REG_CR, &reg0)))		//FSL read PHY control register
		{
			reg0=0;
		};
		
	} while(reg0&PHY_R0_RESET);		//Test RESET bit...1=in reset, 0=reset complete
#else
	for(myctr=0;myctr<32;myctr++)
	{
		fec_mii_read(myctr, PHY_REG_CR, &reg0);
		if(reg0 != 0xffff) 
			break;
	}
asm (	nop);
#endif
		
#if (!AUTO)
	if (BaseT==100)		//FSL BaseT set to 100mpbs
		reg0 |= 0x2000;								// 100Mbps
	else				//FSL BaseT defaults to 10mbps
		reg0 &= ~0x2000;							// 10Mbps

	if (DUPLEX==0)
		reg0 |= 0x0100;								// Full Duplex
	else		
		reg0 &= ~0x0100;							// Half Duplex

	while(!fec_mii_write( FEC_PHY0, PHY_REG_CR, reg0|0x0200 ))
	{
	};					//Force re-negotiation

#endif

	while(!(fec_mii_read(FEC_PHY0, 0x10, &reg0)))	// read PHY status register
	{
		reg0=0;
	};
	DUPLEX_phy_r17_dpm = (int)((reg0&0x0004)>>2);	// 1=full,0=half duplex...used in ifec.c
	
	do		//FSL read PHY status register
	{
		fec_mii_read(FEC_PHY0, 0x10, &reg0);
	}while (!(reg0&(PHY_R1_LS)));		//FSL exit while loop when Link Status up

}


/********************************************************************/
// powerup_config		Written by Eric Gregori
//
// This function reads the switches at power-up, and sets a power-up
// config flag.
/********************************************************************/
void mcf52259_powerup_config( void )
{
	powerup_config_flags = poll_switches();
}
/********************************************************************/
void
mcf52259_wtm_config(void)
{
       /*
        * Disable Software Watchdog Timer
        */

    MCF_SCM_CWCR = 0;

}
/********************************************************************/
