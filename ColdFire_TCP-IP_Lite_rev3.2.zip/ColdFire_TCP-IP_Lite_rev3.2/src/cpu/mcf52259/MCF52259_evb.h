/*
 * File:		mcf52259_evb.h
 * Purpose:		Evaluation board definitions and memory map information
 *
 * Notes:
 */

#ifndef _MCF52259_EVB_H
#define _MCF52259_EVB_H

/********************************************************************/

#include "mcf5xxx.h"
#include "io.h"

/********************************************************************/

/*
 * Debug prints ON (#undef) or OFF (#define)
 */
#undef DEBUG

/* 
 * System Bus Clock Info 
 */
#define	SYS_CLK_MHZ		80		/* system bus frequency in MHz */
#define SYS_CLK_KHZ		80000	/* system bus frequency in kHz */

extern int sys_clk_khz;
extern int sys_clk_mhz;
/* 
 * System Bus Clock Info 
 */
#define	SYSTEM_CLOCK			80		/* system bus frequency in MHz */

/*
 * LED Info
 */
//#undef HAS_LEDS
#define HAS_LEDS 1

/*
 * Ethernet Port Info
 */
#ifdef M52259DEMO
#define FEC_PHY0            (0x01)		//FSL per schematic
#endif
#ifdef M52259EVB
#define FEC_PHY0            (0x01)		//FSL? per schematic
#endif

/* 
 * Memory map definitions from linker command files 
 */
extern uint8 __IPSBAR[];
extern uint8 __SRAM[];
extern uint8 __SRAM_SIZE[];
extern uint8 __MRAM[];
extern uint8 __MRAM_SIZE[];

/* 
 * Memory Map Info 
 */
#define SRAM_ADDRESS			(uint32)__SRAM
#define SRAM_SIZE				(uint32)__SRAM_SIZE

#define MRAM_ADDRESS			(uint32)__MRAM
#define MRAM_SIZE				(uint32)__MRAM_SIZE

/*
 *	Interrupt Controller Definitions
 */
#define TIMER_NETWORK_LEVEL		3
#define FEC_LEVEL				4

/********************************************************************/
/********************************************************************/
/********************************************************************/
#ifdef HAS_LEDS /* { */
static unsigned char LED3=1,LED2=1,LED1=1,LED0=1;

	#define LED0_TOGGLE     MCF_GPIO_PORTTC = (uint8)(MCF_GPIO_PORTTC ^ MCF_GPIO_PORTTC_PORTTC0)
	#define LED1_TOGGLE     MCF_GPIO_PORTTC = (uint8)(MCF_GPIO_PORTTC ^ MCF_GPIO_PORTTC_PORTTC1);
	#define LED2_TOGGLE     MCF_GPIO_PORTTC = (uint8)(MCF_GPIO_PORTTC ^ MCF_GPIO_PORTTC_PORTTC2);
	#define LED3_TOGGLE     MCF_GPIO_PORTTC = (uint8)(MCF_GPIO_PORTTC ^ MCF_GPIO_PORTTC_PORTTC3);

	#define LED0_ON     	MCF_GPIO_PORTTC = (uint8)(MCF_GPIO_PORTTC | MCF_GPIO_PORTTC_PORTTC0)
	#define LED1_ON		    MCF_GPIO_PORTTC = (uint8)(MCF_GPIO_PORTTC | MCF_GPIO_PORTTC_PORTTC1);
	#define LED2_ON         MCF_GPIO_PORTTC = (uint8)(MCF_GPIO_PORTTC | MCF_GPIO_PORTTC_PORTTC2);
	#define LED3_ON         MCF_GPIO_PORTTC = (uint8)(MCF_GPIO_PORTTC | MCF_GPIO_PORTTC_PORTTC3);

	#define LED0_OFF        MCF_GPIO_PORTTC = (uint8)(MCF_GPIO_PORTTC & ~MCF_GPIO_PORTTC_PORTTC0)
	#define LED1_OFF        MCF_GPIO_PORTTC = (uint8)(MCF_GPIO_PORTTC & ~MCF_GPIO_PORTTC_PORTTC1);
	#define LED2_OFF        MCF_GPIO_PORTTC = (uint8)(MCF_GPIO_PORTTC & ~MCF_GPIO_PORTTC_PORTTC2);
	#define LED3_OFF        MCF_GPIO_PORTTC = (uint8)(MCF_GPIO_PORTTC & ~MCF_GPIO_PORTTC_PORTTC3);

	#define LED_INIT()		Leds_Init()
#else  /* No LEDS  */
	#define LED_INIT()		void()
#endif

/********************************************************************/
/********************************************************************/
void Leds_Init();
void board_led_display(uint8 number);
/********************************************************************/
/********************************************************************/
#endif /* _MCF52259_EVB_H */
