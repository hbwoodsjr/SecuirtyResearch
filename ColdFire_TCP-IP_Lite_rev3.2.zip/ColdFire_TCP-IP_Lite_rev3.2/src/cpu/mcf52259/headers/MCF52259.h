/* ColdFire C Header File
 * Copyright Freescale Semiconductor Inc
 * All rights reserved.
 *
 * 2008/02/26 Revision: 0.1
 *
 * (c) Copyright UNIS, spol. s r.o. 1997-2008
 * UNIS, spol. s r.o.
 * Jundrovska 33
 * 624 00 Brno
 * Czech Republic
 * http      : www.processorexpert.com
 * mail      : info@processorexpert.com
 */

#ifndef __MCF52259_H__
#define __MCF52259_H__

#ifdef __cplusplus
extern "C" {
#endif

#pragma define_section system ".system" far_absolute RW

/***
 * MCF52259 Derivative Memory map definitions from linker command files:
 * __IPSBAR, __RAMBAR, __RAMBAR_SIZE, __FLASHBAR, __FLASHBAR_SIZE linker
 * symbols must be defined in the linker command file.
 */

#define IPSBAR_ADDRESS   (uint32)__IPSBAR
#define RAMBAR_ADDRESS   (uint32)__RAMBAR
#define RAMBAR_SIZE      (uint32)__RAMBAR_SIZE
#define FLASHBAR_ADDRESS (uint32)__FLASHBAR
#define FLASHBAR_SIZE    (uint32)__FLASHBAR_SIZE


#include "MCF52259_SCM.h"
#include "MCF52259_DMA.h"
#include "MCF52259_UART.h"
#include "MCF52259_I2C.h"
#include "MCF52259_QSPI.h"
#include "MCF52259_TMR.h"
#include "MCF52259_INTC.h"
#include "MCF52259_FEC.h"
#include "MCF52259_GPIO.h"
#include "MCF52259_PAD.h"
#include "MCF52259_RCM.h"
#include "MCF52259_CCM.h"
#include "MCF52259_PMM.h"
#include "MCF52259_CLOCK.h"
#include "MCF52259_EPORT.h"
#include "MCF52259_BWT.h"
#include "MCF52259_PIT.h"
#include "MCF52259_FlexCAN.h"
#include "MCF52259_RTC.h"
#include "MCF52259_ADC.h"
#include "MCF52259_GPT.h"
#include "MCF52259_PWM.h"
#include "MCF52259_CFM.h"
#include "MCF52259_RNGA.h"
#include "MCF52259_MB.h"		//FSL created the MiniBus header

#ifdef __cplusplus
}
#endif


#endif /* __MCF52259_H__ */
