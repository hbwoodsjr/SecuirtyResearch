/* Coldfire C Header File
 * Copyright Freescale Semiconductor Inc
 * All rights reserved.
 *
 * 2008/02/26 
 */

//FSL created this header

#ifndef __MCF52259_MB_H__
#define __MCF52259_MB_H__


/*********************************************************************
*
* MiniBus (MB)
*
*********************************************************************/

/* Register read/write macros */
#define MCF_MB_CSAR0                        (*(vuint32 *)(0x40000080))
#define MCF_MB_CSMR0                        (*(vuint32 *)(0x40000084))
#define MCF_MB_CSCR0                        (*(vuint32 *)(0x40000088))

#define MCF_MB_CSAR1                        (*(vuint32 *)(0x40000080))
#define MCF_MB_CSMR1                        (*(vuint32 *)(0x40000084))
#define MCF_MB_CSCR1                        (*(vuint32 *)(0x40000088))

/* Register read/write macros */
#define MCF_MB_CSAR(x)                     (*(vuint32 *)(0x40000080) + ((x)*0xc))
#define MCF_MB_CSMR(x)                     (*(vuint32 *)(0x40000084) + ((x)*0xc))
#define MCF_MB_CSCR(x)                     (*(vuint32 *)(0x40000088) + ((x)*0xc))


/* Bit definitions and macros for MCF_MB_CSAR */
#define MCF_MB_CSAR_BA(x)            (((x)&0xffff0000))

/* Bit definitions and macros for MCF_MB_CSMR */
#define MCF_MB_CSMR_BAM(x)           (((x)&0xffff)<<0x10)
#define MCF_MB_CSMR_WP(x)            (((x)&0x1)<<0x8)
#define MCF_MB_CSMR_V(x)             (((x)&0x1)<<0x0)

/* Bit definitions and macros for MCF_MB_CSCR */
#define MCF_MB_CSCR_SWS(x)              (((x)&0x3f)<<0x1a)
#define MCF_MB_CSCR_SWSEN(x)            (((x)&0x1)<<0x17)
#define MCF_MB_CSCR_ASET(x)             (((x)&0x3)<<0x14)
#define MCF_MB_CSCR_RDAH(x)             (((x)&0x3)<<0x12)
#define MCF_MB_CSCR_WRAH(x)             (((x)&0x3)<<0x10)
#define MCF_MB_CSCR_WS(x)               (((x)&0x3f)<<0xa)
#define MCF_MB_CSCR_MUX(x)              (((x)&0x1)<<0x9)
#define MCF_MB_CSCR_AA(x)               (((x)&0x1)<<0x8)
#define MCF_MB_CSCR_PS(x)               (((x)&0x3)<<0x6)
#define MCF_MB_CSCR_BSTR(x)             (((x)&0x1)<<0x4)
#define MCF_MB_CSCR_BSTW(x)             (((x)&0x1)<<0x3)

#endif /* __MCF52259_MB_H__ */
