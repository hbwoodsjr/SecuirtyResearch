/*
 * File:    clock.h
 * Purpose: Driver for the MCF5329 on-chip Clock module
 *
 * Notes:
 */

#ifndef _CLOCK_H_
#define _CLOCK_H_

/********************************************************************/
/* 
 * PLL min/max specifications
 */
#define MAX_FVCO    500000	/* KHz */
#define MAX_FSYS    80000 	/* KHz */
#define MIN_FSYS    58333 	/* KHz */
#define FREF    	16000   /* KHz */


#define MAX_MFD     135     /* Multiplier */
#define MIN_MFD     88      /* Multiplier */
#define BUSDIV  	6       /* Divider */

/*
 * Low Power Divider specifications
 */
#define MIN_LPD     (1 << 0)    /* Divider (not encoded) */
#define MAX_LPD     (1 << 15)   /* Divider (not encoded) */
#define DEFAULT_LPD (1 << 1)	/* Divider (not encoded) */

/* 
 * Operating Parameters
 * Pass to clock_pll() the 'flags' argument
 */
/*
#define PLL_DISABLE   (0x0001)
#define PLL_CLKSRC    (0x0004)
#define PLL_FWKUP     (0x0020)
#define PLL_DISCLK    (0x0040)
#define PLL_LOCEN     (0x0080)
#define PLL_LOCRE     (0x0800)
#define PLL_LOLRE     (0x8000)
#define PLL_ALLFLAGS  (0x88E4)
*/
/********************************************************************/
/*
 * Function Protoypes
 */
int
clock_pll (int, int);

int
clock_limp (int);

int
clock_exit_limp (void);

int
get_sys_clock (void);

/********************************************************************/

#endif /* _CLOCK_H_ */
