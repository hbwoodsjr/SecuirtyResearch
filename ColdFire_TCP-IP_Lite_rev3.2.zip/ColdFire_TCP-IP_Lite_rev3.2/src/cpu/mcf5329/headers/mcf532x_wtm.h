/*
 * File:    mcf532x_wtm.h
 * Purpose: Register and bit definitions
 */

#ifndef __MCF532X_WTM_H__
#define __MCF532X_WTM_H__

/*********************************************************************
*
* Watchdog Timer Modules (WTM)
*
*********************************************************************/

/* Register read/write macros */
#define MCF_WTM_WCR          (*(vuint16*)(0xFC098000))
#define MCF_WTM_WMR          (*(vuint16*)(0xFC098002))
#define MCF_WTM_WCNTR        (*(vuint16*)(0xFC098004))
#define MCF_WTM_WSR          (*(vuint16*)(0xFC098006))

/* Bit definitions and macros for MCF_WTM_WCR */
#define MCF_WTM_WCR_EN       (0x0001)
#define MCF_WTM_WCR_HALTED   (0x0002)
#define MCF_WTM_WCR_DOZE     (0x0004)
#define MCF_WTM_WCR_WAIT     (0x0008)

/* Bit definitions and macros for MCF_WTM_WMR */
#define MCF_WTM_WMR_WM(x)    (((x)&0xFFFF)<<0)

/* Bit definitions and macros for MCF_WTM_WCNTR */
#define MCF_WTM_WCNTR_WC(x)  (((x)&0xFFFF)<<0)

/* Bit definitions and macros for MCF_WTM_WSR */
#define MCF_WTM_WSR_WS(x)    (((x)&0xFFFF)<<0)

//FSL WD Timer Test #define
/* Test WD Timer Module by hanging external bus with bad access address */
#define MCF_BAD_EXTERNAL_ADDRESS		(*(vuint16*)(0x10080000))
#define MCF_BAD_INTERNAL_ADDRESS		(*(vuint16*)(0x90000000))
/********************************************************************/

#endif /* __MCF532X_WTM_H__ */
