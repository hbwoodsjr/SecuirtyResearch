/*
 * File:    mcf532x_pll.h
 * Purpose: Register and bit definitions
 */

#ifndef __MCF532X_PLL_H__
#define __MCF532X_PLL_H__

/*********************************************************************
*
* Phase Locked Loop (PLL)
*
*********************************************************************/

/* Register read/write macros */
#define MCF_PLL_PODR              (*(vuint8 *)(0xFC0C0000))
#define MCF_PLL_PLLCR             (*(vuint8 *)(0xFC0C0004))
#define MCF_PLL_PMDR              (*(vuint8 *)(0xFC0C0008))
#define MCF_PLL_PFDR              (*(vuint8 *)(0xFC0C000C))

/* Bit definitions and macros for MCF_PLL_PODR */
#define MCF_PLL_PODR_BUSDIV(x)    (((x)&0x0F)<<0)
#define MCF_PLL_PODR_CPUDIV(x)    (((x)&0x0F)<<4)

/* Bit definitions and macros for MCF_PLL_PLLCR */
#define MCF_PLL_PLLCR_DITHDEV(x)  (((x)&0x07)<<0)
#define MCF_PLL_PLLCR_DITHEN      (0x80)

/* Bit definitions and macros for MCF_PLL_PMDR */
#define MCF_PLL_PMDR_MODDIV(x)    (((x)&0xFF)<<0)

/* Bit definitions and macros for MCF_PLL_PFDR */
#define MCF_PLL_PFDR_MFD(x)       (((x)&0xFF)<<0)

/********************************************************************/

#endif /* __MCF532X_PLL_H__ */
