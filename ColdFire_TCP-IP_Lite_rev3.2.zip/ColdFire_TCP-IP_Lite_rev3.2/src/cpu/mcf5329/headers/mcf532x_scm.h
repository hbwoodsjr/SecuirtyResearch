/*
 * File:    mcf532x_scm.h
 * Purpose: Register and bit definitions
 */

#ifndef __MCF532X_SCM_H__
#define __MCF532X_SCM_H__

/*********************************************************************
*
* System Control Module (SCM)
*
*********************************************************************/

/* Register read/write macros */
#define MCF_SCM_MPR0                      (*(vuint32*)(0xEC000000))
#define MCF_SCM_MPR1                      (*(vuint32*)(0xFC000000))
#define MCF_SCM_BMT0                      (*(vuint32*)(0xEC000054))
#define MCF_SCM_BMT1                      (*(vuint32*)(0xFC000054))
#define MCF_SCM_PACRA                     (*(vuint32*)(0xFC000020))
#define MCF_SCM_PACRB                     (*(vuint32*)(0xFC000024))
#define MCF_SCM_PACRC                     (*(vuint32*)(0xFC000028))
#define MCF_SCM_PACRD                     (*(vuint32*)(0xFC00002C))
#define MCF_SCM_PACRE                     (*(vuint32*)(0xFC000040))
#define MCF_SCM_PACRF                     (*(vuint32*)(0xFC000044))
#define MCF_SCM_PACRG                     (*(vuint32*)(0xEC000048))
#define MCF_SCM_PACRH                     (*(vuint32*)(0xEC000040))
#define MCF_SCM_CWCR                      (*(vuint16*)(0xFC040016))
#define MCF_SCM_CWSR                      (*(vuint8 *)(0xFC04001B))
#define MCF_SCM_CWIR                      (*(vuint8 *)(0xFC04001F))
#define MCF_SCM_BCR                       (*(vuint32*)(0xFC040024))
#define MCF_SCM_CFADR                     (*(vuint32*)(0xFC040070))
#define MCF_SCM_CFIER                     (*(vuint8 *)(0xFC040075))
#define MCF_SCM_CFLOC                     (*(vuint8 *)(0xFC040076))
#define MCF_SCM_CFATR                     (*(vuint8 *)(0xFC040077))
#define MCF_SCM_CFDTR                     (*(vuint32*)(0xFC04007C))

/* Bit definitions and macros for MCF_SCM_MPR */
#define MCF_SCM_MPR_MPROT6(x)             (((x)&0x0000000F)<<4)
#define MCF_SCM_MPR_MPROT5(x)             (((x)&0x0000000F)<<8)
#define MCF_SCM_MPR_MPROT4(x)             (((x)&0x0000000F)<<12)
#define MCF_SCM_MPR_MPROT2(x)             (((x)&0x0000000F)<<20)
#define MCF_SCM_MPR_MPROT1(x)             (((x)&0x0000000F)<<24)
#define MCF_SCM_MPR_MPROT0(x)             (((x)&0x0000000F)<<28)
#define MCF_SCM_MPR_MPROT_MTR             (0x4)
#define MCF_SCM_MPR_MPROT_MTW             (0x2)
#define MCF_SCM_MPR_MPROT_MPL             (0x1)

/* Bit definitions and macros for MCF_SCM_BMT */
#define MCF_SCM_BMT_BMT(x)                (((x)&0x00000007)<<0)
#define MCF_SCM_BMT_BME                   (0x00000008)
#define MCF_SCM_BMT_BMT_1024              (0x00000000)
#define MCF_SCM_BMT_BMT_512               (0x00000001)
#define MCF_SCM_BMT_BMT_256               (0x00000002)
#define MCF_SCM_BMT_BMT_128               (0x00000003)
#define MCF_SCM_BMT_BMT_64                (0x00000004)
#define MCF_SCM_BMT_BMT_32                (0x00000005)
#define MCF_SCM_BMT_BMT_16                (0x00000006)
#define MCF_SCM_BMT_BMT_8                 (0x00000007)

/* Bit definitions and macros for MCF_SCM_PACRA */
#define MCF_SCM_PACRA_PACR2(x)            (((x)&0x0000000F)<<20)
#define MCF_SCM_PACRA_PACR1(x)            (((x)&0x0000000F)<<24)
#define MCF_SCM_PACRA_PACR0(x)            (((x)&0x0000000F)<<28)
#define MCF_SCM_PACRA_PACR_SP             (0x4)
#define MCF_SCM_PACRA_PACR_WP             (0x2)
#define MCF_SCM_PACRA_PACR_TP             (0x1)

/* Bit definitions and macros for MCF_SCM_PACRB */
#define MCF_SCM_PACRB_PACR12(x)           (((x)&0x0000000F)<<12)
#define MCF_SCM_PACRB_PACR8(x)            (((x)&0x0000000F)<<28)

/* Bit definitions and macros for MCF_SCM_PACRC */
#define MCF_SCM_PACRC_PACR23(x)           (((x)&0x0000000F)<<0)
#define MCF_SCM_PACRC_PACR22(x)           (((x)&0x0000000F)<<4)
#define MCF_SCM_PACRC_PACR21(x)           (((x)&0x0000000F)<<8)
#define MCF_SCM_PACRC_PACR19(x)           (((x)&0x0000000F)<<16)
#define MCF_SCM_PACRC_PACR18(x)           (((x)&0x0000000F)<<20)
#define MCF_SCM_PACRC_PACR17(x)           (((x)&0x0000000F)<<24)
#define MCF_SCM_PACRC_PACR16(x)           (((x)&0x0000000F)<<28)

/* Bit definitions and macros for MCF_SCM_PACRD */
#define MCF_SCM_PACRD_PACR31(x)           (((x)&0x0000000F)<<0)
#define MCF_SCM_PACRD_PACR30(x)           (((x)&0x0000000F)<<4)
#define MCF_SCM_PACRD_PACR29(x)           (((x)&0x0000000F)<<8)
#define MCF_SCM_PACRD_PACR28(x)           (((x)&0x0000000F)<<12)
#define MCF_SCM_PACRD_PACR26(x)           (((x)&0x0000000F)<<20)
#define MCF_SCM_PACRD_PACR25(x)           (((x)&0x0000000F)<<24)
#define MCF_SCM_PACRD_PACR24(x)           (((x)&0x0000000F)<<28)

/* Bit definitions and macros for MCF_SCM_PACRE */
#define MCF_SCM_PACRE_PACR38(x)           (((x)&0x0000000F)<<4)
#define MCF_SCM_PACRE_PACR37(x)           (((x)&0x0000000F)<<8)
#define MCF_SCM_PACRE_PACR36(x)           (((x)&0x0000000F)<<12)
#define MCF_SCM_PACRE_PACR35(x)           (((x)&0x0000000F)<<16)
#define MCF_SCM_PACRE_PACR34(x)           (((x)&0x0000000F)<<20)
#define MCF_SCM_PACRE_PACR33(x)           (((x)&0x0000000F)<<24)
#define MCF_SCM_PACRE_PACR32(x)           (((x)&0x0000000F)<<28)

/* Bit definitions and macros for MCF_SCM_PACRF */
#define MCF_SCM_PACRF_PACR47(x)           (((x)&0x0000000F)<<0)
#define MCF_SCM_PACRF_PACR46(x)           (((x)&0x0000000F)<<4)
#define MCF_SCM_PACRF_PACR45(x)           (((x)&0x0000000F)<<8)
#define MCF_SCM_PACRF_PACR44(x)           (((x)&0x0000000F)<<12)
#define MCF_SCM_PACRF_PACR43(x)           (((x)&0x0000000F)<<16)
#define MCF_SCM_PACRF_PACR42(x)           (((x)&0x0000000F)<<20)
#define MCF_SCM_PACRF_PACR41(x)           (((x)&0x0000000F)<<24)
#define MCF_SCM_PACRF_PACR40(x)           (((x)&0x0000000F)<<28)

/* Bit definitions and macros for MCF_SCM_PACRG */
#define MCF_SCM_PACRG_PACR48(x)           (((x)&0x0000000F)<<28)

/* Bit definitions and macros for MCF_SCM_PACRH */
#define MCF_SCM_PACRH_PACR58(x)           (((x)&0x0000000F)<<20)
#define MCF_SCM_PACRH_PACR57(x)           (((x)&0x0000000F)<<24)
#define MCF_SCM_PACRH_PACR56(x)           (((x)&0x0000000F)<<28)

/* Bit definitions and macros for MCF_SCM_CWCR */
#define MCF_SCM_CWCR_CWT(x)               (((x)&0x001F)<<0)
#define MCF_SCM_CWCR_CWRI(x)              (((x)&0x0003)<<5)
#define MCF_SCM_CWCR_CWE                  (0x0080)
#define MCF_SCM_CWCR_CWR_WH               (0x0100)
#define MCF_SCM_CWCR_RO                   (0x8000)
#define MCF_SCM_CWCR_CWRI_INT             (0x0000)
#define MCF_SCM_CWCR_CWRI_INT_THEN_RESET  (0x0020)
#define MCF_SCM_CWCR_CWRI_RESET           (0x0040)
#define MCF_SCM_CWCR_CWRI_WINDOW          (0x0060)

/* Bit definitions and macros for MCF_SCM_CWSR */
#define MCF_SCM_CWSR_CWSR(x)              (((x)&0xFF)<<0)

/* Bit definitions and macros for MCF_SCM_CWIR */
#define MCF_SCM_CWIR_CWIC                 (0x01)
#define MCF_SCM_CWIR_CFEI                 (0x02)

/* Bit definitions and macros for MCF_SCM_BCR */
#define MCF_SCM_BCR_S1                    (0x00000002)
#define MCF_SCM_BCR_S4                    (0x00000010)
#define MCF_SCM_BCR_S6                    (0x00000040)
#define MCF_SCM_BCR_S7                    (0x00000080)
#define MCF_SCM_BCR_GBW                   (0x00000100)
#define MCF_SCM_BCR_GBR                   (0x00000200)

/* Bit definitions and macros for MCF_SCM_CFADR */
#define MCF_SCM_CFADR_ADDR(x)             (((x)&0xFFFFFFFF)<<0)

/* Bit definitions and macros for MCF_SCM_CFIER */
#define MCF_SCM_CFIER_ECFEI               (0x01)

/* Bit definitions and macros for MCF_SCM_CFLOC */
#define MCF_SCM_CFLOC_LOC                 (0x80)

/* Bit definitions and macros for MCF_SCM_CFATR */
#define MCF_SCM_CFATR_TYPE                (0x01)
#define MCF_SCM_CFATR_MODE                (0x02)
#define MCF_SCM_CFATR_CACHE               (0x08)
#define MCF_SCM_CFATR_SIZE(x)             (((x)&0x07)<<4)
#define MCF_SCM_CFATR_WRITE               (0x80)

/* Bit definitions and macros for MCF_SCM_CFDTR */
#define MCF_SCM_CFDTR_CFDTR(x)            (((x)&0xFFFFFFFF)<<0)

/********************************************************************/

#endif /* __MCF532X_SCM_H__ */
