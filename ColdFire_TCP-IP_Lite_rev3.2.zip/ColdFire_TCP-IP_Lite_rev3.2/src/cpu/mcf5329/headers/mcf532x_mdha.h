/*
 * File:    mcf532x_mdha.h
 * Purpose: Register and bit definitions
 */

#ifndef __MCF532X_MDHA_H__
#define __MCF532X_MDHA_H__

/*********************************************************************
*
* Message Digest Hardware Accelerator (MDHA)
*
*********************************************************************/

/* Register read/write macros */
#define MCF_MDHA_MDMR               (*(vuint32*)(0xEC080000))
#define MCF_MDHA_MDCR               (*(vuint32*)(0xEC080004))
#define MCF_MDHA_MDCMR              (*(vuint32*)(0xEC080008))
#define MCF_MDHA_MDSR               (*(vuint32*)(0xEC08000C))
#define MCF_MDHA_MDISR              (*(vuint32*)(0xEC080010))
#define MCF_MDHA_MDIMR              (*(vuint32*)(0xEC080014))
#define MCF_MDHA_MDDSR              (*(vuint32*)(0xEC08001C))
#define MCF_MDHA_MDIN               (*(vuint32*)(0xEC080020))
#define MCF_MDHA_MDA0               (*(vuint32*)(0xEC080030))
#define MCF_MDHA_MDB0               (*(vuint32*)(0xEC080034))
#define MCF_MDHA_MDC0               (*(vuint32*)(0xEC080038))
#define MCF_MDHA_MDD0               (*(vuint32*)(0xEC08003C))
#define MCF_MDHA_MDE0               (*(vuint32*)(0xEC080040))
#define MCF_MDHA_MDMDS              (*(vuint32*)(0xEC080044))
#define MCF_MDHA_MDA1               (*(vuint32*)(0xEC080070))
#define MCF_MDHA_MDB1               (*(vuint32*)(0xEC080074))
#define MCF_MDHA_MDC1               (*(vuint32*)(0xEC080078))
#define MCF_MDHA_MDD1               (*(vuint32*)(0xEC08007C))
#define MCF_MDHA_MDE1               (*(vuint32*)(0xEC080080))

/* Bit definitions and macros for MCF_MDHA_MDMR */
#define MCF_MDHA_MDMR_ALG           (0x00000001)
#define MCF_MDHA_MDMR_PDATA         (0x00000004)
#define MCF_MDHA_MDMR_MAC(x)        (((x)&0x00000003)<<3)
#define MCF_MDHA_MDMR_INIT          (0x00000020)
#define MCF_MDHA_MDMR_IPAD          (0x00000040)
#define MCF_MDHA_MDMR_OPAD          (0x00000080)
#define MCF_MDHA_MDMR_SWAP          (0x00000100)
#define MCF_MDHA_MDMR_MACFULL       (0x00000200)
#define MCF_MDHA_MDMR_SSL           (0x00000400)

/* Bit definitions and macros for MCF_MDHA_MDCR */
#define MCF_MDHA_MDCR_IE            (0x00000001)
#define MCF_MDHA_MDCR_DMA           (0x00000002)
#define MCF_MDHA_MDCR_ENDIAN        (0x00000004)
#define MCF_MDHA_MDCR_DMAL(x)       (((x)&0x0000001F)<<16)

/* Bit definitions and macros for MCF_MDHA_MDCMR */
#define MCF_MDHA_MDCMR_SWR          (0x00000001)
#define MCF_MDHA_MDCMR_RI           (0x00000002)
#define MCF_MDHA_MDCMR_CI           (0x00000004)
#define MCF_MDHA_MDCMR_GO           (0x00000008)

/* Bit definitions and macros for MCF_MDHA_MDSR */
#define MCF_MDHA_MDSR_INT           (0x00000001)
#define MCF_MDHA_MDSR_DONE          (0x00000002)
#define MCF_MDHA_MDSR_ERR           (0x00000004)
#define MCF_MDHA_MDSR_RD            (0x00000008)
#define MCF_MDHA_MDSR_BUSY          (0x00000010)
#define MCF_MDHA_MDSR_END           (0x00000020)
#define MCF_MDHA_MDSR_HSH           (0x00000040)
#define MCF_MDHA_MDSR_GNW           (0x00000080)
#define MCF_MDHA_MDSR_FS(x)         (((x)&0x00000007)<<8)
#define MCF_MDHA_MDSR_APD(x)        (((x)&0x00000007)<<13)
#define MCF_MDHA_MDSR_IFL(x)        (((x)&0x000000FF)<<16)

/* Bit definitions and macros for MCF_MDHA_MDISR */
#define MCF_MDHA_MDISR_IFO          (0x00000001)
#define MCF_MDHA_MDISR_NON          (0x00000004)
#define MCF_MDHA_MDISR_IME          (0x00000010)
#define MCF_MDHA_MDISR_IDS          (0x00000020)
#define MCF_MDHA_MDISR_RMDP         (0x00000080)
#define MCF_MDHA_MDISR_ERE          (0x00000100)
#define MCF_MDHA_MDISR_GTDS         (0x00000200)

/* Bit definitions and macros for MCF_MDHA_MDIMR */
#define MCF_MDHA_MDIMR_IFO          (0x00000001)
#define MCF_MDHA_MDIMR_NON          (0x00000004)
#define MCF_MDHA_MDIMR_IME          (0x00000010)
#define MCF_MDHA_MDIMR_IDS          (0x00000020)
#define MCF_MDHA_MDIMR_RMDP         (0x00000080)
#define MCF_MDHA_MDIMR_ERE          (0x00000100)
#define MCF_MDHA_MDIMR_GTDS         (0x00000200)

/* Bit definitions and macros for MCF_MDHA_MDDSR */
#define MCF_MDHA_MDDSR_DATASIZE(x)  (((x)&0x1FFFFFFF)<<0)

/* Bit definitions and macros for MCF_MDHA_MDIN */
#define MCF_MDHA_MDIN_DATAIN(x)     (((x)&0xFFFFFFFF)<<0)

/* Bit definitions and macros for MCF_MDHA_MDA0 */
#define MCF_MDHA_MDA0_DATA(x)       (((x)&0xFFFFFFFF)<<0)

/* Bit definitions and macros for MCF_MDHA_MDB0 */
#define MCF_MDHA_MDB0_DATA(x)       (((x)&0xFFFFFFFF)<<0)

/* Bit definitions and macros for MCF_MDHA_MDC0 */
#define MCF_MDHA_MDC0_DATA(x)       (((x)&0xFFFFFFFF)<<0)

/* Bit definitions and macros for MCF_MDHA_MDD0 */
#define MCF_MDHA_MDD0_DATA(x)       (((x)&0xFFFFFFFF)<<0)

/* Bit definitions and macros for MCF_MDHA_MDE0 */
#define MCF_MDHA_MDE0_DATA(x)       (((x)&0xFFFFFFFF)<<0)

/* Bit definitions and macros for MCF_MDHA_MDMDS */
#define MCF_MDHA_MDMDS_DATASIZE(x)  (((x)&0xFFFFFFFF)<<0)

/* Bit definitions and macros for MCF_MDHA_MDA1 */
#define MCF_MDHA_MDA1_DATA(x)       (((x)&0xFFFFFFFF)<<0)

/* Bit definitions and macros for MCF_MDHA_MDB1 */
#define MCF_MDHA_MDB1_DATA(x)       (((x)&0xFFFFFFFF)<<0)

/* Bit definitions and macros for MCF_MDHA_MDC1 */
#define MCF_MDHA_MDC1_DATA(x)       (((x)&0xFFFFFFFF)<<0)

/* Bit definitions and macros for MCF_MDHA_MDD1 */
#define MCF_MDHA_MDD1_DATA(x)       (((x)&0xFFFFFFFF)<<0)

/* Bit definitions and macros for MCF_MDHA_MDE1 */
#define MCF_MDHA_MDE1_DATA(x)       (((x)&0xFFFFFFFF)<<0)

/********************************************************************/

#endif /* __MCF532X_MDHA_H__ */
