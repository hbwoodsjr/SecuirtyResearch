/*
 * File:    mcf532x_skha.h
 * Purpose: Register and bit definitions
 */

#ifndef __MCF532X_SKHA_H__
#define __MCF532X_SKHA_H__

/*********************************************************************
*
* Symmetric Key Hardware Accelerator (SKHA)
*
*********************************************************************/

/* Register read/write macros */
#define MCF_SKHA_SKMR               (*(vuint32*)(0xEC084000))
#define MCF_SKHA_SKCR               (*(vuint32*)(0xEC084004))
#define MCF_SKHA_SKCMR              (*(vuint32*)(0xEC084008))
#define MCF_SKHA_SKSR               (*(vuint32*)(0xEC08400C))
#define MCF_SKHA_SKISR              (*(vuint32*)(0xEC084010))
#define MCF_SKHA_SKIMR              (*(vuint32*)(0xEC084014))
#define MCF_SKHA_SKKSR              (*(vuint32*)(0xEC084018))
#define MCF_SKHA_SKDSR              (*(vuint32*)(0xEC08401C))
#define MCF_SKHA_SKIN               (*(vuint32*)(0xEC084020))
#define MCF_SKHA_SKOUT              (*(vuint32*)(0xEC084024))
#define MCF_SKHA_SKK0               (*(vuint32*)(0xEC084030))
#define MCF_SKHA_SKK1               (*(vuint32*)(0xEC084034))
#define MCF_SKHA_SKK2               (*(vuint32*)(0xEC084038))
#define MCF_SKHA_SKK3               (*(vuint32*)(0xEC08403C))
#define MCF_SKHA_SKK4               (*(vuint32*)(0xEC084040))
#define MCF_SKHA_SKK5               (*(vuint32*)(0xEC084044))
#define MCF_SKHA_SKK(x)             (*(vuint32*)(0xEC084030+((x)*0x004)))
#define MCF_SKHA_SKC0               (*(vuint32*)(0xEC084070))
#define MCF_SKHA_SKC1               (*(vuint32*)(0xEC084074))
#define MCF_SKHA_SKC2               (*(vuint32*)(0xEC084078))
#define MCF_SKHA_SKC3               (*(vuint32*)(0xEC08407C))
#define MCF_SKHA_SKC4               (*(vuint32*)(0xEC084080))
#define MCF_SKHA_SKC5               (*(vuint32*)(0xEC084084))
#define MCF_SKHA_SKC6               (*(vuint32*)(0xEC084088))
#define MCF_SKHA_SKC7               (*(vuint32*)(0xEC08408C))
#define MCF_SKHA_SKC8               (*(vuint32*)(0xEC084090))
#define MCF_SKHA_SKC9               (*(vuint32*)(0xEC084094))
#define MCF_SKHA_SKC10              (*(vuint32*)(0xEC084098))
#define MCF_SKHA_SKC11              (*(vuint32*)(0xEC08409C))
#define MCF_SKHA_SKC(x)             (*(vuint32*)(0xEC084070+((x)*0x004)))

/* Bit definitions and macros for MCF_SKHA_SKMR */
#define MCF_SKHA_SKMR_ALG(x)        (((x)&0x00000003)<<0)
#define MCF_SKHA_SKMR_DIR           (0x00000004)
#define MCF_SKHA_SKMR_CM(x)         (((x)&0x00000003)<<3)
#define MCF_SKHA_SKMR_DKP           (0x00000100)
#define MCF_SKHA_SKMR_CTRM(x)       (((x)&0x0000000F)<<9)
#define MCF_SKHA_SKMR_CM_ECB        (0x00000000)
#define MCF_SKHA_SKMR_CM_CBC        (0x00000008)
#define MCF_SKHA_SKMR_CM_CTR        (0x00000018)
#define MCF_SKHA_SKMR_DIR_DEC       (0x00000000)
#define MCF_SKHA_SKMR_DIR_ENC       (0x00000004)
#define MCF_SKHA_SKMR_ALG_AES       (0x00000000)
#define MCF_SKHA_SKMR_ALG_DES       (0x00000001)
#define MCF_SKHA_SKMR_ALG_TDES      (0x00000002)

/* Bit definitions and macros for MCF_SKHA_SKCR */
#define MCF_SKHA_SKCR_IE            (0x00000001)
#define MCF_SKHA_SKCR_IDMA          (0x00000002)
#define MCF_SKHA_SKCR_ODMA          (0x00000004)
#define MCF_SKHA_SKCR_ENDIAN        (0x00000008)
#define MCF_SKHA_SKCR_IDMAL(x)      (((x)&0x0000003F)<<16)
#define MCF_SKHA_SKCR_ODMAL(x)      (((x)&0x0000003F)<<24)

/* Bit definitions and macros for MCF_SKHA_SKCMR */
#define MCF_SKHA_SKCMR_SWR          (0x00000001)
#define MCF_SKHA_SKCMR_RI           (0x00000002)
#define MCF_SKHA_SKCMR_CI           (0x00000004)
#define MCF_SKHA_SKCMR_GO           (0x00000008)

/* Bit definitions and macros for MCF_SKHA_SKSR */
#define MCF_SKHA_SKSR_INT           (0x00000001)
#define MCF_SKHA_SKSR_DONE          (0x00000002)
#define MCF_SKHA_SKSR_ERR           (0x00000004)
#define MCF_SKHA_SKSR_RD            (0x00000008)
#define MCF_SKHA_SKSR_BUSY          (0x00000010)
#define MCF_SKHA_SKSR_IFL(x)        (((x)&0x000000FF)<<16)
#define MCF_SKHA_SKSR_OFL(x)        (((x)&0x000000FF)<<24)

/* Bit definitions and macros for MCF_SKHA_SKISR */
#define MCF_SKHA_SKISR_IFO          (0x00000001)
#define MCF_SKHA_SKISR_OFU          (0x00000002)
#define MCF_SKHA_SKISR_NEIF         (0x00000004)
#define MCF_SKHA_SKISR_NEOF         (0x00000008)
#define MCF_SKHA_SKISR_IME          (0x00000010)
#define MCF_SKHA_SKISR_DSE          (0x00000020)
#define MCF_SKHA_SKISR_KSE          (0x00000040)
#define MCF_SKHA_SKISR_RMDP         (0x00000080)
#define MCF_SKHA_SKISR_ERE          (0x00000100)
#define MCF_SKHA_SKISR_KPE          (0x00000200)
#define MCF_SKHA_SKISR_KRE          (0x00000400)
#define MCF_SKHA_SKISR_DRL          (0x00000800)

/* Bit definitions and macros for MCF_SKHA_SKIMR */
#define MCF_SKHA_SKIMR_IFO          (0x00000001)
#define MCF_SKHA_SKIMR_OFU          (0x00000002)
#define MCF_SKHA_SKIMR_NEIF         (0x00000004)
#define MCF_SKHA_SKIMR_NEOF         (0x00000008)
#define MCF_SKHA_SKIMR_IME          (0x00000010)
#define MCF_SKHA_SKIMR_DSE          (0x00000020)
#define MCF_SKHA_SKIMR_KSE          (0x00000040)
#define MCF_SKHA_SKIMR_RMDP         (0x00000080)
#define MCF_SKHA_SKIMR_ERE          (0x00000100)
#define MCF_SKHA_SKIMR_KPE          (0x00000200)
#define MCF_SKHA_SKIMR_KRE          (0x00000400)
#define MCF_SKHA_SKIMR_DRL          (0x00000800)

/* Bit definitions and macros for MCF_SKHA_SKKSR */
#define MCF_SKHA_SKKSR_KEYSIZE(x)   (((x)&0x0000003F)<<0)

/* Bit definitions and macros for MCF_SKHA_SKDSR */
#define MCF_SKHA_SKDSR_DATASIZE(x)  (((x)&0xFFFFFFFF)<<0)

/* Bit definitions and macros for MCF_SKHA_SKIN */
#define MCF_SKHA_SKIN_DATAIN(x)     (((x)&0xFFFFFFFF)<<0)

/* Bit definitions and macros for MCF_SKHA_SKOUT */
#define MCF_SKHA_SKOUT_DATAOUT(x)   (((x)&0xFFFFFFFF)<<0)

/* Bit definitions and macros for MCF_SKHA_SKK */
#define MCF_SKHA_SKK_KEY(x)         (((x)&0xFFFFFFFF)<<0)

/* Bit definitions and macros for MCF_SKHA_SKC */
#define MCF_SKHA_SKC_CONTEXT(x)     (((x)&0xFFFFFFFF)<<0)

/********************************************************************/

#endif /* __MCF532X_SKHA_H__ */
