/*
 * File:    mcf532x_pmm.h
 * Purpose: Register and bit definitions
 */

#ifndef __MCF532X_PMM_H__
#define __MCF532X_PMM_H__

/*********************************************************************
*
* Power Management Module (PMM)
*
*********************************************************************/

/* Register read/write macros */
#define MCF_PMM_WCR                             (*(vuint8 *)(0xFC040013))
#define MCF_PMM_PPMSR0                          (*(vuint8 *)(0xFC04002C))
#define MCF_PMM_PPMSR1                          (*(vuint8 *)(0xFC04002E))
#define MCF_PMM_PPMCR0                          (*(vuint8 *)(0xFC04002D))
#define MCF_PMM_PPMCR1                          (*(vuint8 *)(0xFC04002F))
#define MCF_PMM_PPMHR0                          (*(vuint32*)(0xFC040030))
#define MCF_PMM_PPMLR0                          (*(vuint32*)(0xFC040034))
#define MCF_PMM_PPMHR1                          (*(vuint32*)(0xFC040038))
#define MCF_PMM_LPCR                            (*(vuint8 *)(0xFC0A0007))

/* Bit definitions and macros for MCF_PMM_WCR */
#define MCF_PMM_WCR_PRILVL(x)                   (((x)&0x07)<<0)
#define MCF_PMM_WCR_ENBWCR                      (0x80)

/* Bit definitions and macros for MCF_PMM_PPMSR */
#define MCF_PMM_PPMSR_SMCD(x)                   (((x)&0x3F)<<0)
#define MCF_PMM_PPMSR_SAMCD                     (0x40)

/* Bit definitions and macros for MCF_PMM_PPMCR */
#define MCF_PMM_PPMCR_CMCD(x)                   (((x)&0x3F)<<0)
#define MCF_PMM_PPMCR_CAMCD                     (0x40)

/* Bit definitions and macros for MCF_PMM_PPMHR0 */
#define MCF_PMM_PPMHR0_CD32                     (0x00000001)
#define MCF_PMM_PPMHR0_CD33                     (0x00000002)
#define MCF_PMM_PPMHR0_CD34                     (0x00000004)
#define MCF_PMM_PPMHR0_CD35                     (0x00000008)
#define MCF_PMM_PPMHR0_CD36                     (0x00000010)
#define MCF_PMM_PPMHR0_CD37                     (0x00000020)
#define MCF_PMM_PPMHR0_CD38                     (0x00000040)
#define MCF_PMM_PPMHR0_CD40                     (0x00000100)
#define MCF_PMM_PPMHR0_CD41                     (0x00000200)
#define MCF_PMM_PPMHR0_CD42                     (0x00000400)
#define MCF_PMM_PPMHR0_CD43                     (0x00000800)
#define MCF_PMM_PPMHR0_CD44                     (0x00001000)
#define MCF_PMM_PPMHR0_CD45                     (0x00002000)
#define MCF_PMM_PPMHR0_CD46                     (0x00004000)
#define MCF_PMM_PPMHR0_CD47                     (0x00008000)
#define MCF_PMM_PPMHR0_CD48                     (0x00010000)

/* Bit definitions and macros for MCF_PMM_PPMLR0 */
#define MCF_PMM_PPMLR0_CD2                      (0x00000004)
#define MCF_PMM_PPMLR0_CD8                      (0x00000100)
#define MCF_PMM_PPMLR0_CD12                     (0x00001000)
#define MCF_PMM_PPMLR0_CD17                     (0x00020000)
#define MCF_PMM_PPMLR0_CD18                     (0x00040000)
#define MCF_PMM_PPMLR0_CD19                     (0x00080000)
#define MCF_PMM_PPMLR0_CD21                     (0x00200000)
#define MCF_PMM_PPMLR0_CD22                     (0x00400000)
#define MCF_PMM_PPMLR0_CD23                     (0x00800000)
#define MCF_PMM_PPMLR0_CD24                     (0x01000000)
#define MCF_PMM_PPMLR0_CD25                     (0x02000000)
#define MCF_PMM_PPMLR0_CD26                     (0x04000000)
#define MCF_PMM_PPMLR0_CD28                     (0x10000000)
#define MCF_PMM_PPMLR0_CD29                     (0x20000000)
#define MCF_PMM_PPMLR0_CD30                     (0x40000000)
#define MCF_PMM_PPMLR0_CD31                     (0x80000000)

/* Bit definitions and macros for MCF_PMM_PPMHR1 */
#define MCF_PMM_PPMHR1_CD32                     (0x00000001)
#define MCF_PMM_PPMHR1_CD33                     (0x00000002)
#define MCF_PMM_PPMHR1_CD34                     (0x00000004)

/* Bit definitions and macros for MCF_PMM_LPCR */
#define MCF_PMM_LPCR_STPMD(x)                   (((x)&0x03)<<3)
#define MCF_PMM_LPCR_FWKUP                      (0x20)
#define MCF_PMM_LPCR_LPMD(x)                    (((x)&0x03)<<6)
#define MCF_PMM_LPCR_LPMD_RUN                   (0x00)
#define MCF_PMM_LPCR_LPMD_DOZE                  (0x40)
#define MCF_PMM_LPCR_LPMD_WAIT                  (0x80)
#define MCF_PMM_LPCR_LPMD_STOP                  (0xC0)
#define MCF_PMM_LPCR_STPMD_SYS_DISABLED         (0x00)
#define MCF_PMM_LPCR_STPMD_SYS_BUSCLK_DISABLED  (0x04)
#define MCF_PMM_LPCR_STPMD_ONLY_OSC_ENABLED     (0x08)
#define MCF_PMM_LPCR_STPMD_ALL_DISABLED         (0x0C)

/********************************************************************/

#endif /* __MCF532X_PMM_H__ */
