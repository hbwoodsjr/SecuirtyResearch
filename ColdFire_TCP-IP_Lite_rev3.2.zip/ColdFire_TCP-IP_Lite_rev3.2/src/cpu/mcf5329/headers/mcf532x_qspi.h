/*
 * File:    mcf532x_qspi.h
 * Purpose: Register and bit definitions
 */

#ifndef __MCF532X_QSPI_H__
#define __MCF532X_QSPI_H__

/*********************************************************************
*
* Queued Serial Peripheral Interface (QSPI)
*
*********************************************************************/

/* Register read/write macros */
#define MCF_QSPI_QMR           (*(vuint16*)(0xFC05C000))
#define MCF_QSPI_QDLYR         (*(vuint16*)(0xFC05C004))
#define MCF_QSPI_QWR           (*(vuint16*)(0xFC05C008))
#define MCF_QSPI_QIR           (*(vuint16*)(0xFC05C00C))
#define MCF_QSPI_QAR           (*(vuint16*)(0xFC05C010))
#define MCF_QSPI_QDR           (*(vuint16*)(0xFC05C014))

/* Bit definitions and macros for MCF_QSPI_QMR */
#define MCF_QSPI_QMR_BAUD(x)   (((x)&0x00FF)<<0)
#define MCF_QSPI_QMR_CPHA      (0x0100)
#define MCF_QSPI_QMR_CPOL      (0x0200)
#define MCF_QSPI_QMR_BITS(x)   (((x)&0x000F)<<10)
#define MCF_QSPI_QMR_DOHIE     (0x4000)
#define MCF_QSPI_QMR_MSTR      (0x8000)

/* Bit definitions and macros for MCF_QSPI_QDLYR */
#define MCF_QSPI_QDLYR_DTL(x)  (((x)&0x00FF)<<0)
#define MCF_QSPI_QDLYR_QCD(x)  (((x)&0x007F)<<8)
#define MCF_QSPI_QDLYR_SPE     (0x8000)

/* Bit definitions and macros for MCF_QSPI_QWR */
#define MCF_QSPI_QWR_NEWQP(x)  (((x)&0x000F)<<0)
#define MCF_QSPI_QWR_ENDQP(x)  (((x)&0x000F)<<8)
#define MCF_QSPI_QWR_CSIV      (0x1000)
#define MCF_QSPI_QWR_WRTO      (0x2000)
#define MCF_QSPI_QWR_WREN      (0x4000)
#define MCF_QSPI_QWR_HALT      (0x8000)

/* Bit definitions and macros for MCF_QSPI_QIR */
#define MCF_QSPI_QIR_SPIF      (0x0001)
#define MCF_QSPI_QIR_ABRT      (0x0004)
#define MCF_QSPI_QIR_WCEF      (0x0008)
#define MCF_QSPI_QIR_SPIFE     (0x0100)
#define MCF_QSPI_QIR_ABRTE     (0x0400)
#define MCF_QSPI_QIR_WCEFE     (0x0800)
#define MCF_QSPI_QIR_ABRTL     (0x1000)
#define MCF_QSPI_QIR_ABRTB     (0x4000)
#define MCF_QSPI_QIR_WCEFB     (0x8000)

/* Bit definitions and macros for MCF_QSPI_QAR */
#define MCF_QSPI_QAR_ADDR(x)   (((x)&0x003F)<<0)
#define MCF_QSPI_QAR_TRANS     (0x0000)
#define MCF_QSPI_QAR_RECV      (0x0010)
#define MCF_QSPI_QAR_CMD       (0x0020)

/* Bit definitions and macros for MCF_QSPI_QDR */
#define MCF_QSPI_QDR_DATA(x)   (((x)&0xFFFF)<<0)
#define MCF_QSPI_QDR_CONT      (0x8000)
#define MCF_QSPI_QDR_BITSE     (0x4000)
#define MCF_QSPI_QDR_DT        (0x2000)
#define MCF_QSPI_QDR_DSCK      (0x1000)
#define MCF_QSPI_QDR_QSPI_CS3  (0x0800)
#define MCF_QSPI_QDR_QSPI_CS2  (0x0400)
#define MCF_QSPI_QDR_QSPI_CS1  (0x0200)
#define MCF_QSPI_QDR_QSPI_CS0  (0x0100)

/********************************************************************/

#endif /* __MCF532X_QSPI_H__ */
