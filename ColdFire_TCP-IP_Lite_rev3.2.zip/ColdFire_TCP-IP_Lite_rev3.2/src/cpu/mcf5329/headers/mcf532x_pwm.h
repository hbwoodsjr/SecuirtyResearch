/*
 * File:    mcf532x_pwm.h
 * Purpose: Register and bit definitions
 */

#ifndef __MCF532X_PWM_H__
#define __MCF532X_PWM_H__

/*********************************************************************
*
* Pulse Width Modulation (PWM)
*
*********************************************************************/

/* Register read/write macros */
#define MCF_PWM_PWME               (*(vuint8 *)(0xFC090020))
#define MCF_PWM_PWMPOL             (*(vuint8 *)(0xFC090021))
#define MCF_PWM_PWMCLK             (*(vuint8 *)(0xFC090022))
#define MCF_PWM_PWMPRCLK           (*(vuint8 *)(0xFC090023))
#define MCF_PWM_PWMCAE             (*(vuint8 *)(0xFC090024))
#define MCF_PWM_PWMCTL             (*(vuint8 *)(0xFC090025))
#define MCF_PWM_PWMSCLA            (*(vuint8 *)(0xFC090028))
#define MCF_PWM_PWMSCLB            (*(vuint8 *)(0xFC090029))
#define MCF_PWM_PWMCNT0            (*(vuint8 *)(0xFC09002C))
#define MCF_PWM_PWMCNT1            (*(vuint8 *)(0xFC09002D))
#define MCF_PWM_PWMCNT2            (*(vuint8 *)(0xFC09002E))
#define MCF_PWM_PWMCNT3            (*(vuint8 *)(0xFC09002F))
#define MCF_PWM_PWMCNT4            (*(vuint8 *)(0xFC090030))
#define MCF_PWM_PWMCNT5            (*(vuint8 *)(0xFC090031))
#define MCF_PWM_PWMCNT6            (*(vuint8 *)(0xFC090032))
#define MCF_PWM_PWMCNT7            (*(vuint8 *)(0xFC090033))
#define MCF_PWM_PWMCNT(x)          (*(vuint8 *)(0xFC09002C+((x)*0x001)))
#define MCF_PWM_PWMPER0            (*(vuint8 *)(0xFC090034))
#define MCF_PWM_PWMPER1            (*(vuint8 *)(0xFC090035))
#define MCF_PWM_PWMPER2            (*(vuint8 *)(0xFC090036))
#define MCF_PWM_PWMPER3            (*(vuint8 *)(0xFC090037))
#define MCF_PWM_PWMPER4            (*(vuint8 *)(0xFC090038))
#define MCF_PWM_PWMPER5            (*(vuint8 *)(0xFC090039))
#define MCF_PWM_PWMPER6            (*(vuint8 *)(0xFC09003A))
#define MCF_PWM_PWMPER7            (*(vuint8 *)(0xFC09003B))
#define MCF_PWM_PWMPER(x)          (*(vuint8 *)(0xFC090034+((x)*0x001)))
#define MCF_PWM_PWMDTY0            (*(vuint8 *)(0xFC09003C))
#define MCF_PWM_PWMDTY1            (*(vuint8 *)(0xFC09003D))
#define MCF_PWM_PWMDTY2            (*(vuint8 *)(0xFC09003E))
#define MCF_PWM_PWMDTY3            (*(vuint8 *)(0xFC09003F))
#define MCF_PWM_PWMDTY4            (*(vuint8 *)(0xFC090040))
#define MCF_PWM_PWMDTY5            (*(vuint8 *)(0xFC090041))
#define MCF_PWM_PWMDTY6            (*(vuint8 *)(0xFC090042))
#define MCF_PWM_PWMDTY7            (*(vuint8 *)(0xFC090043))
#define MCF_PWM_PWMDTY(x)          (*(vuint8 *)(0xFC09003C+((x)*0x001)))
#define MCF_PWM_PWMSDN             (*(vuint8 *)(0xFC090044))

/* Bit definitions and macros for MCF_PWM_PWME */
#define MCF_PWM_PWME_PWME0         (0x01)
#define MCF_PWM_PWME_PWME1         (0x02)
#define MCF_PWM_PWME_PWME2         (0x04)
#define MCF_PWM_PWME_PWME3         (0x08)
#define MCF_PWM_PWME_PWME4         (0x10)
#define MCF_PWM_PWME_PWME5         (0x20)
#define MCF_PWM_PWME_PWME6         (0x40)
#define MCF_PWM_PWME_PWME7         (0x80)

/* Bit definitions and macros for MCF_PWM_PWMPOL */
#define MCF_PWM_PWMPOL_PPOL0       (0x01)
#define MCF_PWM_PWMPOL_PPOL1       (0x02)
#define MCF_PWM_PWMPOL_PPOL2       (0x04)
#define MCF_PWM_PWMPOL_PPOL3       (0x08)
#define MCF_PWM_PWMPOL_PPOL4       (0x10)
#define MCF_PWM_PWMPOL_PPOL5       (0x20)
#define MCF_PWM_PWMPOL_PPOL6       (0x40)
#define MCF_PWM_PWMPOL_PPOL7       (0x80)

/* Bit definitions and macros for MCF_PWM_PWMCLK */
#define MCF_PWM_PWMCLK_PCLK0       (0x01)
#define MCF_PWM_PWMCLK_PCLK1       (0x02)
#define MCF_PWM_PWMCLK_PCLK2       (0x04)
#define MCF_PWM_PWMCLK_PCLK3       (0x08)
#define MCF_PWM_PWMCLK_PCLK4       (0x10)
#define MCF_PWM_PWMCLK_PCLK5       (0x20)
#define MCF_PWM_PWMCLK_PCLK6       (0x40)
#define MCF_PWM_PWMCLK_PCLK7       (0x80)

/* Bit definitions and macros for MCF_PWM_PWMPRCLK */
#define MCF_PWM_PWMPRCLK_PCKA(x)   (((x)&0x07)<<0)
#define MCF_PWM_PWMPRCLK_PCKB(x)   (((x)&0x07)<<4)

/* Bit definitions and macros for MCF_PWM_PWMCAE */
#define MCF_PWM_PWMCAE_CAE0        (0x01)
#define MCF_PWM_PWMCAE_CAE1        (0x02)
#define MCF_PWM_PWMCAE_CAE2        (0x04)
#define MCF_PWM_PWMCAE_CAE3        (0x08)
#define MCF_PWM_PWMCAE_CAE4        (0x10)
#define MCF_PWM_PWMCAE_CAE5        (0x20)
#define MCF_PWM_PWMCAE_CAE6        (0x40)
#define MCF_PWM_PWMCAE_CAE7        (0x80)

/* Bit definitions and macros for MCF_PWM_PWMCTL */
#define MCF_PWM_PWMCTL_PFRZ        (0x04)
#define MCF_PWM_PWMCTL_PSWAI       (0x08)
#define MCF_PWM_PWMCTL_CON01       (0x10)
#define MCF_PWM_PWMCTL_CON23       (0x20)
#define MCF_PWM_PWMCTL_CON45       (0x40)
#define MCF_PWM_PWMCTL_CON67       (0x80)

/* Bit definitions and macros for MCF_PWM_PWMSCLA */
#define MCF_PWM_PWMSCLA_SCALEA(x)  (((x)&0xFF)<<0)

/* Bit definitions and macros for MCF_PWM_PWMSCLB */
#define MCF_PWM_PWMSCLB_SCALEB(x)  (((x)&0xFF)<<0)

/* Bit definitions and macros for MCF_PWM_PWMCNT */
#define MCF_PWM_PWMCNT_COUNT(x)    (((x)&0xFF)<<0)

/* Bit definitions and macros for MCF_PWM_PWMPER */
#define MCF_PWM_PWMPER_PERIOD(x)   (((x)&0xFF)<<0)

/* Bit definitions and macros for MCF_PWM_PWMDTY */
#define MCF_PWM_PWMDTY_DUTY(x)     (((x)&0xFF)<<0)

/* Bit definitions and macros for MCF_PWM_PWMSDN */
#define MCF_PWM_PWMSDN_SDNEN       (0x01)
#define MCF_PWM_PWMSDN_PWM7IL      (0x02)
#define MCF_PWM_PWMSDN_PWM7IN      (0x04)
#define MCF_PWM_PWMSDN_LVL         (0x10)
#define MCF_PWM_PWMSDN_RESTART     (0x20)
#define MCF_PWM_PWMSDN_IE          (0x40)
#define MCF_PWM_PWMSDN_IF          (0x80)

/********************************************************************/

#endif /* __MCF532X_PWM_H__ */
