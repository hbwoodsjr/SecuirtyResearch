/*
 * File:		m5329evb.c
 * Purpose:		Source to EVB specific routines
 *
 * Notes:
 */
/********************************************************************/
#include "common.h"

//FSL added below extern's
extern uint32	html_vars[];
extern uint8	html_vars_flags[];
extern uint32	hit_counter;

/********************************************************************/
/*
 * Setup LED on the EVB
 */
void
Leds_Init(void){
//user LEDs
/* m5329evb has two LEDs that are driven via a memory mapped i/o register */
/* I've placed the code within the LED marcos (LED_ON, LED_OFF, LED_toggle) */
/* Note that CS1 needs to be programmed to access the i/o register */
/* This is the address that will be used as the CS1 */
/* base address to access the latch on the Fire engine card.  */ 
 
 /*
 
#define LATCH_ADDRESS		(uint32)0x10080000 
#define LATCH_BASE_ADDRESS	(uint32)0x10000000 
		
   *((uint16 *)(LATCH_ADDRESS)) = 0x00FF;		//LED's off bits 8 and 7 =1

   *((uint16 *)(LATCH_ADDRESS)) = 0x003F;		//LED's on bits 8 and 7 =0    
	return;
	
  */	
}

/********************************************************************/
/* 
 * Display the lower 2 bits of 'number' on the 2 LEDs connected to 
 * ??????
 *
 *  LED: LED2 LED1
 *  PIN: ???? ????
 *  BIT: 1    0
 */
void
board_led_display(uint8 number)
{
    /* Set output values */
    return;
}
/********************************************************************/


/********************************************************************/
// Poll switch status
/********************************************************************/
int poll_switches( void )
{
	int		map;

	map = 0;

    
    return( map );
}
/********************************************************************/


/*********************************************************************
* init_adc - Analog-to-Digital Converter (ADC)                       *
**********************************************************************/
void init_adc (void)
{
	return;
}


void start_AD( void )
{
	return;
}


short read_AD( int channel )
{
	return(0);
}

void evb_specific_collect_sensor_data()
{
	html_vars[0] 		= 0;
	html_vars_flags[0] 	= 1;

	html_vars[1] 		= poll_switches();
	html_vars_flags[1] 	= 1;

	html_vars[2]		= hit_counter++;
	html_vars_flags[2] 	= 1;

	html_vars[3]		= read_AD(0);
	html_vars_flags[3] 	= 1;

	html_vars[4]		= read_AD(1);;
	html_vars_flags[4] 	= 1;

	html_vars[5]		= 0;
	html_vars_flags[5] 	= 1;

	html_vars[6]		= 0;
	html_vars_flags[6] 	= 1;

	html_vars[7]		= read_AD(4);
	html_vars_flags[7] 	= 1;

	html_vars[8]		= read_AD(5);
	html_vars_flags[8] 	= 1;

	html_vars[9]		= read_AD(6);
	html_vars_flags[9] 	= 1;

	html_vars[10]		= 0;
	html_vars_flags[10] = 1;

	html_vars[11]		= 0;
	html_vars_flags[11] = 1;

	html_vars[12]		= 0;
	html_vars_flags[12] = 1;

	html_vars[13]		= 0;
	html_vars_flags[13] = 1;
}


/********************************************************************/
/* Function to toogle the m5329evb LEDs */
/********************************************************************/

uint32 cnt=0;

void
toogle(int LED)
{
  cnt++;
  switch(LED) 
  {
  	case 0:
  	case 2:
	   if(cnt % 2) 
	   {
		LED0_OFF;			//FSL added for debugging
	   }
	   else 
	   {
		LED0_ON;			//FSL added for debugging
	   }
	   break;
  	case 1:
  	case 3:
	   if(cnt % 2) 
	   {
		LED1_ON;			//FSL added for debugging   	
	   }
	   else 
	   {
		LED1_OFF;			//FSL added for debugging
	   }
  	   break;
  }
}