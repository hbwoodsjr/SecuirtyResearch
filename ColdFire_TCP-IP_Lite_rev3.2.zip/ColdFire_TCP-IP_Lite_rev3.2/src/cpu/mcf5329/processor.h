/*
 * File:		processor.h
 * Purpose:		This header specifies which ColdFire processor will be used
 *			with the project.
 *
 * Notes:
 */

#ifndef _PROCESSOR_H
#define _PROCESSOR_H

/********************************************************************/

#define MCF5329			1		/* This defines the processor being used */
#define FULL			0
#define HALF			1

#define M5329EVB		1		/* This defines the evb being used */
#define DHCP			0		/* 0=DHCP off, 1=DHCP on */
#define CACHE			OFF		/* OFF=cache off, ON=cache on */
#define CONSOLE_UART	0		/* Set to the respective UART number to use for console */
/* Default is 0; 1 works if evb supports it; 2 and above not configured in software/hardware  */

#define AUTO			1		//FSL 0=disable autonegotiation, 1=enable autonegotiation
#if (!AUTO)						//FLS DUPLEX and BaseT only used if AUTO=0
#define DUPLEX			HALF	//FSL enter HALF or FULL to select Ethernet duplex mode
#define BaseT			100		//FSL set Ethernet BaseT to 10 or 100
#endif
#define ETH_PORT		0		//FSL the MCF5223x has one Ethernet FEC port FEC0

#define CLIENT			0		//FSL 1=client software operates. 0=server

#define MAX_ETH_PKT 1522		//FSL 1522 to support VLAN tagging
								//FSL bigbufsize and TCP_MSS calculated off of MAX_ETH_PKT

#define ETH_PROCESSOR_H	1		//FSL comment out to have ipport.h values used
#define NUM_RXBDS    2			//FSL number of Receive Buffer Descriptors
#define NUM_TXBDS    (2*NUM_RXBDS)				//FSL number of Transmit Buffer Descriptors
#define NUMBIGBUFS   (NUM_RXBDS+NUM_TXBDS)	//FSL number of Big Buffers for Ethernet Frames
#define NUMLILBUFS   (NUM_TXBDS) 				//FSL number of Little Buffers for Ethernet Frames

#define DMA_TIMER_LEVEL 3		//jpw dma interrupt level									

#define WD_TEST			0		//FSL Enable watchdog timer module ability to reset device if bus hangs
								//FSL 0=disable, 1=enable

/* 
 * Include the specific CPU header file 
 */

#include "mcf532x.h"		/* processor specific headers */
#include "m5329evb.h"		/* evb specific headers */

/********************************************************************/
#endif /* _PROCESSOR_H */
