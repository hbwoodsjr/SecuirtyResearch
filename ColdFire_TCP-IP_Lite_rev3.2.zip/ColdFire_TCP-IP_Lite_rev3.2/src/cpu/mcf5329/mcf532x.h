/*
 * File:    mcf532x.h
 * Purpose: Register and bit definitions
 */

#ifndef __MCF532X_H__
#define __MCF532X_H__

/********************************************************************/

#include "mcf532x_scm.h"
#include "mcf532x_mdha.h"
#include "mcf532x_skha.h"
#include "mcf532x_rng.h"
#include "mcf532x_pmm.h"
#include "mcf532x_xbs.h"
#include "mcf532x_fbcs.h"
#include "mcf532x_can.h"
#include "mcf532x_fec.h"
#include "mcf532x_edma.h"
#include "mcf532x_intc.h"
#include "mcf532x_intc_iack.h"
#include "mcf532x_i2c.h"
#include "mcf532x_qspi.h"
#include "mcf532x_uart.h"
#include "mcf532x_dtim.h"
#include "mcf532x_pit.h"
#include "mcf532x_pwm.h"
#include "mcf532x_eport.h"
#include "mcf532x_wtm.h"
#include "mcf532x_ccm.h"
#include "mcf532x_rcm.h"
#include "mcf532x_gpio.h"
#include "mcf532x_rtc.h"
#include "mcf532x_lcdc.h"
#include "mcf532x_usb.h"
#include "mcf532x_sdramc.h"
#include "mcf532x_ssi.h"
#include "mcf532x_pll.h"

/********************************************************************/

#endif /* __MCF532X_H__ */
