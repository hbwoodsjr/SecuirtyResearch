/*
 * File:		mcf54455_sysinit.c
 * Purpose:		Reset configuration of the M54455EVB
 *
 * Notes:
 */

#include "common.h"
#include "clock.h"		//FSL added

void fbcs_init(void);
void sdramc_init(void);
void gpio_init(void);
void eport_init(void);
void intc_init(void);
void intc0_init(void);
void intc1_init(void);
void scc_init(void);
void mcf54455_powerup_config( void );
void mcf54455_PHY_init(void);

/* Actual system clock frequency */
int sys_clk_khz;
int sys_clk_mhz;
uint8 powerup_config_flags = 0;

extern int poll_switches( void );
extern void mcf5xxx_wr_pc (uint32);


/********************************************************************/
void
mcf5445x_init (void)
{
    extern char __DATA_ROM[];
    extern char __DATA_RAM[];
    extern char __DATA_END[];
    extern char __BSS_START[];
    extern char __BSS_END[];
    extern uint32 VECTOR_TABLE[];
    extern uint32 __VECTOR_RAM[];

    static uint32 n;
    static uint8 *dp, *sp;

    /* configure to come out of LIMP Mode and Write into PLL registers */ 
    sys_clk_khz = clock_pll_init (FREF, FSYS, CLOCK_PLL_DEFAULT, NULL) / 1000;
    sys_clk_mhz = sys_clk_khz/1000;
    gpio_init();
    
    if ((ADDRESS)fbcs_init & (ADDRESS)(__SRAM)) 	//FSL test to see if running from SRAM
    {
    	fbcs_init();    	
    }
    else 		//FSL if not running in SRAM, implement the Self Modifying Code
    {
				//FSL Self modifying code to load RAM with fbcs_init() function
				//FSL and then it gets overwritten below.
				//FSL We need this for cases when we are running out of the same
				//FSL memory that we are configuring (this is bad) otherwise
				//FSL the system crashes.
		sp = (unsigned char *)fbcs_init;
		dp = (unsigned char *)__VECTOR_RAM;
        for (n = (ADDRESS)fbcs_init; n < (ADDRESS)sdramc_init; n++)
        {
            *dp++ = *sp++;
        }
		mcf5xxx_wr_pc((ADDRESS)__VECTOR_RAM);
	    	
    }
    
	sdramc_init();
 
     /* Copy the vector table to RAM */
    if (__VECTOR_RAM != VECTOR_TABLE)
    {
        for (n = 0; n < 256; n++)
            __VECTOR_RAM[n] = VECTOR_TABLE[n];
    }
    
   /* Don't want to reload the initilise variable from DATA_ROM accept for POR and External Reset condition */
    if(((MCF_RCM_RSR & MCF_RCM_RSR_POR) == 0x08) | ((MCF_RCM_RSR & MCF_RCM_RSR_EXT) == 0x04))
    {
    /* Move initialized data from ROM to RAM. */
    if (__DATA_ROM != __DATA_RAM)
       {
        dp = (uint8 *)__DATA_RAM;
        sp = (uint8 *)__DATA_ROM;
        n = __DATA_END - __DATA_RAM;
        while (n--)
            *dp++ = *sp++;
       }

   	if (__BSS_START != __BSS_END)
       {
        	sp = (uint8 *)__BSS_START;
	        n = __BSS_END - __BSS_START;
        	while (n--)
            	*sp++ = 0;
       }
    }

    mcf5xxx_wr_vbr((uint32)__VECTOR_RAM);

    board_led_display(0xCA);		//FSL Testing dual 7-segment display on evb

    uart_init(0);
    uart_init(1);
//FSL    uart_init(2);

	mcf54455_powerup_config();
	mcf54455_PHY_init();   

   // Enabling Interrupts after locating VBR
    intc_init();

 }
/********************************************************************/
void
gpio_init(void)
{
	volatile unsigned char *cpld_ptr;
	
	/* Enable UART0/1 pins */
	MCF_GPIO_PAR_UART = (0
		| MCF_GPIO_PAR_UART_U1CTS
		| MCF_GPIO_PAR_UART_U1RTS
		| MCF_GPIO_PAR_UART_U1RXD
		| MCF_GPIO_PAR_UART_U1TXD
		| MCF_GPIO_PAR_UART_U0CTS
		| MCF_GPIO_PAR_UART_U0RTS
		| MCF_GPIO_PAR_UART_U0RXD
		| MCF_GPIO_PAR_UART_U0TXD);
		
	/*Enable all chip select in CS mode*/
	MCF_GPIO_PAR_CS = (0
	     | MCF_GPIO_PAR_CS_CS3                
	     | MCF_GPIO_PAR_CS_CS2 
	     | MCF_GPIO_PAR_CS_CS1);
	     

    /* Pin assignments for port BUSCTL 
           Pin BUSCTL3 : External bus output enable, /OE 
           Pin BUSCTL2 : External bus transfer acknowledge, /TA 
           Pin BUSCTL1 : External bus read/write, R/W 
           Pin BUSCTL0 : External bus transfer start, /TS 
    */

    /*     PAR_BUSCTL[PAR_OE] = 1 
           PAR_BUSCTL[PAR_TA] = 1 
           PAR_BUSCTL[PAR_RWB] = 1 
           PAR_BUSCTL[PAR_TS] = %11 
    */
    MCF_GPIO_PAR_FBCTL = MCF_GPIO_PAR_FBCTL_OE      |
                          MCF_GPIO_PAR_FBCTL_TA     |
                          MCF_GPIO_PAR_FBCTL_RW     |
                          MCF_GPIO_PAR_FBCTL_TS(0x3);

    /* Pin assignments for port BE 
           Pin BE3 : External bus byte enable BW/BWE3 
           Pin BE2 : External bus byte enable BW/BWE2 
           Pin BE1 : External bus byte enable BW/BWE1 
           Pin BE0 : External bus byte enable BW/BWE0 
    */

    MCF_GPIO_PAR_BE = 	MCF_GPIO_PAR_BE_BE3(3) |
    					MCF_GPIO_PAR_BE_BE2(3) |
    					MCF_GPIO_PAR_BE_BE1 |
    					MCF_GPIO_PAR_BE_BE0;

    /* Reset the FEC */
    MCF_FEC_ECR(0) = MCF_FEC_ECR_RESET;
    MCF_FEC_ECR(1) = MCF_FEC_ECR_RESET;
    
    /* Enable FEC RMII pin functions */
	MCF_GPIO_PAR_FEC = MCF_GPIO_PAR_FEC		//FSL FEC0
            & MCF_GPIO_PAR_FEC_FEC0_MASK
            | MCF_GPIO_PAR_FEC_FEC0_RMII_GPIO;
	MCF_GPIO_PAR_FEC |= MCF_GPIO_PAR_FEC	//FSL FEC1
            & MCF_GPIO_PAR_FEC_FEC1_MASK
            | MCF_GPIO_PAR_FEC_FEC1_RMII_GPIO;
    MCF_GPIO_PAR_FECI2C |= 0
        | MCF_GPIO_PAR_FECI2C_MDC0_MDC0
        | MCF_GPIO_PAR_FECI2C_MDIO0_MDIO0;
        
	CPLD_CONTROL &= ~CPLD_CONTROL_PHY0_PWRDWN;	//FSL PHY0/1 enable
                
    /* Pin assignments for port TIMER 
           Pins are all GPIO outputs 
    */

    /*     PDDR_TIMER[DDR3] = 1 
           PDDR_TIMER[DDR2] = 1 
           PDDR_TIMER[DDR1] = 1 
           PDDR_TIMER[DDR0] = 1 
    MCF_GPIO_PDDR_TIMER = MCF_GPIO_PDDR_TIMER_PDDR_TIMER3 |
                          MCF_GPIO_PDDR_TIMER_PDDR_TIMER2 |
                          MCF_GPIO_PDDR_TIMER_PDDR_TIMER1 |
                          MCF_GPIO_PDDR_TIMER_PDDR_TIMER0;
    */

    /*     PAR_TIMER[PAR_T3IN] = 0 
           PAR_TIMER[PAR_T2IN] = 0 
           PAR_TIMER[PAR_T1IN] = 0 
           PAR_TIMER[PAR_T0IN] = 0 
    */
    MCF_GPIO_PAR_TIMER = 0;

}
/********************************************************************/
/*!
 * \brief   Initialize the Flexbus interface
 * \return  None
 *
 * M54455EVB uses four chip-selects:
 *  - FBCS[0|1] : Flash 0 (U12, Atmel AT49BV040, 512KB)
 *  - FBCS[0|1] : Flash 1 (U903, Intel 28F128J3D, 16MB)
 *  - FBCS[2]   : Xilinx CPLD (U15, XC95144XL)
 *  - FBCS[3]   : Xilinx FPGA (U919, XC3S400)
 *
 * The CPLD maps FB_CS[1:0] to the two flash devcies based on the value
 * of the configuration switch CPLD_MODE[2] at reset.  This initialization
 * routine reads the CPLD settings to determine which flash is connected
 * to which chip-select.
 *
 * The Flexbus memory map is independent of the CPLD_MODE[2] setting
 * and is organized as follows:
 *\verbatim
 *
 *  Device   Port-size     Start     Size
 * ---------------------------------------
 *  Flash1      16      0x0000_0000   16M
 *  Flash0      8       0x0400_0000  512K
 *   CPLD       8       0x0800_0000   16M
 *   FPGA       32      0x0900_0000   16M
 */

void
fbcs_init (void)
{
  if(!(MCF_FBCS_CSMR0&MCF_FBCS_CSMR_V))		//FSL if CS0 Valid bit set...do not reinitialize chip selects
  {
    int flash0_cs, flash1_cs, ws, sws, fb_period;

    /* Make sure the Flexbus signals are set for Flexbus functionality */
    MCF_GPIO_PAR_FBCTL = 0
        | MCF_GPIO_PAR_FBCTL_OE_OE
        | MCF_GPIO_PAR_FBCTL_TA_TA
        | MCF_GPIO_PAR_FBCTL_RW_RW
        | MCF_GPIO_PAR_FBCTL_TS_TS;
    MCF_GPIO_PAR_BE = 0
        | MCF_GPIO_PAR_BE_BE3_BE3
        | MCF_GPIO_PAR_BE_BE2_BE2
        | MCF_GPIO_PAR_BE_BE1_BE1
        | MCF_GPIO_PAR_BE_BE0_BE0;
        
    /* The global chip-select (FBCS0) will assert for all Flexbus
     * accesses until the CSMR0[V] bit is set.  CS0 must be enabled
     * before the CPLD config register can be read.  The reset values
     * are left untouched except for the address mask. Both flash devices
     * will be contained within the first 128M of Flexbus address, so
     * CS0 is given all 128M for now. */
    MCF_FBCS_CSMR0 = 0
        | MCF_FBCS_CSMR_BAM_128M
        | MCF_FBCS_CSMR_V;

    /* Enable CPLD chip-select */
    MCF_FBCS_CSAR2 = MCF_FBCS_CSAR_BA(CPLD_ADDRESS);
    MCF_FBCS_CSCR2 = 0
        | MCF_FBCS_CSCR_AA          /* Auto acknowledge */
        | MCF_FBCS_CSCR_WS(8)       /* Wait states */
        | MCF_FBCS_CSCR_PS_8        /* Port size: 8 bits */
        | MCF_FBCS_CSCR_RDAH(1)     /* Read address hold */
        | MCF_FBCS_CSCR_WRAH(1)     /* Write address hold */
        | MCF_FBCS_CSCR_ASET(1);     /* Address setup */
    MCF_FBCS_CSMR2 = 0
        | MCF_FBCS_CSMR_BAM((CPLD_SIZE-1)>>16)
        | MCF_FBCS_CSMR_V;          /* Activate this chip-select */

    /* Determine chip-select mapping */
    if (CPLD_MODE & CPLD_MODE_FLASH_CS) {
        flash1_cs = 0;
        flash0_cs = 1;
    }
    else {
        flash1_cs = 1;
        flash0_cs = 0;
    }
        
    /* Determine flash wait states. The maximum access time for the flashes
     * are defined in jamaica.h.  The chip-select is delayed ~7.5ns
     * through the CPLD.  The wait states are calculated assuming
     * that the entire access time is covered by wait-states.  This
     * allows the one clock of normal access time (pre wait-states)
     * to cover the additional delay through the CPLD.
     */
    ws = 1 + ((clock_get_ffb() / 1000000) * FLASH0_MAX_ACCESS) / 1000;

    /* Enable Flash 0 (Atmel AT49BV040) chip-select */
    MCF_FBCS_CSAR(flash0_cs) = MCF_FBCS_CSAR_BA(FLASH0_ADDRESS);
    MCF_FBCS_CSCR(flash0_cs) = 0
        | MCF_FBCS_CSCR_AA          /* Auto acknowledge */
        | MCF_FBCS_CSCR_WS(ws)      /* Wait states */
        | MCF_FBCS_CSCR_PS_8;       /* Port size: 8 bits */
    MCF_FBCS_CSMR(flash0_cs) = 0
        | MCF_FBCS_CSMR_BAM((FLASH0_SIZE-1)>>16)
        | MCF_FBCS_CSMR_V;          /* Activate this chip-select */

    /* Enable Flash 1 (Intel J3D) chip-select
     *
     * The interface to Flash 1 is a non-multiplexed 8-bit data bus / 24 bit
     * address bus interface.
     * 
     * The J3D flash defaults to asynchronous page-mode which allows
     * burst reads. Secondary wait-states can be used to realize this timing 
     * (otherwise, the Flexbus will use the normal wait-states for all burst
     * beats). The SWS is calculated to allow for the output valid plus our
     * data setup time requirement of 3ns. 
     */
    ws = 1 + ((clock_get_ffb() / 1000000) * FLASH1_MAX_ACCESS) / 1000;
    //sws = (FLASH1_PAGE_MAX_ACCESS + 3) / fb_period;
    MCF_FBCS_CSAR(flash1_cs) = MCF_FBCS_CSAR_BA(FLASH1_ADDRESS);
    MCF_FBCS_CSCR(flash1_cs) = 0
    //    | MCF_FBCS_CSCR_BSTR        /* Burst Reads (asynch page-mode reads) */
        | MCF_FBCS_CSCR_AA          /* Auto acknowledge */
        | MCF_FBCS_CSCR_WS(ws)      /* Wait states */
        | MCF_FBCS_CSCR_RDAH(0)     /* Read address hold */
        | MCF_FBCS_CSCR_WRAH(0)     /* Write address hold */
        | MCF_FBCS_CSCR_ASET(0)     /* Address setup */
    //    | MCF_FBCS_CSCR_SWSEN       /* Secondary wait-states enable */
    //    | MCF_FBCS_CSCR_SWS(sws)    /* Secondary wait-states */
        | MCF_FBCS_CSCR_PS_8;       /* Port size: 8 bits */
    MCF_FBCS_CSMR(flash1_cs) = 0
        | MCF_FBCS_CSMR_BAM((FLASH1_SIZE-1)>>16)
        | MCF_FBCS_CSMR_V;          /* Activate this chip-select */

    /* Enable FPGA chip-select */
    MCF_FBCS_CSAR3 = MCF_FBCS_CSAR_BA(FPGA_ADDRESS);
    MCF_FBCS_CSCR3 = 0
        | MCF_FBCS_CSCR_AA          /* Auto acknowledge */
        | MCF_FBCS_CSCR_WS(8)       /* Wait states */
        | MCF_FBCS_CSCR_PS_32;      /* Port size: 32 bits */
    MCF_FBCS_CSMR3 = 0
        | MCF_FBCS_CSMR_BAM((FPGA_SIZE-1)>>16)
        | MCF_FBCS_CSMR_V;          /* Activate this chip-select */
  }
}

/********************************************************************/
/*!
 * \brief   Initialize the SDRAM Controller
 * \return  None
 *
 * There are four MT47H64M8 (512Mb, 16Meg x 8 x 4 banks) DDR2 chips
 * on Jamamica; two on each of the two chip-selects.  This provides
 * a total of 256MB of DDR2 memory.
 *
 * SDRAM timing and configuration notes:
 *  - Burst Length: On this architecture, the internal bus is 32-bits and the
 *    SDRAM data bus is 16-bits.  Thus a 4 beat burst on the internal bus will
 *    result in an 8 beat burst to the SDRAM
 *  - CAS Latency: The bus is only running at a max of 133/266MHz; in the low
 *    end of DDR2 capabilites.  The lowest CAS latency setting of 3 will work
 *    for all DDR2 devices.
 *  - Additive Latency: Typical additive latency setting would be
 *    tRCD(min)-1 tCLKs.  At 133/266MHz, this usually works out to be
 *    one clock of AL.
 *  - Address Mux: The MT47H64M8 is organized as 64M x 8bit with 14 row
 *    addresses, 10 column addresses, and 4 banks (14 x 10 x 4).  This
 *    calls for an address mux setting (SDCR[ADDR_MUX]) of 2 as shown in
 *    Tables 20-2,3 in the MCF54455RM.
 */
void
sdramc_init (void)
{

	/*
	 * Check to see if the SDRAM has already been initialized
	 * by a run control tool
	 */
	 
    /* Only execute this init if the controller isn't already enabled */
    if (!(MCF_SDRAMC_SDCR & MCF_SDRAMC_SDCR_REF_EN))
    {
        /* Program the SDRAMC pins to DDR2 mode */
        MCF_GPIO_MSCR_SDRAM = 0
            | MCF_GPIO_MSCR_SDRAM_SDDATA_DDR2
            | MCF_GPIO_MSCR_SDRAM_SDDQS_DDR2
            | MCF_GPIO_MSCR_SDRAM_SDCLK_DDR2
            | MCF_GPIO_MSCR_SDRAM_SDCTL_DDR2;

        /* Initialize SDRAM chip selects */
        MCF_SDRAMC_SDCS0 = 0
            | MCF_SDRAMC_SDCS_BA(SDRAM_ADDRESS)
            | MCF_SDRAMC_SDCS_CSSZ_128MBYTE;
        MCF_SDRAMC_SDCS1 = 0
            | MCF_SDRAMC_SDCS_BA(SDRAM_ADDRESS + (128 * 1024 * 1024))
            | MCF_SDRAMC_SDCS_CSSZ_128MBYTE;

        /* Configuration Register 1 */
        MCF_SDRAMC_SDCFG1 = 0
            | MCF_SDRAMC_SDCFG1_SRD2RWP(8/2+2)
            | MCF_SDRAMC_SDCFG1_SWT2RWP(SDRAM_SWT2RWP)
            | MCF_SDRAMC_SDCFG1_RD_LAT(SDRAM_CL)
            | MCF_SDRAMC_SDCFG1_ACT2RW(SDRAM_ACT2RW)
            | MCF_SDRAMC_SDCFG1_PRE2ACT(SDRAM_PRE2ACT)
            | MCF_SDRAMC_SDCFG1_REF2ACT(SDRAM_REF2ACT)
            | MCF_SDRAMC_SDCFG1_WT_LAT(SDRAM_AL);

        /* Configuration Register 2 */
        MCF_SDRAMC_SDCFG2 = 0
            | MCF_SDRAMC_SDCFG2_BRD2RP(8/2+SDRAM_AL)
            | MCF_SDRAMC_SDCFG2_BWT2RWP(SDRAM_BWT2RWP)
            | MCF_SDRAMC_SDCFG2_BRD2W(8/2+2)
            | MCF_SDRAMC_SDCFG2_BL(8-1);

        /* Precharge and enable write to SDMR */
        MCF_SDRAMC_SDCR = 0
            | MCF_SDRAMC_SDCR_MODE_EN
            | MCF_SDRAMC_SDCR_CKE
            | MCF_SDRAMC_SDCR_DDR_MODE
            | MCF_SDRAMC_SDCR_DDR2_MODE
            | MCF_SDRAMC_SDCR_ADDR_MUX(2)
            | MCF_SDRAMC_SDCR_REF_CNT(SDRAM_REFCNT)
            | MCF_SDRAMC_SDCR_MEM_PS
            | MCF_SDRAMC_SDCR_IPALL;

        /* Write extended mode register */
        MCF_SDRAMC_SDMR = 0
            | MCF_SDRAMC_SDMR_BK_LEMR
            | MCF_SDRAMC_SDMR_DDR2_AD(0
                | 1 << 10
                | SDRAM_AL << 3)
            | MCF_SDRAMC_SDMR_CMD;

        /* Write mode register and reset DLL */
        MCF_SDRAMC_SDMR = 0
            | MCF_SDRAMC_SDMR_BK_LMR
            | MCF_SDRAMC_SDMR_DDR2_AD(0
                | SDRAM_WR << 9
                | 1 << 8
                | 3 << 4
                | 3 << 0)
            | MCF_SDRAMC_SDMR_CMD;

        /* Execute a PALL command */
        MCF_SDRAMC_SDCR |= MCF_SDRAMC_SDCR_IPALL;

        /* Perform two REF cycles */
        MCF_SDRAMC_SDCR |= MCF_SDRAMC_SDCR_IREF;
        MCF_SDRAMC_SDCR |= MCF_SDRAMC_SDCR_IREF;

        /* Write mode register and clear reset DLL */
        MCF_SDRAMC_SDMR = 0
            | MCF_SDRAMC_SDMR_BK_LMR
            | MCF_SDRAMC_SDMR_DDR2_AD(0
                | SDRAM_WR << 9
                | 3 << 4
                | 3 << 0)
            | MCF_SDRAMC_SDMR_CMD;

        /* Enable auto refresh and lock SDMR */
        MCF_SDRAMC_SDCR &= ~MCF_SDRAMC_SDCR_MODE_EN;
        MCF_SDRAMC_SDCR |= 0
            | MCF_SDRAMC_SDCR_REF_EN
            | MCF_SDRAMC_SDCR_DQS_OE_BOTH;
    }
}
/********************************************************************/ 
void intc_init()
{
  intc0_init();
  intc1_init();
  mcf5xxx_irq_enable();
}
/********************************************************************/ 
#if 0
////initialize the timer for scc/////////
void scc_timer_init()
{
  MCF_SCC_TIMER_IV = 0xffffffff;
  MCF_SCC_TIMER_CTRL = MCF_SCC_TIMER_CTRL_STRT|MCF_SCC_TIMER_CTRL_LOAD;
}
#endif  
/********************************************************************/
//intc_init1 assign default priority level 1.//
void intc1_init ()
{
//FSL MCF_INTC1_CIMR = 0x40;
   
#if 0	//DON'T program as they are "not used"              
 MCF_INTC1_ICR0  =0x01;
 MCF_INTC1_ICR1  =0x01; 
 MCF_INTC1_ICR2  =0x01; 
 MCF_INTC1_ICR3  =0x01; 
 MCF_INTC1_ICR4  =0x01; 
 MCF_INTC1_ICR5  =0x01; 
 MCF_INTC1_ICR6  =0x01; 
 MCF_INTC1_ICR7  =0x01; 
 MCF_INTC1_ICR8  =0x01; 
 MCF_INTC1_ICR9  =0x01; 
 MCF_INTC1_ICR10 =0x01; 
 MCF_INTC1_ICR11 =0x01; 
 MCF_INTC1_ICR12 =0x01; 
 MCF_INTC1_ICR13 =0x01; 
 MCF_INTC1_ICR14 =0x01; 
 MCF_INTC1_ICR15 =0x01; 
 MCF_INTC1_ICR16 =0x01; 
 MCF_INTC1_ICR17 =0x01; 
 MCF_INTC1_ICR18 =0x01; 
 MCF_INTC1_ICR19 =0x01; 
 MCF_INTC1_ICR20 =0x01; 
 MCF_INTC1_ICR21 =0x01; 
 MCF_INTC1_ICR22 =0x01; 
 MCF_INTC1_ICR23 =0x01; 
 MCF_INTC1_ICR24 =0x01; 
 MCF_INTC1_ICR25 =0x01; 
 MCF_INTC1_ICR26 =0x01; 
 MCF_INTC1_ICR27 =0x01; 
 MCF_INTC1_ICR28 =0x01; 
 MCF_INTC1_ICR29 =0x01; 
 MCF_INTC1_ICR30 =0x01; 
 MCF_INTC1_ICR31 =0x01; 
 MCF_INTC1_ICR32 =0x01; 
 MCF_INTC1_ICR33 =0x01; 
#endif
 MCF_INTC1_ICR34 =0x01; 
 MCF_INTC1_ICR35 =0x01; 
 MCF_INTC1_ICR36 =0x01; 
 MCF_INTC1_ICR37 =0x01; 
 MCF_INTC1_ICR38 =0x01; 
 MCF_INTC1_ICR39 =0x01; 
 MCF_INTC1_ICR40 =0x01; 
#if 0	//DON'T program as they are "not used"              
 MCF_INTC1_ICR41 =0x01; 
 MCF_INTC1_ICR42 =0x01; 
#endif
 MCF_INTC1_ICR43 =0x01; 
 MCF_INTC1_ICR44 =0x01; 
 MCF_INTC1_ICR45 =0x01; 
 MCF_INTC1_ICR46 =0x01; 
 MCF_INTC1_ICR47 =0x01; 
#if 0	//DON'T program as "not used"              
 MCF_INTC1_ICR48 =0x01; 
#endif
 MCF_INTC1_ICR49 =0x01;
#if 0	//DON'T program as they are "not used"              
 MCF_INTC1_ICR50 =0x01; 
 MCF_INTC1_ICR51 =0x01; 
 MCF_INTC1_ICR52 =0x01; 
#endif
 MCF_INTC1_ICR53 =0x01; 
 MCF_INTC1_ICR54 =0x01; 
 MCF_INTC1_ICR55 =0x01; 
 MCF_INTC1_ICR56 =0x01; 
 MCF_INTC1_ICR57 =0x01; 
#if 0	//DON'T program as they are "not used"              
 MCF_INTC1_ICR58 =0x01; 
 MCF_INTC1_ICR59 =0x01; 
 MCF_INTC1_ICR60 =0x01; 
 MCF_INTC1_ICR61 =0x00;
 MCF_INTC1_ICR62 =0x01; 
 MCF_INTC1_ICR63 =0x01; 
#endif 
}

//intc_init0 assign default priority level 1.//
void intc0_init()
{
//FSL MCF_INTC0_CIMR = 0x40;
#if 0	//DON'T program as "not used"              
 MCF_INTC0_ICR0  =0x01; 
#endif 
 MCF_INTC0_ICR1  =0x01; 
 MCF_INTC0_ICR2  =0x01; 
 MCF_INTC0_ICR3  =0x01; 
 MCF_INTC0_ICR4  =0x01; 
 MCF_INTC0_ICR5  =0x01; 
 MCF_INTC0_ICR6  =0x01; 
 MCF_INTC0_ICR7  =0x01; 
 MCF_INTC0_ICR8  =0x01; 
 MCF_INTC0_ICR9  =0x01; 
 MCF_INTC0_ICR10 =0x01; 
 MCF_INTC0_ICR11 =0x01; 
 MCF_INTC0_ICR12 =0x01; 
 MCF_INTC0_ICR13 =0x01; 
 MCF_INTC0_ICR14 =0x01; 
 MCF_INTC0_ICR15 =0x01; 
 MCF_INTC0_ICR16 =0x01; 
 MCF_INTC0_ICR17 =0x01; 
 MCF_INTC0_ICR18 =0x01; 
 MCF_INTC0_ICR19 =0x01; 
 MCF_INTC0_ICR20 =0x01; 
 MCF_INTC0_ICR21 =0x01; 
 MCF_INTC0_ICR22 =0x01; 
 MCF_INTC0_ICR23 =0x01; 
 MCF_INTC0_ICR24 =0x01; 
 MCF_INTC0_ICR25 =0x01; 
//FSL MCF_INTC0_ICR26 =0x01;  //FSL UART0
//FSL MCF_INTC0_ICR27 =0x01;  //FSL UART1 
//FSL MCF_INTC0_ICR28 =0x01;  //FSL UART2 
#if 0	//DON'T program as "not used"              
 MCF_INTC0_ICR29 =0x01; 
#endif
 MCF_INTC0_ICR30 =0x01; 
 MCF_INTC0_ICR31 =0x01; 
 MCF_INTC0_ICR32 =0x01; 
 MCF_INTC0_ICR33 =0x01; 
 MCF_INTC0_ICR34 =0x01; 
 MCF_INTC0_ICR35 =0x01; 
 MCF_INTC0_ICR36 =0x01; 
 MCF_INTC0_ICR37 =0x01; 
 MCF_INTC0_ICR38 =0x01; 
 MCF_INTC0_ICR39 =0x01; 
 MCF_INTC0_ICR40 =0x01; 
 MCF_INTC0_ICR41 =0x01; 
 MCF_INTC0_ICR42 =0x01; 
 MCF_INTC0_ICR43 =0x01; 
 MCF_INTC0_ICR44 =0x01; 
 MCF_INTC0_ICR45 =0x01; 
 MCF_INTC0_ICR46 =0x01; 
 MCF_INTC0_ICR47 =0x01; 
 MCF_INTC0_ICR48 =0x01; 
 MCF_INTC0_ICR49 =0x01; 
 MCF_INTC0_ICR50 =0x01; 
 MCF_INTC0_ICR51 =0x01; 
 MCF_INTC0_ICR52 =0x01; 
 MCF_INTC0_ICR53 =0x01; 
 MCF_INTC0_ICR54 =0x01; 
 MCF_INTC0_ICR55 =0x01; 
 MCF_INTC0_ICR56 =0x01; 
 MCF_INTC0_ICR57 =0x01; 
 MCF_INTC0_ICR58 =0x01; 
 MCF_INTC0_ICR59 =0x01; 
 MCF_INTC0_ICR60 =0x01; 
 MCF_INTC0_ICR61 =0x01; 
 MCF_INTC0_ICR62 =0x01; 
 MCF_INTC0_ICR63 =0x01;
}

/********************************************************************/ 
// This function reads the switches at power-up, and sets a power-up
// config flag.
/********************************************************************/
void mcf54455_powerup_config( void )
{
	powerup_config_flags = poll_switches();
}

/********************************************************************/
/*!
 * \brief   Enable all the external interrupts on the platform
 * \return  None
 *
 * Enable the extneral interrupts in the MCF5445x and enabled the two
 * switches for interrupt generation in the M54455EVB FPGA.
 *
 * \note    The generic interrupt handler will be called unless the 
 *          application registers a custom one.  Example:
 *          mcf5xxx_set_handler(64 + 4, (ADDRESS)sw6_handler);
 */
void
platform_enable_interrupts (void)
{
    /* Enable interrupts in the Edge Port */
    MCF_EPORT_EPPAR = 0
        | MCF_EPORT_EPPAR_EPPA1_RISING
        | MCF_EPORT_EPPAR_EPPA3_RISING
        | MCF_EPORT_EPPAR_EPPA4_RISING
        | MCF_EPORT_EPPAR_EPPA7_LEVEL;
    MCF_EPORT_EPIER = 0
        | MCF_EPORT_EPIER_EPIE1
        | MCF_EPORT_EPIER_EPIE3
        | MCF_EPORT_EPIER_EPIE4
        | MCF_EPORT_EPIER_EPIE7;

    /* Enable interrupts in the interrupt controller */
    MCF_INTC0_CIMR = MCF_INTC0_ICR1 = 1;
    MCF_INTC0_CIMR = MCF_INTC0_ICR3 = 3;
    MCF_INTC0_CIMR = MCF_INTC0_ICR4 = 4;
    MCF_INTC0_CIMR = MCF_INTC0_ICR7 = 7;
    
    /* Enable interrupts in the FPGA */
    FPGA_IRQEN = 0
        | FPGA_IRQEN_SW7
        | FPGA_IRQEN_SW6;
        
    /* Route the switch interrupts to IRQ7 & IRQ4 */
    FPGA_IRQROUTE = 0
        | FPGA_IRQROUTE_SW7_IRQ7
        | FPGA_IRQROUTE_SW6_IRQ4;
    
    /* Enable interrupts in the core */
    mcf5xxx_irq_enable();
}
/********************************************************************/
// Init external PHY...National Semiconductor DP83491
/********************************************************************/
int DUPLEX_phy_r17_dpm=0;
void mcf54455_PHY_init(void)
{
  	unsigned short reg0;
  	int myctr;

//FSL replace function call	fec_mii_init((SYSTEM_CLOCK));  with below MCF_FEC_MSCR macro
    /*
     * Configure MII interface speed. Must be <= 2.5MHz
     *
     * Desired MII clock is 2.5MHz
     * MII Speed Setting = System_Clock_Bus_Speed / (2.5MHz * 2)
     */

	MCF_FEC0_MSCR = MCF_FEC_MSCR_MII_SPEED((uint32)(SYS_CLK_MHZ/5)+1); 
	cpu_pause(100);

	do
	{
		while(!(fec_mii_read(FEC_PHY0, PHY_REG_CR, &reg0)))		//FSL read PHY control register
		{
			reg0=0;
		};
		
	} while(reg0&PHY_R0_RESET);		//Test RESET bit...1=in reset, 0=reset complete
		
#if (!AUTO)
	if (BaseT==100)		//FSL BaseT set to 100mpbs
		reg0 |= 0x2000;								// 100Mbps
	else				//FSL BaseT defaults to 10mbps
		reg0 &= ~0x2000;							// 10Mbps

	if (DUPLEX==0)
		reg0 |= 0x0100;								// Full Duplex
	else		
		reg0 &= ~0x0100;							// Half Duplex

	while(!fec_mii_write( FEC_PHY0, PHY_REG_CR, reg0|0x0200 ))
	{
	};					//Force re-negotiation

#endif

	cpu_pause(100);
    
	while(!(fec_mii_read(FEC_PHY0, 0x10, &reg0)))	// read PHY status register
	{
		reg0=0;
	};
	DUPLEX_phy_r17_dpm = (int)((reg0&0x0004)>>2);	// 1=full,0=half duplex...used in ifec.c
	
	myctr=0;
	printf("\n\nEthernet Link" );
	do		//FSL read PHY status register
	{
		fec_mii_read(FEC_PHY0, 0x10, &reg0);
		myctr++;
		if(myctr>333333)
		{
			printf("FAILED...check cable please\n\n" );
			return;
		}
	}while (!(reg0&(PHY_R1_LS)));		//FSL exit while loop when Link Status up
	
	printf("Established!\n\n");


}
/********************************************************************/