/*! 
 * \file    cache.h
 * \brief   Simple driver for the V4 cache controller
 * \version $Revision: 1.1 $
 * \author  Michael Norman
 *
 * Driver for the ColdFire V4 cache controller
 *
 */

#ifndef _CACHE_H_
#define _CACHE_H_

/********************************************************************/

int
cpu_cache_init (int settings);

int
cpu_icache_enable (uint32 addr, uint32 size);

void
cpu_icache_disable (void);

void
cpu_bcache_enable (void);

void
cpu_bcache_disable (void);

int
cpu_dcache_enable (uint32 addr, uint32 size, int mode);

void
cpu_dcache_disable (void);

/********************************************************************/

#endif /* _CACHE_H_ */
