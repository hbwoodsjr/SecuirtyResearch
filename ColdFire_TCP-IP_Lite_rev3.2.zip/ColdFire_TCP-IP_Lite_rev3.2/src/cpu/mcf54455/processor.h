/*
 * File:		processor.h
 * Purpose:		This header specifies which ColdFire processor will be used
 *			with the project.
 *
 * Notes:  FSL created file
 */

#ifndef _PROCESSOR_H
#define _PROCESSOR_H

/********************************************************************/

#define MCF54455		1		/* This defines the processor being used */

#define FULL			0
#define HALF			1

#define M54455EVB		1		/* This defines the evb being used */

#define DHCP			0		/* 0=DHCP off, 1=DHCP on */
#define CONSOLE_UART	0		/* Set to the respective UART number to use for console */
								//FSL 0 = UART0 to USB interface (JP909-JP912 pin 2-3)[DEFAULT]
								//FSL 0 = UART0 to UART1 DB9 connector (JP909-JP912 pin 1-2)
								//FSL 1 = UART1 to UART1 DB9 connector (JP907-JP908 pin 1-2)
#define AUTO			1		//FSL 0=disable autonegotiation, 1=enable autonegotiation
#if (!AUTO)						//FLS DUPLEX and BaseT only used if AUTO=0
#define DUPLEX			HALF	//FSL enter HALF or FULL to select Ethernet duplex mode
#define BaseT			100		//FSL set Ethernet BaseT to 10 or 100
#endif
#define ETH_PORT		0		//FSL the MCF54455 has two Ethernet FEC ports FEC0/FEC1
								//FSL 0 = FEC0,	1 = FEC1

#ifndef CLIENT
#define CLIENT			0		//FSL 1=client software operates. 0=server
#endif

#define MAX_ETH_PKT 	1522	//FSL BIGBUFSIZE, TCP_MSS, and MTU calculated off of MAX_ETH_PKT.
								//FSL default setting 1522

#define ETH_PROCESSOR_H	1		//FSL comment out to have ipport.h values used

#if 0		//FSL Default settings
#define NUM_RXBDS    2			//FSL number of Receive Buffer Descriptors; default=2
#define NUM_TXBDS    (2*NUM_RXBDS)				//FSL number of Transmit Buffer Descriptors
#define NUMBIGBUFS   (NUM_RXBDS+NUM_TXBDS+1)	//FSL number of Big Buffers for Ethernet Frames
#define NUMLILBUFS   (NUM_TXBDS) 				//FSL number of Little Buffers for Ethernet Frames
#else		//FSL play around settings
#define NUM_RXBDS    10			//FSL number of Receive Buffer Descriptors; default=2
#define NUM_TXBDS  	 20			//FSL number of Transmit Buffer Descriptors
#define NUMBIGBUFS   (NUM_RXBDS+NUM_TXBDS+1)	//FSL number of Big Buffers for Ethernet Frames
#define NUMLILBUFS   (NUM_TXBDS) 				//FSL number of Little Buffers for Ethernet Frames
#endif

#define DMA_TIMER_LEVEL 3		//FSL dma interrupt level									
#define USB				0		//FSL enable USB code

#define WD_TEST			0		//FSL Enable watchdog timer module ability to reset device if bus hangs
								//FSL 0=disable, 1=enable

/* 
 * Include the specific CPU header file 
 */

#include "mcf5445x.h"					/* processor specific headers */
#include "mcf54455_evb.h"				/* evb specific headers */

/********************************************************************/
#endif /* _PROCESSOR_H */
