/*
 * File:		mcf54455_evb.h
 * Purpose:		Evaluation board definitions and memory map information
 *
 * Notes:
 */

#ifndef _MCF54455_EVB_H
#define _MCF54455_EVB_H

/********************************************************************/

#include "mcf5xxx.h"
#include "io.h"

/********************************************************************/

/*
 * Debug prints ON (#undef) or OFF (#define)
 */
#undef DEBUG

/********************************************************************/

/*
 * Include board specific header files
 */

/*
 * System Bus Clock Info
 */
#ifndef FREF
#define FREF            33333333
#endif

#ifndef FSYS
#define FSYS            266666666       /*!< Core clock freq (Hz) */
#endif

#define FSYS_KHZ        (FSYS/1000)     /*!< Core clock freq (KHz) */
#define FSYS_MHZ        (FSYS_KHZ/1000) /*!< Core clock freq (MHz) */
#define TSYS_NS         (1000/FSYS_MHZ) /*!< Core clock period (ns) */
#define FBUS            (FSYS/2)        /*!< Internal bus clock freq (Hz) */
#define FBUS_KHZ        (FSYS_KHZ/2)    /*!< Internal bus clock freq (KHz) */
#define FBUS_MHZ        (FSYS_MHZ/2)    /*!< Internal bus clock freq (MHz) */
#define TBUS_NS         (1000/FBUS_MHZ) /*!< Internal bus clock period (ns) */

#define SYSTEM_CLOCK      FSYS          /* system bus frequency in MHz */
#define SYS_CLK_KHZ	      FBUS_KHZ      /* this is a dummy define*/
#define SYS_CLK_MHZ		  FBUS_MHZ		//FSL used by ifec.c

/*
 * Flash Info
 */
//#define AMD_FLASH_DEVICES   2
//#define AMD_FLASH_AM29LV128M_16BIT

/*
 * Serial Port Info
 */
#define TERM_PORT           0       /*!< UART channel used as terminal */
#define TERM_BAUD           115200  /*!< Default UART baud rate */

#define TERMINAL_PORT       TERM_PORT          
#define TERMINAL_BAUD       TERM_BAUD	   
#undef  HARDWARE_FLOW_CONTROL          /* Flow control ON or OFF */

/*
 * SDRAM Timing Parameters
 */
#define SDRAM_CL    3               /*!< DDR2 CAS Latency */
#define SDRAM_AL    1               /*!< DDR2 Additive Latency */
#define SDRAM_TRCD  (15/TBUS_NS)    /*!< DDR2 RAS to CAS delay (ns) */
#define SDRAM_TRP   (15/TBUS_NS)    /*!< DDR2 Precharge commadn period (ns) */
#define SDRAM_TWR   (15/TBUS_NS)    /*!< DDR2 Write recovery time */
#define SDRAM_TRFC  105             /*!< DDR2 Refresh to Active interval (ns) */
#define SDRAM_TREFI 7800            /*!< DDR2 Average refresh interval (ns) */

/* 
 * SDRAM timing calculations
 */
#if ((FSYS_KHZ == 266666) || (FSYS_KHZ == 250000))
#define SDRAM_SWT2RWP       5   /* SDRAM_CL + SDRAM_AL + SDRAM_TWR */
#define SDRAM_ACT2RW        1   /* SDRAM_TRCD */
#define SDRAM_PRE2ACT       1   /* SDRAM_TRP */
#define SDRAM_REF2ACT       8   /* SDRAM_TRFC/(TBUS_NS * 2) + 1 */
#define SDRAM_BWT2RWP       9   /* SDRAM_CL + SDRAM_AL + 8/2 + SDRAM_TWR */
#define SDRAM_REFCNT        15  /* SDRAM_TREFI/(TBUS_NS*64) - 1 */
#define SDRAM_WR            1   /* SDRAM_TWR */
#elif (FSYS_KHZ == 200000)
#define SDRAM_SWT2RWP       5   /* SDRAM_CL + SDRAM_AL + SDRAM_TWR */
#define SDRAM_ACT2RW        1   /* SDRAM_TRCD */
#define SDRAM_PRE2ACT       1   /* SDRAM_TRP */
#define SDRAM_REF2ACT       6   /* SDRAM_TRFC/(TBUS_NS * 2) + 1 */
#define SDRAM_BWT2RWP       9   /* SDRAM_CL + SDRAM_AL + 8/2 + SDRAM_TWR */
#define SDRAM_REFCNT        11  /* SDRAM_TREFI/(TBUS_NS*64) - 1 */
#define SDRAM_WR            1   /* SDRAM_TWR */
#elif ((FSYS_KHZ == 166666) || (FSYS_KHZ == 133333))
#define SDRAM_SWT2RWP       5   /* SDRAM_CL + SDRAM_AL + SDRAM_TWR */
#define SDRAM_ACT2RW        1   /* SDRAM_TRCD */
#define SDRAM_PRE2ACT       1   /* SDRAM_TRP */
#define SDRAM_REF2ACT       5   /* SDRAM_TRFC/(TBUS_NS * 2) + 1 */
#define SDRAM_BWT2RWP       9   /* SDRAM_CL + SDRAM_AL + 8/2 + SDRAM_TWR */
#define SDRAM_REFCNT        10  /* SDRAM_TREFI/(TBUS_NS*64) - 1 */
#define SDRAM_WR            1   /* SDRAM_TWR */
#endif

/*
 * SDRAM Memory Type
 */
 #define SDR                0
 #define DDR 		    	1	
 #define SDRAM_MODE         DDR 
 #define WIDTH32           	0
 #define WIDTH16           	1 
 #define SDRAM_MEM_PS       WIDTH16
 #define SDRAM_AMUX	    	1
								 
/*
 * Interrupt Priorities
 */
#define DMA_INTC_LVL        6
#define DMA_INTC_PRI        0
#define FEC0_INTC_LVL       5
#define FEC0_INTC_PRI       0
#define FEC1_INTC_LVL       5
#define FEC1_INTC_PRI       1
#define FEC_INTC_LVL(x)     ((x == 0) ? FEC0_INTC_LVL : FEC1_INTC_LVL)
#define FEC_INTC_PRI(x)     ((x == 0) ? FEC0_INTC_PRI : FEC1_INTC_PRI)
#define GPT0_INTC_LVL       3
#define GPT0_INTC_PRI       0

/*
 * DMA Task Priorities
 */
#define FEC0RX_DMA_PRI      6
#define FEC1RX_DMA_PRI      6
#define FECRX_DMA_PRI(x)    ((x == 0) ? FEC0RX_DMA_PRI : FEC1RX_DMA_PRI)
#define FEC0TX_DMA_PRI      5
#define FEC1TX_DMA_PRI      5
#define FECTX_DMA_PRI(x)    ((x == 0) ? FEC0TX_DMA_PRI : FEC1TX_DMA_PRI)

/*
 * Memory map definitions from linker command files
 */
extern uint8 __FLASH1[];
extern uint8 __FLASH1_SIZE[];
extern uint8 __FLASH0[];
extern uint8 __FLASH0_SIZE[];
extern uint8 __CPLD[];
extern uint8 __CPLD_SIZE[];
extern uint8 __FPGA[];
extern uint8 __FPGA_SIZE[];
extern uint8 __MRAM[];
extern uint8 __MRAM_SIZE[];
extern uint8 __SDRAM[];
extern uint8 __SDRAM_SIZE[];
extern uint8 __SRAM[];
extern uint8 __SRAM_SIZE[];

/*
 * Flash Info
 */
#define STRATA_FLASH_28F128J3D      /*!< Flash1 device */
#define FLASH1_MAX_ACCESS       75  /*!< Flash1 maximum access time */
#define FLASH1_PAGE_MAX_ACCESS  25  /*!< Flash1 page address access time */

#define ATMEL_FLASH_AT49BV040A      /*!< Flash0 device */
#define FLASH0_MAX_ACCESS       90  /*!< Flash0 maximum access time */

/*
 * Memory Map Info
 */
#define FLASH1_ADDRESS      (uint32)__FLASH1     
#define FLASH1_SIZE         (uint32)__FLASH1_SIZE
#define FLASH0_ADDRESS      (uint32)__FLASH0   
#define FLASH0_SIZE         (uint32)__FLASH0_SIZE
#define CPLD_ADDRESS        (uint32)__CPLD
#define CPLD_SIZE           (uint32)__CPLD_SIZE
#define FPGA_ADDRESS        (uint32)__FPGA
#define FPGA_SIZE           (uint32)__FPGA_SIZE
#define MRAM_ADDRESS        (uint32)__MRAM
#define MRAM_SIZE           (uint32)__MRAM_SIZE
#define SDRAM_ADDRESS       (uint32)__SDRAM
#define SDRAM_SIZE          (uint32)__SDRAM_SIZE
#define SRAM_ADDRESS        (uint32)__SRAM
#define SRAM_SIZE           (uint32)__SRAM_SIZE

/*
* SCC TIMER INIT
*/
//#define SCC_TIMER

/********************************************************************/
/*
 * Ethernet Port Info
 */
#define FEC_PHY(x)          ((x == 0) ? 0x0 : 0x1)		//PHY Addresses from M54455EVB schematics sheet 6.
#define FEC_PHY0            FEC_PHY(ETH_PORT)

/*
 *	Interrupt Controller Definitions
 */
#define TIMER_NETWORK_LEVEL		3
#define FEC_LEVEL				4

/*
 *	Timer period info
 */
#if 1
#define HAS_LEDS	1
#else
#undef HAS_LEDS
#endif
/********************************************************************/
/********************************************************************/
/********************************************************************/
#ifdef HAS_LEDS /* { */
static unsigned char LED3=1,LED2=1,LED1=1,LED0=1;

	#define LED0_TOGGLE     CPLD_LEDS = (LED0 & 0x1)?0:1
	#define LED1_TOGGLE     CPLD_LEDS = (LED1 & 0x2)?0:2
	#define LED2_TOGGLE     CPLD_LEDS = (LED2 & 0x4)?0:4
	#define LED3_TOGGLE     CPLD_LEDS = (LED3 & 0x8)?0:8

	#define LED0_ON     	CPLD_LEDS |= 0x01
	#define LED1_ON		    CPLD_LEDS |= 0x02
	#define LED2_ON         CPLD_LEDS |= 0x04
	#define LED3_ON         CPLD_LEDS |= 0x08

	#define LED0_OFF        CPLD_LEDS &= ~0x01
	#define LED1_OFF        CPLD_LEDS &= ~0x02
	#define LED2_OFF        CPLD_LEDS &= ~0x04
	#define LED3_OFF        CPLD_LEDS &= ~0x08

	#define LED_INIT()		Leds_Init()
#else  /* No LEDS  */

	#define LED0_TOGGLE     1
	#define LED1_TOGGLE     1
	#define LED2_TOGGLE     1
	#define LED3_TOGGLE     1

	#define LED0_ON     	1
	#define LED1_ON		    1
	#define LED2_ON         1
	#define LED3_ON         1

	#define LED0_OFF        1
	#define LED1_OFF        1
	#define LED2_OFF        1
	#define LED3_OFF        1

	#define LED_INIT()		Leds_Not()
#endif

/********************************************************************/
/* 
 * CPLD Defines
 */
#define CPLD_VERSION            (*(vuint8 *)(CPLD_ADDRESS+0))
#define CPLD_CONTROL            (*(vuint8 *)(CPLD_ADDRESS+1))
#define CPLD_DDR2ODT            (*(vuint8 *)(CPLD_ADDRESS+2))
#define CPLD_MODE               (*(vuint8 *)(CPLD_ADDRESS+3))
#define CPLD_FLASHCFG           (*(vuint8 *)(CPLD_ADDRESS+4))
#define CPLD_LEDS               (*(vuint8 *)(CPLD_ADDRESS+5))

/* Bit definitions and macros for CPLD_MODE */
#define CPLD_CONTROL_PHY0_PWRDWN    (0x04)
#define CPLD_CONTROL_ATA_DISABLE    (0x02)
#define CPLD_CONTROL_ULPI_RESET     (0x01)

/* Bit definitions and macros for CPLD_MODE */
#define CPLD_MODE_BOOTMOD_MASK      (0x03)
#define CPLD_MODE_BOOTMOD_00        (0x00)
#define CPLD_MODE_BOOTMOD_01        (0x01)
#define CPLD_MODE_BOOTMOD_10        (0x02)
#define CPLD_MODE_BOOTMOD_11        (0x03)
#define CPLD_MODE_FLASH_CS          (0x04)
#define CPLD_MODE_ULPI_RESET        (0x08)
#define CPLD_MODE_ATA_ENABLE        (0x10)
#define CPLD_MODE_PHY0_PWRDWN       (0x20)

/* 
 * FPGA Register Definitions
 */
#define FPGA_IRQEN              (*(vuint32*)(FPGA_ADDRESS+0x00))
#define FPGA_IRQSTATUS          (*(vuint32*)(FPGA_ADDRESS+0x04))
#define FPGA_PCICLKCFG          (*(vuint32*)(FPGA_ADDRESS+0x08))
#define FPGA_IRQROUTE           (*(vuint32*)(FPGA_ADDRESS+0x0C))
#define FPGA_VERSION            (*(vuint32*)(FPGA_ADDRESS+0x10))
#define FPGA_7SEGMENT           (*(vuint32*)(FPGA_ADDRESS+0x14))
#define FPGA_LEDS               (*(vuint32*)(FPGA_ADDRESS+0x18))

/* Bit definitions and macros for FPGA_IRQEN */
#define FPGA_IRQEN_SW7                  (0x00000020)    /* aka FPGA_SW1 */
#define FPGA_IRQEN_SW6                  (0x00000010)    /* aka FPGA_SW0 */
#define FPGA_IRQEN_PCI3                 (0x00000008)    /* PCI Slot 3 */
#define FPGA_IRQEN_PCI2                 (0x00000004)    /* PCI Slot 2 */
#define FPGA_IRQEN_PCI1                 (0x00000002)    /* PCI Slot 1 */
#define FPGA_IRQEN_PCI0                 (0x00000001)    /* PCI Slot 0 */

/* Bit definitions and macros for FPGA_PCICLKCFG */
#define FPGA_PCICLKCFG_M66EN            (0x00000004)    /* read-only */
#define FPGA_PCICLKCFG_CLKGENS2         (0x00000002)    /* read-only */
#define FPGA_PCICLKCFG_CLKGENS2EN       (0x00000001)    /* read-write */

/* Bit definitions and macros for FPGA_IRQSTATUS */
#define FPGA_IRQSTATUS_SW7              (0x00000020)    /* aka FPGA_SW1 */
#define FPGA_IRQSTATUS_SW6              (0x00000010)    /* aka FPGA_SW0 */
#define FPGA_IRQSTATUS_PCI3             (0x00000008)    /* PCI Slot 3 */
#define FPGA_IRQSTATUS_PCI2             (0x00000004)    /* PCI Slot 2 */
#define FPGA_IRQSTATUS_PCI1             (0x00000002)    /* PCI Slot 1 */
#define FPGA_IRQSTATUS_PCI0             (0x00000001)    /* PCI Slot 0 */

/* Bit definitions and macros for FPGA_IRQROUTE */
#define FPGA_IRQROUTE_SW7_IRQ1          (0x00000000)
#define FPGA_IRQROUTE_SW7_IRQ3          (0x00000010)
#define FPGA_IRQROUTE_SW7_IRQ4          (0x00000020)
#define FPGA_IRQROUTE_SW7_IRQ7          (0x00000030)
#define FPGA_IRQROUTE_SW6_IRQ1          (0x00000000)
#define FPGA_IRQROUTE_SW6_IRQ3          (0x00000004)
#define FPGA_IRQROUTE_SW6_IRQ4          (0x00000008)
#define FPGA_IRQROUTE_SW6_IRQ7          (0x0000000C)
#define FPGA_IRQROUTE_PCI_IRQ1          (0x00000000)
#define FPGA_IRQROUTE_PCI_IRQ3          (0x00000001)
#define FPGA_IRQROUTE_PCI_IRQ4          (0x00000002)
#define FPGA_IRQROUTE_PCI_IRQ7          (0x00000003)

/* Bit definitions and macros for FPGA_IRQROUTE */
#define FGPA_VERSION_BUILDWW_MASK       (0xFF000000)
#define FGPA_VERSION_BUILDTYPE_MASK     (0x00FF0000)
#define FGPA_VERSION_MAJOR_MASK         (0x0000FF00)
#define FGPA_VERSION_MINOR_MASK         (0x000000FF)

/********************************************************************/
void Leds_Init();
void Leds_Not();
void board_led_display(uint8 number);
/********************************************************************/
/********************************************************************/
#endif /* _MCF54455_EVB_H */
