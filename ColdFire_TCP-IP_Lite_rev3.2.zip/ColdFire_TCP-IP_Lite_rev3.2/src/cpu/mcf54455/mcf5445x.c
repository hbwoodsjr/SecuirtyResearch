/*
 * File:    mcf5445x.c
 * Purpose: MCF5445x specific routines
 *
 * Notes:
 */

#include "common.h"
#include "clock.h"

extern int d0_reset;
extern int d1_reset;

__interrupt__
void cpu_fault_isr (void);

void board_handle_interrupt(int vector);
/********************************************************************/
/*!
 * \brief   MCF5445x Startup
 * \return  None
 *
 * This is the MCF5445x specific startup routine.  Any processor
 * specific startup code will be contained here.  For the MCF5445x,
 * this functions mainly as a reporting function, printing the following
 * to the default terminal:
 *  - Cause of reset
 *  - Processor name
 *  - Processor revision
 *  - ColdFire core information
 *  - Reset configuration information
 */
void
cpu_startup (void)
{
	/* All masters are trusted */
    MCF_SCM_MPR = 0x77777777;
    
    /* Allow supervisor/user, read/write, and trusted/untrusted
       access to all slaves */
    MCF_SCM_PACRA = 0;
    MCF_SCM_PACRB = 0;
    MCF_SCM_PACRC = 0;
    MCF_SCM_PACRD = 0;
    MCF_SCM_PACRE = 0;
    MCF_SCM_PACRF = 0;
    MCF_SCM_PACRG = 0;

#ifdef DEBUG_PRINT
    /* Determine cause(s) of Reset */
    printf("\n\n");
    if (MCF_RCM_RSR & MCF_RCM_RSR_LOL)
    	printf("Loss of Lock Reset\n");
    if (MCF_RCM_RSR & MCF_RCM_RSR_WDR_CORE)
        printf("Core Watchdog Timer Reset\n");
    if (MCF_RCM_RSR & MCF_RCM_RSR_EXT)
        printf("External Reset\n");
    if (MCF_RCM_RSR & MCF_RCM_RSR_POR)
        printf("Power-on Reset\n");
    if (MCF_RCM_RSR & MCF_RCM_RSR_SOFT)
        printf("Software Reset\n");

    /* Determine which processor we are running on */
    switch (MCF_CCM_CIR & MCF_CCM_CIR_PIN_MASK)
    {
        case MCF_CCM_CIR_PIN_MCF54450:
            printf("MCF54450 ");
            break;
        case MCF_CCM_CIR_PIN_MCF54451:
            printf("MCF54451 ");
            break;
        case MCF_CCM_CIR_PIN_MCF54452:
            printf("MCF54452 ");
            break;
        case MCF_CCM_CIR_PIN_MCF54453:
            printf("MCF54453 ");
            break;
        case MCF_CCM_CIR_PIN_MCF54454:
            printf("MCF54454 ");
            break;
        case MCF_CCM_CIR_PIN_MCF54455:
            printf("MCF54455 ");
            break;
        default:
            printf("Unknown MCF5445x ");
            break;
    }

    /* Determine the processor revision */
    printf(" (rev %d)\n", MCF_CCM_CIR & MCF_CCM_CIR_PRN_MASK);

    /* Report the core integration information */
    mcf5xxx_interpret_d0d1(d0_reset,d1_reset);

    /* Report the chip configuration */
    cpu_interpret_ccr();
#endif
    
    /* Enable Core Fault interrupts */
    MCF_INTC0_ICR62 = MCF_INTC_ICR_IL(7);
    MCF_INTC0_CIMR = MCF_INTC_CIMR_CIMR(62);
    mcf5xxx_set_handler (64 + 62, (ADDRESS) cpu_fault_isr);
    MCF_SCM_CFIER = MCF_SCM_CFIER_ECFEI;
}
/********************************************************************/
void
cpu_handle_interrupt (int vector)
{
    if (vector < 64 || vector > 192)
        return;

    if (vector >= 64 && vector <= 71)
        board_handle_interrupt(vector);
    else
        printf("User Defined Vector #%d\n",vector);
}
/********************************************************************/
/*
 * Pause for the specified number of micro-seconds.
 */
void
cpu_pause(int usecs)
{
    /* Enable the DMA Timer 3 */
    MCF_DTIM3_DTRR = (usecs - 1);
    MCF_DTIM3_DTER = MCF_DTIM_DTER_REF;
    MCF_DTIM3_DTMR = 0
        | MCF_DTIM_DTMR_PS(FBUS_KHZ / 1000)
        | MCF_DTIM_DTMR_ORRI
        | MCF_DTIM_DTMR_FRR
        | MCF_DTIM_DTMR_CLK_DIV1
        | MCF_DTIM_DTMR_RST;

    while ((MCF_DTIM3_DTER & MCF_DTIM_DTER_REF) == 0) 
    {};
    
    /* Disable the timer */
    MCF_DTIM3_DTMR = 0;
}
/********************************************************************/
void
cpu_interpret_ccr (void)
{
    printf("\nReset Configuration:\n");
    printf("--------------------\n");

    if ((MCF_CCM_CIR & MCF_CCM_CIR_PIN_MASK == MCF_CCM_CIR_PIN_MCF54450) ||
        (MCF_CCM_CIR & MCF_CCM_CIR_PIN_MASK == MCF_CCM_CIR_PIN_MCF54451))
    {
        /* This info is for the 256 pin package */
        printf("Flexbus Mode: ");
        switch (MCF_CCM_CCR_256 & MCF_CCM_CCR_256_FBCONFIG_MASK)
        {
            case MCF_CCM_CCR_256_FBCONFIG_NM_32:
                printf("32-bit non-muxed\n");
                break;
            case MCF_CCM_CCR_256_FBCONFIG_NM_16:
                printf("16-bit non-muxed\n");
                break;
            case MCF_CCM_CCR_256_FBCONFIG_NM_8:
                printf("8-bit non-muxed\n");
                break;
            case MCF_CCM_CCR_256_FBCONFIG_M_32:
                printf("32-bit muxed\n");
                break;
            case MCF_CCM_CCR_256_FBCONFIG_M_16:
                printf("16-bit muxed\n");
                break;
            case MCF_CCM_CCR_256_FBCONFIG_M_8:
                printf("8-bit muxed\n");
                break;
        }
        if (MCF_CCM_CCR_256 & MCF_CCM_CCR_256_OSCMODE) {
            printf("Oscillator bypass mode\n");
        }
        else {
            printf("Crystal Oscillator mode\n");
        }
        printf("PLL mode: ");
        if (MCF_CCM_CCR_256 & MCF_CCM_CCR_256_PLLMODE) {
            printf("Limp\n");
        }
        else {
            printf("Normal\n");
            printf("PLL muliplier: ");
            switch (MCF_CCM_CCR_256 & MCF_CCM_CCR_256_PLLMULT3_MASK)
            {
                case MCF_CCM_CCR_256_PLLMULT3_20X:
                    printf("20");
                    break;
                case MCF_CCM_CCR_256_PLLMULT3_10X:
                    printf("10");
                    break;
                case MCF_CCM_CCR_256_PLLMULT3_24X:
                    printf("24");
                    break;
                case MCF_CCM_CCR_256_PLLMULT3_18X:
                    printf("18");
                    break;
                case MCF_CCM_CCR_256_PLLMULT3_12X:
                    printf("12");
                    break;
                case MCF_CCM_CCR_256_PLLMULT3_6X:
                    printf("6");
                    break;
                case MCF_CCM_CCR_256_PLLMULT3_16X:
                    printf("16");
                    break;
                case MCF_CCM_CCR_256_PLLMULT3_8X:
                    printf("8");
                    break;
            }
            printf(" x REF\n");
        }
    }
    if (((MCF_CCM_CIR & MCF_CCM_CIR_PIN_MASK) == MCF_CCM_CIR_PIN_MCF54452) ||
        ((MCF_CCM_CIR & MCF_CCM_CIR_PIN_MASK) == MCF_CCM_CIR_PIN_MCF54453) ||
        ((MCF_CCM_CIR & MCF_CCM_CIR_PIN_MASK) == MCF_CCM_CIR_PIN_MCF54454) ||
        ((MCF_CCM_CIR & MCF_CCM_CIR_PIN_MASK) == MCF_CCM_CIR_PIN_MCF54455))
    {
        /* This info is for the 360 pin package */
        printf("Flexbus Mode: ");
        switch (MCF_CCM_CCR_360 & MCF_CCM_CCR_360_FBCONFIG_MASK)
        {
            case MCF_CCM_CCR_360_FBCONFIG_NM_NP_32:
                printf("32-bit non-muxed\n");
                printf("PCI Disabled\n");
                if (MCF_CCM_CCR_360 & MCF_CCM_CCR_360_OSCMODE)
                    printf("Oscillator bypass mode\n");
                else
                    printf("Crystal Oscillator mode\n");
                break;
            case MCF_CCM_CCR_360_FBCONFIG_NM_NP_16:
                printf("16-bit non-muxed\n");
                printf("PCI Disabled\n");
                if (MCF_CCM_CCR_360 & MCF_CCM_CCR_360_OSCMODE)
                    printf("Oscillator bypass mode\n");
                else
                    printf("Crystal Oscillator mode\n");
                break;
            case MCF_CCM_CCR_360_FBCONFIG_NM_NP_8:
                printf("8-bit non-muxed\n");
                printf("PCI Disabled\n");
                if (MCF_CCM_CCR_360 & MCF_CCM_CCR_360_OSCMODE)
                    printf("Oscillator bypass mode\n");
                else
                    printf("Crystal Oscillator mode\n");
                break;
            case MCF_CCM_CCR_360_FBCONFIG_M_P_16:
                printf("16-bit muxed\n");
                printf("PCI Enabled in ");
                if (MCF_CCM_CCR_360 & MCF_CCM_CCR_360_PCIMODE)
                    printf("Host mode\n");
                else
                    printf("Agent mode\n");
                break;
            case MCF_CCM_CCR_360_FBCONFIG_M_NP_32:
                printf("32-bit non-muxed\n");
                printf("PCI Disabled\n");
                if (MCF_CCM_CCR_360 & MCF_CCM_CCR_360_OSCMODE)
                    printf("Oscillator bypass mode\n");
                else
                    printf("Crystal Oscillator mode\n");
                break;
            case MCF_CCM_CCR_360_FBCONFIG_M_NP_16:
                printf("16-bit muxed\n");
                printf("PCI Disabled\n");
                if (MCF_CCM_CCR_360 & MCF_CCM_CCR_360_OSCMODE)
                    printf("Oscillator bypass mode\n");
                else
                    printf("Crystal Oscillator mode\n");
                break;
            case MCF_CCM_CCR_360_FBCONFIG_M_NP_8:
                printf("8-bit muxed\n");
                printf("PCI Disabled\n");
                if (MCF_CCM_CCR_360 & MCF_CCM_CCR_360_OSCMODE)
                    printf("Oscillator bypass mode\n");
                else
                    printf("Crystal Oscillator mode\n");
                break;
            case MCF_CCM_CCR_360_FBCONFIG_M_P_8:
                printf("8-bit muxed\n");
                printf("PCI Enabled\n");
                if (MCF_CCM_CCR_360 & MCF_CCM_CCR_360_PCIMODE)
                    printf("Host mode\n");
                else
                    printf("Agent mode\n");
                break;
        }
        printf("PLL mode: ");
        if (MCF_CCM_CCR_360 & MCF_CCM_CCR_360_PLLMODE) {
            printf("Limp\n");
        }
        else {
            printf("Normal\n");
            printf("PLL muliplier: ");
            if ((MCF_CCM_CCR_360 & MCF_CCM_CCR_360_FBCONFIG_MASK) 
                    == MCF_CCM_CCR_360_FBCONFIG_M_P_8 ||
                (MCF_CCM_CCR_360 & MCF_CCM_CCR_360_FBCONFIG_MASK) 
                    == MCF_CCM_CCR_360_FBCONFIG_M_P_16)
            {
                switch (MCF_CCM_CCR_360 & MCF_CCM_CCR_360_PLLMULT2_MASK)
                {
                    case MCF_CCM_CCR_360_PLLMULT2_12X:
                        printf("12");
                        break;
                    case MCF_CCM_CCR_360_PLLMULT2_6X:
                        printf("6");
                        break;
                    case MCF_CCM_CCR_360_PLLMULT2_16X:
                        printf("16");
                        break;
                    case MCF_CCM_CCR_360_PLLMULT2_8X:
                        printf("8");
                        break;
                }
            }
            else
            {
                switch (MCF_CCM_CCR_360 & MCF_CCM_CCR_360_PLLMULT3_MASK)
                {
                    case MCF_CCM_CCR_360_PLLMULT3_20X:
                        printf("20");
                        break;
                    case MCF_CCM_CCR_360_PLLMULT3_10X:
                        printf("10");
                        break;
                    case MCF_CCM_CCR_360_PLLMULT3_24X:
                        printf("24");
                        break;
                    case MCF_CCM_CCR_360_PLLMULT3_18X:
                        printf("18");
                        break;
                    case MCF_CCM_CCR_360_PLLMULT3_12X:
                        printf("12");
                        break;
                    case MCF_CCM_CCR_360_PLLMULT3_6X:
                        printf("6");
                        break;
                    case MCF_CCM_CCR_360_PLLMULT3_16X:
                        printf("16");
                        break;
                    case MCF_CCM_CCR_360_PLLMULT3_8X:
                        printf("8");
                        break;
                }
            }
            printf(" x REF\n\n");
        }
    }
}
/********************************************************************/
__interrupt__
void
cpu_fault_isr (void)
{
    /* Clear the interrupt source */
    MCF_SCM_SCMISR = MCF_SCM_SCMISR_CFEI;
    
#ifdef DEBUG_PRINT
    if (MCF_SCM_CFLOC & MCF_SCM_CFLOC_LOC)
        printf("\nCore Fault\n");
    else
        printf("\nInternal Bus Fault\n");
    printf("   address: 0x%08X\n", MCF_SCM_CFADR);
    printf("      data: 0x%08X\n", MCF_SCM_CFDTR);  
    printf("    access: %s\n", (MCF_SCM_CFATR & MCF_SCM_CFATR_WRITE) ? 
                                "write" : "read");
    printf("      size: ");
    switch (MCF_SCM_CFATR & 0x70)
    {
        case 0x00:
            printf("8-bit\n");
            break;
        case 0x10:
            printf("16-bit\n");
            break;
        case 0x20:
            printf("32-bit\n");
            break;
        default:
            printf("reserved\n");
            break;
    }
    printf(" cacheable: %s\n", (MCF_SCM_CFATR & MCF_SCM_CFATR_CACHE) ? 
                                "yes" : "no");
    printf("      mode: %s\n", (MCF_SCM_CFATR & MCF_SCM_CFATR_MODE) ? 
                                "supervisor" : "user");
    printf("      type: %s\n", (MCF_SCM_CFATR & MCF_SCM_CFATR_TYPE) ? 
                                "data" : "instruction");
#endif
}

/********************************************************************/
void
board_handle_interrupt(int vector)
{
    switch (vector)
    {
        case 68: /* Eport Interrupt 4 */
            printf("SW1\n");
            MCF_EPORT_EPFR = (uint8)(0x01 << 4);
            break;
        case 69: /* Eport Interrupt 5 */
            printf("SW2\n");
            MCF_EPORT_EPFR = (uint8)(0x01 << 5);
            break;
        case 71: /* Eport Interrupt 7 */
            printf("ABORT\n");
            MCF_EPORT_EPFR = (uint8)(0x01 << 7);
            break;
        case 65: /* Eport Interrupt 1 */
        case 66: /* Eport Interrupt 2 */
        case 67: /* Eport Interrupt 3 */
        case 70: /* Eport Interrupt 6 */
        default:
            MCF_EPORT_EPFR = (uint8)(0x01 << (vector - 64));
            printf("Edge Port Interrupt #%d\n",vector - 64);
            break;
    }
}

/********************************************************************/
//processor specific FEC ICR initialization
void 
FEC_ICR_init(void)		
{
	uint32 i;
	
   for (i = 0; i < 12; i++)
   {
#if (ETH_PORT == 0)		/* Set up FEC interrupts (vectors 36 through 48) */
	  MCF_INTC0_ICR(36+i) = MCF_INTC_ICR_IL(6);
#else					/* Set up FEC interrupts (vectors 49 through 61) */
	  MCF_INTC0_ICR(49+i) = MCF_INTC_ICR_IL(6);
#endif
   }
	
}

/********************************************************************/
//FSL configure the FEC IMRs in processor specific file
void 
FEC_IMR_init()			
{						//FSL configure the FEC0 IMRs in processor specific file
#if (ETH_PORT == 0)
	MCF_INTC0_IMRH &= 	~(MCF_INTC_IPRH_INT36); // TXF
	MCF_INTC0_IMRH &= 	~(MCF_INTC_IPRH_INT37); // TXB
	MCF_INTC0_IMRH &= 	~(MCF_INTC_IPRH_INT40); // RXF
	MCF_INTC0_IMRH &= 	~(MCF_INTC_IPRH_INT42); // MII	

#else					//FSL configure the FEC1 IMRs in processor specific file
	MCF_INTC0_IMRH &= 	~(MCF_INTC_IPRH_INT49); // TXF
	MCF_INTC0_IMRH &= 	~(MCF_INTC_IPRH_INT50); // TXB
	MCF_INTC0_IMRH &= 	~(MCF_INTC_IPRH_INT53); // RXF
	MCF_INTC0_IMRH &= 	~(MCF_INTC_IPRH_INT55); // MII	

#endif
}

/********************************************************************/
//FSL configure the UART0 ICR and enable associtate IMR
void 
processor_UART_ICR_init(int dev)	
{
  if(dev == 0)
  {
	  MCF_INTC0_ICR26 = MCF_INTC_ICR_IL(2);
	  MCF_INTC0_IMRL &= ~(MCF_INTC_IMRL_INT_MASK26);
  }
  else
  {
	  MCF_INTC0_ICR27 = MCF_INTC_ICR_IL(2);
	  MCF_INTC0_IMRL &= ~(MCF_INTC_IMRL_INT_MASK27);
  }
	
}

/********************************************************************/	
//FSL processor specific PIT config for 1 msec interrupt
//FSL This equates to the PIT1_INTS_PER_SEC #define value
//FSL Therefore PIT1_INTS_PER_SEC = 1 / 1 msec = 1000
//FSL If we change the PIT interrupt time, the following #define must
//FSL be updated accordingly:
//FSL #define PIT1_INTS_PER_SEC 	1000
//FSL ex1 (default): with PCSR=0, PMR=30000 then 
//FSL		PIT1_INTS_PER_SEC=1000
//FSL ex2: with PCSR=0, PMR=15000 then
//FSL		PIT1_INTS_PER_SEC=2000
//FSL Added default_PMR macro to enable changing PIT rate

//FSL void PIT_Timer_Init(uint8 PCSR, uint16 PMR)
#define default_PMR	30000					//FSL default setting is 30000
#define new_PMR		(30000000/default_PMR)
//FSL improvement: make macros based off Fsys
void 
processor_PIT_Timer_Init()	
{

   PIT_Timer_Init(0,default_PMR);	//FSL (30000/((sys_clk/2)/2^0))) = 1msec PIT interrupt @60MHz core
//   PIT_Timer_Init(0,6000);	//FSL (30000/((sys_clk/2)/2^0))) = 1msec PIT interrupt @60MHz core
									//FSL setting this to 15000 doubles the TCP client bandwidth performance test.
}

/********************************************************************/	
/*
 * Setup PIT Timer
 */
void 
PIT_Timer_Init(uint8 PCSR, uint16 PMR)
{

	/* Set tic for timers	*/

	MCF_PIT0_PCSR  = (uint16)(MCF_PIT_PCSR_PRE(PCSR));	/* Divide system clock/2 by 2^PCSR	*/
	MCF_INTC1_ICR43 = MCF_INTC_ICR_IL(TIMER_NETWORK_LEVEL);
	MCF_INTC1_IMRH &= ~MCF_INTC_IMRH_INT_MASK43;
	MCF_PIT0_PMR = PMR;						/* modulo count	*/
	MCF_PIT0_PCSR |= MCF_PIT_PCSR_DBG | MCF_PIT_PCSR_OVW | 
					 MCF_PIT_PCSR_PIE | MCF_PIT_PCSR_PIF | 
					 MCF_PIT_PCSR_RLD | MCF_PIT_PCSR_EN;
}

/********************************************************************/	
/* FUNCTION: clock_c()
 * 
 * Disable timer interrupts
 *
 * PARAM1: none
 *
 * RETURNS: none
 */

void
clock_c()
{
   MCF_PIT_PCSR(0) &= ~( MCF_PIT_PCSR_PIE | MCF_PIT_PCSR_EN );

   printf("clock_c: disabling timer interrupts\n");
}

