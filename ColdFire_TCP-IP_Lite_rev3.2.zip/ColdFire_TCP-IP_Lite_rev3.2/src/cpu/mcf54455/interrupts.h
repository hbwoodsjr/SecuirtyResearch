/*
 * File:    interrupts.h
 * Purpose:     
 *
 * Notes:
 */

#ifndef _FILE_H_
#define _FILE_H_

/********************************************************************/

/*
 * Interrupt levels and priorities
 */

/* Level 7 */

/* Level 6 */

/* Level 5 */
#define INTC_LVL_FEC0       5
#define INTC_LVL_FEC1       5
#define INTC_LVL_FEC(x)     ((x == 0) ? INTC_LVL_FEC0 : INTC_LVL_FEC1)


/* Level 4 */

/* Level 3 */

/* Level 2 */

/* Level 1 */

/* Level 0 - Disabled */



/********************************************************************/

#endif /* _FILE_H_ */
