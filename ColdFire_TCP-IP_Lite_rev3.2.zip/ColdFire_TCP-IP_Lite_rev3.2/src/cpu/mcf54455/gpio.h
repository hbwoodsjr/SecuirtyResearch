/*
 * File:    gpio.h
 * Purpose:     
 *
 * Notes:
 */

#ifndef _GPIO_H_
#define _GPIO_H_

/********************************************************************/

#define GPIO_FEC0_7WIRE     0
#define GPIO_FEC0_MII       1
#define GPIO_FEC0_RMII      2
#define GPIO_FEC1_7WIRE     3
#define GPIO_FEC1_MII       4
#define GPIO_FEC1_RMII      5

/********************************************************************/

#endif /* _GPIO_H_ */
