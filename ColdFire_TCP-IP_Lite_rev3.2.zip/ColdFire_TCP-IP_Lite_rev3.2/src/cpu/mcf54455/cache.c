/*! 
 * \file    cache.c
 * \brief   Simple driver for the V4 cache controller
 * \version $Revision: 1.2 $
 * \author  Michael Norman
 *
 * Driver for the ColdFire V4 cache controller.
 *
 */

#include "common.h"
#include "cache.h"

/*! Local copy of write-only cache registers */
uint32 cacr = 0;
uint32 acr[4] = {0, 0, 0, 0};

/********************************************************************/
/*!
 * \brief   Initialize Cache
 * \param   settings    Cache settings
 * \return  0 is parameters were acceptable; 1 otherwise
 *
 * This routine allows the global cache setting to be modified. This
 * routine should be used to enable global flags such as enabling/disabling
 * the store buffers, cache-locking, etc.
 *
 * \warning The settings parameter will be ORed in with the CACR unmodified.  
 */
int
cpu_cache_init (int settings)
{
    /* Save off these settings in the local copy of CACR; preserve
     * the instruction and data cache enable and mode settings */
    cacr &= 0x86088400;
    cacr |= settings;
    
    /* Write the CACR with the updated settings */
    mcf5xxx_wr_cacr(cacr);
    
    /* Remove any invalidate-all bits from the local copy */
    cacr &= ~(0
        | MCF5XXX_CACR_ICINVA
        | MCF5XXX_CACR_DCINVA);
    return(0);		//FSL added
}
/********************************************************************/
/*!
 * \brief   Enable Instruction Cache
 * \param   addr    Start address of the region to cache
 * \param   size    Size of the region to cache
 * \return  0 is parameters were acceptable; 1 otherwise
 *
 * This routine will enable the instruction cache for the specified
 * region.  If both the addr and size parameters are 0x0 (NULL), then
 * the instruction cache will be enabled globally (in the CACR).
 */
int
cpu_icache_enable (uint32 addr, uint32 size)
{
    int a;
    
    /* Check for valid parameters */
    if (((acr[2] != 0) && (acr[3] != 0)) || (size < (1 * 1024 * 1024)))
        return 1;
        
    /* Check for global enable request */
    if ((addr == 0) && (size == 0))
    {
        /* Enable i-cache with default as cacheable */
        cacr |= MCF5XXX_CACR_IEC;
        mcf5xxx_wr_cacr(cacr | MCF5XXX_CACR_ICINVA);
        return 0;
    }
    
    /* Determine which ACR (2 or 3) to use */
    if (acr[2] == 0 && acr[3] == 0)
    {
        mcf5xxx_wr_cacr(cacr | MCF5XXX_CACR_ICINVA);
        a = 2;
    }
    else
    {
        a = 3;
    }
    
    /* Enable i-cache with default as non-cacheable */
    cacr = cacr
        | MCF5XXX_CACR_IEC 
        | MCF5XXX_CACR_IDCM;
        
    if (size < (16 * 1024 * 124))
    {
        /* Use 1-16MB masking option */
        acr[a] = 0
            | MCF5XXX_ACR_AB(addr)
            | MCF5XXX_ACR_AM(size - 1)
//            | MCF5XXX_ACR_AMM			//FSL 1-16MB masking option
            | MCF5XXX_ACR_EN
            | MCF5XXX_ACR_SM_IGNORE
            | MCF5XXX_ACR_CM;
    }
    else
    {   
        /* Use 16MB-2GB masking option */
        acr[a] = 0
            | MCF5XXX_ACR_AB(addr)
            | MCF5XXX_ACR_AM(size - 1)
            | MCF5XXX_ACR_EN
            | MCF5XXX_ACR_SM_IGNORE
            | MCF5XXX_ACR_CM;
    }
     
    if (a == 2)
        mcf5xxx_wr_acr2(acr[2]);
    else
        mcf5xxx_wr_acr3(acr[3]);
    
    mcf5xxx_wr_cacr(cacr);   
    return(0);		//FSL added    
}
/********************************************************************/
/*!
 * \brief   Disable Instruction Cache
 * \return  none
 *
 * This routine will disable the instruction cache.
 */
void
cpu_icache_disable (void)
{
    cacr &= ~(MCF5XXX_CACR_IEC | MCF5XXX_CACR_IDCM);
    acr[2] = acr[3] = 0;
    
    mcf5xxx_wr_acr2(0);
    mcf5xxx_wr_acr3(0);
    mcf5xxx_wr_cacr(cacr);
}
/********************************************************************/
/*!
 * \brief   Enable Branch Cache
 * \return  none
 *
 * This routine will enable the branch prediction cache.
 */
void
cpu_bcache_enable (void)
{
    cacr |= MCF5XXX_CACR_BEC;
    mcf5xxx_wr_cacr(cacr | MCF5XXX_CACR_BCINVA);
}
/********************************************************************/
/*!
 * \brief   Disable Branch Cache
 * \return  none
 *
 * This routine will disable the branch prediction cache.
 */
void
cpu_bcache_disable (void)
{
    cacr &= ~MCF5XXX_CACR_BEC;
    mcf5xxx_wr_cacr(cacr | MCF5XXX_CACR_BCINVA);
}
/********************************************************************/
/*!
 * \brief   Enable Data Cache
 * \param   addr    Start address of the region to cache
 * \param   size    Size of the region to cache
 * \param   mode    Cache-mode
 * \return  0 is parameters were acceptable; 1 otherwise
 *
 * This routine will enable the data cache for the specified
 * region.  If both the addr and size parameters are 0x0 (NULL), then
 * the data cache will be enabled globally (in the CACR).
 * 
 * \warning The mode parameter will be ORed in with the ACR unmodified.  
 *          This must be a valid encoding for the ACR[CM] field.
 */
int
cpu_dcache_enable (uint32 addr, uint32 size, int mode)
{
    int a;
    
    /* Check for valid parameters */
    if (((acr[0] != 0) && (acr[1] != 0)) || (size < (1 * 1024 * 1024)))
        return 1;
        
    /* Check for global enable request */
    if ((addr == 0) && (size == 0))
    {
        /* Enable d-cache with default as cacheable */
        cacr |= MCF5XXX_CACR_DEC;
        mcf5xxx_wr_cacr(cacr | MCF5XXX_CACR_DCINVA);
        return 0;
    }
    
    /* Determine which ACR (0 or 1) to use */
    if (acr[0] == 0 && acr[1] == 0)
    {
        mcf5xxx_wr_cacr(cacr | MCF5XXX_CACR_DCINVA);
        a = 0;
    }
    else
    {
        a = 1;
    }
    
    /* Enable d-cache with default as non-cacheable */
    cacr = cacr
        | MCF5XXX_CACR_DEC 
        | MCF5XXX_CACR_DDCM_II;
        
    if (size < (16 * 1024 * 124))
    {
        /* Use 1-16MB masking option */
        acr[a] = 0
            | MCF5XXX_ACR_AB(addr)
            | MCF5XXX_ACR_AM(size - 1)
//            | MCF5XXX_ACR_AMM			//FSL 1-16MB masking option
            | MCF5XXX_ACR_EN
            | MCF5XXX_ACR_SM_IGNORE
            | mode;
    }
    else
    {   
        /* Use 16MB-2GB masking option */
        acr[a] = 0
            | MCF5XXX_ACR_AB(addr)
            | MCF5XXX_ACR_AM(size - 1)
            | MCF5XXX_ACR_EN
            | MCF5XXX_ACR_SM_IGNORE
            | mode;
    }
     
    if (a == 0)
        mcf5xxx_wr_acr0(acr[0]);
    else
        mcf5xxx_wr_acr1(acr[1]);
    
    mcf5xxx_wr_cacr(cacr);    
    return(0);		//FSL added           
}
/********************************************************************/
/*!
 * \brief   Disable Data Cache
 * \return  none
 *
 * This routine will disable the data cache.
 */
void
cpu_dcache_disable (void)
{
    cacr &= ~(MCF5XXX_CACR_DEC | MCF5XXX_CACR_DDCM_II);
    acr[0] = acr[1] = 0;
    
    mcf5xxx_wr_acr0(0);
    mcf5xxx_wr_acr1(0);
    mcf5xxx_wr_cacr(cacr);
}
/********************************************************************/
