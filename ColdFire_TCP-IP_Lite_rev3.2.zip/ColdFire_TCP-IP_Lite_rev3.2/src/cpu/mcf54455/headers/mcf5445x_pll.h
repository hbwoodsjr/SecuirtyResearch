/*
 * File:    mcf5445x_pll.h
 * Purpose: Register and bit definitions
 */

#ifndef __MCF5445X_PLL_H__
#define __MCF5445X_PLL_H__

/*********************************************************************
*
* Phase Locked Loop (PLL)
*
*********************************************************************/

/* Register read/write macros */
#define MCF_PLL_PCR             (*(vuint32*)(0xFC0C4000))   /* PLL Control Register */
#define MCF_PLL_PSR             (*(vuint32*)(0xFC0C4004))   /* PLL Status Register */

/* Bit definitions and macros for PCR */
#define MCF_PLL_PCR_OUTDIV1(x)      (((x)&0x0000000F))      /* Output divider for CPU clock frequency */
#define MCF_PLL_PCR_OUTDIV2(x)      (((x)&0x0000000F)<<4)   /* Output divider for internal bus clock frequency */
#define MCF_PLL_PCR_OUTDIV3(x)      (((x)&0x0000000F)<<8)   /* Output divider for Flexbus clock frequency */
#define MCF_PLL_PCR_OUTDIV4(x)      (((x)&0x0000000F)<<12)  /* Output divider for PCI clock frequency */
#define MCF_PLL_PCR_OUTDIV5(x)      (((x)&0x0000000F)<<16)  /* Output divider for USB clock frequency */
#define MCF_PLL_PCR_PFDR(x)         (((x)&0x000000FF)<<24)  /* Feedback divider for VCO frequency */
#define MCF_PLL_PCR_PFDR_MASK       (0xFF000000)            
#define MCF_PLL_PCR_OUTDIV5_MASK    (0x000F0000)            
#define MCF_PLL_PCR_OUTDIV4_MASK    (0x0000F000)            
#define MCF_PLL_PCR_OUTDIV3_MASK    (0x00000F00)            
#define MCF_PLL_PCR_OUTDIV2_MASK    (0x000000F0)            
#define MCF_PLL_PCR_OUTDIV1_MASK    (0x0000000F)            

/* Bit definitions and macros for PSR */
#define MCF_PLL_PSR_LOCKS       (0x00000001)    /* PLL lost lock - sticky */
#define MCF_PLL_PSR_LOCK        (0x00000002)    /* PLL lock status */
#define MCF_PLL_PSR_LOLIRQ      (0x00000004)    /* PLL loss-of-lock interrupt enable */
#define MCF_PLL_PSR_LOLRE       (0x00000008)    /* PLL loss-of-lock reset enable */
#define MCF_PLL_PSR_LOLDIS      (0x00000010)    /* PLL loss-of-lock disable */

/********************************************************************/

#endif /* __MCF5445X_PLL_H__ */
