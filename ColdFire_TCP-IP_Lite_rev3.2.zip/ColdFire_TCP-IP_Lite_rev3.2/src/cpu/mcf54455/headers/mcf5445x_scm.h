/*
 * File:    mcf5445x_scm.h
 * Purpose: Register and bit definitions
 */

#ifndef __MCF5445X_SCM_H__
#define __MCF5445X_SCM_H__

/*********************************************************************
*
* System Control Module (SCM)
*
*********************************************************************/

/* Register read/write macros */
#define MCF_SCM_MPR             (*(vuint32*)(0xFC000000))   /* Master Privilege Register */
#define MCF_SCM_PACRA           (*(vuint32*)(0xFC000020))   /* Peripheral Access Control Register A */
#define MCF_SCM_PACRB           (*(vuint32*)(0xFC000024))   /* Peripheral Access Control Register B */
#define MCF_SCM_PACRC           (*(vuint32*)(0xFC000028))   /* Peripheral Access Control Register C */
#define MCF_SCM_PACRD           (*(vuint32*)(0xFC00002C))   /* Peripheral Access Control Register D */
#define MCF_SCM_PACRE           (*(vuint32*)(0xFC000040))   /* Peripheral Access Control Register E */
#define MCF_SCM_PACRF           (*(vuint32*)(0xFC000044))   /* Peripheral Access Control Register F */
#define MCF_SCM_PACRG           (*(vuint32*)(0xFC000048))   /* Peripheral Access Control Register G */
#define MCF_SCM_CWCR            (*(vuint16*)(0xFC040016))   /* Core Watchdog Control Register */
#define MCF_SCM_CWSR            (*(vuint8 *)(0xFC04001B))   
#define MCF_SCM_SCMISR          (*(vuint8 *)(0xFC04001F))   
#define MCF_SCM_BCR             (*(vuint32*)(0xFC040024))   
#define MCF_SCM_CFADR           (*(vuint32*)(0xFC040070))   
#define MCF_SCM_CFIER           (*(vuint8 *)(0xFC040075))   
#define MCF_SCM_CFLOC           (*(vuint8 *)(0xFC040076))   
#define MCF_SCM_CFATR           (*(vuint8 *)(0xFC040077))   
#define MCF_SCM_CFDTR           (*(vuint32*)(0xFC04007C))   

/* Bit definitions and macros for MPR */
#define MCF_SCM_MPR_MPROT6(x)   (((x)&0x0000000F)<<4)   /* USB Controller */
#define MCF_SCM_MPR_MPROT5(x)   (((x)&0x0000000F)<<8)   /* PCI Controller */
#define MCF_SCM_MPR_MPROT3(x)   (((x)&0x0000000F)<<16)  /* FEC1 */
#define MCF_SCM_MPR_MPROT2(x)   (((x)&0x0000000F)<<20)  /* FEC0 */
#define MCF_SCM_MPR_MPROT1(x)   (((x)&0x0000000F)<<24)  /* eDMA Controller */
#define MCF_SCM_MPR_MPROT0(x)   (((x)&0x0000000F)<<28)  /* ColdFire Core */
#define MCF_SCM_MPR_MPROT_MTR   (0x4)                   
#define MCF_SCM_MPR_MPROT_MTW   (0x2)                   
#define MCF_SCM_MPR_MPROT_MPL   (0x1)                   

/* Bit definitions and macros for PACRA */
#define MCF_SCM_PACRA_PACR2(x)      (((x)&0x0000000F)<<20)  /* Flexbus */
#define MCF_SCM_PACRA_PACR1(x)      (((x)&0x0000000F)<<24)  /* Cross-bar Switch */
#define MCF_SCM_PACRA_PACR0(x)      (((x)&0x0000000F)<<28)  /* SCM (MPR & PACRs) */
#define MCF_SCM_PACRA_PACR_SP       (0x4)                   
#define MCF_SCM_PACRA_PACR_WP       (0x2)                   
#define MCF_SCM_PACRA_PACR_TP       (0x1)                   

/* Bit definitions and macros for PACRB */
#define MCF_SCM_PACRB_PACR15(x)     (((x)&0x0000000F))      /* Real-Time Clock */
#define MCF_SCM_PACRB_PACR13(x)     (((x)&0x0000000F)<<8)   /* FEC1 */
#define MCF_SCM_PACRB_PACR12(x)     (((x)&0x0000000F)<<12)  /* FEC0 */
#define MCF_SCM_PACRB_PACR_SP       (0x4)                   
#define MCF_SCM_PACRB_PACR_WP       (0x2)                   
#define MCF_SCM_PACRB_PACR_TP       (0x1)                   

/* Bit definitions and macros for PACRC */
#define MCF_SCM_PACRC_PACR23(x)     (((x)&0x0000000F))      /* DSPI */
#define MCF_SCM_PACRC_PACR22(x)     (((x)&0x0000000F)<<4)   /* I2C */
#define MCF_SCM_PACRC_PACR21(x)     (((x)&0x0000000F)<<8)   /* Interrupt Controller IACK */
#define MCF_SCM_PACRC_PACR19(x)     (((x)&0x0000000F)<<16)  /* Interrupt Controller 1 */
#define MCF_SCM_PACRC_PACR18(x)     (((x)&0x0000000F)<<20)  /* Interrupt Controller 0 */
#define MCF_SCM_PACRC_PACR17(x)     (((x)&0x0000000F)<<24)  /* eDMA Controller */
#define MCF_SCM_PACRC_PACR16(x)     (((x)&0x0000000F)<<28)  /* SCM (CWT & Core Fault Registers */
#define MCF_SCM_PACRC_PACR_SP       (0x4)                   
#define MCF_SCM_PACRC_PACR_WP       (0x2)                   
#define MCF_SCM_PACRC_PACR_TP       (0x1)                   

/* Bit definitions and macros for PACRD */
#define MCF_SCM_PACRD_PACR31(x)     (((x)&0x0000000F))      /* DMA Timer 3 */
#define MCF_SCM_PACRD_PACR30(x)     (((x)&0x0000000F)<<4)   /* DMA Timer 2 */
#define MCF_SCM_PACRD_PACR29(x)     (((x)&0x0000000F)<<8)   /* DMA Timer 1 */
#define MCF_SCM_PACRD_PACR28(x)     (((x)&0x0000000F)<<12)  /* DMA Timer 0 */
#define MCF_SCM_PACRD_PACR26(x)     (((x)&0x0000000F)<<20)  /* UART2 */
#define MCF_SCM_PACRD_PACR25(x)     (((x)&0x0000000F)<<24)  /* UART1 */
#define MCF_SCM_PACRD_PACR24(x)     (((x)&0x0000000F)<<28)  /* UART0 */
#define MCF_SCM_PACRD_PACR_SP       (0x4)                   
#define MCF_SCM_PACRD_PACR_WP       (0x2)                   
#define MCF_SCM_PACRD_PACR_TP       (0x1)                   

/* Bit definitions and macros for PACRE */
#define MCF_SCM_PACRE_PACR37(x)     (((x)&0x0000000F)<<8)   /* Edge Port */
#define MCF_SCM_PACRE_PACR35(x)     (((x)&0x0000000F)<<16)  /* PIT 3 */
#define MCF_SCM_PACRE_PACR34(x)     (((x)&0x0000000F)<<20)  /* PIT 2 */
#define MCF_SCM_PACRE_PACR33(x)     (((x)&0x0000000F)<<24)  /* PIT 1 */
#define MCF_SCM_PACRE_PACR32(x)     (((x)&0x0000000F)<<28)  /* PIT 0 */
#define MCF_SCM_PACRE_PACR_SP       (0x4)                   
#define MCF_SCM_PACRE_PACR_WP       (0x2)                   
#define MCF_SCM_PACRE_PACR_TP       (0x1)                   

/* Bit definitions and macros for PACRF */
#define MCF_SCM_PACRF_PACR47(x)     (((x)&0x0000000F))      /* SSI */
#define MCF_SCM_PACRF_PACR46(x)     (((x)&0x0000000F)<<4)   /* SDRAM Controller */
#define MCF_SCM_PACRF_PACR45(x)     (((x)&0x0000000F)<<8)   /* RNG */
#define MCF_SCM_PACRF_PACR44(x)     (((x)&0x0000000F)<<12)  /* USB Controller */
#define MCF_SCM_PACRF_PACR43(x)     (((x)&0x0000000F)<<16)  /* PCI Arbiter */
#define MCF_SCM_PACRF_PACR42(x)     (((x)&0x0000000F)<<20)  /* PCI Controller */
#define MCF_SCM_PACRF_PACR41(x)     (((x)&0x0000000F)<<24)  /* GPIO Module */
#define MCF_SCM_PACRF_PACR40(x)     (((x)&0x0000000F)<<28)  /* CCM, Reset Controller, Power Management */
#define MCF_SCM_PACRF_PACR_SP       (0x4)                   
#define MCF_SCM_PACRF_PACR_WP       (0x2)                   
#define MCF_SCM_PACRF_PACR_TP       (0x1)                   

/* Bit definitions and macros for PACRG */
#define MCF_SCM_PACRG_PACR49(x)     (((x)&0x0000000F)<<24)  /* PLL */
#define MCF_SCM_PACRG_PACR48(x)     (((x)&0x0000000F)<<28)  /* ATA Controller */
#define MCF_SCM_PACRG_PACR_SP       (0x4)                   
#define MCF_SCM_PACRG_PACR_WP       (0x2)                   
#define MCF_SCM_PACRG_PACR_TP       (0x1)                   

/* Bit definitions and macros for CWCR */
#define MCF_SCM_CWCR_CWT(x)                 (((x)&0x001F))      /* Core Watchdog timeout period */
#define MCF_SCM_CWCR_CWRI(x)                (((x)&0x0003)<<5)   /* Core Watchdog reset/interrupt */
#define MCF_SCM_CWCR_CWE                    (0x0080)            /* Core Watchdog timer enable */
#define MCF_SCM_CWCR_CWRWH                  (0x0100)            /* Core Watchdog run while halt */
#define MCF_SCM_CWCR_RO                     (0x8000)            /* Read-only control bit */
#define MCF_SCM_CWCR_CWRI_INT               (0x0000)            
#define MCF_SCM_CWCR_CWRI_INT_THEN_RESET    (0x0020)            
#define MCF_SCM_CWCR_CWRI_RESET             (0x0040)            
#define MCF_SCM_CWCR_CWRI_WINDOW            (0x0060)            

/* Bit definitions and macros for CWSR */
#define MCF_SCM_CWSR_CWSR(x)    (x)     

/* Bit definitions and macros for SCMISR */
#define MCF_SCM_SCMISR_CWIC     (0x01)  
#define MCF_SCM_SCMISR_CFEI     (0x02)  

/* Bit definitions and macros for BCR */
#define MCF_SCM_BCR_S1          (0x00000002)    
#define MCF_SCM_BCR_S4          (0x00000010)    
#define MCF_SCM_BCR_S6          (0x00000040)    
#define MCF_SCM_BCR_S7          (0x00000080)    
#define MCF_SCM_BCR_GBW         (0x00000100)    
#define MCF_SCM_BCR_GBR         (0x00000200)    

/* Bit definitions and macros for CFADR */
#define MCF_SCM_CFADR_ADDR(x)   (x)     

/* Bit definitions and macros for CFIER */
#define MCF_SCM_CFIER_ECFEI     (0x01)  

/* Bit definitions and macros for CFLOC */
#define MCF_SCM_CFLOC_LOC       (0x80)  

/* Bit definitions and macros for CFATR */
#define MCF_SCM_CFATR_TYPE      (0x01)              
#define MCF_SCM_CFATR_MODE      (0x02)              
#define MCF_SCM_CFATR_CACHE     (0x08)              
#define MCF_SCM_CFATR_SIZE(x)   (((x)&0x07)<<4)     
#define MCF_SCM_CFATR_WRITE     (0x80)              

/* Bit definitions and macros for CFDTR */
#define MCF_SCM_CFDTR_CFDTR(x)      (x)     

/********************************************************************/

#endif /* __MCF5445X_SCM_H__ */
