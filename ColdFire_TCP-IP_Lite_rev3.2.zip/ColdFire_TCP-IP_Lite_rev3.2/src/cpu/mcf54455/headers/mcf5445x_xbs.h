/*
 * File:    mcf5445x_xbs.h
 * Purpose: Register and bit definitions
 */

#ifndef __MCF5445X_XBS_H__
#define __MCF5445X_XBS_H__

/*********************************************************************
*
* Cross-bar switch (XBS)
*
*********************************************************************/

/* Register read/write macros */
#define MCF_XBS_PRS1            (*(vuint32*)(0xFC004100))   /* XBS Priority Register */
#define MCF_XBS_CRS1            (*(vuint32*)(0xFC004110))   /* XBS Control Register */
#define MCF_XBS_PRS2            (*(vuint32*)(0xFC004200))   /* XBS Priority Register */
#define MCF_XBS_CRS2            (*(vuint32*)(0xFC004210))   /* XBS Control Register */
#define MCF_XBS_PRS3            (*(vuint32*)(0xFC004300))   /* XBS Priority Register */
#define MCF_XBS_CRS3            (*(vuint32*)(0xFC004310))   /* XBS Control Register */
#define MCF_XBS_PRS4            (*(vuint32*)(0xFC004400))   /* XBS Priority Register */
#define MCF_XBS_CRS4            (*(vuint32*)(0xFC004410))   /* XBS Control Register */
#define MCF_XBS_PRS5            (*(vuint32*)(0xFC004500))   /* XBS Priority Register */
#define MCF_XBS_CRS5            (*(vuint32*)(0xFC004510))   /* XBS Control Register */
#define MCF_XBS_PRS6            (*(vuint32*)(0xFC004600))   /* XBS Priority Register */
#define MCF_XBS_CRS6            (*(vuint32*)(0xFC004610))   /* XBS Control Register */
#define MCF_XBS_PRS7            (*(vuint32*)(0xFC004700))   /* XBS Priority Register */
#define MCF_XBS_CRS7            (*(vuint32*)(0xFC004710))   /* XBS Control Register */

/* Parameterized register read/write macros for multiple registers */
#define MCF_XBS_PRS(x)          (*(vuint32*)(0xFC004100 + ((x-1)*0x100)))   /* XBS Priority Register */
#define MCF_XBS_CRS(x)          (*(vuint32*)(0xFC004110 + ((x-1)*0x100)))   /* XBS Control Register */

/* Bit definitions and macros for PRS group */
#define MCF_XBS_PRS_M0(x)       (((x)&0x00000007))      /* Master 0 (ColdFire core) priority */
#define MCF_XBS_PRS_M1(x)       (((x)&0x00000007)<<4)   /* Master 1 (eDMA) priority */
#define MCF_XBS_PRS_M2(x)       (((x)&0x00000007)<<8)   /* Master 2 (FEC0) priority */
#define MCF_XBS_PRS_M3(x)       (((x)&0x00000007)<<12)  /* Master 3 (FEC1) priority */
#define MCF_XBS_PRS_M5(x)       (((x)&0x00000007)<<20)  /* Master 5 (PCI controller) priority */
#define MCF_XBS_PRS_M6(x)       (((x)&0x00000007)<<24)  /* Master 6 (USB OTG) priority */
#define MCF_XBS_PRS_M7(x)       (((x)&0x00000007)<<28)  /* Master 7 (Serial Boot) priority */

/* Bit definitions and macros for PRS1 */
#define MCF_XBS_PRS1_M0(x)      (((x)&0x00000007))      /* Master 0 (ColdFire core) priority */
#define MCF_XBS_PRS1_M1(x)      (((x)&0x00000007)<<4)   /* Master 1 (eDMA) priority */
#define MCF_XBS_PRS1_M2(x)      (((x)&0x00000007)<<8)   /* Master 2 (FEC0) priority */
#define MCF_XBS_PRS1_M3(x)      (((x)&0x00000007)<<12)  /* Master 3 (FEC1) priority */
#define MCF_XBS_PRS1_M5(x)      (((x)&0x00000007)<<20)  /* Master 5 (PCI controller) priority */
#define MCF_XBS_PRS1_M6(x)      (((x)&0x00000007)<<24)  /* Master 6 (USB OTG) priority */
#define MCF_XBS_PRS1_M7(x)      (((x)&0x00000007)<<28)  /* Master 7 (Serial Boot) priority */

/* Bit definitions and macros for CRS group */
#define MCF_XBS_CRS_PARK(x)             (((x)&0x00000007))      /* Master parking control */
#define MCF_XBS_CRS_PCTL(x)             (((x)&0x00000003)<<4)   /* Parking mode control */
#define MCF_XBS_CRS_ARB                 (0x00000100)            /* Arbitration Mode */
#define MCF_XBS_CRS_RO                  (0x80000000)            /* Read Only */
#define MCF_XBS_CRS_PCTL_PARK_FIELD     (0)                     
#define MCF_XBS_CRS_PCTL_PARK_ON_LAST   (1)                     
#define MCF_XBS_CRS_PCTL_PARK_NONE      (2)                     
#define MCF_XBS_CRS_PCTL_PARK_CORE      (0)                     
#define MCF_XBS_CRS_PCTL_PARK_EDMA      (1)                     
#define MCF_XBS_CRS_PCTL_PARK_FEC0      (2)                     
#define MCF_XBS_CRS_PCTL_PARK_FEC1      (3)                     
#define MCF_XBS_CRS_PCTL_PARK_PCI       (5)                     
#define MCF_XBS_CRS_PCTL_PARK_USB       (6)                     
#define MCF_XBS_CRS_PCTL_PARK_SBF       (7)                     

/* Bit definitions and macros for CRS1 */
#define MCF_XBS_CRS1_PARK(x)                (((x)&0x00000007))      /* Master parking control */
#define MCF_XBS_CRS1_PCTL(x)                (((x)&0x00000003)<<4)   /* Parking mode control */
#define MCF_XBS_CRS1_ARB                    (0x00000100)            /* Arbitration Mode */
#define MCF_XBS_CRS1_RO                     (0x80000000)            /* Read Only */
#define MCF_XBS_CRS1_PCTL_PARK_FIELD        (0)                     
#define MCF_XBS_CRS1_PCTL_PARK_ON_LAST      (1)                     
#define MCF_XBS_CRS1_PCTL_PARK_NONE         (2)                     
#define MCF_XBS_CRS1_PCTL_PARK_CORE         (0)                     
#define MCF_XBS_CRS1_PCTL_PARK_EDMA         (1)                     
#define MCF_XBS_CRS1_PCTL_PARK_FEC0         (2)                     
#define MCF_XBS_CRS1_PCTL_PARK_FEC1         (3)                     
#define MCF_XBS_CRS1_PCTL_PARK_PCI          (5)                     
#define MCF_XBS_CRS1_PCTL_PARK_USB          (6)                     
#define MCF_XBS_CRS1_PCTL_PARK_SBF          (7)                     

/* Bit definitions and macros for PRS2 */
#define MCF_XBS_PRS2_M0(x)      (((x)&0x00000007))      /* Master 0 (ColdFire core) priority */
#define MCF_XBS_PRS2_M1(x)      (((x)&0x00000007)<<4)   /* Master 1 (eDMA) priority */
#define MCF_XBS_PRS2_M2(x)      (((x)&0x00000007)<<8)   /* Master 2 (FEC0) priority */
#define MCF_XBS_PRS2_M3(x)      (((x)&0x00000007)<<12)  /* Master 3 (FEC1) priority */
#define MCF_XBS_PRS2_M5(x)      (((x)&0x00000007)<<20)  /* Master 5 (PCI controller) priority */
#define MCF_XBS_PRS2_M6(x)      (((x)&0x00000007)<<24)  /* Master 6 (USB OTG) priority */
#define MCF_XBS_PRS2_M7(x)      (((x)&0x00000007)<<28)  /* Master 7 (Serial Boot) priority */

/* Bit definitions and macros for CRS2 */
#define MCF_XBS_CRS2_PARK(x)    (((x)&0x00000007))      /* Master parking control */
#define MCF_XBS_CRS2_PCTL(x)    (((x)&0x00000003)<<4)   /* Parking mode control */
#define MCF_XBS_CRS2_ARB        (0x00000100)            /* Arbitration Mode */
#define MCF_XBS_CRS2_RO         (0x80000000)            /* Read Only */

/* Bit definitions and macros for PRS3 */
#define MCF_XBS_PRS3_M0(x)      (((x)&0x00000007))      /* Master 0 (ColdFire core) priority */
#define MCF_XBS_PRS3_M1(x)      (((x)&0x00000007)<<4)   /* Master 1 (eDMA) priority */
#define MCF_XBS_PRS3_M2(x)      (((x)&0x00000007)<<8)   /* Master 2 (FEC0) priority */
#define MCF_XBS_PRS3_M3(x)      (((x)&0x00000007)<<12)  /* Master 3 (FEC1) priority */
#define MCF_XBS_PRS3_M5(x)      (((x)&0x00000007)<<20)  /* Master 5 (PCI controller) priority */
#define MCF_XBS_PRS3_M6(x)      (((x)&0x00000007)<<24)  /* Master 6 (USB OTG) priority */
#define MCF_XBS_PRS3_M7(x)      (((x)&0x00000007)<<28)  /* Master 7 (Serial Boot) priority */

/* Bit definitions and macros for CRS3 */
#define MCF_XBS_CRS3_PARK(x)    (((x)&0x00000007))      /* Master parking control */
#define MCF_XBS_CRS3_PCTL(x)    (((x)&0x00000003)<<4)   /* Parking mode control */
#define MCF_XBS_CRS3_ARB        (0x00000100)            /* Arbitration Mode */
#define MCF_XBS_CRS3_RO         (0x80000000)            /* Read Only */

/* Bit definitions and macros for PRS4 */
#define MCF_XBS_PRS4_M0(x)      (((x)&0x00000007))      /* Master 0 (ColdFire core) priority */
#define MCF_XBS_PRS4_M1(x)      (((x)&0x00000007)<<4)   /* Master 1 (eDMA) priority */
#define MCF_XBS_PRS4_M2(x)      (((x)&0x00000007)<<8)   /* Master 2 (FEC0) priority */
#define MCF_XBS_PRS4_M3(x)      (((x)&0x00000007)<<12)  /* Master 3 (FEC1) priority */
#define MCF_XBS_PRS4_M5(x)      (((x)&0x00000007)<<20)  /* Master 5 (PCI controller) priority */
#define MCF_XBS_PRS4_M6(x)      (((x)&0x00000007)<<24)  /* Master 6 (USB OTG) priority */
#define MCF_XBS_PRS4_M7(x)      (((x)&0x00000007)<<28)  /* Master 7 (Serial Boot) priority */

/* Bit definitions and macros for CRS4 */
#define MCF_XBS_CRS4_PARK(x)    (((x)&0x00000007))      /* Master parking control */
#define MCF_XBS_CRS4_PCTL(x)    (((x)&0x00000003)<<4)   /* Parking mode control */
#define MCF_XBS_CRS4_ARB        (0x00000100)            /* Arbitration Mode */
#define MCF_XBS_CRS4_RO         (0x80000000)            /* Read Only */

/* Bit definitions and macros for PRS5 */
#define MCF_XBS_PRS5_M0(x)      (((x)&0x00000007))      /* Master 0 (ColdFire core) priority */
#define MCF_XBS_PRS5_M1(x)      (((x)&0x00000007)<<4)   /* Master 1 (eDMA) priority */
#define MCF_XBS_PRS5_M2(x)      (((x)&0x00000007)<<8)   /* Master 2 (FEC0) priority */
#define MCF_XBS_PRS5_M3(x)      (((x)&0x00000007)<<12)  /* Master 3 (FEC1) priority */
#define MCF_XBS_PRS5_M5(x)      (((x)&0x00000007)<<20)  /* Master 5 (PCI controller) priority */
#define MCF_XBS_PRS5_M6(x)      (((x)&0x00000007)<<24)  /* Master 6 (USB OTG) priority */
#define MCF_XBS_PRS5_M7(x)      (((x)&0x00000007)<<28)  /* Master 7 (Serial Boot) priority */

/* Bit definitions and macros for CRS5 */
#define MCF_XBS_CRS5_PARK(x)    (((x)&0x00000007))      /* Master parking control */
#define MCF_XBS_CRS5_PCTL(x)    (((x)&0x00000003)<<4)   /* Parking mode control */
#define MCF_XBS_CRS5_ARB        (0x00000100)            /* Arbitration Mode */
#define MCF_XBS_CRS5_RO         (0x80000000)            /* Read Only */

/* Bit definitions and macros for PRS6 */
#define MCF_XBS_PRS6_M0(x)      (((x)&0x00000007))      /* Master 0 (ColdFire core) priority */
#define MCF_XBS_PRS6_M1(x)      (((x)&0x00000007)<<4)   /* Master 1 (eDMA) priority */
#define MCF_XBS_PRS6_M2(x)      (((x)&0x00000007)<<8)   /* Master 2 (FEC0) priority */
#define MCF_XBS_PRS6_M3(x)      (((x)&0x00000007)<<12)  /* Master 3 (FEC1) priority */
#define MCF_XBS_PRS6_M5(x)      (((x)&0x00000007)<<20)  /* Master 5 (PCI controller) priority */
#define MCF_XBS_PRS6_M6(x)      (((x)&0x00000007)<<24)  /* Master 6 (USB OTG) priority */
#define MCF_XBS_PRS6_M7(x)      (((x)&0x00000007)<<28)  /* Master 7 (Serial Boot) priority */

/* Bit definitions and macros for CRS6 */
#define MCF_XBS_CRS6_PARK(x)    (((x)&0x00000007))      /* Master parking control */
#define MCF_XBS_CRS6_PCTL(x)    (((x)&0x00000003)<<4)   /* Parking mode control */
#define MCF_XBS_CRS6_ARB        (0x00000100)            /* Arbitration Mode */
#define MCF_XBS_CRS6_RO         (0x80000000)            /* Read Only */

/* Bit definitions and macros for PRS7 */
#define MCF_XBS_PRS7_M0(x)      (((x)&0x00000007))      /* Master 0 (ColdFire core) priority */
#define MCF_XBS_PRS7_M1(x)      (((x)&0x00000007)<<4)   /* Master 1 (eDMA) priority */
#define MCF_XBS_PRS7_M2(x)      (((x)&0x00000007)<<8)   /* Master 2 (FEC0) priority */
#define MCF_XBS_PRS7_M3(x)      (((x)&0x00000007)<<12)  /* Master 3 (FEC1) priority */
#define MCF_XBS_PRS7_M5(x)      (((x)&0x00000007)<<20)  /* Master 5 (PCI controller) priority */
#define MCF_XBS_PRS7_M6(x)      (((x)&0x00000007)<<24)  /* Master 6 (USB OTG) priority */
#define MCF_XBS_PRS7_M7(x)      (((x)&0x00000007)<<28)  /* Master 7 (Serial Boot) priority */

/* Bit definitions and macros for CRS7 */
#define MCF_XBS_CRS7_PARK(x)    (((x)&0x00000007))      /* Master parking control */
#define MCF_XBS_CRS7_PCTL(x)    (((x)&0x00000003)<<4)   /* Parking mode control */
#define MCF_XBS_CRS7_ARB        (0x00000100)            /* Arbitration Mode */
#define MCF_XBS_CRS7_RO         (0x80000000)            /* Read Only */

/********************************************************************/

#endif /* __MCF5445X_XBS_H__ */
