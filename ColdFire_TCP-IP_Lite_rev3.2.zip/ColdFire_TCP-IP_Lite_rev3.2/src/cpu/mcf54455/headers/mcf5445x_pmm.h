/*
 * File:    mcf5445x_pmm.h
 * Purpose: Register and bit definitions
 */

#ifndef __MCF5445X_PMM_H__
#define __MCF5445X_PMM_H__

/*********************************************************************
*
* Power Management Module (PMM)
*
*********************************************************************/

/* Register read/write macros */
#define MCF_PMM_WCR             (*(vuint8 *)(0xFC040013))   
#define MCF_PMM_PPMSR           (*(vuint8 *)(0xFC04002C))   
#define MCF_PMM_PPMCR           (*(vuint8 *)(0xFC04002D))   
#define MCF_PMM_PPMHR           (*(vuint32*)(0xFC040030))   
#define MCF_PMM_PPMLR           (*(vuint32*)(0xFC040034))   
#define MCF_PMM_LPCR            (*(vuint8 *)(0xFC0A0007))   

/* Bit definitions and macros for WCR */
#define MCF_PMM_WCR_PRILVL(x)   (((x)&0x07))        
#define MCF_PMM_WCR_LPMD(x)     (((x)&0x03)<<4)     
#define MCF_PMM_WCR_ENBWCR      (0x80)              
#define MCF_PMM_WCR_LPMD_RUN    (0x00)              
#define MCF_PMM_WCR_LPMD_DOZE   (0x10)              
#define MCF_PMM_WCR_LPMD_WAIT   (0x20)              
#define MCF_PMM_WCR_LPMD_STOP   (0x30)              

/* Bit definitions and macros for PPMSR */
#define MCF_PMM_PPMSR_SMCD(x)   (((x)&0x3F))    
#define MCF_PMM_PPMSR_SAMCD     (0x40)          

/* Bit definitions and macros for PPMCR */
#define MCF_PMM_PPMCR_CMCD(x)   (((x)&0x3F))    
#define MCF_PMM_PPMCR_CAMCD     (0x40)          

/* Bit definitions and macros for PPMHR */
#define MCF_PMM_PPMHR_CD32      (0x00000001)    
#define MCF_PMM_PPMHR_CD33      (0x00000002)    
#define MCF_PMM_PPMHR_CD34      (0x00000004)    
#define MCF_PMM_PPMHR_CD35      (0x00000008)    
#define MCF_PMM_PPMHR_CD36      (0x00000010)    
#define MCF_PMM_PPMHR_CD37      (0x00000020)    
#define MCF_PMM_PPMHR_CD40      (0x00000100)    
#define MCF_PMM_PPMHR_CD41      (0x00000200)    
#define MCF_PMM_PPMHR_CD42      (0x00000400)    
#define MCF_PMM_PPMHR_CD43      (0x00000800)    
#define MCF_PMM_PPMHR_CD44      (0x00001000)    
#define MCF_PMM_PPMHR_CD45      (0x00002000)    
#define MCF_PMM_PPMHR_CD46      (0x00004000)    
#define MCF_PMM_PPMHR_CD47      (0x00008000)    
#define MCF_PMM_PPMHR_CD48      (0x00010000)    
#define MCF_PMM_PPMHR_CD49      (0x00020000)    

/* Bit definitions and macros for PPMLR */
#define MCF_PMM_PPMLR_CD2       (0x00000004)    
#define MCF_PMM_PPMLR_CD12      (0x00001000)    
#define MCF_PMM_PPMLR_CD13      (0x00002000)    
#define MCF_PMM_PPMLR_CD15      (0x00008000)    
#define MCF_PMM_PPMLR_CD17      (0x00020000)    
#define MCF_PMM_PPMLR_CD18      (0x00040000)    
#define MCF_PMM_PPMLR_CD19      (0x00080000)    
#define MCF_PMM_PPMLR_CD21      (0x00200000)    
#define MCF_PMM_PPMLR_CD22      (0x00400000)    
#define MCF_PMM_PPMLR_CD23      (0x00800000)    
#define MCF_PMM_PPMLR_CD24      (0x01000000)    
#define MCF_PMM_PPMLR_CD25      (0x02000000)    
#define MCF_PMM_PPMLR_CD26      (0x04000000)    
#define MCF_PMM_PPMLR_CD28      (0x10000000)    
#define MCF_PMM_PPMLR_CD29      (0x20000000)    
#define MCF_PMM_PPMLR_CD30      (0x40000000)    
#define MCF_PMM_PPMLR_CD31      (0x80000000)    

/* Bit definitions and macros for LPCR */
#define MCF_PMM_LPCR_STPMD(x)   (((x)&0x03)<<3)     
#define MCF_PMM_LPCR_FWKUP      (0x20)              

/********************************************************************/

#endif /* __MCF5445X_PMM_H__ */
