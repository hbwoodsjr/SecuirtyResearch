/*
 * File:    mcf5445x_usb.h
 * Purpose: Register and bit definitions
 */

#ifndef __MCF5445X_USB_H__
#define __MCF5445X_USB_H__

/*********************************************************************
*
* USB Controller (USB)
*
*********************************************************************/

/* Register read/write macros */
#define MCF_USB_ID                  (*(vuint32*)(0xFC0B0000))   
#define MCF_USB_HWGENERAL           (*(vuint32*)(0xFC0B0004))   
#define MCF_USB_HWHOST              (*(vuint32*)(0xFC0B0008))   
#define MCF_USB_HWDEVICE            (*(vuint32*)(0xFC0B000C))   
#define MCF_USB_HWTXBUF             (*(vuint32*)(0xFC0B0010))   
#define MCF_USB_HWRXBUF             (*(vuint32*)(0xFC0B0014))   
#define MCF_USB_CAPLENGTH           (*(vuint8 *)(0xFC0B0100))   
#define MCF_USB_HCIVERSION          (*(vuint16*)(0xFC0B0102))   
#define MCF_USB_HCSPARAMS           (*(vuint32*)(0xFC0B0104))   
#define MCF_USB_HCCPARAMS           (*(vuint32*)(0xFC0B0108))   
#define MCF_USB_DCIVERSION          (*(vuint16*)(0xFC0B0120))   
#define MCF_USB_DCCPARAMS           (*(vuint32*)(0xFC0B0124))   
#define MCF_USB_USBCMD              (*(vuint32*)(0xFC0B0140))   
#define MCF_USB_USBSTS              (*(vuint32*)(0xFC0B0144))   
#define MCF_USB_USBINTR             (*(vuint32*)(0xFC0B0148))   
#define MCF_USB_FRINDEX             (*(vuint32*)(0xFC0B014C))   
#define MCF_USB_PERIODICLISTBASE    (*(vuint32*)(0xFC0B0154))   
#define MCF_USB_DEVICEADDR          (*(vuint32*)(0xFC0B0154))   
#define MCF_USB_EPLISTADDR          (*(vuint32*)(0xFC0B0158))   
#define MCF_USB_ASYNCLISTADDR       (*(vuint32*)(0xFC0B0158))   
#define MCF_USB_ASYNCTTSTS          (*(vuint32*)(0xFC0B015C))   
#define MCF_USB_BURSTSIZE           (*(vuint32*)(0xFC0B0160))   
#define MCF_USB_TXFILLTUNING        (*(vuint32*)(0xFC0B0164))   
#define MCF_USB_TXTTFILLTUNING      (*(vuint32*)(0xFC0B0168))   
#define MCF_USB_ULPI_VIEWPORT       (*(vuint32*)(0xFC0B0170))   
#define MCF_USB_CONFIGFLAG          (*(vuint32*)(0xFC0B0180))   
#define MCF_USB_PORTSC              (*(vuint32*)(0xFC0B0184))   
#define MCF_USB_OTGSC               (*(vuint32*)(0xFC0B01A4))   
#define MCF_USB_USBMODE             (*(vuint32*)(0xFC0B01A8))   
#define MCF_USB_EPSETUPSR           (*(vuint32*)(0xFC0B01AC))   
#define MCF_USB_EPPRIME             (*(vuint32*)(0xFC0B01B0))   
#define MCF_USB_EPFLUSH             (*(vuint32*)(0xFC0B01B4))   
#define MCF_USB_EPSR                (*(vuint32*)(0xFC0B01B8))   
#define MCF_USB_EPCOMPLETE          (*(vuint32*)(0xFC0B01BC))   
#define MCF_USB_EPCR0               (*(vuint32*)(0xFC0B01C0))   
#define MCF_USB_EPCR1               (*(vuint32*)(0xFC0B01C4))   
#define MCF_USB_EPCR2               (*(vuint32*)(0xFC0B01C8))   
#define MCF_USB_EPCR3               (*(vuint32*)(0xFC0B01CC))   

/* Parameterized register read/write macros for multiple registers */
#define MCF_USB_EPCR(x)         (*(vuint32*)(0xFC0B01C4 + ((x-1)*0x004)))   

/* Bit definitions and macros for ID */
#define MCF_USB_ID_ID(x)            (((x)&0x0000003F)   
#define MCF_USB_ID_NID(x)           (((x)&0x0000003F)   
#define MCF_USB_ID_REVISION(x)      (((x)&0x000000FF)   

/* Bit definitions and macros for HWGENERAL */
#define MCF_USB_HWGENERAL_RT        (0x00000001)            
#define MCF_USB_HWGENERAL_CLKC(x)   (((x)&0x00000003)<<1)   
#define MCF_USB_HWGENERAL_BWT       (0x00000008)            
#define MCF_USB_HWGENERAL_PHYW(x)   (((x)&0x00000003)<<4)   
#define MCF_USB_HWGENERAL_PHYM(x)   (((x)&0x00000007)<<6)   
#define MCF_USB_HWGENERAL_SM(x)     (((x)&0x00000003)<<9)   

/* Bit definitions and macros for HWHOST */
#define MCF_USB_HWHOST_HC           (0x00000001)            
#define MCF_USB_HWHOST_NPORT(x)     (((x)&0x00000007)<<1)   
#define MCF_USB_HWHOST_TTASY(x)     (((x)&0x000000FF)<<16)  
#define MCF_USB_HWHOST_TTPER(x)     (((x)&0x000000FF)<<24)  

/* Bit definitions and macros for HWDEVICE */
#define MCF_USB_HWDEVICE_DC         (0x00000001)            
#define MCF_USB_HWDEVICE_DEVEP(x)   (((x)&0x0000001F)<<1)   

/* Bit definitions and macros for HWTXBUF */
#define MCF_USB_HWTXBUF_TXBURST(x)      (((x)&0x000000FF))      
#define MCF_USB_HWTXBUF_TXADD(x)        (((x)&0x000000FF)<<8)   
#define MCF_USB_HWTXBUF_TXCHANADD(x)    (((x)&0x000000FF)<<16)  
#define MCF_USB_HWTXBUF_TXLC            (0x80000000)            

/* Bit definitions and macros for HWRXBUF */
#define MCF_USB_HWRXBUF_RXBURST(x)      (((x)&0x000000FF))      
#define MCF_USB_HWRXBUF_RXADD(x)        (((x)&0x000000FF)<<8)   

/* Bit definitions and macros for CAPLENGTH */
#define MCF_USB_CAPLENGTH_CAPLENGTH(x)      (x)     

/* Bit definitions and macros for HCIVERSION */
#define MCF_USB_HCIVERSION_HCIVERSION(x)    (x)     

/* Bit definitions and macros for HCSPARAMS */
#define MCF_USB_HCSPARAMS_N_PORTS(x)    (((x)&0x0000000F))      
#define MCF_USB_HCSPARAMS_PPC           (0x00000010)            
#define MCF_USB_HCSPARAMS_N_PCC(x)      (((x)&0x0000000F)<<8)   
#define MCF_USB_HCSPARAMS_N_CC(x)       (((x)&0x0000000F)<<12)  
#define MCF_USB_HCSPARAMS_PI            (0x00010000)            
#define MCF_USB_HCSPARAMS_N_PTT(x)      (((x)&0x0000000F)<<20)  
#define MCF_USB_HCSPARAMS_N_TT(x)       (((x)&0x0000000F)<<24)  

/* Bit definitions and macros for HCCPARAMS */
#define MCF_USB_HCCPARAMS_ADC       (0x00000001)            
#define MCF_USB_HCCPARAMS_PFL       (0x00000002)            
#define MCF_USB_HCCPARAMS_ASP       (0x00000004)            
#define MCF_USB_HCCPARAMS_IST(x)    (((x)&0x0000000F)<<4)   
#define MCF_USB_HCCPARAMS_EECP(x)   (((x)&0x000000FF)<<8)   

/* Bit definitions and macros for DCIVERSION */
#define MCF_USB_DCIVERSION_DCIVERSION(x)    (x)     

/* Bit definitions and macros for DCCPARAMS */
#define MCF_USB_DCCPARAMS_DEN(x)    (((x)&0x0000001F))  
#define MCF_USB_DCCPARAMS_DC        (0x00000080)        
#define MCF_USB_DCCPARAMS_HC        (0x00000100)        

/* Bit definitions and macros for USBCMD */
#define MCF_USB_USBCMD_RS           (0x00000001)            
#define MCF_USB_USBCMD_RST          (0x00000002)            
#define MCF_USB_USBCMD_FS0          (0x00000004)            
#define MCF_USB_USBCMD_FS1          (0x00000008)            
#define MCF_USB_USBCMD_PSE          (0x00000010)            
#define MCF_USB_USBCMD_ASE          (0x00000020)            
#define MCF_USB_USBCMD_IAA          (0x00000040)            
#define MCF_USB_USBCMD_LR           (0x00000080)            
#define MCF_USB_USBCMD_ASP(x)       (((x)&0x00000003)<<8)   
#define MCF_USB_USBCMD_ASPE         (0x00000800)            
#define MCF_USB_USBCMD_SUTW         (0x00002000)            
#define MCF_USB_USBCMD_ATDTW        (0x00004000)            
#define MCF_USB_USBCMD_FS2          (0x00008000)            
#define MCF_USB_USBCMD_ITC(x)       (((x)&0x000000FF)<<16)  
#define MCF_USB_USBCMD_ITC_IMM      (0x00000000)            
#define MCF_USB_USBCMD_ITC_1        (0x00010000)            
#define MCF_USB_USBCMD_ITC_2        (0x00020000)            
#define MCF_USB_USBCMD_ITC_4        (0x00040000)            
#define MCF_USB_USBCMD_ITC_8        (0x00080000)            
#define MCF_USB_USBCMD_ITC_16       (0x00100000)            
#define MCF_USB_USBCMD_ITC_32       (0x00200000)            
#define MCF_USB_USBCMD_ITC_40       (0x00400000)            
#define MCF_USB_USBCMD_FS_1024      (0x00000000)            
#define MCF_USB_USBCMD_FS_512       (0x00000004)            
#define MCF_USB_USBCMD_FS_256       (0x00000008)            
#define MCF_USB_USBCMD_FS_128       (0x0000000C)            
#define MCF_USB_USBCMD_FS_64        (0x00008000)            
#define MCF_USB_USBCMD_FS_32        (0x00008004)            
#define MCF_USB_USBCMD_FS_16        (0x00008008)            
#define MCF_USB_USBCMD_FS_8         (0x0000800C)            

/* Bit definitions and macros for USBSTS */
#define MCF_USB_USBSTS_UI       (0x00000001)    
#define MCF_USB_USBSTS_UEI      (0x00000002)    
#define MCF_USB_USBSTS_PCI      (0x00000004)    
#define MCF_USB_USBSTS_FRI      (0x00000008)    
#define MCF_USB_USBSTS_SEI      (0x00000010)    
#define MCF_USB_USBSTS_AAI      (0x00000020)    
#define MCF_USB_USBSTS_URI      (0x00000040)    
#define MCF_USB_USBSTS_SRI      (0x00000080)    
#define MCF_USB_USBSTS_SLI      (0x00000100)    
#define MCF_USB_USBSTS_HCH      (0x00001000)    
#define MCF_USB_USBSTS_RCL      (0x00002000)    
#define MCF_USB_USBSTS_PS       (0x00004000)    
#define MCF_USB_USBSTS_AS       (0x00008000)    

/* Bit definitions and macros for USBINTR */
#define MCF_USB_USBINTR_UE      (0x00000001)    
#define MCF_USB_USBINTR_UEE     (0x00000002)    
#define MCF_USB_USBINTR_PCE     (0x00000004)    
#define MCF_USB_USBINTR_FRE     (0x00000008)    
#define MCF_USB_USBINTR_SEE     (0x00000010)    
#define MCF_USB_USBINTR_AAE     (0x00000020)    
#define MCF_USB_USBINTR_URE     (0x00000040)    
#define MCF_USB_USBINTR_SRE     (0x00000080)    
#define MCF_USB_USBINTR_SLE     (0x00000100)    

/* Bit definitions and macros for FRINDEX */
#define MCF_USB_FRINDEX_FRINDEX(x)      (((x)&0x00003FFF))  

/* Bit definitions and macros for PERIODICLISTBASE */
#define MCF_USB_PERIODICLISTBASE_PERBASE(x)     (((x)&0x000FFFFF)<<12)  

/* Bit definitions and macros for DEVICEADDR */
#define MCF_USB_DEVICEADDR_USBADR(x)    (((x)&0x0000007F)<<25)  

/* Bit definitions and macros for EPLISTADDR */
#define MCF_USB_EPLISTADDR_EPBASE(x)    (((x)&0x001FFFFF)<<11)  

/* Bit definitions and macros for ASYNCLISTADDR */
#define MCF_USB_ASYNCLISTADDR_ASYBASE(x)    (((x)&0x07FFFFFF)<<5)   

/* Bit definitions and macros for ASYNCTTSTS */
#define MCF_USB_ASYNCTTSTS_TTAS     (0x00000001)    
#define MCF_USB_ASYNCTTSTS_TTAC     (0x00000002)    

/* Bit definitions and macros for BURSTSIZE */
#define MCF_USB_BURSTSIZE_RXPBURST(x)   (((x)&0x000000FF))      
#define MCF_USB_BURSTSIZE_TXPBURST(x)   (((x)&0x000000FF)<<8)   

/* Bit definitions and macros for TXFILLTUNING */
#define MCF_USB_TXFILLTUNING_TXSCHOH(x)         (((x)&0x000000FF))      
#define MCF_USB_TXFILLTUNING_TXSCHHEALTH(x)     (((x)&0x0000001F)<<8)   
#define MCF_USB_TXFILLTUNING_TXFIFOTHRES(x)     (((x)&0x0000003F)<<16)  

/* Bit definitions and macros for TXTTFILLTUNING */
#define MCF_USB_TXTTFILLTUNING_TXTTSCHOH(x)         (((x)&0x0000001F))      
#define MCF_USB_TXTTFILLTUNING_TXTTSCHHEALTH(x)     (((x)&0x0000001F)<<8)   

/* Bit definitions and macros for ULPI_VIEWPORT */
#define MCF_USB_ULPI_VIEWPORT_ULPI_DATWR(x)     (((x)&0x000000FF))      
#define MCF_USB_ULPI_VIEWPORT_ULPI_DATRD(x)     (((x)&0x000000FF)<<8)   
#define MCF_USB_ULPI_VIEWPORT_ULPI_ADDR(x)      (((x)&0x000000FF)<<16)  
#define MCF_USB_ULPI_VIEWPORT_ULPI_PORT(x)      (((x)&0x00000007)<<24)  
#define MCF_USB_ULPI_VIEWPORT_ULPI_SS           (0x08000000)            
#define MCF_USB_ULPI_VIEWPORT_ULPI_RW           (0x20000000)            
#define MCF_USB_ULPI_VIEWPORT_ULPI_RUN          (0x40000000)            
#define MCF_USB_ULPI_VIEWPORT_ULPI_WU           (0x80000000)            

/* Bit definitions and macros for CONFIGFLAG */
#define MCF_USB_CONFIGFLAG_CONFIGFLAG(x)    (x)     

/* Bit definitions and macros for PORTSC */
#define MCF_USB_PORTSC_CCS                  (0x20000001)        
#define MCF_USB_PORTSC_CSC                  (0x20000002)        
#define MCF_USB_PORTSC_PE                   (0x20000004)        
#define MCF_USB_PORTSC_PEC                  (0x20000008)        
#define MCF_USB_PORTSC_OCA                  (0x20000010)        
#define MCF_USB_PORTSC_OCC                  (0x20000020)        
#define MCF_USB_PORTSC_FPR                  (0x20000040)        
#define MCF_USB_PORTSC_SUSP                 (0x20000080)        
#define MCF_USB_PORTSC_PR                   (0x20000100)        
#define MCF_USB_PORTSC_LS(x)                (((x)&0x00000003)   
#define MCF_USB_PORTSC_PP                   (0x20001000)        
#define MCF_USB_PORTSC_PO                   (0x20002000)        
#define MCF_USB_PORTSC_PIC(x)               (((x)&0x00000003)   
#define MCF_USB_PORTSC_PTC(x)               (((x)&0x0000000F)   
#define MCF_USB_PORTSC_WLCN                 (0x20100000)        
#define MCF_USB_PORTSC_WKDS                 (0x20200000)        
#define MCF_USB_PORTSC_WKOC                 (0x20400000)        
#define MCF_USB_PORTSC_PHCD                 (0x20800000)        
#define MCF_USB_PORTSC_PFSC                 (0x21000000)        
#define MCF_USB_PORTSC_PSPD(x)              (((x)&0x00000003)   
#define MCF_USB_PORTSC_PTS(x)               (((x)&0x00000003)   
#define MCF_USB_PORTSC_PTS_ULPI             (0xA0000000)        
#define MCF_USB_PORTSC_PTS_FS_LS            (0xE0000000)        
#define MCF_USB_PORTSC_PSPD_FULL            (0x00000000)        
#define MCF_USB_PORTSC_PSPD_LOW             (0x04000000)        
#define MCF_USB_PORTSC_PSPD_HIGH            (0x08000000)        
#define MCF_USB_PORTSC_PTC_DISBALE          (0x00000000)        
#define MCF_USB_PORTSC_PTC_JSTATE           (0x00010000)        
#define MCF_USB_PORTSC_PTC_KSTATE           (0x00020000)        
#define MCF_USB_PORTSC_PTC_SEQ_NAK          (0x00030000)        
#define MCF_USB_PORTSC_PTC_PACKET           (0x00040000)        
#define MCF_USB_PORTSC_PTC_FORCE_ENABLE     (0x00050000)        
#define MCF_USB_PORTSC_PIC_OFF              (0x00000000)        
#define MCF_USB_PORTSC_PIC_AMBER            (0x00004000)        
#define MCF_USB_PORTSC_PIC_GREEN            (0x00008000)        
#define MCF_USB_PORTSC_LS_SE0               (0x00000000)        
#define MCF_USB_PORTSC_LS_JSTATE            (0x00000400)        
#define MCF_USB_PORTSC_LS_KSTATE            (0x00000800)        

/* Bit definitions and macros for OTGSC */
#define MCF_USB_OTGSC_VD            (0x00000001)    
#define MCF_USB_OTGSC_VC            (0x00000002)    
#define MCF_USB_OTGSC_OT            (0x00000008)    
#define MCF_USB_OTGSC_DP            (0x00000010)    
#define MCF_USB_OTGSC_ID            (0x00000100)    
#define MCF_USB_OTGSC_AVV           (0x00000200)    
#define MCF_USB_OTGSC_ASV           (0x00000400)    
#define MCF_USB_OTGSC_BSV           (0x00000800)    
#define MCF_USB_OTGSC_BSE           (0x00001000)    
#define MCF_USB_OTGSC_1MST          (0x00002000)    
#define MCF_USB_OTGSC_DPS           (0x00004000)    
#define MCF_USB_OTGSC_IDIS          (0x00010000)    
#define MCF_USB_OTGSC_AVVIS         (0x00020000)    
#define MCF_USB_OTGSC_ASVIS         (0x00040000)    
#define MCF_USB_OTGSC_BSVIS         (0x00080000)    
#define MCF_USB_OTGSC_BSEIS         (0x00100000)    
#define MCF_USB_OTGSC_1MSS          (0x00200000)    
#define MCF_USB_OTGSC_DPIS          (0x00400000)    
#define MCF_USB_OTGSC_IDIE          (0x01000000)    
#define MCF_USB_OTGSC_AVVIE         (0x02000000)    
#define MCF_USB_OTGSC_ADVIE         (0x04000000)    
#define MCF_USB_OTGSC_BSVIE         (0x08000000)    
#define MCF_USB_OTGSC_BSEIE         (0x10000000)    
#define MCF_USB_OTGSC_1MSE          (0x20000000)    
#define MCF_USB_OTGSC_DPIE          (0x40000000)    
#define MCF_USB_OTGSC_CLEAR         (0x007F0000)    
#define MCF_USB_OTGSC_ENABLE_ALL    (0x7F000000)    

/* Bit definitions and macros for USBMODE */
#define MCF_USB_USBMODE_CM(x)       (((x)&0x00000003))  
#define MCF_USB_USBMODE_ES          (0x00000004)        
#define MCF_USB_USBMODE_SLOM        (0x00000008)        
#define MCF_USB_USBMODE_SDIS        (0x00000010)        
#define MCF_USB_USBMODE_CM_IDLE     (0x00000000)        
#define MCF_USB_USBMODE_CM_DEVICE   (0x00000002)        
#define MCF_USB_USBMODE_CM_HOST     (0x00000003)        

/* Bit definitions and macros for EPSETUPSR */
#define MCF_USB_EPSETUPSR_EPSETUPSTAT(x)    (((x)&0x0000003F))  

/* Bit definitions and macros for EPPRIME */
#define MCF_USB_EPPRIME_PERB(x)     (((x)&0x0000003F))      
#define MCF_USB_EPPRIME_PETB(x)     (((x)&0x0000003F)<<16)  
#define MCF_USB_EPPRIME_PETB0       (0x00010000)            
#define MCF_USB_EPPRIME_PETB1       (0x00020000)            
#define MCF_USB_EPPRIME_PETB2       (0x00040000)            
#define MCF_USB_EPPRIME_PETB3       (0x00080000)            
#define MCF_USB_EPPRIME_PETB4       (0x00100000)            
#define MCF_USB_EPPRIME_PETB5       (0x00200000)            
#define MCF_USB_EPPRIME_PERB0       (0x00000001)            
#define MCF_USB_EPPRIME_PERB1       (0x00000002)            
#define MCF_USB_EPPRIME_PERB2       (0x00000004)            
#define MCF_USB_EPPRIME_PERB3       (0x00000008)            
#define MCF_USB_EPPRIME_PERB4       (0x00000010)            
#define MCF_USB_EPPRIME_PERB5       (0x00000020)            

/* Bit definitions and macros for EPFLUSH */
#define MCF_USB_EPFLUSH_FERB(x)     (((x)&0x0000003F))      
#define MCF_USB_EPFLUSH_FETB(x)     (((x)&0x0000003F)<<16)  
#define MCF_USB_EPFLUSH_FETB0       (0x00010000)            
#define MCF_USB_EPFLUSH_FETB1       (0x00020000)            
#define MCF_USB_EPFLUSH_FETB2       (0x00040000)            
#define MCF_USB_EPFLUSH_FETB3       (0x00080000)            
#define MCF_USB_EPFLUSH_FETB4       (0x00100000)            
#define MCF_USB_EPFLUSH_FETB5       (0x00200000)            
#define MCF_USB_EPFLUSH_FERB0       (0x00000001)            
#define MCF_USB_EPFLUSH_FERB1       (0x00000002)            
#define MCF_USB_EPFLUSH_FERB2       (0x00000004)            
#define MCF_USB_EPFLUSH_FERB3       (0x00000008)            
#define MCF_USB_EPFLUSH_FERB4       (0x00000010)            
#define MCF_USB_EPFLUSH_FERB5       (0x00000020)            

/* Bit definitions and macros for EPSR */
#define MCF_USB_EPSR_ERBR(x)    (((x)&0x0000003F))      
#define MCF_USB_EPSR_ETBR(x)    (((x)&0x0000003F)<<16)  
#define MCF_USB_EPSR_ETBR0      (0x00010000)            
#define MCF_USB_EPSR_ETBR1      (0x00020000)            
#define MCF_USB_EPSR_ETBR2      (0x00040000)            
#define MCF_USB_EPSR_ETBR3      (0x00080000)            
#define MCF_USB_EPSR_ETBR4      (0x00100000)            
#define MCF_USB_EPSR_ETBR5      (0x00200000)            
#define MCF_USB_EPSR_ERBR0      (0x00000001)            
#define MCF_USB_EPSR_ERBR1      (0x00000002)            
#define MCF_USB_EPSR_ERBR2      (0x00000004)            
#define MCF_USB_EPSR_ERBR3      (0x00000008)            
#define MCF_USB_EPSR_ERBR4      (0x00000010)            
#define MCF_USB_EPSR_ERBR5      (0x00000020)            

/* Bit definitions and macros for EPCOMPLETE */
#define MCF_USB_EPCOMPLETE_ERCE(x)      (((x)&0x0000003F))      
#define MCF_USB_EPCOMPLETE_ETCE(x)      (((x)&0x0000003F)<<16)  
#define MCF_USB_EPCOMPLETE_ETCE0        (0x00010000)            
#define MCF_USB_EPCOMPLETE_ETCE1        (0x00020000)            
#define MCF_USB_EPCOMPLETE_ETCE2        (0x00040000)            
#define MCF_USB_EPCOMPLETE_ETCE3        (0x00080000)            
#define MCF_USB_EPCOMPLETE_ETCE4        (0x00100000)            
#define MCF_USB_EPCOMPLETE_ETCE5        (0x00200000)            
#define MCF_USB_EPCOMPLETE_ERCE0        (0x00000001)            
#define MCF_USB_EPCOMPLETE_ERCE1        (0x00000002)            
#define MCF_USB_EPCOMPLETE_ERCE2        (0x00000004)            
#define MCF_USB_EPCOMPLETE_ERCE3        (0x00000008)            
#define MCF_USB_EPCOMPLETE_ERCE4        (0x00000010)            
#define MCF_USB_EPCOMPLETE_ERCE5        (0x00000020)            

/* Bit definitions and macros for EPCR0 */
#define MCF_USB_EPCR0_RXS       (0x00000001)            
#define MCF_USB_EPCR0_RXT(x)    (((x)&0x00000003)<<2)   
#define MCF_USB_EPCR0_RXE       (0x00000080)            
#define MCF_USB_EPCR0_TXS       (0x00010000)            
#define MCF_USB_EPCR0_TXT(x)    (((x)&0x00000003)<<18)  
#define MCF_USB_EPCR0_TXE       (0x00800000)            

/* Bit definitions and macros for EPCR group */
#define MCF_USB_EPCR_RXS            (0x00000001)            
#define MCF_USB_EPCR_RXD            (0x00000002)            
#define MCF_USB_EPCR_RXT(x)         (((x)&0x00000003)<<2)   
#define MCF_USB_EPCR_RXI            (0x00000020)            
#define MCF_USB_EPCR_RXR            (0x00000040)            
#define MCF_USB_EPCR_RXE            (0x00000080)            
#define MCF_USB_EPCR_TXS            (0x00010000)            
#define MCF_USB_EPCR_TXD            (0x00020000)            
#define MCF_USB_EPCR_TXT(x)         (((x)&0x00000003)<<18)  
#define MCF_USB_EPCR_TXI            (0x00200000)            
#define MCF_USB_EPCR_TXR            (0x00400000)            
#define MCF_USB_EPCR_TXE            (0x00800000)            
#define MCF_USB_EPCR_TXT_CONTROL    (0x00000000)            
#define MCF_USB_EPCR_TXT_ISO        (0x00040000)            
#define MCF_USB_EPCR_TXT_BULK       (0x00080000)            
#define MCF_USB_EPCR_TXT_INT        (0x000C0000)            
#define MCF_USB_EPCR_RXT_CONTROL    (0x00000000)            
#define MCF_USB_EPCR_RXT_ISO        (0x00000004)            
#define MCF_USB_EPCR_RXT_BULK       (0x00000008)            
#define MCF_USB_EPCR_RXT_INT        (0x0000000C)            

/* Bit definitions and macros for EPCR1 */
#define MCF_USB_EPCR1_RXS           (0x00000001)            
#define MCF_USB_EPCR1_RXD           (0x00000002)            
#define MCF_USB_EPCR1_RXT(x)        (((x)&0x00000003)<<2)   
#define MCF_USB_EPCR1_RXI           (0x00000020)            
#define MCF_USB_EPCR1_RXR           (0x00000040)            
#define MCF_USB_EPCR1_RXE           (0x00000080)            
#define MCF_USB_EPCR1_TXS           (0x00010000)            
#define MCF_USB_EPCR1_TXD           (0x00020000)            
#define MCF_USB_EPCR1_TXT(x)        (((x)&0x00000003)<<18)  
#define MCF_USB_EPCR1_TXI           (0x00200000)            
#define MCF_USB_EPCR1_TXR           (0x00400000)            
#define MCF_USB_EPCR1_TXE           (0x00800000)            
#define MCF_USB_EPCR1_TXT_CONTROL   (0x00000000)            
#define MCF_USB_EPCR1_TXT_ISO       (0x00040000)            
#define MCF_USB_EPCR1_TXT_BULK      (0x00080000)            
#define MCF_USB_EPCR1_TXT_INT       (0x000C0000)            
#define MCF_USB_EPCR1_RXT_CONTROL   (0x00000000)            
#define MCF_USB_EPCR1_RXT_ISO       (0x00000004)            
#define MCF_USB_EPCR1_RXT_BULK      (0x00000008)            
#define MCF_USB_EPCR1_RXT_INT       (0x0000000C)            

/* Bit definitions and macros for EPCR2 */
#define MCF_USB_EPCR2_RXS       (0x00000001)            
#define MCF_USB_EPCR2_RXD       (0x00000002)            
#define MCF_USB_EPCR2_RXT(x)    (((x)&0x00000003)<<2)   
#define MCF_USB_EPCR2_RXI       (0x00000020)            
#define MCF_USB_EPCR2_RXR       (0x00000040)            
#define MCF_USB_EPCR2_RXE       (0x00000080)            
#define MCF_USB_EPCR2_TXS       (0x00010000)            
#define MCF_USB_EPCR2_TXD       (0x00020000)            
#define MCF_USB_EPCR2_TXT(x)    (((x)&0x00000003)<<18)  
#define MCF_USB_EPCR2_TXI       (0x00200000)            
#define MCF_USB_EPCR2_TXR       (0x00400000)            
#define MCF_USB_EPCR2_TXE       (0x00800000)            

/* Bit definitions and macros for EPCR3 */
#define MCF_USB_EPCR3_RXS       (0x00000001)            
#define MCF_USB_EPCR3_RXD       (0x00000002)            
#define MCF_USB_EPCR3_RXT(x)    (((x)&0x00000003)<<2)   
#define MCF_USB_EPCR3_RXI       (0x00000020)            
#define MCF_USB_EPCR3_RXR       (0x00000040)            
#define MCF_USB_EPCR3_RXE       (0x00000080)            
#define MCF_USB_EPCR3_TXS       (0x00010000)            
#define MCF_USB_EPCR3_TXD       (0x00020000)            
#define MCF_USB_EPCR3_TXT(x)    (((x)&0x00000003)<<18)  
#define MCF_USB_EPCR3_TXI       (0x00200000)            
#define MCF_USB_EPCR3_TXR       (0x00400000)            
#define MCF_USB_EPCR3_TXE       (0x00800000)            

/********************************************************************/

#endif /* __MCF5445X_USB_H__ */
