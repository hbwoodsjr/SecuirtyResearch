/*
 * File:    mcf5445x_rng.h
 * Purpose: Register and bit definitions
 */

#ifndef __MCF5445X_RNG_H__
#define __MCF5445X_RNG_H__

/*********************************************************************
*
* Random Number Generator (RNG)
*
*********************************************************************/

/* Register read/write macros */
#define MCF_RNG_RNGCR           (*(vuint32*)(0xFC0B4000))   
#define MCF_RNG_RNGSR           (*(vuint32*)(0xFC0B4004))   
#define MCF_RNG_RNGER           (*(vuint32*)(0xFC0B4008))   
#define MCF_RNG_RNGOUT          (*(vuint32*)(0xFC0B400C))   

/* Bit definitions and macros for RNGCR */
#define MCF_RNG_RNGCR_GO        (0x00000001)    
#define MCF_RNG_RNGCR_HA        (0x00000002)    
#define MCF_RNG_RNGCR_IM        (0x00000004)    
#define MCF_RNG_RNGCR_CI        (0x00000008)    

/* Bit definitions and macros for RNGSR */
#define MCF_RNG_RNGSR_SV        (0x00000001)            
#define MCF_RNG_RNGSR_LRS       (0x00000002)            
#define MCF_RNG_RNGSR_FUF       (0x00000004)            
#define MCF_RNG_RNGSR_EI        (0x00000008)            
#define MCF_RNG_RNGSR_OFL(x)    (((x)&0x000000FF)<<8)   
#define MCF_RNG_RNGSR_OFS(x)    (((x)&0x000000FF)<<16)  

/* Bit definitions and macros for RNGER */
#define MCF_RNG_RNGER_ENTROPY(x)    (x)     

/* Bit definitions and macros for RNGOUT */
#define MCF_RNG_RNGOUT_OUTPUT(x)    (x)     

/********************************************************************/

#endif /* __MCF5445X_RNG_H__ */
