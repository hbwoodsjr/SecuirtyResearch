/*
 * File:    mcf5445x_dtim.h
 * Purpose: Register and bit definitions
 */

#ifndef __MCF5445X_DTIM_H__
#define __MCF5445X_DTIM_H__

/*********************************************************************
*
* DMA Timers (DTIM)
*
*********************************************************************/

/* Register read/write macros */
#define MCF_DTIM0_DTMR          (*(vuint16*)(0xFC070000))   /* DMA Timer Mode Register */
#define MCF_DTIM0_DTXMR         (*(vuint8 *)(0xFC070002))   /* DMA Timer Extended Mode Register */
#define MCF_DTIM0_DTER          (*(vuint8 *)(0xFC070003))   /* DMA Timer Event Register */
#define MCF_DTIM0_DTRR          (*(vuint32*)(0xFC070004))   /* DMA Timer Reference Register */
#define MCF_DTIM0_DTCR          (*(vuint32*)(0xFC070008))   /* DMA Timer Capture Register */
#define MCF_DTIM0_DTCN          (*(vuint32*)(0xFC07000C))   /* DMA Timer Counter Register */
#define MCF_DTIM1_DTMR          (*(vuint16*)(0xFC074000))   /* DMA Timer Mode Register */
#define MCF_DTIM1_DTXMR         (*(vuint8 *)(0xFC074002))   /* DMA Timer Extended Mode Register */
#define MCF_DTIM1_DTER          (*(vuint8 *)(0xFC074003))   /* DMA Timer Event Register */
#define MCF_DTIM1_DTRR          (*(vuint32*)(0xFC074004))   /* DMA Timer Reference Register */
#define MCF_DTIM1_DTCR          (*(vuint32*)(0xFC074008))   /* DMA Timer Capture Register */
#define MCF_DTIM1_DTCN          (*(vuint32*)(0xFC07400C))   /* DMA Timer Counter Register */
#define MCF_DTIM2_DTMR          (*(vuint16*)(0xFC078000))   /* DMA Timer Mode Register */
#define MCF_DTIM2_DTXMR         (*(vuint8 *)(0xFC078002))   /* DMA Timer Extended Mode Register */
#define MCF_DTIM2_DTER          (*(vuint8 *)(0xFC078003))   /* DMA Timer Event Register */
#define MCF_DTIM2_DTRR          (*(vuint32*)(0xFC078004))   /* DMA Timer Reference Register */
#define MCF_DTIM2_DTCR          (*(vuint32*)(0xFC078008))   /* DMA Timer Capture Register */
#define MCF_DTIM2_DTCN          (*(vuint32*)(0xFC07800C))   /* DMA Timer Counter Register */
#define MCF_DTIM3_DTMR          (*(vuint16*)(0xFC07C000))   /* DMA Timer Mode Register */
#define MCF_DTIM3_DTXMR         (*(vuint8 *)(0xFC07C002))   /* DMA Timer Extended Mode Register */
#define MCF_DTIM3_DTER          (*(vuint8 *)(0xFC07C003))   /* DMA Timer Event Register */
#define MCF_DTIM3_DTRR          (*(vuint32*)(0xFC07C004))   /* DMA Timer Reference Register */
#define MCF_DTIM3_DTCR          (*(vuint32*)(0xFC07C008))   /* DMA Timer Capture Register */
#define MCF_DTIM3_DTCN          (*(vuint32*)(0xFC07C00C))   /* DMA Timer Counter Register */

/* Parameterized register read/write macros for multiple modules */
#define MCF_DTIM_DTMR(x)        (*(vuint16*)(0xFC070000 + ((x)*0x4000)))    /* DMA Timer Mode Register */
#define MCF_DTIM_DTXMR(x)       (*(vuint8 *)(0xFC070002 + ((x)*0x4000)))    /* DMA Timer Extended Mode Register */
#define MCF_DTIM_DTER(x)        (*(vuint8 *)(0xFC070003 + ((x)*0x4000)))    /* DMA Timer Event Register */
#define MCF_DTIM_DTRR(x)        (*(vuint32*)(0xFC070004 + ((x)*0x4000)))    /* DMA Timer Reference Register */
#define MCF_DTIM_DTCR(x)        (*(vuint32*)(0xFC070008 + ((x)*0x4000)))    /* DMA Timer Capture Register */
#define MCF_DTIM_DTCN(x)        (*(vuint32*)(0xFC07000C + ((x)*0x4000)))    /* DMA Timer Counter Register */

/* Bit definitions and macros for DTMR */
#define MCF_DTIM_DTMR_RST           (0x0001)            /* Reset */
#define MCF_DTIM_DTMR_CLK(x)        (((x)&0x0003)<<1)   /* Input clock source */
#define MCF_DTIM_DTMR_FRR           (0x0008)            /* Free run/restart */
#define MCF_DTIM_DTMR_ORRI          (0x0010)            /* Output reference request/interrupt enable */
#define MCF_DTIM_DTMR_OM            (0x0020)            /* Output Mode */
#define MCF_DTIM_DTMR_CE(x)         (((x)&0x0003)<<6)   /* Capture Edge */
#define MCF_DTIM_DTMR_PS(x)         (((x)&0x00FF)<<8)   /* Prescaler value */
#define MCF_DTIM_DTMR_RST_EN        (0x0001)            
#define MCF_DTIM_DTMR_RST_RST       (0x0000)            
#define MCF_DTIM_DTMR_CE_ANY        (0x00C0)            
#define MCF_DTIM_DTMR_CE_FALL       (0x0080)            
#define MCF_DTIM_DTMR_CE_RISE       (0x0040)            
#define MCF_DTIM_DTMR_CE_NONE       (0x0000)            
#define MCF_DTIM_DTMR_CLK_DTIN      (0x0006)            
#define MCF_DTIM_DTMR_CLK_DIV16     (0x0004)            
#define MCF_DTIM_DTMR_CLK_DIV1      (0x0002)            
#define MCF_DTIM_DTMR_CLK_STOP      (0x0000)            

/* Bit definitions and macros for DTXMR */
#define MCF_DTIM_DTXMR_MODE16   (0x01)  /* Increment Mode */
#define MCF_DTIM_DTXMR_DMAEN    (0x80)  /* DMA request */

/* Bit definitions and macros for DTER */
#define MCF_DTIM_DTER_CAP       (0x01)  /* Capture event */
#define MCF_DTIM_DTER_REF       (0x02)  /* Output reference event */

/********************************************************************/

#endif /* __MCF5445X_DTIM_H__ */
