/*
 * File:    mcf5445x_rcm.h
 * Purpose: Register and bit definitions
 */

#ifndef __MCF5445X_RCM_H__
#define __MCF5445X_RCM_H__

/*********************************************************************
*
* Reset Controller Module (RCM)
*
*********************************************************************/

/* Register read/write macros */
#define MCF_RCM_RCR             (*(vuint8 *)(0xFC0A0000))   
#define MCF_RCM_RSR             (*(vuint8 *)(0xFC0A0001))   

/* Bit definitions and macros for RCR */
#define MCF_RCM_RCR_FRCRSTOUT   (0x40)  
#define MCF_RCM_RCR_SOFTRST     (0x80)  

/* Bit definitions and macros for RSR */
#define MCF_RCM_RSR_LOL         (0x01)  
#define MCF_RCM_RSR_WDR_CORE    (0x02)  
#define MCF_RCM_RSR_EXT         (0x04)  
#define MCF_RCM_RSR_POR         (0x08)  
#define MCF_RCM_RSR_SOFT        (0x20)  

/********************************************************************/

#endif /* __MCF5445X_RCM_H__ */
