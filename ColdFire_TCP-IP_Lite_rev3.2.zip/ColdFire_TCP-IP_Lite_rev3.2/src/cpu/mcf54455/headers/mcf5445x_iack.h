/*
 * File:    mcf5445x_iack.h
 * Purpose: Register and bit definitions
 */

#ifndef __MCF5445X_IACK_H__
#define __MCF5445X_IACK_H__

/*********************************************************************
*
* Global Interrupt Acknowledge (IACK)
*
*********************************************************************/

/* Register read/write macros */
#define MCF_IACK_GSWIACK        (*(vuint8 *)(0xFC0540E0))   
#define MCF_IACK_GL1IACK        (*(vuint8 *)(0xFC0540E4))   
#define MCF_IACK_GL2IACK        (*(vuint8 *)(0xFC0540E8))   
#define MCF_IACK_GL3IACK        (*(vuint8 *)(0xFC0540EC))   
#define MCF_IACK_GL4IACK        (*(vuint8 *)(0xFC0540F0))   
#define MCF_IACK_GL5IACK        (*(vuint8 *)(0xFC0540F4))   
#define MCF_IACK_GL6IACK        (*(vuint8 *)(0xFC0540F8))   
#define MCF_IACK_GL7IACK        (*(vuint8 *)(0xFC0540FC))   

/* Parameterized register read/write macros for multiple registers */
#define MCF_IACK_GLIACK(x)      (*(vuint8 *)(0xFC0540E4 + ((x-1)*0x004)))   

/* Bit definitions and macros for GSWIACK */
#define MCF_IACK_GSWIACK_VECTOR(x)      (x)     

/* Bit definitions and macros for GLIACK group */
#define MCF_IACK_GLIACK_VECTOR(x)   (x)     

/* Bit definitions and macros for GL1IACK */
#define MCF_IACK_GL1IACK_VECTOR(x)      (x)     

/* Bit definitions and macros for GL2IACK */
#define MCF_IACK_GL2IACK_VECTOR(x)      (x)     

/* Bit definitions and macros for GL3IACK */
#define MCF_IACK_GL3IACK_VECTOR(x)      (x)     

/* Bit definitions and macros for GL4IACK */
#define MCF_IACK_GL4IACK_VECTOR(x)      (x)     

/* Bit definitions and macros for GL5IACK */
#define MCF_IACK_GL5IACK_VECTOR(x)      (x)     

/* Bit definitions and macros for GL6IACK */
#define MCF_IACK_GL6IACK_VECTOR(x)      (x)     

/* Bit definitions and macros for GL7IACK */
#define MCF_IACK_GL7IACK_VECTOR(x)      (x)     

/********************************************************************/

#endif /* __MCF5445X_IACK_H__ */
