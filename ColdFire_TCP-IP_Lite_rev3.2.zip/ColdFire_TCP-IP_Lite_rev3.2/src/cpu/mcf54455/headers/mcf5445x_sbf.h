/*
 * File:    mcf5445x_sbf.h
 * Purpose: Register and bit definitions
 */

#ifndef __MCF5445X_SBF_H__
#define __MCF5445X_SBF_H__

/*********************************************************************
*
* Serial Boot Facility (SBF)
*
*********************************************************************/

/* Register read/write macros */
#define MCF_SBF_SBFSR           (*(vuint16*)(0xFC0A0018))   /* Serial Boot Facility Status Register */
#define MCF_SBF_SBFCR           (*(vuint16*)(0xFC0A0020))   /* Serial Boot Facility Control Register */

/* Bit definitions and macros for SBFSR */
#define MCF_SBF_SBFSR_BLL(x)    (x)     /* Boot load length (read-only) */

/* Bit definitions and macros for SBFCR */
#define MCF_SBF_SBFCR_BLDIV(x)      (((x)&0x000F))  /* Boot loader clock divider */
#define MCF_SBF_SBFCR_FR            (0x0010)        /* Fast read */

/********************************************************************/

#endif /* __MCF5445X_SBF_H__ */
