/*
 * \file    watchdog.h
 * \brief   Driver for SCM Watchdog Timer
 * \version $Revision: 1.1 $
 * \author  Michael Norman
 */

#ifndef __WATCHDOG_H__
#define __WATCHDOG_H__

/********************************************************************/

void
watchdog_init (void);

void
watchdog_service (void);

/********************************************************************/

#endif
