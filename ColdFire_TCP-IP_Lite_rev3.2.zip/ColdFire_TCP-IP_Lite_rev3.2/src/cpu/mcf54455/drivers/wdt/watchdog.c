/*
 * \file    watchdog.c
 * \brief   Driver for SCM Watchdog Timer
 * \version $Revision: 1.1 $
 * \author  Michael Norman
 */

#include "common.h"
#include "watchdog.h"

/********************************************************************/
void
watchdog_init (void)
{
    /* 2^31 * 1/266MHz = ~8sec */
    MCF_SCM_CWCR = 0
        | MCF_SCM_CWCR_CWE
        | MCF_SCM_CWCR_CWRI_RESET
        | MCF_SCM_CWCR_CWT(31);
}
/********************************************************************/
void
watchdog_service (void)
{
    MCF_SCM_CWSR = 0x55;
    MCF_SCM_CWSR = 0xAA;
}
/********************************************************************/

