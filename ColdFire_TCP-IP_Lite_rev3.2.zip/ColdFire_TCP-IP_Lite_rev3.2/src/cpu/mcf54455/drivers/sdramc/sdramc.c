/*! 
 * \file    sdramc.c
 * \brief   Driver for the SDRAM Controller
 * \version $Revision: 1.1 $
 * \author  Michael Norman
 *
 * \todo    Add section assignment to allow linker files to 
 *          force all code and data into non-sdram address
 */

#include "common.h"
#include "sdramc.h"

/********************************************************************/
/*!
 * \brief   Enter self-refresh mode
 * 
 * Place the SDRAM devices into self-refresh mode and disable the module
 * clock.  This also disables SD_CLK and /SD_CLK.  The data in the devices
 * will be retained.
 */
void
sdram_enter_self_refresh (void)
{
    /* Only do this if the SDRAMC was already initialized */
    if (MCF_SDRAMC_SDCR & MCF_SDRAMC_SDCR_DDR_MODE)
    {
        /* Issue self-refresh command (CKE cleared w/ REF_EN set) */
        MCF_SDRAMC_SDCR &= ~MCF_SDRAMC_SDCR_CKE;
        
        /* Disable SDRAMC clock */
        MCF_PMM_PPMSR = MCF_PMM_PPMSR_SMCD(46);
    }
}
/********************************************************************/
/*!
 * \brief   Exit self-refresh mode
 */
void
sdram_exit_self_refresh (void)
{
    /* Only do this if the SDRAMC was already initialized */
    if (MCF_SDRAMC_SDCR & MCF_SDRAMC_SDCR_DDR_MODE)
    {
        /* Enable SDRAMC clock */
        MCF_PMM_PPMCR = MCF_PMM_PPMCR_CMCD(46);
        
        /* Reset the refresh-interval timer */
        MCF_SDRAMC_SDCR &= ~MCF_SDRAMC_SDCR_REF_EN;
        
        /* Exit self-refresh mode */
        MCF_SDRAMC_SDCR |= MCF_SDRAMC_SDCR
            | MCF_SDRAMC_SDCR_REF_EN
            | MCF_SDRAMC_SDCR_CKE;
    }
}
/********************************************************************/
/*!
 * \brief   Enter power-down mode
 * 
 * Place the SDRAM devices into power-down mode and disable the module
 * clock.  This also disables SD_CLK and /SD_CLK.  The data in the devices
 * will be retained.
 */
void
sdram_enter_power_down (void)
{
    /* Issue power-down command (CKE cleared w/ REF_EN cleared) */
    MCF_SDRAMC_SDCR = MCF_SDRAMC_SDCR
        & ~(MCF_SDRAMC_SDCR_CKE | MCF_SDRAMC_SDCR_REF_EN);
    
    /* Disable SDRAMC clock */
    MCF_PMM_PPMSR = MCF_PMM_PPMSR_SMCD(46);
}
/********************************************************************/
/*!
 * \brief   Exit power-down mode
 */
void
sdram_exit_power_down (void)
{
    /* Enable SDRAMC clock */
    MCF_PMM_PPMCR = MCF_PMM_PPMCR_CMCD(46);
    
    /* Exit power-down mode */
    MCF_SDRAMC_SDCR = MCF_SDRAMC_SDCR
        | MCF_SDRAMC_SDCR_REF_EN
        | MCF_SDRAMC_SDCR_CKE;
}
