/*
 * File:    sdramc.h
 * Purpose: Driver for the SDRAM Controller
 *
 * Notes:
 */

#ifndef _SDRAMC_H_
#define _SDRAMC_H_

/********************************************************************/

/*
 * Functions provided by this driver
 */
void
sdram_enter_self_refresh (void);

void
sdram_exit_self_refresh (void);

void
sdram_enter_power_down (void);

void
sdram_exit_power_down (void);


/********************************************************************/

#endif /* _SDRAMC_H_ */
