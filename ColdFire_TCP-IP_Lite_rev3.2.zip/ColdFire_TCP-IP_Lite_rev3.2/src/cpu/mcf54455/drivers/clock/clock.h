/*
 * File:    clock.h
 * Purpose: Driver for the MCF5208 on-chip Clock module
 *
 * Notes:
 */

#ifndef _CLOCK_H_
#define _CLOCK_H_

/********************************************************************/

/* 
 * PLL min/max specifications (in Hz)
 */
#define CLOCK_PLL_OUTDIV1_MIN   2       /*!< Minimum output1 divider */
#define CLOCK_PLL_OUTDIV1_MAX   4       /*!< Maximum output1 divider */

#define CLOCK_PLL_FVCO_MAX      540000000
#define CLOCK_PLL_FVCO_MIN      300000000
#define CLOCK_PLL_FSYS_MAX      266666666
#define CLOCK_PLL_FSYS_MIN      (CLOCK_PLL_FVCO_MIN/CLOCK_PLL_OUTDIV1_MAX)
#define CLOCK_PLL_FREF_MAX      66666666
#define CLOCK_PLL_FREF_MIN      16000000

#define CLOCK_PLL_PFD_MAX       34      /*!< Max PLL Feedback Divider */
#define CLOCK_PLL_PFD_MIN       4       /*!< Min PLL Feedback Divider */

/*
 * Low Power Divider specifications
 */
#define CLOCK_LPD_MIN           (1 << 0)    /* Divider (decoded) */
#define CLOCK_LPD_MAX           (1 << 15)   /* Divider (decoded) */

/* 
 * Flags for init routines
 */
#define CLOCK_PLL_LOLRE         0x01    /*!< Loss-of-lock reset enable */
#define CLOCK_PLL_LOLIRQ        0x02    /*!< Loss-of-lock interrupt enable */
#define CLOCK_PLL_FBCLK_NONE    0x04    /*!< Disable FBCLK */
#define CLOCK_PLL_FBCLK_DIV4    0x08    /*!< FBCLK = FSYS / 4 */
#define CLOCK_PLL_FBCLK_DIV8    0x10    /*!< FBCLK = FSYS / 8 */
#define CLOCK_PLL_FORCE_60      0x20    /*!< Allow for 60MHz USB from PLL */
#define CLOCK_PLL_DEFAULT       0x40    /*!< Leave default PLL settings */
#define CLOCK_PLL_LOLDIS        0x80    /*!< Disabled loss-of-lock logic

/********************************************************************/
/*
 * Functions provided by this driver
 */
int
clock_pll_init (int fref, int fsys, int flags, void (*isr)(void));

void
clock_irq_handler (void);

void
clock_enter_limp (int lpdiv);

void
clock_exit_limp (void);

int
clock_get_fsys (void);

int
clock_get_fbus (void);

int
clock_get_ffb (void);

int
clock_get_fpci (void);

/********************************************************************/

#endif /* _CLOCK_H_ */
