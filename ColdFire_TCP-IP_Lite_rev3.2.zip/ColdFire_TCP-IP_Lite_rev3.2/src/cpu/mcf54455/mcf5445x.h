/*
 * File:    mcf5445x.h
 * Purpose: Register and bit definitions
 */

#ifndef __MCF5445X_H__
#define __MCF5445X_H__

/********************************************************************/

#include "headers/mcf5445x_scm.h"
#include "headers/mcf5445x_xbs.h"
#include "headers/mcf5445x_fbcs.h"
#include "headers/mcf5445x_fec.h"
#include "headers/mcf5445x_rtc.h"
#include "headers/mcf5445x_pmm.h"
#include "headers/mcf5445x_edma.h"
#include "headers/mcf5445x_intc.h"
#include "headers/mcf5445x_iack.h"
#include "headers/mcf5445x_i2c.h"
#include "headers/mcf5445x_dspi.h"
#include "headers/mcf5445x_uart.h"
#include "headers/mcf5445x_dtim.h"
#include "headers/mcf5445x_pit.h"
#include "headers/mcf5445x_eport.h"
#include "headers/mcf5445x_wtm.h"
#include "headers/mcf5445x_sbf.h"
#include "headers/mcf5445x_rcm.h"
#include "headers/mcf5445x_ccm.h"
#include "headers/mcf5445x_gpio.h"
#include "headers/mcf5445x_pci.h"
#include "headers/mcf5445x_pciarb.h"
#include "headers/mcf5445x_usb.h"
#include "headers/mcf5445x_rng.h"
#include "headers/mcf5445x_sdramc.h"
#include "headers/mcf5445x_ssi.h"
#include "headers/mcf5445x_pll.h"

/* Include CPU specific driver headers */
#include "interrupts.h"
#include "gpio.h"
#include "cache.h"

/* Function prototypes for CPU specific routines */
void
cpu_startup (void);

void
cpu_interpret_ccr (void);

void 
cpu_pause (int);

void 
PIT_Timer_Init(uint8 PCSR, uint16 PMR);


/********************************************************************/

#endif /* __MCF5445X_H__ */