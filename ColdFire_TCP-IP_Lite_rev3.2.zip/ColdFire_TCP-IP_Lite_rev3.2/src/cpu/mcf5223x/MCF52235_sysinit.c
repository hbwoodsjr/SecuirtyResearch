/*
 * File:		sysinit.c
 * Purpose:		Reset configuration of the M5223EVB
 *
 * Notes:
 */

#include "common.h"

/********************************************************************/

void mcf5223x_init(void);
void mcf5223x_wtm_init(void);
void mcf5223x_pll_init(void);
void mcf5223x_scm_init(void);
void mcf5223x_gpio_init(void);
void mcf5223x_ePHY_init(void);
void mcf5223x_powerup_config(void);
void mcf5223x_wtm_config(void);
void dma0_init(int timer_norm);
void dma1_init(int timer_norm);

extern int poll_switches( void );

uint8 powerup_config_flags = 0;

/********************************************************************/
void
mcf5223x_init(void)
{

	MCF_GPIO_PDDPAR = 0x0F;		//enable pst[0..3]
		
	/*
	 * Set Port UA to initialize URXD0/UTXD0
	 */
    MCF_GPIO_PUAPAR = 0
        | MCF_GPIO_PUAPAR_URXD0_URXD0
        | MCF_GPIO_PUAPAR_UTXD0_UTXD0;

    MCF_GPIO_PUBPAR = 0
        | MCF_GPIO_PUBPAR_URXD1_URXD1
        | MCF_GPIO_PUBPAR_UTXD1_UTXD1;

	/* Set real time clock freq */

	MCF_CLOCK_RTCDR = 25000000;
	
	mcf5223x_wtm_init();
	mcf5223x_pll_init();
	mcf5223x_scm_init();
	mcf5223x_gpio_init();

    uart_init(0);
    uart_init(1);

	mcf5223x_powerup_config();
	mcf5223x_ePHY_init();
#if WD_TEST	
	mcf5223x_wtm_config();		//FSL Enable Watchdog Timer
#endif

	dma0_init(0xFFFFFFFF);
	dma1_init(0x00000001);

	MCF_CIM_RCR &= ~MCF_CIM_RCR_FRCRSTOUT; 

}

static uint8 x_cwcr=0;
static uint8 x_cwsr=0;

/********************************************************************/
void
mcf5223x_wtm_init(void)
{
	/*
	 * Disable Software Watchdog Timer
	 */
	MCF_SCM_CWCR = 0;
	
}
/********************************************************************/
void
mcf5223x_pll_init(void)
{
	/* The PLL pre-divider affects this!!! 
	 * Multiply 25Mhz reference crystal /CCHR by 12 to acheive system clock of 60Mhz
	 */

	MCF_CLOCK_SYNCR = MCF_CLOCK_SYNCR_MFD(4) | MCF_CLOCK_SYNCR_CLKSRC| MCF_CLOCK_SYNCR_PLLMODE | MCF_CLOCK_SYNCR_PLLEN ;

	while (!(MCF_CLOCK_SYNSR & MCF_CLOCK_SYNSR_LOCK))
	{
	}
}
/********************************************************************/
void
mcf5223x_scm_init(void)
{
	/*
	 * Enable on-chip modules to access internal SRAM
	 */
	MCF_SCM_RAMBAR = (0
		| MCF_SCM_RAMBAR_BA(SRAM_ADDRESS)
		| MCF_SCM_RAMBAR_BDE);
}
/********************************************************************/
tU08 gotlink;   					/**<Global Variable For Determination if
                                      * link is active (1=active)
                                      * defined in "main.c" */
int DUPLEX_phy_r17_dpm=0;              
                        
void
mcf5223x_gpio_init(void)
{
    /* 
     * Allow interrupts from ABORT, SW1, SW2, and SW3 (IRQ[1,4,7,11]) 
     */
     
#if 0  // EMG - Need to poll Switch state from web server
    /* Enable IRQ signals on the port */
    MCF_GPIO_PNQPAR = 0
        | MCF_GPIO_PNQPAR_IRQ1_IRQ1
        | MCF_GPIO_PNQPAR_IRQ4_IRQ4
        | MCF_GPIO_PNQPAR_IRQ7_IRQ7;
    
    MCF_GPIO_PGPPAR = 0
        | MCF_GPIO_PGPPAR_IRQ11_IRQ11;
        
    /* Set EPORT to look for rising edges */
    MCF_EPORT_EPPAR0 = 0
        | MCF_EPORT_EPPAR_EPPA1_RISING
        | MCF_EPORT_EPPAR_EPPA4_RISING
        | MCF_EPORT_EPPAR_EPPA7_RISING;
        
    MCF_EPORT_EPPAR1 = 0
        | MCF_EPORT_EPPAR_EPPA11_RISING;
        
    /* Clear any currently triggered events on the EPORT  */
    MCF_EPORT_EPIER0 = 0
        | MCF_EPORT_EPIER_EPIE1
        | MCF_EPORT_EPIER_EPIE4
        | MCF_EPORT_EPIER_EPIE7;
       
    MCF_EPORT_EPIER1 = 0
        | MCF_EPORT_EPIER_EPIE11;
       
    /* Enable interrupts in the interrupt controller */
	MCF_INTC0_IMRL &= 	~(MCF_INTC_IMRL_MASK1 | MCF_INTC_IMRL_MASKALL); // 
	MCF_INTC0_IMRL &= 	~(MCF_INTC_IMRL_MASK4 | MCF_INTC_IMRL_MASKALL); // 
	MCF_INTC0_IMRL &= 	~(MCF_INTC_IMRL_MASK7 | MCF_INTC_IMRL_MASKALL); // 

	MCF_INTC1_ICR35 = MCF_INTC_ICR_IL(4);
    MCF_INTC1_IMRH &=  ~(MCF_INTC_IMRH_MASK35);


#else
	  MCF_GPIO_PNQPAR = 0;
	  MCF_GPIO_PGPPAR = 0;

#endif

	/*
	 * Initialize PLDPAR to enable Ethernet LEDs
     * Ethernet status LEDs 
     */
     		MCF_GPIO_PLDPAR = (0
						| MCF_GPIO_PORTLD_PORTLD0 // ACTLED
						| MCF_GPIO_PORTLD_PORTLD1 // LNKLED
						| MCF_GPIO_PORTLD_PORTLD2 // SPDLED
						| MCF_GPIO_PORTLD_PORTLD3 // DUPLED
						| MCF_GPIO_PORTLD_PORTLD4 // COLLED
#ifndef M52233DEMO									//FSL M52233DEMO doesn't have RX/TXLEDs
						| MCF_GPIO_PORTLD_PORTLD5 // RXLED
						| MCF_GPIO_PORTLD_PORTLD6 // TXLED
#endif						
						);
 
	/*
	 * Initialize Port TA to enable Axcel control
	 */
	MCF_GPIO_PTAPAR = 0x00; 
	MCF_GPIO_DDRTA  = 0x0F;
	MCF_GPIO_PORTTA = 0x04;
}

/********************************************************************/
// Init ePHY
/********************************************************************/
void mcf5223x_ePHY_init(void)
{
	uint32 myctr, i; 				//generic counter variable
	static uint16 mymrdata, mymwdata;  	//temp variable for MII read/write data
  	uint16 reg0=0;

  //No link present
  gotlink = 0;

/********************************************************************/
// setup / enable MDIO interface <2.5Mhz
/********************************************************************/
    MCF_FEC_MSCR = MCF_FEC_MSCR_MII_SPEED((uint32)(SYS_CLK_MHZ/5));

	// Write EPHY address before EPHYEN is set; this will latch EPHY register 14 on reset
	// address PHY 0 (default address of internal EPHY)
	MCF_EPHY_EPHYCTL1 = MCF_EPHY_EPHYCTL1_PHYADD(FEC_PHY0); // FEC_PHY0 from MCF52235_EVB.h 
	// Enable EPHY module with PHY clocks disabled and ANDIS off
	// Do not turn on EPHY clocks until  EPHY is setup (see Below)
	MCF_EPHY_EPHYCTL0 =  MCF_EPHY_EPHYCTL0_DIS100 | MCF_EPHY_EPHYCTL0_DIS10;

	//turn on the EPHY - latches ANDIS in EPHY...note clocks not enabled yet.
	MCF_EPHY_EPHYCTL0 |= MCF_EPHY_EPHYCTL0_EPHYIEN; 	//FSL enable PHY interrupts
	MCF_EPHY_EPHYCTL0 |= MCF_EPHY_EPHYCTL0_EPHYEN; 

	while(!(fec_mii_write( FEC_PHY0, PHY_REG_CR,0x8000)))	// issue a reset to PHY
	do
	{
		while(!(fec_mii_read(FEC_PHY0, PHY_REG_CR, &reg0)))		//FSL read PHY control register
		{
			reg0=0;
		};
		
	} while(reg0&PHY_R0_RESET);		//Test RESET bit...1=in reset, 0=reset complete

	while(!(fec_mii_read(FEC_PHY0, PHY_REG_ANAR, &mymrdata)))	// read PHY AN Ad register
		;
	mymwdata = mymrdata & ~PHY_R4_NP;							// turn off next page (only 1g)
	while(!(fec_mii_write( FEC_PHY0, PHY_REG_ANAR,mymwdata)))	// update PHY AN Ad register
		;					
	// Wait 360us for EPHY to start-up,
	// see table 30 in Data sheet.
	for (myctr=2400; myctr >0; myctr--)
	{
		asm (	nop);
	}

	while(!(fec_mii_read(FEC_PHY0, PHY_REG_CR, &reg0)))			// read PHY control register
	{
		reg0=0;
	};

#if (!AUTO)		// manually set the advertising capability to only one choice
	while(!(fec_mii_read(FEC_PHY0, PHY_REG_ANAR, &mymrdata)))	// read PHY AN Ad register
		;
	mymrdata &= ~(PHY_R4_100F | PHY_R4_100H | PHY_R4_10F | PHY_R4_10H); // clear all capabilities
	if (BaseT==100)					// BaseT set to 100mpbs
	{
		reg0 |= 0x2000;				// 100Mbps
		reg0 &= ~0x0100;			// Half Duplex
		mymwdata = mymrdata | PHY_R4_100H;		// advertise only 100 Half Duplex
	}
	else							// BaseT defaults to 10mbps
	{
		reg0 &= ~0x2000;			// 10Mbps
		reg0 &= ~0x0100;			// Half Duplex
		mymwdata = mymrdata | PHY_R4_10H;		// advertise only 100 Half Duplex
	}

	while(!(fec_mii_write( FEC_PHY0, PHY_REG_ANAR,mymwdata)))	// write advertising choice
		;					
#endif

#if(MANUAL)
	reg0 &= ~(0x1000);				// clear auto-negotiation bit to disable
	reg0 &= ~0x0100;				// force Half Duplex when auto-negotiation not used
#endif
	
	while(!fec_mii_write( FEC_PHY0, PHY_REG_CR, reg0 ))				// write configuration
	;

  	// EPHY now ready; enable it by turning on clks. 
	MCF_EPHY_EPHYCTL0 &= ~(MCF_EPHY_EPHYCTL0_DIS100 | MCF_EPHY_EPHYCTL0_DIS10); 

// AUTONEGOTIATION ATTEMPT
	myctr=0;
	while (myctr<200000)		// while myctr < ~5 seconds try autonegotiation
	{
		while(!(fec_mii_read(FEC_PHY0, PHY_REG_SR, &mymrdata))){};	// read PHY AN Ad register
		if ((mymrdata & PHY_R1_LS)==1)
		{
			gotlink =1;
			goto exit;
		}
		myctr++;	// increment counter
	};

// 100mbps half duplex ATTEMPT if autonegotiation failed
	while(!(fec_mii_read(FEC_PHY0, PHY_REG_CR, &reg0)))			// read PHY control register
	{
		reg0=0;
	};
	reg0 |= 0x2000;				// 100Mbps
	reg0 &= ~0x0100;			// Half Duplex
	reg0 &= ~(0x1000);			// clear auto-negotiation bit to disable
	while(!fec_mii_write( FEC_PHY0, PHY_REG_CR, reg0 ))			// write configuration
	;
	while(!(fec_mii_read(FEC_PHY0, PHY_REG_ANAR, &mymrdata)))	// read PHY AN Ad register
		;
	mymrdata &= ~(PHY_R4_100F | PHY_R4_100H | PHY_R4_10F | PHY_R4_10H); // clear all capabilities
	mymwdata = mymrdata | PHY_R4_100H;		// advertise only 100 Half Duplex
	while(!(fec_mii_write( FEC_PHY0, PHY_REG_ANAR,mymwdata)))	// write advertising choice
		;					
	myctr=0;
	while (myctr<200000)		// while myctr < ~5 seconds try 100mbps half duplex
	{
		while(!(fec_mii_read(FEC_PHY0, PHY_REG_SR, &mymrdata))){};	// read PHY AN Ad register
		if ((mymrdata & PHY_R1_LS)==1)
		{
			gotlink =1;
			goto exit;
		}
		myctr++;	// increment counter
	};

// 10mbps half duplex ATTEMPT if 100mbps half duplex failed
	while(!(fec_mii_read(FEC_PHY0, PHY_REG_CR, &reg0)))			// read PHY control register
	{
		reg0=0;
	};
	reg0 &= ~0x2000;			// 10Mbps
	reg0 &= ~0x0100;			// Half Duplex
	reg0 &= ~(0x1000);			// clear auto-negotiation bit to disable
	while(!fec_mii_write( FEC_PHY0, PHY_REG_CR, reg0 ))			// write configuration
	;
	while(!(fec_mii_read(FEC_PHY0, PHY_REG_ANAR, &mymrdata)))	// read PHY AN Ad register
		;
	mymrdata &= ~(PHY_R4_100F | PHY_R4_100H | PHY_R4_10F | PHY_R4_10H); // clear all capabilities
	mymwdata = mymrdata | PHY_R4_10H;		// advertise only 100 Half Duplex
	while(!(fec_mii_write( FEC_PHY0, PHY_REG_ANAR,mymwdata)))	// write advertising choice
		;					
	myctr=0;
	while (myctr<200000)		// while myctr < ~5 seconds try 100mbps half duplex
	{
		while(!(fec_mii_read(FEC_PHY0, PHY_REG_SR, &mymrdata))){};	// read PHY AN Ad register
		if ((mymrdata & PHY_R1_LS)==1)
		{
			gotlink =1;
			goto exit;
		}
		myctr++;	// increment counter
	};

// ELSE COULD NOT ESTABLISH LINK.....print error message
	printf("\n\n .....COULD NOT ESTABLISH LINK.....\n\n");	
    gotlink = 0;
    
exit:
	/********************************************************************/
	// setup / enable interrupts
	/********************************************************************/
	//Enable PHY interrupts in Reg 16 (PHY Interrupt Control Register)
	mymwdata = PHY_R16_ACKIE | PHY_R16_PRIE | PHY_R16_LCIE | PHY_R16_ANIE;
	mymwdata = mymwdata | PHY_R16_PDFIE | PHY_R16_RFIE | PHY_R16_JABIE;
	//Set PHY Interrupt Control Register
	while (!(fec_mii_write(FEC_PHY0, PHY_REG_IR, mymwdata))){};
	MCF_INTC0_ICR36 = MCF_INTC_ICR_IL(PHY_INT_LEVEL);
	MCF_INTC0_IMRH &=  ~(MCF_INTC_IMRH_INT_MASK36);
//read PHY proprietary status register (17)
	while ( !(fec_mii_read(FEC_PHY0, PHY_REG_PSR, &mymrdata)) )
	{
     	
	};
   
	DUPLEX_phy_r17_dpm = (mymrdata&PHY_R17_DPM);	//0=half duplex, 1=full duplex

  if(gotlink==1)
  {
	if ((mymrdata & PHY_R17_SPD) == PHY_R17_SPD)  
	{
		printf("\n100bT - ");
	}
	else		
	{
	    printf("\n10bT - ");
	}

	if ((mymrdata & PHY_R17_DPM) == PHY_R17_DPM)  
	{
	    printf("Full Dup\n\n");
	}
	else		
	{
	    printf("Half Dup\n\n");
	}
  }
	
	return;
}
/********************************************************************/
// This function reads the switches at power-up, and sets a power-up
// config flag.
/********************************************************************/
void mcf5223x_powerup_config( void )
{
	powerup_config_flags = poll_switches();
}
/********************************************************************/
void
mcf5223x_wtm_config(void)
{
       /*
        * Disable Software Watchdog Timer
        */

    MCF_SCM_CWCR = 0;

       //defensive programming.

    MCF_SCM_CWSR = 0x55;    //step 1 to reset the core watchdog timeout counter
    MCF_SCM_CWSR = 0xAA;    //step 2 to reset the core watchdog timeout counter
    MCF_SCM_CWCR = 3;       //clear CWTAVAL and CWTIF

    /* Core Watchdog Timer enabled 
       Interrupt will occur if CWT unserviced for 2.237 s 
       */     

    MCF_SCM_CWCR =  (MCF_SCM_CWCR_CWE | MCF_SCM_CWCR_CWT(0x7) | MCF_SCM_CWCR_CWTA | MCF_SCM_CWCR_CWTAVAL | MCF_SCM_CWCR_CWTIF); 
    MCF_SCM_CWSR = 0x55; 	//step 1 to reset the core watchdog timeout counter
    MCF_SCM_CWSR = 0xAA;    //step 2 to reset the core watchdog timeout counter
	MCF_INTC0_ICR08  = MCF_INTC_ICR_IL(0x7) | MCF_INTC_ICR_IP(0x7);
	MCF_INTC0_IMRL &= ~(MCF_INTC_IMRL_INT_MASK8 | MCF_INTC_IMRL_MASKALL);
 
	mcf5xxx_irq_wd_enable();		//FSL uncomment to enable Watchdog Timer
	
}
/********************************************************************/
/********************************************************************/
void dma0_init(int timer_norm)
{
   /* Turn Module clock on */
     MCF_SCM_PPMRL &= ~MCF_SCM_PPMRL_CDTMR0;  
   /* Setting Interrupt Controller priority and level 
    MCF_INTC0_ICR(19) = 0
        | MCF_INTC_ICR_IP(MCF_INTC_ICR_IL(DMA_TIMER_LEVEL))
        | MCF_INTC_ICR_IL(1);*/
    
    /* Unmasking the corresponding interrupt mask for DTIM0 
    MCF_INTC0_IMRL &= ~(
          MCF_INTC_IMRL_INT_MASK19 
        | MCF_INTC_IMRL_MASKALL);*/

    /* Enable DMA Timer 0 */
    MCF_DTIM0_DTRR = (uint32)(timer_norm);
    MCF_DTIM0_DTER = MCF_DTIM_DTER_REF;
    MCF_DTIM0_DTMR = 0
        | MCF_DTIM_DTMR_PS(0)
        | MCF_DTIM_DTMR_FRR
        | MCF_DTIM_DTMR_CLK_DIV1;
        
    MCF_DTIM0_DTXMR = 0
        | MCF_DTIM_DTXMR_HALTED;
        
    /* Resetting Counter */      
    MCF_DTIM0_DTCN = 0;
    MCF_DTIM0_DTER = MCF_DTIM_DTER_REF;
    MCF_DTIM0_DTMR |= MCF_DTIM_DTMR_RST
    			   | MCF_DTIM_DTMR_OM;
//        		   | MCF_DTIM_DTMR_ORRI //enable int.
}
/*******************************************************************/
/********************************************************************/
void dma1_init(int timer_norm)
{
   /* Turn Module clock on */
     MCF_SCM_PPMRL &= ~MCF_SCM_PPMRL_CDTMR1;  
    /* Setting Interrupt Controller priority and level 
    MCF_INTC0_ICR(20) = 0
        | MCF_INTC_ICR_IP(MCF_INTC_ICR_IL(DMA_TIMER_LEVEL))
        | MCF_INTC_ICR_IL(4);*/
    
    /* Unmasking the corresponding interrupt mask for DTIM0 
    MCF_INTC0_IMRL &= ~(
          MCF_INTC_IMRL_INT_MASK20 
        | MCF_INTC_IMRL_MASKALL);*/

    /* Enable DMA Timer 0 */
    MCF_DTIM1_DTRR = (uint32)(timer_norm);
    MCF_DTIM1_DTER = MCF_DTIM_DTER_REF;
    MCF_DTIM1_DTMR = 0
        | MCF_DTIM_DTMR_PS(0)
        | MCF_DTIM_DTMR_FRR
        | MCF_DTIM_DTMR_CLK_DIV1;
        
    MCF_DTIM1_DTXMR = 0
        | MCF_DTIM_DTXMR_HALTED;
        
    /* Resetting Counter */      
    MCF_DTIM1_DTCN = 0;
    MCF_DTIM1_DTER = MCF_DTIM_DTER_REF;
    MCF_DTIM1_DTMR |= MCF_DTIM_DTMR_RST
    			   | MCF_DTIM_DTMR_OM;
//        		   | MCF_DTIM_DTMR_ORRI //enable int.

}
/*******************************************************************/
