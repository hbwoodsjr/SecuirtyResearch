/*
 * File:		processor.h
 * Purpose:		This header specifies which ColdFire processor will be used
 *				with the project.
 *
 * Notes:  FSL created file
 */

#ifndef _PROCESSOR_H
#define _PROCESSOR_H

/********************************************************************/

#define MCF5223x		1		/* This defines the processor being used */
#define FULL			0
#define HALF			1

#if 1							//FSL #if 1 (default) for M52233DEMO and #if 0 for M52235EVB
#define M52233DEMO		1		/* This defines the evb being used */
#define RevF			1		//FSL make RevF for final version //FSL Board revision RevC, RevD, or RevF (look on back of board)
#else
#define M52235EVB		1		/* This defines the evb being used */
#endif

#define AUTOIP			0		/* 0=AutoIP off (default), 1=AutoIP on */
#define DHCP			0		/* 0=DHCP capability off (default), 1=DHCP capability on */
#define CONSOLE_UART	0		/* Set to the respective UART number to use for console */
/* Default is 0; 1 works if evb supports it; 2 and above not configured in software/hardware  */

#define MANUAL			0		//FSL 0=do re-negotiation(default), 1=do not re-negotiation
#define AUTO			1		//FSL 0=autonegotiate one capability, 1=autonegotiate all capabilities(default)
#if (!AUTO)						//FLS DUPLEX and BaseT only used if AUTO=0
#define DUPLEX			HALF	//FSL enter HALF (default) or FULL to select Ethernet duplex mode
#define BaseT			10		//FSL set Ethernet BaseT to 10 (default) or 100
#endif
#define ETH_PORT		0		//FSL the MCF5223x has one Ethernet FEC port FEC0

#ifndef CLIENT
#define CLIENT			0		//FSL 1=client software operates. 0=server
#endif

#define ETH_PROCESSOR_H	1		//FSL comment out to have ipport.h values used

#if 1		//FSL Default settings
#define MAX_ETH_PKT 	1522	//FSL BIGBUFSIZE, TCP_MSS, and MTU calculated off of MAX_ETH_PKT
#define NUM_RXBDS    2							//FSL number of Receive Buffer Descriptors; default=2
#define NUM_TXBDS    (2*NUM_RXBDS)				//FSL number of Transmit Buffer Descriptors
#define NUMBIGBUFS   (NUM_RXBDS+NUM_TXBDS+1)	//FSL number of Big Buffers for Ethernet Frames
#define NUMLILBUFS   (NUM_TXBDS) 				//FSL number of Little Buffers for Ethernet Frames
#else		//FSL play around settings
#define MAX_ETH_PKT 	800		//FSL BIGBUFSIZE, TCP_MSS, and MTU calculated off of MAX_ETH_PKT
#define NUM_RXBDS    4							//FSL number of Receive Buffer Descriptors; default=2
#define NUM_TXBDS    (2*NUM_RXBDS)				//FSL number of Transmit Buffer Descriptors
#define NUMBIGBUFS   (NUM_RXBDS+NUM_TXBDS+1)	//FSL number of Big Buffers for Ethernet Frames
#define NUMLILBUFS   (NUM_TXBDS) 				//FSL number of Little Buffers for Ethernet Frames
#endif

//FSL Note that ALL ICR registers must have unique settings.  Below Interrupt Level
//FSL #defines by default have the Interrupt Priority = 0
#define DMA_TIMER_LEVEL 3		//FSL dma interrupt level									
#define FEC_INT_LEVEL	6		//FSL FEC interrupt level
#define PHY_INT_LEVEL	4		//FSL PHY interrupt level

#define WD_TEST			0		//FSL Enable watchdog timer module ability to reset device if bus hangs
								//FSL 0=disable, 1=enable

// FLASH Parameters 
// Start address for region of flash available for web page upload
#define FLASH_START_ADDRESS					0x44020000
// End address for region of flash available for web page upload
#define FLASH_END_ADDRESS					0x4403FFFF
// Flash erase page size
#define FLASH_PAGE_SIZE						0x0800
// Number of flash pages erased per task iteration
#define PAGES_PER_SESSION					0x08
// Address for flash region as seen by CPU
#define FAT_FILE_BASE_ADDR					0x00020000

/* 
 * Include the specific CPU header file 
 */

#include "MCF52235.h"					/* processor specific headers */
#include "MCF52235_evb.h"				/* evb specific headers */


/********************************************************************/
#endif /* _PROCESSOR_H */

