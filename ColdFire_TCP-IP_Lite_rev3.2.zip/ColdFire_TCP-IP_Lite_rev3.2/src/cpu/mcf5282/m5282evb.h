/*
 * File:		m5282evb.h
 * Purpose:		Evaluation board definitions and memory map information
 *
 * Notes:
 */

#ifndef _M5282EVB_H
#define _M5282EVB_H

/********************************************************************/

#include "mcf5xxx.h"
#include "io.h"

/********************************************************************/

/*
 * Debug prints ON (#undef) or OFF (#define)
 */
#undef DEBUG

/* 
 * System Bus Clock Info 
 */
#define REF_CLK_MHZ     (8)
#define REF_CLK_KHZ     (8000)
#define	SYS_CLK_MHZ		(64)		/* system bus frequency in MHz */
#define SYS_CLK_KHZ		(64000)		/* system bus frequency in kHz */
extern int sys_clk_khz;
extern int sys_clk_mhz;
/* 
 * System Bus Clock Info 
 */
#define	SYSTEM_CLOCK	(64)		/* system bus frequency in MHz */

/*
 * LED Info
 */
//#undef HAS_LEDS
//#define HAS_LEDS 1

/*
 * Ethernet Port Info
 */
#define FEC_PHY0        (0x01)

/* 
 * Memory map definitions from linker command files 
 */
extern uint8 __IPSBAR[];
extern uint8 __SDRAM[];
extern uint8 __SDRAM_SIZE[];
extern uint8 __SRAM[];
extern uint8 __SRAM_SIZE[];
extern uint8 __EXT_SRAM[];
extern uint8 __EXT_SRAM_SIZE[];
extern uint8 __EXT_FLASH[];
extern uint8 __EXT_FLASH_SIZE[];

/* 
 * Memory Map Info 
 */
#define IPSBAR_ADDRESS			(uint32)__IPSBAR

#define SDRAM_ADDRESS			(uint32)__SDRAM
#define SDRAM_SIZE				(uint32)__SDRAM_SIZE

#define SRAM_ADDRESS			(uint32)__SRAM
#define SRAM_SIZE				(uint32)__SRAM_SIZE

#define EXT_SRAM_ADDRESS		(uint32)__EXT_SRAM
#define EXT_SRAM_SIZE			(uint32)__EXT_SRAM_SIZE

#define FLASH_ADDRESS			(uint32)__FLASH
#define FLASH_SIZE				(uint32)__FLASH_SIZE

#define EXT_FLASH_ADDRESS		(uint32)__EXT_FLASH
#define EXT_FLASH_SIZE			(uint32)__EXT_FLASH_SIZE

/*
 *	Interrupt Controller Definitions
 */
#define TIMER_NETWORK_LEVEL		3
#define FEC_LEVEL				4

/*
 *	Timer period info
 */
#define TIMER_NETWORK_PERIOD	1000000000/0x10000	/* 1 sec / max timeout */
#define HAS_LEDS	1			//FSL added to enable LEDS to blink on evb

/********************************************************************/
/********************************************************************/
/********************************************************************/
#ifdef HAS_LEDS /* { */    //FSL updated the LED definitions to work with m5282evb

	static unsigned char LED3=1,LED2=1,LED1=1,LED0=1;

	#define LED0_TOGGLE     MCF_GPIO_PORTTD = (uint8)(MCF_GPIO_PORTTD ^ MCF_GPIO_PORTx0)
	#define LED1_TOGGLE     MCF_GPIO_PORTTD = (uint8)(MCF_GPIO_PORTTD ^ MCF_GPIO_PORTx2);
	#define LED2_TOGGLE     MCF_GPIO_PORTTC = (uint8)(MCF_GPIO_PORTTC ^ MCF_GPIO_PORTx0);
	#define LED3_TOGGLE     MCF_GPIO_PORTTC = (uint8)(MCF_GPIO_PORTTC ^ MCF_GPIO_PORTx2);

	#define LED0_ON     	MCF_GPIO_PORTTC = (uint8)(MCF_GPIO_PORTTC | MCF_GPIO_PORTx0)
	#define LED1_ON		    MCF_GPIO_PORTTC = (uint8)(MCF_GPIO_PORTTC | MCF_GPIO_PORTx2);
	#define LED2_ON         MCF_GPIO_PORTTC = (uint8)(MCF_GPIO_PORTTC | MCF_GPIO_PORTx0);
	#define LED3_ON         MCF_GPIO_PORTTC = (uint8)(MCF_GPIO_PORTTC | MCF_GPIO_PORTx2);

	#define LED0_OFF        MCF_GPIO_PORTTC = (uint8)(MCF_GPIO_PORTTC & MCF_GPIO_PORTx0)
	#define LED1_OFF        MCF_GPIO_PORTTC = (uint8)(MCF_GPIO_PORTTC & ~MCF_GPIO_PORTx2);
	#define LED2_OFF        MCF_GPIO_PORTTC = (uint8)(MCF_GPIO_PORTTC & MCF_GPIO_PORTx0);
	#define LED3_OFF        MCF_GPIO_PORTTC = (uint8)(MCF_GPIO_PORTTC & ~MCF_GPIO_PORTx2);

	#define LED_INIT()		Leds_Init()
#else  /* No LEDS  */
	#define LED0_TOGGLE     /*MCF_GPIO_PORTTC = (uint8)(MCF_GPIO_PORTTC ^ MCF_GPIO_PORTTC_PORTTC0)*/
	#define LED1_TOGGLE     /*MCF_GPIO_PORTTC = (uint8)(MCF_GPIO_PORTTC ^ MCF_GPIO_PORTTC_PORTTC1)*/;
	#define LED2_TOGGLE     /*MCF_GPIO_PORTTC = (uint8)(MCF_GPIO_PORTTC ^ MCF_GPIO_PORTTC_PORTTC2)*/;
	#define LED3_TOGGLE     /*MCF_GPIO_PORTTC = (uint8)(MCF_GPIO_PORTTC ^ MCF_GPIO_PORTTC_PORTTC3)*/;

	#define LED0_ON     	/*MCF_GPIO_PORTTC = (uint8)(MCF_GPIO_PORTTC | MCF_GPIO_PORTTC_PORTTC0)*/
	#define LED1_ON		    /*MCF_GPIO_PORTTC = (uint8)(MCF_GPIO_PORTTC | MCF_GPIO_PORTTC_PORTTC1)*/;
	#define LED2_ON         /*MCF_GPIO_PORTTC = (uint8)(MCF_GPIO_PORTTC | MCF_GPIO_PORTTC_PORTTC2)*/;
	#define LED3_ON         /*MCF_GPIO_PORTTC = (uint8)(MCF_GPIO_PORTTC | MCF_GPIO_PORTTC_PORTTC3)*/;

	#define LED0_OFF        /*MCF_GPIO_PORTTC = (uint8)(MCF_GPIO_PORTTC & ~MCF_GPIO_PORTTC_PORTTC0)*/
	#define LED1_OFF        /*MCF_GPIO_PORTTC = (uint8)(MCF_GPIO_PORTTC & ~MCF_GPIO_PORTTC_PORTTC1)*/;
	#define LED2_OFF        /*MCF_GPIO_PORTTC = (uint8)(MCF_GPIO_PORTTC & ~MCF_GPIO_PORTTC_PORTTC2)*/;
	#define LED3_OFF        /*MCF_GPIO_PORTTC = (uint8)(MCF_GPIO_PORTTC & ~MCF_GPIO_PORTTC_PORTTC3)*/;
	#define LED_INIT()		/*void()*/
#endif
	#define RXLED_TOGGLE     /*MCF_GPIO_PORTLD = (uint8)(MCF_GPIO_PORTLD ^ MCF_GPIO_PORTLD_PORTLD5)*/;
	#define TXLED_TOGGLE     /*MCF_GPIO_PORTLD = (uint8)(MCF_GPIO_PORTLD ^ MCF_GPIO_PORTLD_PORTLD6)*/;
	#define ACTLED_TOGGLE    /*MCF_GPIO_PORTLD = (uint8)(MCF_GPIO_PORTLD ^ MCF_GPIO_PORTLD_PORTLD0)*/;
/********************************************************************/
/********************************************************************/
void Leds_Init();
void board_led_display(uint8 number);
/********************************************************************/
/********************************************************************/
#endif /* _M5282EVB_H */
