/*
 * File:		mcf5282_sysinit.c
 * Purpose:		Reset configuration of the M5282EVB
 *
 * Notes:
 */

#include "common.h"

/********************************************************************/

void mcf5282_init(void);
void mcf5282_wtm_init(void);
void mcf5282_pll_init(void);
#ifndef MCF5282
void mcf5282_uart_init(void);
#endif
void mcf5282_scm_init(void);
void mcf5282_gpio_init(void);
void mcf5282_ePHY_init(void);
void mcf5282_powerup_config(void);


extern int SoftEthernetNegotiation( int seconds );
extern int poll_switches( void );


uint8	powerup_config_flags = 0;

/********************************************************************/
void
mcf5282_init(void)
{
	mcf5282_wtm_init();
	mcf5282_pll_init();
	mcf5282_scm_init();
	mcf5282_gpio_init();
    uart_init(0);
#ifndef M5282LITE    
    uart_init(1);
#endif    

	mcf5282_powerup_config();
//FSL    MCF_FEC_MSCR = MCF_FEC_MSCR_MII_SPEED(0x0A);
    /*
     * Configure MII interface speed. Must be <= 2.5MHz
     *
     * Desired MII clock is 2.5MHz
     * MII Speed Setting = System_Clock_Bus_Speed / (2.5MHz * 2)
     */
    MCF_FEC_MSCR = MCF_FEC_MSCR_MII_SPEED((uint32)(SYS_CLK_MHZ/5));	
    
	mcf5282_ePHY_init();
    
#if 0    
/* Turn Instruction Cache ON */
   mcf5xxx_wr_cacr(0
		| MCF5XXX_CACR_CENB
		| MCF5XXX_CACR_CINV
		| MCF5XXX_CACR_DISD
		| MCF5XXX_CACR_CEIB
		| MCF5XXX_CACR_CLNF_00);
#endif		    
}
/********************************************************************/
void
mcf5282_wtm_init(void)
{
	/*
	 * Disable Software Watchdog Timer
	 */
	MCF_SCM_CWCR = 0;		//FSL SCM core watchdog
	MCF_WTM_WCR  = 0;		//FSL Watchdog timer module
}
/********************************************************************/
void
mcf5282_pll_init(void)
{
	MCF_CLOCK_SYNCR = MCF_CLOCK_SYNCR_MFD(2);

	while (!(MCF_CLOCK_SYNSR & MCF_CLOCK_SYNSR_LOCK))
	{
	}
}
/********************************************************************/
void
mcf5282_scm_init(void)
{
	/*
	 * Enable on-chip modules to access internal SRAM
	 */
	MCF_SCM_RAMBAR = (0
		| MCF_SCM_RAMBAR_BA(SRAM_ADDRESS)
		| MCF_SCM_RAMBAR_BDE);
}
/********************************************************************/
tU08	gotlink;   						/**<Global Variable For Determination if
                                      * link is active (1=active)
                                      * defined in "main.c" */
                                      
void
mcf5282_gpio_init(void)
{

	/*
	 * Set Port UA to initialize URXD0/UTXD0, URXD1/UTXD1
	 */
    MCF_GPIO_PUAPAR = 0x0F;
    
	/*
	 * When booting from external Flash, the port-size is less than
	 * the port-size of SDRAM.  In this case it is necessary to enable 
	 * Data[23:0] on Ports B, C, and D.
	 */ 
	MCF_GPIO_PBCDPAR = (0
		| MCF_GPIO_PBCDPAR_PBPA
		| MCF_GPIO_PBCDPAR_PCDPA);

	/* 
	 * Initialize PEHLPAR to enable Ethernet signals 
	 */
	MCF_GPIO_PEHLPAR = 0xC0;

	/* 
	 * ChipSelect 1 - External SRAM 
	 */
	MCF_CS1_CSAR = MCF_CS_CSAR_BA(EXT_SRAM_ADDRESS);
	MCF_CS1_CSCR = MCF_CS_CSCR_AA | MCF_CS_CSCR_PS_32;
	MCF_CS1_CSMR = MCF_CS_CSMR_BAM_512K | MCF_CS_CSMR_V;
    
    /* 
	 * ChipSelect 0 - External Flash 
	 */ 
	MCF_CS0_CSAR = MCF_CS_CSAR_BA(EXT_FLASH_ADDRESS);
	MCF_CS0_CSCR = (0
		| MCF_CS_CSCR_WS(6)
		| MCF_CS_CSCR_AA
		| MCF_CS_CSCR_PS_16);
	MCF_CS0_CSMR = MCF_CS_CSMR_BAM_2M | MCF_CS_CSMR_V;

	
	/*
	 * Clear mask all bit to allow intrrupts
	 */
    MCF_INTC0_IMRL &= ~(MCF_INTC_IMRL_MASKALL);
}

/********************************************************************/
// Init external PHY...AMD Am79C874
/********************************************************************/
int DUPLEX_phy_r17_dpm=0;
void mcf5282_ePHY_init(void)
{
	uint32 		myctr; 					//generic counter variable
	uint16 		mymrdata, mymwdata;    	//temp variable for MII read/write data
  	uint16		reg0, reg1, reg4;				//


	MCF_GPIO_PEHLPAR = 0xC0;
	MCF_GPIO_PASPAR = (MCF_GPIO_PASPAR & 0xF0FF) | 0x0F00;

	// Force re-negotiation
	for(myctr=0;myctr<20000000;myctr++)			// delay
	{
		asm(	nop);
	}
	
	(void)fec_mii_read(FEC_PHY0, PHY_REG_CR, &reg0);
	(void)fec_mii_write( 0, 0, (reg0|0x0200) ); // Force re-negotiate 
	(void)fec_mii_read(FEC_PHY0, 18, &mymrdata);
	DUPLEX_phy_r17_dpm = (mymrdata&0x0800)>>11;	// 1=full,0=half duplex...used in ifec.c

	(void)fec_mii_read(FEC_PHY0, PHY_REG_CR, &mymrdata);
	(void)fec_mii_read(FEC_PHY0, PHY_REG_SR, &mymrdata);
	printf("\n\nEthernet Link ");
	if(mymrdata&PHY_R1_LS)
	{
		printf("Established\n");
	}
	else
	{
		printf("NOT Established\n");
		
	}
	for (myctr=10000; myctr >0; myctr--){uart_check();}

	return;
}


/********************************************************************/
// powerup_config		Written by Eric Gregori
//
// This function reads the switches at power-up, and sets a power-up
// config flag.
/********************************************************************/
void mcf5282_powerup_config( void )
{
	powerup_config_flags = poll_switches() | 0x80;		
}
