/* Coldfire C Header File
 * Copyright Freescale Semiconductor Inc
 * All rights reserved.
 *
 * 2007/03/19 Revision: 0.9
 */

#ifndef __MCF5208_PMM_H__
#define __MCF5208_PMM_H__


/*********************************************************************
*
* Power Management (PMM)
*
*********************************************************************/

/* Register read/write macros */
#define MCF_PMM_WCR                          (*(vuint8 *)(0xFC040013))
#define MCF_PMM_PPMSR0                       (*(vuint8 *)(0xFC04002C))
#define MCF_PMM_PPMCR0                       (*(vuint8 *)(0xFC04002D))
#define MCF_PMM_PPMHR0                       (*(vuint32*)(0xFC040030))
#define MCF_PMM_PPMLR0                       (*(vuint32*)(0xFC040034))
#define MCF_PMM_LPCR                         (*(vuint8 *)(0xFC0A0007))
#define MCF_PMM_MISCCR                       (*(vuint16*)(0xFC0A0010))


/* Bit definitions and macros for MCF_PMM_WCR */
#define MCF_PMM_WCR_PRILVL(x)                (((x)&0x7)<<0)
#define MCF_PMM_WCR_ENBWCR                   (0x80)

/* Bit definitions and macros for MCF_PMM_PPMSR0 */
#define MCF_PMM_PPMSR0_SMCD(x)               (((x)&0x3F)<<0)
#define MCF_PMM_PPMSR0_SAMCD                 (0x40)

/* Bit definitions and macros for MCF_PMM_PPMCR0 */
#define MCF_PMM_PPMCR0_CMCD(x)               (((x)&0x3F)<<0)
#define MCF_PMM_PPMCR0_CAMCD                 (0x40)

/* Bit definitions and macros for MCF_PMM_PPMHR0 */
#define MCF_PMM_PPMHR0_CD32                  (0x1)
#define MCF_PMM_PPMHR0_CD33                  (0x2)
#define MCF_PMM_PPMHR0_CD34                  (0x4)
#define MCF_PMM_PPMHR0_CD35                  (0x8)
#define MCF_PMM_PPMHR0_CD36                  (0x10)
#define MCF_PMM_PPMHR0_CD40                  (0x100)
#define MCF_PMM_PPMHR0_CD41                  (0x200)
#define MCF_PMM_PPMHR0_CD42                  (0x400)

/* Bit definitions and macros for MCF_PMM_PPMLR0 */
#define MCF_PMM_PPMLR0_CD2                   (0x4)
#define MCF_PMM_PPMLR0_CD12                  (0x1000)
#define MCF_PMM_PPMLR0_CD17                  (0x20000)
#define MCF_PMM_PPMLR0_CD18                  (0x40000)
#define MCF_PMM_PPMLR0_CD21                  (0x200000)
#define MCF_PMM_PPMLR0_CD22                  (0x400000)
#define MCF_PMM_PPMLR0_CD23                  (0x800000)
#define MCF_PMM_PPMLR0_CD24                  (0x1000000)
#define MCF_PMM_PPMLR0_CD25                  (0x2000000)
#define MCF_PMM_PPMLR0_CD26                  (0x4000000)
#define MCF_PMM_PPMLR0_CD28                  (0x10000000)
#define MCF_PMM_PPMLR0_CD29                  (0x20000000)
#define MCF_PMM_PPMLR0_CD30                  (0x40000000)
#define MCF_PMM_PPMLR0_CD31                  (0x80000000)

/* Bit definitions and macros for MCF_PMM_LPCR */
#define MCF_PMM_LPCR_STPMD(x)                (((x)&0x3)<<0x3)
#define MCF_PMM_LPCR_STPMD_SYS_DISABLED      (0)
#define MCF_PMM_LPCR_STPMD_SYS_BUSCLK_DISABLED (0x8)
#define MCF_PMM_LPCR_STPMD_ONLY_OSC_ENABLED  (0x10)
#define MCF_PMM_LPCR_STPMD_ALL_DISABLED      (0x18)
#define MCF_PMM_LPCR_FWKUP                   (0x20)
#define MCF_PMM_LPCR_LPMD(x)                 (((x)&0x3)<<0x6)
#define MCF_PMM_LPCR_LPMD_RUN                (0)
#define MCF_PMM_LPCR_LPMD_DOZE               (0x40)
#define MCF_PMM_LPCR_LPMD_WAIT               (0x80)
#define MCF_PMM_LPCR_LPMD_STOP               (0xC0)

/* Bit definitions and macros for MCF_PMM_MISCCR */
#define MCF_PMM_MISCCR_LPDIV(x)              (((x)&0xF)<<0)
#define MCF_PMM_MISCCR_LIMP                  (0x1000)
#define MCF_PMM_MISCCR_PLLLOCK               (0x2000)


#endif /* __MCF5208_PMM_H__ */
