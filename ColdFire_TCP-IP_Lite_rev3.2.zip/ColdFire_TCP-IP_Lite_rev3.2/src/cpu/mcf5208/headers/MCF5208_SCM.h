/* Coldfire C Header File
 * Copyright Freescale Semiconductor Inc
 * All rights reserved.
 *
 * 2007/03/19 Revision: 0.9
 */

#ifndef __MCF5208_SCM_H__
#define __MCF5208_SCM_H__


/*********************************************************************
*
* System Control Module (SCM)
*
*********************************************************************/

/* Register read/write macros */
#define MCF_SCM_MPR                          (*(vuint32*)(0xFC000000))
#define MCF_SCM_PACRA                        (*(vuint32*)(0xFC000020))
#define MCF_SCM_PACRB                        (*(vuint32*)(0xFC000024))
#define MCF_SCM_PACRC                        (*(vuint32*)(0xFC000028))
#define MCF_SCM_PACRD                        (*(vuint32*)(0xFC00002C))
#define MCF_SCM_PACRE                        (*(vuint32*)(0xFC000040))
#define MCF_SCM_PACRF                        (*(vuint32*)(0xFC000044))
#define MCF_SCM_BMT                          (*(vuint32*)(0xFC000054))
#define MCF_SCM_CWCR                         (*(vuint16*)(0xFC040016))
#define MCF_SCM_CWSR                         (*(vuint8 *)(0xFC04001B))
#define MCF_SCM_SCMISR                       (*(vuint8 *)(0xFC04001F))
#define MCF_SCM_CFADR                        (*(vuint32*)(0xFC040070))
#define MCF_SCM_CFIER                        (*(vuint8 *)(0xFC040075))
#define MCF_SCM_CFLOC                        (*(vuint8 *)(0xFC040076))
#define MCF_SCM_CFATR                        (*(vuint8 *)(0xFC040077))
#define MCF_SCM_CFDTR                        (*(vuint32*)(0xFC04007C))


/* Bit definitions and macros for MCF_SCM_MPR */
#define MCF_SCM_MPR_MPL2                     (0x100000)
#define MCF_SCM_MPR_MTW2                     (0x200000)
#define MCF_SCM_MPR_MTR2                     (0x400000)
#define MCF_SCM_MPR_MPL1                     (0x1000000)
#define MCF_SCM_MPR_MTW1                     (0x2000000)
#define MCF_SCM_MPR_MTR1                     (0x4000000)
#define MCF_SCM_MPR_MPL0                     (0x10000000)
#define MCF_SCM_MPR_MTW0                     (0x20000000)
#define MCF_SCM_MPR_MTR0                     (0x40000000)
#define MCF_SCM_MPR_MPROT2(x)                (((x)&0xF)<<0x14)
#define MCF_SCM_MPR_MPROT1(x)                (((x)&0xF)<<0x18)
#define MCF_SCM_MPR_MPROT0(x)                (((x)&0xF)<<0x1C)
#define MCF_SCM_MPR_MPROT_MTR                (0x4)
#define MCF_SCM_MPR_MPROT_MTW                (0x2)
#define MCF_SCM_MPR_MPROT_MPL                (0x1)

/* Bit definitions and macros for MCF_SCM_PACRA */
#define MCF_SCM_PACRA_TP2                    (0x100000)
#define MCF_SCM_PACRA_WP2                    (0x200000)
#define MCF_SCM_PACRA_SP2                    (0x400000)
#define MCF_SCM_PACRA_TP1                    (0x1000000)
#define MCF_SCM_PACRA_WP1                    (0x2000000)
#define MCF_SCM_PACRA_SP1                    (0x4000000)
#define MCF_SCM_PACRA_TP0                    (0x10000000)
#define MCF_SCM_PACRA_WP0                    (0x20000000)
#define MCF_SCM_PACRA_SP0                    (0x40000000)
#define MCF_SCM_PACRA_PACR2(x)               (((x)&0xF)<<0x14)
#define MCF_SCM_PACRA_PACR1(x)               (((x)&0xF)<<0x18)
#define MCF_SCM_PACRA_PACR0(x)               (((x)&0xF)<<0x1C)
#define MCF_SCM_PACRA_PACR_SP                (0x4)
#define MCF_SCM_PACRA_PACR_WP                (0x2)
#define MCF_SCM_PACRA_PACR_TP                (0x1)

/* Bit definitions and macros for MCF_SCM_PACRB */
#define MCF_SCM_PACRB_TP12                   (0x1000)
#define MCF_SCM_PACRB_WP12                   (0x2000)
#define MCF_SCM_PACRB_SP12                   (0x4000)
#define MCF_SCM_PACRB_PACR12(x)              (((x)&0xF)<<0xC)

/* Bit definitions and macros for MCF_SCM_PACRC */
#define MCF_SCM_PACRC_TP23                   (0x1)
#define MCF_SCM_PACRC_WP23                   (0x2)
#define MCF_SCM_PACRC_SP23                   (0x4)
#define MCF_SCM_PACRC_TP22                   (0x10)
#define MCF_SCM_PACRC_WP22                   (0x20)
#define MCF_SCM_PACRC_SP22                   (0x40)
#define MCF_SCM_PACRC_TP21                   (0x100)
#define MCF_SCM_PACRC_WP21                   (0x200)
#define MCF_SCM_PACRC_SP21                   (0x400)
#define MCF_SCM_PACRC_TP18                   (0x100000)
#define MCF_SCM_PACRC_WP18                   (0x200000)
#define MCF_SCM_PACRC_SP18                   (0x400000)
#define MCF_SCM_PACRC_TP17                   (0x1000000)
#define MCF_SCM_PACRC_WP17                   (0x2000000)
#define MCF_SCM_PACRC_SP17                   (0x4000000)
#define MCF_SCM_PACRC_TP16                   (0x10000000)
#define MCF_SCM_PACRC_WP16                   (0x20000000)
#define MCF_SCM_PACRC_SP16                   (0x40000000)
#define MCF_SCM_PACRC_PACR23(x)              (((x)&0xF)<<0)
#define MCF_SCM_PACRC_PACR22(x)              (((x)&0xF)<<0x4)
#define MCF_SCM_PACRC_PACR21(x)              (((x)&0xF)<<0x8)
#define MCF_SCM_PACRC_PACR18(x)              (((x)&0xF)<<0x14)
#define MCF_SCM_PACRC_PACR17(x)              (((x)&0xF)<<0x18)
#define MCF_SCM_PACRC_PACR16(x)              (((x)&0xF)<<0x1C)

/* Bit definitions and macros for MCF_SCM_PACRD */
#define MCF_SCM_PACRD_TP31                   (0x1)
#define MCF_SCM_PACRD_WP31                   (0x2)
#define MCF_SCM_PACRD_SP31                   (0x4)
#define MCF_SCM_PACRD_TP30                   (0x10)
#define MCF_SCM_PACRD_WP30                   (0x20)
#define MCF_SCM_PACRD_SP30                   (0x40)
#define MCF_SCM_PACRD_TP29                   (0x100)
#define MCF_SCM_PACRD_WP29                   (0x200)
#define MCF_SCM_PACRD_SP29                   (0x400)
#define MCF_SCM_PACRD_TP28                   (0x1000)
#define MCF_SCM_PACRD_WP28                   (0x2000)
#define MCF_SCM_PACRD_SP28                   (0x4000)
#define MCF_SCM_PACRD_TP26                   (0x100000)
#define MCF_SCM_PACRD_WP26                   (0x200000)
#define MCF_SCM_PACRD_SP26                   (0x400000)
#define MCF_SCM_PACRD_TP25                   (0x1000000)
#define MCF_SCM_PACRD_WP25                   (0x2000000)
#define MCF_SCM_PACRD_SP25                   (0x4000000)
#define MCF_SCM_PACRD_TP24                   (0x10000000)
#define MCF_SCM_PACRD_WP24                   (0x20000000)
#define MCF_SCM_PACRD_SP24                   (0x40000000)
#define MCF_SCM_PACRD_PACR31(x)              (((x)&0xF)<<0)
#define MCF_SCM_PACRD_PACR30(x)              (((x)&0xF)<<0x4)
#define MCF_SCM_PACRD_PACR29(x)              (((x)&0xF)<<0x8)
#define MCF_SCM_PACRD_PACR28(x)              (((x)&0xF)<<0xC)
#define MCF_SCM_PACRD_PACR26(x)              (((x)&0xF)<<0x14)
#define MCF_SCM_PACRD_PACR25(x)              (((x)&0xF)<<0x18)
#define MCF_SCM_PACRD_PACR24(x)              (((x)&0xF)<<0x1C)

/* Bit definitions and macros for MCF_SCM_PACRE */
#define MCF_SCM_PACRE_TP36                   (0x1000)
#define MCF_SCM_PACRE_WP36                   (0x2000)
#define MCF_SCM_PACRE_SP36                   (0x4000)
#define MCF_SCM_PACRE_TP35                   (0x10000)
#define MCF_SCM_PACRE_WP35                   (0x20000)
#define MCF_SCM_PACRE_SP35                   (0x40000)
#define MCF_SCM_PACRE_TP34                   (0x100000)
#define MCF_SCM_PACRE_WP34                   (0x200000)
#define MCF_SCM_PACRE_SP34                   (0x400000)
#define MCF_SCM_PACRE_TP33                   (0x1000000)
#define MCF_SCM_PACRE_WP33                   (0x2000000)
#define MCF_SCM_PACRE_SP33                   (0x4000000)
#define MCF_SCM_PACRE_TP32                   (0x10000000)
#define MCF_SCM_PACRE_WP32                   (0x20000000)
#define MCF_SCM_PACRE_SP32                   (0x40000000)
#define MCF_SCM_PACRE_PACR36(x)              (((x)&0xF)<<0xC)
#define MCF_SCM_PACRE_PACR35(x)              (((x)&0xF)<<0x10)
#define MCF_SCM_PACRE_PACR34(x)              (((x)&0xF)<<0x14)
#define MCF_SCM_PACRE_PACR33(x)              (((x)&0xF)<<0x18)
#define MCF_SCM_PACRE_PACR32(x)              (((x)&0xF)<<0x1C)

/* Bit definitions and macros for MCF_SCM_PACRF */
#define MCF_SCM_PACRF_TP42                   (0x100000)
#define MCF_SCM_PACRF_WP42                   (0x200000)
#define MCF_SCM_PACRF_SP42                   (0x400000)
#define MCF_SCM_PACRF_TP41                   (0x1000000)
#define MCF_SCM_PACRF_WP41                   (0x2000000)
#define MCF_SCM_PACRF_SP41                   (0x4000000)
#define MCF_SCM_PACRF_TP40                   (0x10000000)
#define MCF_SCM_PACRF_WP40                   (0x20000000)
#define MCF_SCM_PACRF_SP40                   (0x40000000)
#define MCF_SCM_PACRF_PACR42(x)              (((x)&0xF)<<0x14)
#define MCF_SCM_PACRF_PACR41(x)              (((x)&0xF)<<0x18)
#define MCF_SCM_PACRF_PACR40(x)              (((x)&0xF)<<0x1C)

/* Bit definitions and macros for MCF_SCM_BMT */
#define MCF_SCM_BMT_BMT(x)                   (((x)&0x7)<<0)
#define MCF_SCM_BMT_BMT_1024                 (0)
#define MCF_SCM_BMT_BMT_512                  (0x1)
#define MCF_SCM_BMT_BMT_256                  (0x2)
#define MCF_SCM_BMT_BMT_128                  (0x3)
#define MCF_SCM_BMT_BMT_64                   (0x4)
#define MCF_SCM_BMT_BMT_32                   (0x5)
#define MCF_SCM_BMT_BMT_16                   (0x6)
#define MCF_SCM_BMT_BMT_8                    (0x7)
#define MCF_SCM_BMT_BME                      (0x8)

/* Bit definitions and macros for MCF_SCM_CWCR */
#define MCF_SCM_CWCR_CWT(x)                  (((x)&0x1F)<<0)
#define MCF_SCM_CWCR_CWRI(x)                 (((x)&0x3)<<0x5)
#define MCF_SCM_CWCR_CWRI_INT                (0)
#define MCF_SCM_CWCR_CWRI_INT_THEN_RESET     (0x20)
#define MCF_SCM_CWCR_CWRI_RESET              (0x40)
#define MCF_SCM_CWCR_CWRI_WINDOW             (0x60)
#define MCF_SCM_CWCR_CWE                     (0x80)
#define MCF_SCM_CWCR_CWRWH                   (0x100)
#define MCF_SCM_CWCR_RO                      (0x8000)

/* Bit definitions and macros for MCF_SCM_CWSR */
#define MCF_SCM_CWSR_CWSR(x)                 (((x)&0xFF)<<0)

/* Bit definitions and macros for MCF_SCM_SCMISR */
#define MCF_SCM_SCMISR_CWIC                  (0x1)
#define MCF_SCM_SCMISR_CFEI                  (0x2)

/* Bit definitions and macros for MCF_SCM_CFADR */
#define MCF_SCM_CFADR_ADDR(x)                (((x)&0xFFFFFFFF)<<0)

/* Bit definitions and macros for MCF_SCM_CFIER */
#define MCF_SCM_CFIER_ECFEI                  (0x1)

/* Bit definitions and macros for MCF_SCM_CFLOC */
#define MCF_SCM_CFLOC_LOC                    (0x80)

/* Bit definitions and macros for MCF_SCM_CFATR */
#define MCF_SCM_CFATR_TYPE                   (0x1)
#define MCF_SCM_CFATR_MODE                   (0x2)
#define MCF_SCM_CFATR_CACHE                  (0x8)
#define MCF_SCM_CFATR_SIZE(x)                (((x)&0x7)<<0x4)
#define MCF_SCM_CFATR_WRITE                  (0x80)

/* Bit definitions and macros for MCF_SCM_CFDTR */
#define MCF_SCM_CFDTR_CFDTR(x)               (((x)&0xFFFFFFFF)<<0)


#endif /* __MCF5208_SCM_H__ */
