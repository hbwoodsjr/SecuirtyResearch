/* Coldfire C Header File
 * Copyright Freescale Semiconductor Inc
 * All rights reserved.
 *
 * 2007/03/19 Revision: 0.9
 */

#ifndef __MCF5208_XBS_H__
#define __MCF5208_XBS_H__


/*********************************************************************
*
* Cross-Bar Switch Module (XBS)
*
*********************************************************************/

/* Register read/write macros */
#define MCF_XBS_XBS_PRS1                     (*(vuint32*)(0xFC004100))
#define MCF_XBS_XBS_CRS1                     (*(vuint32*)(0xFC004110))
#define MCF_XBS_XBS_PRS4                     (*(vuint32*)(0xFC004400))
#define MCF_XBS_XBS_CRS4                     (*(vuint32*)(0xFC004410))
#define MCF_XBS_XBS_PRS7                     (*(vuint32*)(0xFC004700))
#define MCF_XBS_XBS_CRS7                     (*(vuint32*)(0xFC004710))


/* Bit definitions and macros for MCF_XBS_XBS_PRS1 */
#define MCF_XBS_XBS_PRS1_M0(x)               (((x)&0x7)<<0)
#define MCF_XBS_XBS_PRS1_M1(x)               (((x)&0x7)<<0x4)
#define MCF_XBS_XBS_PRS1_M2(x)               (((x)&0x7)<<0x8)
#define MCF_XBS_XBS_PRS1_M7(x)               (((x)&0x7)<<0x1C)

/* Bit definitions and macros for MCF_XBS_XBS_CRS1 */
#define MCF_XBS_XBS_CRS1_PARK(x)             (((x)&0x7)<<0)
#define MCF_XBS_XBS_CRS1_PARK_CORE           (0)
#define MCF_XBS_XBS_CRS1_PARK_EDMA           (0x1)
#define MCF_XBS_XBS_CRS1_PARK_FEC            (0x2)
#define MCF_XBS_XBS_CRS1_PCTL(x)             (((x)&0x3)<<0x4)
#define MCF_XBS_XBS_CRS1_PARK_FIELD          (0)
#define MCF_XBS_XBS_CRS1_PARK_ON_LAST        (0x10)
#define MCF_XBS_XBS_CRS1_PARK_NO_MASTER      (0x20)
#define MCF_XBS_XBS_CRS1_ARB                 (0x100)
#define MCF_XBS_XBS_CRS1_RO                  (0x80000000)

/* Bit definitions and macros for MCF_XBS_XBS_PRS4 */
#define MCF_XBS_XBS_PRS4_M0(x)               (((x)&0x7)<<0)
#define MCF_XBS_XBS_PRS4_M1(x)               (((x)&0x7)<<0x4)
#define MCF_XBS_XBS_PRS4_M2(x)               (((x)&0x7)<<0x8)
#define MCF_XBS_XBS_PRS4_M7(x)               (((x)&0x7)<<0x1C)

/* Bit definitions and macros for MCF_XBS_XBS_CRS4 */
#define MCF_XBS_XBS_CRS4_PARK(x)             (((x)&0x7)<<0)
#define MCF_XBS_XBS_CRS4_PARK_CORE           (0)
#define MCF_XBS_XBS_CRS4_PARK_EDMA           (0x1)
#define MCF_XBS_XBS_CRS4_PARK_FEC            (0x2)
#define MCF_XBS_XBS_CRS4_PCTL(x)             (((x)&0x3)<<0x4)
#define MCF_XBS_XBS_CRS4_PARK_FIELD          (0)
#define MCF_XBS_XBS_CRS4_PARK_ON_LAST        (0x10)
#define MCF_XBS_XBS_CRS4_PARK_NO_MASTER      (0x20)
#define MCF_XBS_XBS_CRS4_ARB                 (0x100)
#define MCF_XBS_XBS_CRS4_RO                  (0x80000000)

/* Bit definitions and macros for MCF_XBS_XBS_PRS7 */
#define MCF_XBS_XBS_PRS7_M0(x)               (((x)&0x7)<<0)
#define MCF_XBS_XBS_PRS7_M1(x)               (((x)&0x7)<<0x4)
#define MCF_XBS_XBS_PRS7_M2(x)               (((x)&0x7)<<0x8)
#define MCF_XBS_XBS_PRS7_M7(x)               (((x)&0x7)<<0x1C)

/* Bit definitions and macros for MCF_XBS_XBS_CRS7 */
#define MCF_XBS_XBS_CRS7_PARK(x)             (((x)&0x7)<<0)
#define MCF_XBS_XBS_CRS7_PARK_CORE           (0)
#define MCF_XBS_XBS_CRS7_PARK_EDMA           (0x1)
#define MCF_XBS_XBS_CRS7_PARK_FEC            (0x2)
#define MCF_XBS_XBS_CRS7_PCTL(x)             (((x)&0x3)<<0x4)
#define MCF_XBS_XBS_CRS7_PARK_FIELD          (0)
#define MCF_XBS_XBS_CRS7_PARK_ON_LAST        (0x10)
#define MCF_XBS_XBS_CRS7_PARK_NO_MASTER      (0x20)
#define MCF_XBS_XBS_CRS7_ARB                 (0x100)
#define MCF_XBS_XBS_CRS7_RO                  (0x80000000)


#endif /* __MCF5208_XBS_H__ */
