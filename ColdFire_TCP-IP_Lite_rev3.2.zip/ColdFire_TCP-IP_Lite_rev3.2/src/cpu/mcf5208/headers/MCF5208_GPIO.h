/* Coldfire C Header File
 * Copyright Freescale Semiconductor Inc
 * All rights reserved.
 *
 * 2007/03/19 Revision: 0.9
 */

#ifndef __MCF5208_GPIO_H__
#define __MCF5208_GPIO_H__


/*********************************************************************
*
* General Purpose I/O (GPIO)
*
*********************************************************************/

/* Register read/write macros */
#define MCF_GPIO_PODR_BUSCTL                 (*(vuint8 *)(0xFC0A4000))
#define MCF_GPIO_PDDR_BUSCTL                 (*(vuint8 *)(0xFC0A400C))
#define MCF_GPIO_PPDSDR_BUSCTL               (*(vuint8 *)(0xFC0A4018))
#define MCF_GPIO_PCLRR_BUSCTL                (*(vuint8 *)(0xFC0A4024))

#define MCF_GPIO_PODR_BE                     (*(vuint8 *)(0xFC0A4001))
#define MCF_GPIO_PDDR_BE                     (*(vuint8 *)(0xFC0A400D))
#define MCF_GPIO_PPDSDR_BE                   (*(vuint8 *)(0xFC0A4019))
#define MCF_GPIO_PCLRR_BE                    (*(vuint8 *)(0xFC0A4025))

#define MCF_GPIO_PODR_CS                     (*(vuint8 *)(0xFC0A4002))
#define MCF_GPIO_PDDR_CS                     (*(vuint8 *)(0xFC0A400E))
#define MCF_GPIO_PPDSDR_CS                   (*(vuint8 *)(0xFC0A401A))
#define MCF_GPIO_PCLRR_CS                    (*(vuint8 *)(0xFC0A4026))

#define MCF_GPIO_PODR_FECI2C                 (*(vuint8 *)(0xFC0A4003))
#define MCF_GPIO_PDDR_FECI2C                 (*(vuint8 *)(0xFC0A400F))
#define MCF_GPIO_PPDSDR_FECI2C               (*(vuint8 *)(0xFC0A401B))
#define MCF_GPIO_PCLRR_FECI2C                (*(vuint8 *)(0xFC0A4027))

#define MCF_GPIO_PODR_QSPI                   (*(vuint8 *)(0xFC0A4004))
#define MCF_GPIO_PDDR_QSPI                   (*(vuint8 *)(0xFC0A4010))
#define MCF_GPIO_PPDSDR_QSPI                 (*(vuint8 *)(0xFC0A401C))
#define MCF_GPIO_PCLRR_QSPI                  (*(vuint8 *)(0xFC0A4028))

#define MCF_GPIO_PODR_TIMER                  (*(vuint8 *)(0xFC0A4005))
#define MCF_GPIO_PDDR_TIMER                  (*(vuint8 *)(0xFC0A4011))
#define MCF_GPIO_PPDSDR_TIMER                (*(vuint8 *)(0xFC0A401D))
#define MCF_GPIO_PCLRR_TIMER                 (*(vuint8 *)(0xFC0A4029))

#define MCF_GPIO_PODR_UART                   (*(vuint8 *)(0xFC0A4006))
#define MCF_GPIO_PDDR_UART                   (*(vuint8 *)(0xFC0A4012))
#define MCF_GPIO_PPDSDR_UART                 (*(vuint8 *)(0xFC0A401E))
#define MCF_GPIO_PCLRR_UART                  (*(vuint8 *)(0xFC0A402A))

#define MCF_GPIO_PODR_FECH                   (*(vuint8 *)(0xFC0A4007))
#define MCF_GPIO_PDDR_FECH                   (*(vuint8 *)(0xFC0A4013))
#define MCF_GPIO_PPDSDR_FECH                 (*(vuint8 *)(0xFC0A401F))
#define MCF_GPIO_PCLRR_FECH                  (*(vuint8 *)(0xFC0A402B))

#define MCF_GPIO_PODR_FECL                   (*(vuint8 *)(0xFC0A4008))
#define MCF_GPIO_PDDR_FECL                   (*(vuint8 *)(0xFC0A4014))
#define MCF_GPIO_PPDSDR_FECL                 (*(vuint8 *)(0xFC0A4020))
#define MCF_GPIO_PCLRR_FECL                  (*(vuint8 *)(0xFC0A402C))



/* Bit definitions and macros for MCF_GPIO_PODR_BUSCTL */
#define MCF_GPIO_PODR_BUSCTL_PODR_BUSCTL0    (0x1)
#define MCF_GPIO_PODR_BUSCTL_PODR_BUSCTL1    (0x2)
#define MCF_GPIO_PODR_BUSCTL_PODR_BUSCTL2    (0x4)
#define MCF_GPIO_PODR_BUSCTL_PODR_BUSCTL3    (0x8)

/* Bit definitions and macros for MCF_GPIO_PDDR_BUSCTL */
#define MCF_GPIO_PDDR_BUSCTL_PDDR_BUSCTL0    (0x1)
#define MCF_GPIO_PDDR_BUSCTL_PDDR_BUSCTL1    (0x2)
#define MCF_GPIO_PDDR_BUSCTL_PDDR_BUSCTL2    (0x4)
#define MCF_GPIO_PDDR_BUSCTL_PDDR_BUSCTL3    (0x8)

/* Bit definitions and macros for MCF_GPIO_PPDSDR_BUSCTL */
#define MCF_GPIO_PPDSDR_BUSCTL_PPDSDR_BUSCTL0 (0x1)
#define MCF_GPIO_PPDSDR_BUSCTL_PPDSDR_BUSCTL1 (0x2)
#define MCF_GPIO_PPDSDR_BUSCTL_PPDSDR_BUSCTL2 (0x4)
#define MCF_GPIO_PPDSDR_BUSCTL_PPDSDR_BUSCTL3 (0x8)

/* Bit definitions and macros for MCF_GPIO_PCLRR_BUSCTL */
#define MCF_GPIO_PCLRR_BUSCTL_PCLRR_BUSCTL0  (0x1)
#define MCF_GPIO_PCLRR_BUSCTL_PCLRR_BUSCTL1  (0x2)
#define MCF_GPIO_PCLRR_BUSCTL_PCLRR_BUSCTL2  (0x4)
#define MCF_GPIO_PCLRR_BUSCTL_PCLRR_BUSCTL3  (0x8)

/* Bit definitions and macros for MCF_GPIO_PODR_BE */
#define MCF_GPIO_PODR_BE_PODR_BE0            (0x1)
#define MCF_GPIO_PODR_BE_PODR_BE1            (0x2)
#define MCF_GPIO_PODR_BE_PODR_BE2            (0x4)
#define MCF_GPIO_PODR_BE_PODR_BE3            (0x8)

/* Bit definitions and macros for MCF_GPIO_PDDR_BE */
#define MCF_GPIO_PDDR_BE_PDDR_BE0            (0x1)
#define MCF_GPIO_PDDR_BE_PDDR_BE1            (0x2)
#define MCF_GPIO_PDDR_BE_PDDR_BE2            (0x4)
#define MCF_GPIO_PDDR_BE_PDDR_BE3            (0x8)

/* Bit definitions and macros for MCF_GPIO_PPDSDR_BE */
#define MCF_GPIO_PPDSDR_BE_PPDSDR_BE0        (0x1)
#define MCF_GPIO_PPDSDR_BE_PPDSDR_BE1        (0x2)
#define MCF_GPIO_PPDSDR_BE_PPDSDR_BE2        (0x4)
#define MCF_GPIO_PPDSDR_BE_PPDSDR_BE3        (0x8)

/* Bit definitions and macros for MCF_GPIO_PCLRR_BE */
#define MCF_GPIO_PCLRR_BE_PCLRR_BE0          (0x1)
#define MCF_GPIO_PCLRR_BE_PCLRR_BE1          (0x2)
#define MCF_GPIO_PCLRR_BE_PCLRR_BE2          (0x4)
#define MCF_GPIO_PCLRR_BE_PCLRR_BE3          (0x8)

/* Bit definitions and macros for MCF_GPIO_PODR_CS */
#define MCF_GPIO_PODR_CS_PODR_CS1            (0x2)
#define MCF_GPIO_PODR_CS_PODR_CS2            (0x4)
#define MCF_GPIO_PODR_CS_PODR_CS3            (0x8)

/* Bit definitions and macros for MCF_GPIO_PDDR_CS */
#define MCF_GPIO_PDDR_CS_PDDR_CS1            (0x2)
#define MCF_GPIO_PDDR_CS_PDDR_CS2            (0x4)
#define MCF_GPIO_PDDR_CS_PDDR_CS3            (0x8)

/* Bit definitions and macros for MCF_GPIO_PPDSDR_CS */
#define MCF_GPIO_PPDSDR_CS_PPDSDR_CS1        (0x2)
#define MCF_GPIO_PPDSDR_CS_PPDSDR_CS2        (0x4)
#define MCF_GPIO_PPDSDR_CS_PPDSDR_CS3        (0x8)

/* Bit definitions and macros for MCF_GPIO_PCLRR_CS */
#define MCF_GPIO_PCLRR_CS_PCLRR_CS1          (0x2)
#define MCF_GPIO_PCLRR_CS_PCLRR_CS2          (0x4)
#define MCF_GPIO_PCLRR_CS_PCLRR_CS3          (0x8)

/* Bit definitions and macros for MCF_GPIO_PODR_FECI2C */
#define MCF_GPIO_PODR_FECI2C_PODR_FECI2C0    (0x1)
#define MCF_GPIO_PODR_FECI2C_PODR_FECI2C1    (0x2)
#define MCF_GPIO_PODR_FECI2C_PODR_FECI2C2    (0x4)
#define MCF_GPIO_PODR_FECI2C_PODR_FECI2C3    (0x8)

/* Bit definitions and macros for MCF_GPIO_PDDR_FECI2C */
#define MCF_GPIO_PDDR_FECI2C_PDDR_FECI2C0    (0x1)
#define MCF_GPIO_PDDR_FECI2C_PDDR_FECI2C1    (0x2)
#define MCF_GPIO_PDDR_FECI2C_PDDR_FECI2C2    (0x4)
#define MCF_GPIO_PDDR_FECI2C_PDDR_FECI2C3    (0x8)

/* Bit definitions and macros for MCF_GPIO_PPDSDR_FECI2C */
#define MCF_GPIO_PPDSDR_FECI2C_PPDSDR_FECI2C0 (0x1)
#define MCF_GPIO_PPDSDR_FECI2C_PPDSDR_FECI2C1 (0x2)
#define MCF_GPIO_PPDSDR_FECI2C_PPDSDR_FECI2C2 (0x4)
#define MCF_GPIO_PPDSDR_FECI2C_PPDSDR_FECI2C3 (0x8)

/* Bit definitions and macros for MCF_GPIO_PCLRR_FECI2C */
#define MCF_GPIO_PCLRR_FECI2C_PCLRR_FECI2C0  (0x1)
#define MCF_GPIO_PCLRR_FECI2C_PCLRR_FECI2C1  (0x2)
#define MCF_GPIO_PCLRR_FECI2C_PCLRR_FECI2C2  (0x4)
#define MCF_GPIO_PCLRR_FECI2C_PCLRR_FECI2C3  (0x8)

/* Bit definitions and macros for MCF_GPIO_PODR_QSPI */
#define MCF_GPIO_PODR_QSPI_PODR_QSPI0        (0x1)
#define MCF_GPIO_PODR_QSPI_PODR_QSPI1        (0x2)
#define MCF_GPIO_PODR_QSPI_PODR_QSPI2        (0x4)
#define MCF_GPIO_PODR_QSPI_PODR_QSPI3        (0x8)

/* Bit definitions and macros for MCF_GPIO_PDDR_QSPI */
#define MCF_GPIO_PDDR_QSPI_PDDR_QSPI0        (0x1)
#define MCF_GPIO_PDDR_QSPI_PDDR_QSPI1        (0x2)
#define MCF_GPIO_PDDR_QSPI_PDDR_QSPI2        (0x4)
#define MCF_GPIO_PDDR_QSPI_PDDR_QSPI3        (0x8)

/* Bit definitions and macros for MCF_GPIO_PPDSDR_QSPI */
#define MCF_GPIO_PPDSDR_QSPI_PPDSDR_QSPI0    (0x1)
#define MCF_GPIO_PPDSDR_QSPI_PPDSDR_QSPI1    (0x2)
#define MCF_GPIO_PPDSDR_QSPI_PPDSDR_QSPI2    (0x4)
#define MCF_GPIO_PPDSDR_QSPI_PPDSDR_QSPI3    (0x8)

/* Bit definitions and macros for MCF_GPIO_PCLRR_QSPI */
#define MCF_GPIO_PCLRR_QSPI_PCLRR_QSPI0      (0x1)
#define MCF_GPIO_PCLRR_QSPI_PCLRR_QSPI1      (0x2)
#define MCF_GPIO_PCLRR_QSPI_PCLRR_QSPI2      (0x4)
#define MCF_GPIO_PCLRR_QSPI_PCLRR_QSPI3      (0x8)

/* Bit definitions and macros for MCF_GPIO_PODR_TIMER */
#define MCF_GPIO_PODR_TIMER_PODR_TIMER0      (0x1)
#define MCF_GPIO_PODR_TIMER_PODR_TIMER1      (0x2)
#define MCF_GPIO_PODR_TIMER_PODR_TIMER2      (0x4)
#define MCF_GPIO_PODR_TIMER_PODR_TIMER3      (0x8)

/* Bit definitions and macros for MCF_GPIO_PDDR_TIMER */
#define MCF_GPIO_PDDR_TIMER_PDDR_TIMER0      (0x1)
#define MCF_GPIO_PDDR_TIMER_PDDR_TIMER1      (0x2)
#define MCF_GPIO_PDDR_TIMER_PDDR_TIMER2      (0x4)
#define MCF_GPIO_PDDR_TIMER_PDDR_TIMER3      (0x8)

/* Bit definitions and macros for MCF_GPIO_PPDSDR_TIMER */
#define MCF_GPIO_PPDSDR_TIMER_PPDSDR_TIMER0  (0x1)
#define MCF_GPIO_PPDSDR_TIMER_PPDSDR_TIMER1  (0x2)
#define MCF_GPIO_PPDSDR_TIMER_PPDSDR_TIMER2  (0x4)
#define MCF_GPIO_PPDSDR_TIMER_PPDSDR_TIMER3  (0x8)

/* Bit definitions and macros for MCF_GPIO_PCLRR_TIMER */
#define MCF_GPIO_PCLRR_TIMER_PCLRR_TIMER0    (0x1)
#define MCF_GPIO_PCLRR_TIMER_PCLRR_TIMER1    (0x2)
#define MCF_GPIO_PCLRR_TIMER_PCLRR_TIMER2    (0x4)
#define MCF_GPIO_PCLRR_TIMER_PCLRR_TIMER3    (0x8)

/* Bit definitions and macros for MCF_GPIO_PODR_UART */
#define MCF_GPIO_PODR_UART_PODR_UART0        (0x1)
#define MCF_GPIO_PODR_UART_PODR_UART1        (0x2)
#define MCF_GPIO_PODR_UART_PODR_UART2        (0x4)
#define MCF_GPIO_PODR_UART_PODR_UART3        (0x8)
#define MCF_GPIO_PODR_UART_PODR_UART4        (0x10)
#define MCF_GPIO_PODR_UART_PODR_UART5        (0x20)
#define MCF_GPIO_PODR_UART_PODR_UART6        (0x40)
#define MCF_GPIO_PODR_UART_PODR_UART7        (0x80)

/* Bit definitions and macros for MCF_GPIO_PDDR_UART */
#define MCF_GPIO_PDDR_UART_PDDR_UART0        (0x1)
#define MCF_GPIO_PDDR_UART_PDDR_UART1        (0x2)
#define MCF_GPIO_PDDR_UART_PDDR_UART2        (0x4)
#define MCF_GPIO_PDDR_UART_PDDR_UART3        (0x8)
#define MCF_GPIO_PDDR_UART_PDDR_UART4        (0x10)
#define MCF_GPIO_PDDR_UART_PDDR_UART5        (0x20)
#define MCF_GPIO_PDDR_UART_PDDR_UART6        (0x40)
#define MCF_GPIO_PDDR_UART_PDDR_UART7        (0x80)

/* Bit definitions and macros for MCF_GPIO_PPDSDR_UART */
#define MCF_GPIO_PPDSDR_UART_PPDSDR_UART0    (0x1)
#define MCF_GPIO_PPDSDR_UART_PPDSDR_UART1    (0x2)
#define MCF_GPIO_PPDSDR_UART_PPDSDR_UART2    (0x4)
#define MCF_GPIO_PPDSDR_UART_PPDSDR_UART3    (0x8)
#define MCF_GPIO_PPDSDR_UART_PPDSDR_UART4    (0x10)
#define MCF_GPIO_PPDSDR_UART_PPDSDR_UART5    (0x20)
#define MCF_GPIO_PPDSDR_UART_PPDSDR_UART6    (0x40)
#define MCF_GPIO_PPDSDR_UART_PPDSDR_UART7    (0x80)

/* Bit definitions and macros for MCF_GPIO_PCLRR_UART */
#define MCF_GPIO_PCLRR_UART_PCLRR_UART0      (0x1)
#define MCF_GPIO_PCLRR_UART_PCLRR_UART1      (0x2)
#define MCF_GPIO_PCLRR_UART_PCLRR_UART2      (0x4)
#define MCF_GPIO_PCLRR_UART_PCLRR_UART3      (0x8)
#define MCF_GPIO_PCLRR_UART_PCLRR_UART4      (0x10)
#define MCF_GPIO_PCLRR_UART_PCLRR_UART5      (0x20)
#define MCF_GPIO_PCLRR_UART_PCLRR_UART6      (0x40)
#define MCF_GPIO_PCLRR_UART_PCLRR_UART7      (0x80)

/* Bit definitions and macros for MCF_GPIO_PODR_FECH */
#define MCF_GPIO_PODR_FECH_PODR_FECH0        (0x1)
#define MCF_GPIO_PODR_FECH_PODR_FECH1        (0x2)
#define MCF_GPIO_PODR_FECH_PODR_FECH2        (0x4)
#define MCF_GPIO_PODR_FECH_PODR_FECH3        (0x8)
#define MCF_GPIO_PODR_FECH_PODR_FECH4        (0x10)
#define MCF_GPIO_PODR_FECH_PODR_FECH5        (0x20)
#define MCF_GPIO_PODR_FECH_PODR_FECH6        (0x40)
#define MCF_GPIO_PODR_FECH_PODR_FECH7        (0x80)

/* Bit definitions and macros for MCF_GPIO_PDDR_FECH */
#define MCF_GPIO_PDDR_FECH_PDDR_FECH0        (0x1)
#define MCF_GPIO_PDDR_FECH_PDDR_FECH1        (0x2)
#define MCF_GPIO_PDDR_FECH_PDDR_FECH2        (0x4)
#define MCF_GPIO_PDDR_FECH_PDDR_FECH3        (0x8)
#define MCF_GPIO_PDDR_FECH_PDDR_FECH4        (0x10)
#define MCF_GPIO_PDDR_FECH_PDDR_FECH5        (0x20)
#define MCF_GPIO_PDDR_FECH_PDDR_FECH6        (0x40)
#define MCF_GPIO_PDDR_FECH_PDDR_FECH7        (0x80)

/* Bit definitions and macros for MCF_GPIO_PPDSDR_FECH */
#define MCF_GPIO_PPDSDR_FECH_PPDSDR_FECH0    (0x1)
#define MCF_GPIO_PPDSDR_FECH_PPDSDR_FECH1    (0x2)
#define MCF_GPIO_PPDSDR_FECH_PPDSDR_FECH2    (0x4)
#define MCF_GPIO_PPDSDR_FECH_PPDSDR_FECH3    (0x8)
#define MCF_GPIO_PPDSDR_FECH_PPDSDR_FECH4    (0x10)
#define MCF_GPIO_PPDSDR_FECH_PPDSDR_FECH5    (0x20)
#define MCF_GPIO_PPDSDR_FECH_PPDSDR_FECH6    (0x40)
#define MCF_GPIO_PPDSDR_FECH_PPDSDR_FECH7    (0x80)

/* Bit definitions and macros for MCF_GPIO_PCLRR_FECH */
#define MCF_GPIO_PCLRR_FECH_PCLRR_FECH0      (0x1)
#define MCF_GPIO_PCLRR_FECH_PCLRR_FECH1      (0x2)
#define MCF_GPIO_PCLRR_FECH_PCLRR_FECH2      (0x4)
#define MCF_GPIO_PCLRR_FECH_PCLRR_FECH3      (0x8)
#define MCF_GPIO_PCLRR_FECH_PCLRR_FECH4      (0x10)
#define MCF_GPIO_PCLRR_FECH_PCLRR_FECH5      (0x20)
#define MCF_GPIO_PCLRR_FECH_PCLRR_FECH6      (0x40)
#define MCF_GPIO_PCLRR_FECH_PCLRR_FECH7      (0x80)

/* Bit definitions and macros for MCF_GPIO_PODR_FECL */
#define MCF_GPIO_PODR_FECL_PODR_FECL0        (0x1)
#define MCF_GPIO_PODR_FECL_PODR_FECL1        (0x2)
#define MCF_GPIO_PODR_FECL_PODR_FECL2        (0x4)
#define MCF_GPIO_PODR_FECL_PODR_FECL3        (0x8)
#define MCF_GPIO_PODR_FECL_PODR_FECL4        (0x10)
#define MCF_GPIO_PODR_FECL_PODR_FECL5        (0x20)
#define MCF_GPIO_PODR_FECL_PODR_FECL6        (0x40)
#define MCF_GPIO_PODR_FECL_PODR_FECL7        (0x80)

/* Bit definitions and macros for MCF_GPIO_PDDR_FECL */
#define MCF_GPIO_PDDR_FECL_PDDR_FECL0        (0x1)
#define MCF_GPIO_PDDR_FECL_PDDR_FECL1        (0x2)
#define MCF_GPIO_PDDR_FECL_PDDR_FECL2        (0x4)
#define MCF_GPIO_PDDR_FECL_PDDR_FECL3        (0x8)
#define MCF_GPIO_PDDR_FECL_PDDR_FECL4        (0x10)
#define MCF_GPIO_PDDR_FECL_PDDR_FECL5        (0x20)
#define MCF_GPIO_PDDR_FECL_PDDR_FECL6        (0x40)
#define MCF_GPIO_PDDR_FECL_PDDR_FECL7        (0x80)

/* Bit definitions and macros for MCF_GPIO_PPDSDR_FECL */
#define MCF_GPIO_PPDSDR_FECL_PPDSDR_FECL0    (0x1)
#define MCF_GPIO_PPDSDR_FECL_PPDSDR_FECL1    (0x2)
#define MCF_GPIO_PPDSDR_FECL_PPDSDR_FECL2    (0x4)
#define MCF_GPIO_PPDSDR_FECL_PPDSDR_FECL3    (0x8)
#define MCF_GPIO_PPDSDR_FECL_PPDSDR_FECL4    (0x10)
#define MCF_GPIO_PPDSDR_FECL_PPDSDR_FECL5    (0x20)
#define MCF_GPIO_PPDSDR_FECL_PPDSDR_FECL6    (0x40)
#define MCF_GPIO_PPDSDR_FECL_PPDSDR_FECL7    (0x80)

/* Bit definitions and macros for MCF_GPIO_PCLRR_FECL */
#define MCF_GPIO_PCLRR_FECL_PCLRR_FECL0      (0x1)
#define MCF_GPIO_PCLRR_FECL_PCLRR_FECL1      (0x2)
#define MCF_GPIO_PCLRR_FECL_PCLRR_FECL2      (0x4)
#define MCF_GPIO_PCLRR_FECL_PCLRR_FECL3      (0x8)
#define MCF_GPIO_PCLRR_FECL_PCLRR_FECL4      (0x10)
#define MCF_GPIO_PCLRR_FECL_PCLRR_FECL5      (0x20)
#define MCF_GPIO_PCLRR_FECL_PCLRR_FECL6      (0x40)
#define MCF_GPIO_PCLRR_FECL_PCLRR_FECL7      (0x80)


#endif /* __MCF5208_GPIO_H__ */
