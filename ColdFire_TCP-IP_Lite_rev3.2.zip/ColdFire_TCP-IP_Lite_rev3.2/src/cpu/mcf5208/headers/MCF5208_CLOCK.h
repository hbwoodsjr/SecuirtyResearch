/* Coldfire C Header File
 * Copyright Freescale Semiconductor Inc
 * All rights reserved.
 *
 * 2007/03/19 Revision: 0.9
 */

#ifndef __MCF5208_CLOCK_H__
#define __MCF5208_CLOCK_H__


/*********************************************************************
*
* Clock Module (CLOCK)
*
*********************************************************************/

/* Register read/write macros */
#define MCF_CLOCK_PODR                       (*(vuint8 *)(0xFC090000))
#define MCF_CLOCK_PCR                        (*(vuint8 *)(0xFC090002))
#define MCF_CLOCK_PMDR                       (*(vuint8 *)(0xFC090004))
#define MCF_CLOCK_PFDR                       (*(vuint8 *)(0xFC090006))


/* Bit definitions and macros for MCF_CLOCK_PODR */
#define MCF_CLOCK_PODR_BUSDIV(x)             (((x)&0xF)<<0)
#define MCF_CLOCK_PODR_CPUDIV(x)             (((x)&0xF)<<0x4)

/* Bit definitions and macros for MCF_CLOCK_PCR */
#define MCF_CLOCK_PCR_DITHDEV(x)             (((x)&0x7)<<0)
#define MCF_CLOCK_PCR_DITHEN                 (0x80)

/* Bit definitions and macros for MCF_CLOCK_PMDR */
#define MCF_CLOCK_PMDR_MODDIV(x)             (((x)&0xFF)<<0)

/* Bit definitions and macros for MCF_CLOCK_PFDR */
#define MCF_CLOCK_PFDR_MFD(x)                (((x)&0xFF)<<0)


#endif /* __MCF5208_CLOCK_H__ */
