/* Coldfire C Header File
 * Copyright Freescale Semiconductor Inc
 * All rights reserved.
 *
 * 2007/03/19 Revision: 0.9
 */

#ifndef __MCF5208_SDRAMC_H__
#define __MCF5208_SDRAMC_H__


/*********************************************************************
*
* Synchronous DRAM Controller (SDRAMC)
*
*********************************************************************/

/* Register read/write macros */
#define MCF_SDRAMC_SDMR                      (*(vuint32*)(0xFC0A8000))
#define MCF_SDRAMC_SDCR                      (*(vuint32*)(0xFC0A8004))
#define MCF_SDRAMC_SDCFG1                    (*(vuint32*)(0xFC0A8008))
#define MCF_SDRAMC_SDCFG2                    (*(vuint32*)(0xFC0A800C))
#define MCF_SDRAMC_SDCS0                     (*(vuint32*)(0xFC0A8110))
#define MCF_SDRAMC_SDCS1                     (*(vuint32*)(0xFC0A8114))
#define MCF_SDRAMC_SDCS(x)                   (*(vuint32*)(0xFC0A8110 + ((x)*0x4)))


/* Bit definitions and macros for MCF_SDRAMC_SDMR */
#define MCF_SDRAMC_SDMR_CMD                  (0x10000)
#define MCF_SDRAMC_SDMR_AD(x)                (((x)&0xFFF)<<0x12)
#define MCF_SDRAMC_SDMR_BK(x)                (((x)&0x3)<<0x1E)
#define MCF_SDRAMC_SDMR_BK_LMR               (0)
#define MCF_SDRAMC_SDMR_BK_LEMR              (0x40000000)

/* Bit definitions and macros for MCF_SDRAMC_SDCR */
#define MCF_SDRAMC_SDCR_IPALL                (0x2)
#define MCF_SDRAMC_SDCR_IREF                 (0x4)
#define MCF_SDRAMC_SDCR_DQS_OE(x)            (((x)&0x3)<<0xA)
#define MCF_SDRAMC_SDCR_MEM_PS               (0x2000)
#define MCF_SDRAMC_SDCR_PS_32                (0)
#define MCF_SDRAMC_SDCR_PS_16                (0x2000)
#define MCF_SDRAMC_SDCR_REF_CNT(x)           (((x)&0x3F)<<0x10)
#define MCF_SDRAMC_SDCR_OE_RULE              (0x400000)
#define MCF_SDRAMC_SDCR_ADDR_MUX(x)          (((x)&0x3)<<0x18)
#define MCF_SDRAMC_SDCR_REF_EN               (0x10000000)
#define MCF_SDRAMC_SDCR_DDR_MODE             (0x20000000)
#define MCF_SDRAMC_SDCR_CKE                  (0x40000000)
#define MCF_SDRAMC_SDCR_MODE_EN              (0x80000000)

/* Bit definitions and macros for MCF_SDRAMC_SDCFG1 */
#define MCF_SDRAMC_SDCFG1_WT_LAT(x)          (((x)&0x7)<<0x4)
#define MCF_SDRAMC_SDCFG1_REF2ACT(x)         (((x)&0xF)<<0x8)
#define MCF_SDRAMC_SDCFG1_PRE2ACT(x)         (((x)&0x7)<<0xC)
#define MCF_SDRAMC_SDCFG1_ACT2RW(x)          (((x)&0x7)<<0x10)
#define MCF_SDRAMC_SDCFG1_RD_LAT(x)          (((x)&0xF)<<0x14)
#define MCF_SDRAMC_SDCFG1_SWT2RWP(x)         (((x)&0x7)<<0x18)
#define MCF_SDRAMC_SDCFG1_SRD2RWP(x)         (((x)&0xF)<<0x1C)

/* Bit definitions and macros for MCF_SDRAMC_SDCFG2 */
#define MCF_SDRAMC_SDCFG2_BL(x)              (((x)&0xF)<<0x10)
#define MCF_SDRAMC_SDCFG2_BRD2W(x)           (((x)&0xF)<<0x14)
#define MCF_SDRAMC_SDCFG2_BWT2RWP(x)         (((x)&0xF)<<0x18)
#define MCF_SDRAMC_SDCFG2_BRD2RP(x)          (((x)&0xF)<<0x1C)

/* Bit definitions and macros for MCF_SDRAMC_SDCS */
#define MCF_SDRAMC_SDCS_CSSZ(x)              (((x)&0x1F)<<0)
#define MCF_SDRAMC_SDCS_CSSZ_DISABLED        (0)
#define MCF_SDRAMC_SDCS_CSSZ_1MBYTE          (0x13)
#define MCF_SDRAMC_SDCS_CSSZ_2MBYTE          (0x14)
#define MCF_SDRAMC_SDCS_CSSZ_4MBYTE          (0x15)
#define MCF_SDRAMC_SDCS_CSSZ_8MBYTE          (0x16)
#define MCF_SDRAMC_SDCS_CSSZ_16MBYTE         (0x17)
#define MCF_SDRAMC_SDCS_CSSZ_32MBYTE         (0x18)
#define MCF_SDRAMC_SDCS_CSSZ_64MBYTE         (0x19)
#define MCF_SDRAMC_SDCS_CSSZ_128MBYTE        (0x1A)
#define MCF_SDRAMC_SDCS_CSSZ_256MBYTE        (0x1B)
#define MCF_SDRAMC_SDCS_CSSZ_512MBYTE        (0x1C)
#define MCF_SDRAMC_SDCS_CSSZ_1GBYTE          (0x1D)
#define MCF_SDRAMC_SDCS_CSSZ_2GBYTE          (0x1E)
#define MCF_SDRAMC_SDCS_CSSZ_4GBYTE          (0x1F)
#define MCF_SDRAMC_SDCS_CSBA(x)              (((x)&0xFFF)<<0x14)
#define MCF_SDRAMC_SDCS_BA(x)                ((x)&0xFFF00000)


#endif /* __MCF5208_SDRAMC_H__ */
