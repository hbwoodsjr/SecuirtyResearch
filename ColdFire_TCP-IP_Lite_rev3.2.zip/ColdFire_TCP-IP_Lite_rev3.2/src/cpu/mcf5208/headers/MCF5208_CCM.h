/* Coldfire C Header File
 * Copyright Freescale Semiconductor Inc
 * All rights reserved.
 *
 * 2007/03/19 Revision: 0.9
 */

#ifndef __MCF5208_CCM_H__
#define __MCF5208_CCM_H__


/*********************************************************************
*
* Chip Configuration Module (CCM)
*
*********************************************************************/

/* Register read/write macros */
#define MCF_CCM_CCR                          (*(vuint16*)(0xFC0A0004))
#define MCF_CCM_RCON                         (*(vuint16*)(0xFC0A0008))
#define MCF_CCM_CIR                          (*(vuint16*)(0xFC0A000A))


/* Bit definitions and macros for MCF_CCM_CCR */
#define MCF_CCM_CCR_RESERVED                 (0x1)
#define MCF_CCM_CCR_PLLMODE                  (0x3)
#define MCF_CCM_CCR_OSCMODE                  (0x5)
#define MCF_CCM_CCR_BOOTPS(x)                (((x)&0x3)<<0x3|0x1)
#define MCF_CCM_CCR_LOAD                     (0x21)
#define MCF_CCM_CCR_LIMP                     (0x41)
#define MCF_CCM_CCR_OSCFREQ                  (0x81)
#define MCF_CCM_CCR_CSC                      (0x201)

/* Bit definitions and macros for MCF_CCM_RCON */
#define MCF_CCM_RCON_RESERVED                (0x1)
#define MCF_CCM_RCON_PLLMODE                 (0x3)
#define MCF_CCM_RCON_OSCMODE                 (0x5)
#define MCF_CCM_RCON_BOOTPS(x)               (((x)&0x3)<<0x3|0x1)
#define MCF_CCM_RCON_LOAD                    (0x21)
#define MCF_CCM_RCON_LIMP                    (0x41)
#define MCF_CCM_RCON_OSCFREQ                 (0x81)
#define MCF_CCM_RCON_CSC                     (0x201)

/* Bit definitions and macros for MCF_CCM_CIR */
#define MCF_CCM_CIR_PRN(x)                   (((x)&0x3F)<<0)
#define MCF_CCM_CIR_PIN(x)                   (((x)&0x3FF)<<0x6)


#endif /* __MCF5208_CCM_H__ */
