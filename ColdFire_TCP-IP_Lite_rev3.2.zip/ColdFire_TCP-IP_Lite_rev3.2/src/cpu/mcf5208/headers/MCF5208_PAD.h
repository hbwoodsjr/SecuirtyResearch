/* Coldfire C Header File
 * Copyright Freescale Semiconductor Inc
 * All rights reserved.
 *
 * 2007/03/19 Revision: 0.9
 */

#ifndef __MCF5208_PAD_H__
#define __MCF5208_PAD_H__


/*********************************************************************
*
* Common GPIO Registers
*
*********************************************************************/

/* Register read/write macros */
#define MCF_PAD_PAR_BUSCTL                   (*(vuint8 *)(0xFC0A4030))
#define MCF_PAD_PAR_BE                       (*(vuint8 *)(0xFC0A4031))
#define MCF_PAD_PAR_CS                       (*(vuint8 *)(0xFC0A4032))
#define MCF_PAD_PAR_FECI2C                   (*(vuint8 *)(0xFC0A4033))
#define MCF_PAD_PAR_QSPI                     (*(vuint8 *)(0xFC0A4034))
#define MCF_PAD_PAR_TIMER                    (*(vuint8 *)(0xFC0A4035))
#define MCF_PAD_PAR_UART                     (*(vuint16*)(0xFC0A4036))
#define MCF_PAD_PAR_FEC                      (*(vuint8 *)(0xFC0A4038))
#define MCF_PAD_PAR_IRQ                      (*(vuint8 *)(0xFC0A4039))
#define MCF_PAD_MSCR_FLEXBUS                 (*(vuint8 *)(0xFC0A403A))
#define MCF_PAD_MSCR_SDRAM                   (*(vuint8 *)(0xFC0A403B))
#define MCF_PAD_DSCR_I2C                     (*(vuint8 *)(0xFC0A403C))
#define MCF_PAD_DSCR_MISC                    (*(vuint8 *)(0xFC0A403D))
#define MCF_PAD_DSCR_FEC                     (*(vuint8 *)(0xFC0A403E))
#define MCF_PAD_DSCR_UART                    (*(vuint8 *)(0xFC0A403F))
#define MCF_PAD_DSCR_QSPI                    (*(vuint8 *)(0xFC0A4040))


/* Bit definitions and macros for MCF_PAD_PAR_BUSCTL */
#define MCF_PAD_PAR_BUSCTL_PAR_TS(x)         (((x)&0x3)<<0)
#define MCF_PAD_PAR_BUSCTL_PAR_TS_GPIO       (0)
#define MCF_PAD_PAR_BUSCTL_PAR_TS_DACK0      (0x2)
#define MCF_PAD_PAR_BUSCTL_PAR_TS_TS         (0x3)
#define MCF_PAD_PAR_BUSCTL_PAR_RWB           (0x4)
#define MCF_PAD_PAR_BUSCTL_PAR_TA            (0x8)
#define MCF_PAD_PAR_BUSCTL_PAR_OE            (0x10)

/* Bit definitions and macros for MCF_PAD_PAR_BE */
#define MCF_PAD_PAR_BE_PAR_BE0               (0x1)
#define MCF_PAD_PAR_BE_PAR_BE1               (0x2)
#define MCF_PAD_PAR_BE_PAR_BE2               (0x4)
#define MCF_PAD_PAR_BE_PAR_BE3               (0x8)

/* Bit definitions and macros for MCF_PAD_PAR_CS */
#define MCF_PAD_PAR_CS_PAR_CS1(x)            (((x)&0x3)<<0)
#define MCF_PAD_PAR_CS_PAR_CS1_GPIO          (0)
#define MCF_PAD_PAR_CS_PAR_CS1_SDCS1         (0x2)
#define MCF_PAD_PAR_CS_PAR_CS1_CS1           (0x3)
#define MCF_PAD_PAR_CS_PAR_CS2               (0x4)
#define MCF_PAD_PAR_CS_PAR_CS3               (0x8)

/* Bit definitions and macros for MCF_PAD_PAR_FECI2C */
#define MCF_PAD_PAR_FECI2C_PAR_SDA(x)        (((x)&0x3)<<0)
#define MCF_PAD_PAR_FECI2C_PAR_SDA_GPIO      (0)
#define MCF_PAD_PAR_FECI2C_PAR_SDA_URXD2     (0x1)
#define MCF_PAD_PAR_FECI2C_PAR_SDA_SDA       (0x3)
#define MCF_PAD_PAR_FECI2C_PAR_SCL(x)        (((x)&0x3)<<0x2)
#define MCF_PAD_PAR_FECI2C_PAR_SCL_GPIO      (0)
#define MCF_PAD_PAR_FECI2C_PAR_SCL_UTXD2     (0x4)
#define MCF_PAD_PAR_FECI2C_PAR_SCL_SCL       (0xC)
#define MCF_PAD_PAR_FECI2C_PAR_MDIO(x)       (((x)&0x3)<<0x4)
#define MCF_PAD_PAR_FECI2C_PAR_MDIO_GPIO     (0)
#define MCF_PAD_PAR_FECI2C_PAR_MDIO_URXD2    (0x10)
#define MCF_PAD_PAR_FECI2C_PAR_MDIO_SDA      (0x20)
#define MCF_PAD_PAR_FECI2C_PAR_MDIO_EMDIO    (0x30)
#define MCF_PAD_PAR_FECI2C_PAR_MDC(x)        (((x)&0x3)<<0x6)
#define MCF_PAD_PAR_FECI2C_PAR_MDC_GPIO      (0)
#define MCF_PAD_PAR_FECI2C_PAR_MDC_UTXD2     (0x40)
#define MCF_PAD_PAR_FECI2C_PAR_MDC_SCL       (0x80)
#define MCF_PAD_PAR_FECI2C_PAR_MDC_EMDC      (0xC0)

/* Bit definitions and macros for MCF_PAD_PAR_QSPI */
#define MCF_PAD_PAR_QSPI_PAR_SCK(x)          (((x)&0x3)<<0)
#define MCF_PAD_PAR_QSPI_PAR_SCK_GPIO        (0)
#define MCF_PAD_PAR_QSPI_PAR_SCK_SCL         (0x2)
#define MCF_PAD_PAR_QSPI_PAR_SCK_SCK         (0x3)
#define MCF_PAD_PAR_QSPI_PAR_DOUT(x)         (((x)&0x3)<<0x2)
#define MCF_PAD_PAR_QSPI_PAR_DOUT_GPIO       (0)
#define MCF_PAD_PAR_QSPI_PAR_DOUT_SDA        (0x8)
#define MCF_PAD_PAR_QSPI_PAR_DOUT_DOUT       (0xC)
#define MCF_PAD_PAR_QSPI_PAR_DIN(x)          (((x)&0x3)<<0x4)
#define MCF_PAD_PAR_QSPI_PAR_DIN_GPIO        (0)
#define MCF_PAD_PAR_QSPI_PAR_DIN_UCTS2       (0x10)
#define MCF_PAD_PAR_QSPI_PAR_DIN_DREQ0       (0x20)
#define MCF_PAD_PAR_QSPI_PAR_DIN_DIN         (0x30)
#define MCF_PAD_PAR_QSPI_PAR_PCS2(x)         (((x)&0x3)<<0x6)
#define MCF_PAD_PAR_QSPI_PAR_PCS2_GPIO       (0)
#define MCF_PAD_PAR_QSPI_PAR_PCS2_URTS2      (0x40)
#define MCF_PAD_PAR_QSPI_PAR_PCS2_DACK0      (0x80)
#define MCF_PAD_PAR_QSPI_PAR_PCS2_PCS2       (0xC0)

/* Bit definitions and macros for MCF_PAD_PAR_TIMER */
#define MCF_PAD_PAR_TIMER_PAR_T0IN(x)        (((x)&0x3)<<0)
#define MCF_PAD_PAR_TIMER_PAR_TIN0_GPIO      (0)
#define MCF_PAD_PAR_TIMER_PAR_TIN0_UTXD2     (0x1)
#define MCF_PAD_PAR_TIMER_PAR_TIN0_TOUT0     (0x2)
#define MCF_PAD_PAR_TIMER_PAR_TIN0_TIN0      (0x3)
#define MCF_PAD_PAR_TIMER_PAR_T1IN(x)        (((x)&0x3)<<0x2)
#define MCF_PAD_PAR_TIMER_PAR_TIN1_GPIO      (0)
#define MCF_PAD_PAR_TIMER_PAR_TIN1_URXD2     (0x4)
#define MCF_PAD_PAR_TIMER_PAR_TIN1_TOUT1     (0x8)
#define MCF_PAD_PAR_TIMER_PAR_TIN1_TIN1      (0xC)
#define MCF_PAD_PAR_TIMER_PAR_T2IN(x)        (((x)&0x3)<<0x4)
#define MCF_PAD_PAR_TIMER_PAR_TIN2_GPIO      (0)
#define MCF_PAD_PAR_TIMER_PAR_TIN2_URTS2     (0x10)
#define MCF_PAD_PAR_TIMER_PAR_TIN2_TOUT2     (0x20)
#define MCF_PAD_PAR_TIMER_PAR_TIN2_TIN2      (0x30)
#define MCF_PAD_PAR_TIMER_PAR_T3IN(x)        (((x)&0x3)<<0x6)
#define MCF_PAD_PAR_TIMER_PAR_TIN3_GPIO      (0)
#define MCF_PAD_PAR_TIMER_PAR_TIN3_UCTS2     (0x40)
#define MCF_PAD_PAR_TIMER_PAR_TIN3_TOUT3     (0x80)
#define MCF_PAD_PAR_TIMER_PAR_TIN3_TIN3      (0xC0)

/* Bit definitions and macros for MCF_PAD_PAR_UART */
#define MCF_PAD_PAR_UART_PAR_U0RXD           (0x1)
#define MCF_PAD_PAR_UART_PAR_U0TXD           (0x2)
#define MCF_PAD_PAR_UART_PAR_U0RTS(x)        (((x)&0x3)<<0x2)
#define MCF_PAD_PAR_UART_PAR_URTS0_GPIO      (0)
#define MCF_PAD_PAR_UART_PAR_URTS0_PCS0      (0x4)
#define MCF_PAD_PAR_UART_PAR_URTS0_TOUT0     (0x8)
#define MCF_PAD_PAR_UART_PAR_URTS0_URTS0     (0xC)
#define MCF_PAD_PAR_UART_PAR_U0CTS(x)        (((x)&0x3)<<0x4)
#define MCF_PAD_PAR_UART_PAR_UCTS0_GPIO      (0)
#define MCF_PAD_PAR_UART_PAR_UCTS0_PCS0      (0x10)
#define MCF_PAD_PAR_UART_PAR_UCTS0_TIN0      (0x20)
#define MCF_PAD_PAR_UART_PAR_UCTS0_UCTS0     (0x30)
#define MCF_PAD_PAR_UART_PAR_U1RXD           (0x40)
#define MCF_PAD_PAR_UART_PAR_U1TXD           (0x80)
#define MCF_PAD_PAR_UART_PAR_U1RTS(x)        (((x)&0x3)<<0x8)
#define MCF_PAD_PAR_UART_PAR_URTS1_GPIO      (0)
#define MCF_PAD_PAR_UART_PAR_URTS1_PCS1      (0x100)
#define MCF_PAD_PAR_UART_PAR_URTS1_TOUT1     (0x200)
#define MCF_PAD_PAR_UART_PAR_URTS1_URTS1     (0x300)
#define MCF_PAD_PAR_UART_PAR_U1CTS(x)        (((x)&0x3)<<0xA)
#define MCF_PAD_PAR_UART_PAR_UCTS1_GPIO      (0)
#define MCF_PAD_PAR_UART_PAR_UCTS1_PCS1      (0x400)
#define MCF_PAD_PAR_UART_PAR_UCTS1_TIN1      (0x800)
#define MCF_PAD_PAR_UART_PAR_UCTS1_UCTS1     (0xC00)

/* Bit definitions and macros for MCF_PAD_PAR_FEC */
#define MCF_PAD_PAR_FEC_PAR_FEC_MII(x)       (((x)&0x3)<<0)
#define MCF_PAD_PAR_FEC_PAR_FEC_MII_GPIO     (0)
#define MCF_PAD_PAR_FEC_PAR_FEC_MII_UART     (0x1)
#define MCF_PAD_PAR_FEC_PAR_FEC_MII_FEC      (0x3)
#define MCF_PAD_PAR_FEC_PAR_FEC_7W(x)        (((x)&0x3)<<0x2)
#define MCF_PAD_PAR_FEC_PAR_FEC_7W_GPIO      (0)
#define MCF_PAD_PAR_FEC_PAR_FEC_7W_UART      (0x4)
#define MCF_PAD_PAR_FEC_PAR_FEC_7W_FEC       (0xC)

/* Bit definitions and macros for MCF_PAD_PAR_IRQ */
#define MCF_PAD_PAR_IRQ_PAR_IRQ4             (0x1)

/* Bit definitions and macros for MCF_PAD_MSCR_FLEXBUS */
#define MCF_PAD_MSCR_FLEXBUS_MSCR_ADDRCTL(x) (((x)&0x3)<<0)
#define MCF_PAD_MSCR_FLEXBUS_MSCR_DLOWER(x)  (((x)&0x3)<<0x2)
#define MCF_PAD_MSCR_FLEXBUS_MSCR_DUPPER(x)  (((x)&0x3)<<0x4)
#define MCF_PAD_MSCR_FLEXBUS_MSCR_FBCLK(x)   (((x)&0x3)<<0x6)
#define MCF_PAD_MSCR_FLEXBUS_HALF_DRIVE_1_8  (0)
#define MCF_PAD_MSCR_FLEXBUS_OPEN_DRAIN      (0x1)
#define MCF_PAD_MSCR_FLEXBUS_FULL_DRIVE_1_8  (0x2)
#define MCF_PAD_MSCR_FLEXBUS_CMOS_OR_2_5     (0x3)

/* Bit definitions and macros for MCF_PAD_MSCR_SDRAM */
#define MCF_PAD_MSCR_SDRAM_MSCR_SDRAM(x)     (((x)&0x3)<<0)
#define MCF_PAD_MSCR_SDRAM_MSCR_SDCLK(x)     (((x)&0x3)<<0x2)
#define MCF_PAD_MSCR_SDRAM_MSCR_SDCLKB(x)    (((x)&0x3)<<0x4)
#define MCF_PAD_MSCR_SDRAM_HALF_DRIVE_1_8    (0)
#define MCF_PAD_MSCR_SDRAM_OPEN_DRAIN        (0x1)
#define MCF_PAD_MSCR_SDRAM_FULL_DRIVE_1_8    (0x2)
#define MCF_PAD_MSCR_SDRAM_CMOS_OR_2_5       (0x3)

/* Bit definitions and macros for MCF_PAD_DSCR_I2C */
#define MCF_PAD_DSCR_I2C_I2C_DSE(x)          (((x)&0x3)<<0)
#define MCF_PAD_DSCR_I2C_DSE_10_pF           (0)
#define MCF_PAD_DSCR_I2C_DSE_20_pF           (0x1)
#define MCF_PAD_DSCR_I2C_DSE_30_pF           (0x2)
#define MCF_PAD_DSCR_I2C_DSE_50_pF           (0x3)

/* Bit definitions and macros for MCF_PAD_DSCR_MISC */
#define MCF_PAD_DSCR_MISC_TIMER_DSE(x)       (((x)&0x3)<<0)
#define MCF_PAD_DSCR_MISC_RSTOUT_DSE(x)      (((x)&0x3)<<0x2)
#define MCF_PAD_DSCR_MISC_DEBUG_DSE(x)       (((x)&0x3)<<0x4)
#define MCF_PAD_DSCR_MISC_DSE_10_pF          (0)
#define MCF_PAD_DSCR_MISC_DSE_20_pF          (0x1)
#define MCF_PAD_DSCR_MISC_DSE_30_pF          (0x2)
#define MCF_PAD_DSCR_MISC_DSE_50_pF          (0x3)

/* Bit definitions and macros for MCF_PAD_DSCR_FEC */
#define MCF_PAD_DSCR_FEC_FEC_DSE(x)          (((x)&0x3)<<0)
#define MCF_PAD_DSCR_FEC_DSE_10_pF           (0)
#define MCF_PAD_DSCR_FEC_DSE_20_pF           (0x1)
#define MCF_PAD_DSCR_FEC_DSE_30_pF           (0x2)
#define MCF_PAD_DSCR_FEC_DSE_50_pF           (0x3)

/* Bit definitions and macros for MCF_PAD_DSCR_UART */
#define MCF_PAD_DSCR_UART_IRQ_DSE(x)         (((x)&0x3)<<0)
#define MCF_PAD_DSCR_UART_UART0_DSE(x)       (((x)&0x3)<<0x2)
#define MCF_PAD_DSCR_UART_UART1_DSE(x)       (((x)&0x3)<<0x4)
#define MCF_PAD_DSCR_UART_DSE_10_pF          (0)
#define MCF_PAD_DSCR_UART_DSE_20_pF          (0x1)
#define MCF_PAD_DSCR_UART_DSE_30_pF          (0x2)
#define MCF_PAD_DSCR_UART_DSE_50_pF          (0x3)

/* Bit definitions and macros for MCF_PAD_DSCR_QSPI */
#define MCF_PAD_DSCR_QSPI_QSPI_DSE(x)        (((x)&0x3)<<0)
#define MCF_PAD_DSCR_QSPI_DSE_10_pF          (0)
#define MCF_PAD_DSCR_QSPI_DSE_20_pF          (0x1)
#define MCF_PAD_DSCR_QSPI_DSE_30_pF          (0x2)
#define MCF_PAD_DSCR_QSPI_DSE_50_pF          (0x3)


#endif /* __MCF5208_PAD_H__ */
