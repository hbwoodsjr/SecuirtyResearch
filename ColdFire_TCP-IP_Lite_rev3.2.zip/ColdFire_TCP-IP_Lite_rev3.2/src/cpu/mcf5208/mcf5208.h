/* Coldfire C Header File
 * Copyright Freescale Semiconductor Inc
 * All rights reserved.
 *
 * 2007/03/19 Revision: 0.9
 */

#ifndef __MCF5208_H__
#define __MCF5208_H__


/********************************************************************/
#ifdef __cplusplus
extern "C" {
#endif

#pragma define_section system ".system" far_absolute RW

/***
 * MCF5208 Derivative Memory map definitions from linker command files:
 * __MBAR, __RAMBAR, __RAMBAR_SIZE linker symbols must be defined in the
 * linker command file.
 */

extern uint8 __MBAR[];
extern uint8 __RAMBAR[];
extern uint8 __RAMBAR_SIZE[];

#define MBAR_ADDRESS    (uint32)__MBAR
#define RAMBAR_ADDRESS  (uint32)__RAMBAR
#define RAMBAR_SIZE     (uint32)__RAMBAR_SIZE
#define __IPSBAR		(uint32)__MBAR

#include "MCF5208_SCM.h"
#include "MCF5208_XBS.h"
#include "MCF5208_FBCS.h"
#include "MCF5208_FEC.h"
#include "MCF5208_PMM.h"
#include "MCF5208_eDMA.h"
#include "MCF5208_INTC.h"
#include "MCF5208_I2C.h"
#include "MCF5208_QSPI.h"
#include "MCF5208_UART.h"
#include "MCF5208_DTIM.h"
#include "MCF5208_PIT.h"
#include "MCF5208_EPORT.h"
#include "MCF5208_WTM.h"
#include "MCF5208_CLOCK.h"
#include "MCF5208_RCM.h"
#include "MCF5208_CCM.h"
#include "MCF5208_GPIO.h"
#include "MCF5208_PAD.h"
#include "MCF5208_SDRAMC.h"

#ifdef __cplusplus
}
#endif


#endif /* __MCF5208_H__ */
