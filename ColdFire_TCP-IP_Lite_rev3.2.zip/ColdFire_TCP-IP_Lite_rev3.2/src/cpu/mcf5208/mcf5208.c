/*********************************************************************
 *
 * Copyright:
 *	2005 FREESCALE, INC. All Rights Reserved.  
 *  You are hereby granted a copyright license to use, modify, and
 *  distribute the SOFTWARE so long as this entire notice is
 *  retained without alteration in any modified and/or redistributed
 *  versions, and that such modified versions are clearly identified
 *  as such. No licenses are granted by implication, estoppel or
 *  otherwise under any patents or trademarks of Motorola, Inc. This 
 *  software is provided on an "AS IS" basis and without warranty.
 *
 *  To the maximum extent permitted by applicable law, FREESCALE 
 *  DISCLAIMS ALL WARRANTIES WHETHER EXPRESS OR IMPLIED, INCLUDING 
 *  IMPLIED WARRANTIES OF MERCHANTABILITY OR FITNESS FOR A PARTICULAR
 *  PURPOSE AND ANY WARRANTY AGAINST INFRINGEMENT WITH REGARD TO THE 
 *  SOFTWARE (INCLUDING ANY MODIFIED VERSIONS THEREOF) AND ANY 
 *  ACCOMPANYING WRITTEN MATERIALS.
 * 
 *  To the maximum extent permitted by applicable law, IN NO EVENT
 *  SHALL FREESCALE BE LIABLE FOR ANY DAMAGES WHATSOEVER (INCLUDING 
 *  WITHOUT LIMITATION, DAMAGES FOR LOSS OF BUSINESS PROFITS, BUSINESS 
 *  INTERRUPTION, LOSS OF BUSINESS INFORMATION, OR OTHER PECUNIARY
 *  LOSS) ARISING OF THE USE OR INABILITY TO USE THE SOFTWARE.   
 * 
 *  Freescale assumes no responsibility for the maintenance and support
 *  of this software
 ********************************************************************/

/*
 * File:	mcf5208.c
 * Purpose:	MCF5208/7 specific routines	
 *
 * Notes:		
 */

#include "common.h"

extern int d0_reset;
extern int d1_reset;

void FEC_ICR_init(void);				//FSL added function prototype
void FEC_IMR_init(void);				//FSL added function prototype
void processor_UART_ICR_init(int);		//FSL added function prototype
void processor_PIT_Timer_Init(void);	//FSL added function prototype
/********************************************************************/
void
cpu_startup (void)
{
#ifdef DEBUG_PRINT
    /*
     * Determine cause(s) of reset
     */
    printf("\n\n");
    if (MCF_RCM_RSR & MCF_RCM_RSR_LOL)
    	printf("Loss of Lock Reset\n");
    if (MCF_RCM_RSR & MCF_RCM_RSR_WDRCORE)
        printf("Core Watchdog Timer Reset\n");
    if (MCF_RCM_RSR & MCF_RCM_RSR_EXT)
        printf("External Reset\n");
    if (MCF_RCM_RSR & MCF_RCM_RSR_POR)
        printf("Power-on Reset\n");
    if (MCF_RCM_RSR & MCF_RCM_RSR_WDRCHIP)
        printf("Watchdog Timer Reset\n");
    if (MCF_RCM_RSR & MCF_RCM_RSR_SOFT)
        printf("Software Reset\n");
    
    /*
     * Print out the core integration information
     */
    mcf5xxx_interpret_d0d1(d0_reset,d1_reset);
#endif

    /* 
	 * Enable on-chip modules to access internal SRAM 
	 */
//	MCF5208_SCM_RAMBAR = ( MCF5208_SCM_RAMBAR_BA(SRAM_ADDRESS)
//		             | MCF5208_SCM_RAMBAR_BDE);
}
/********************************************************************/
void
cpu_handle_interrupt (int vector)
{
    if (vector < 64 || vector > 192)
        return;
    
    switch (vector)
    {
        case 65: /* Eport Interrupt 1 */
        case 66: /* Eport Interrupt 2 */
        case 67: /* Eport Interrupt 3 */
        case 68: /* Eport Interrupt 4 */
        case 69: /* Eport Interrupt 5 */
        case 70: /* Eport Interrupt 6 */
        case 71: /* Eport Interrupt 7 */

            /* 
             * Clear the interrupt source 
             * This clears the flag for edge triggered interrupts
             */
            MCF_EPORT_EPFR = (uint8)(0x01 << (vector - 64));
            printf("Edge Port Interrupt #%d\n",vector - 64);
            break;  
        default:
            printf("User Defined Vector #%d\n",vector);
            break;
    }
}


/********************************************************************/
/*
 * Setup PIT Timer
 */
void 
PIT_Timer_Init(uint8 PCSR, uint16 PMR)
{

	mcf5xxx_irq_disable();		//FSL Good practice per manual
	
	/* Clear interrupt at CSR */
	MCF_PIT_PCSR(0) |= MCF_PIT_PCSR_PIF;

	/* Set tic for timers	*/

	MCF_PIT0_PCSR  = (uint16)(MCF_PIT_PCSR_PRE(PCSR));	/* Divide system clock/2 by 2^PCSR	*/
	MCF_INTC0_ICR04 = MCF_INTC_ICR_IL(TIMER_NETWORK_LEVEL);
	MCF_INTC0_IMRL &= ~(MCF_INTC_IPRL_INT4);
	MCF_PIT0_PMR = PMR;						/* modulo count	*/
	MCF_PIT0_PCSR |= MCF_PIT_PCSR_OVW | MCF_PIT_PCSR_DBG |
					 MCF_PIT_PCSR_PIE | MCF_PIT_PCSR_PIF | 
					 MCF_PIT_PCSR_RLD | MCF_PIT_PCSR_EN;

	mcf5xxx_irq_enable();		//FSL Good practice per manual
}

/********************************************************************/

void 
mcf5208_interrupt_init(int source, int ipl, void (*func)(void))
{
   if ((source >= 0) && (source <= 63)) 
   {
      MCF_INTC0_ICR(source) = ipl;
      mcf5xxx_set_handler(source+64, (ADDRESS)func);
      MCF_INTC0_CIMR = MCF_INTC_CIMR_CIMR(source);
   }
}

/********************************************************************/
void FEC_ICR_init(void)						//FSL processor specific FEC ICR initialization
{
	uint32 i;
	
   /* Set up FEC interrupts (vectors 36 through 49) */
   for (i = 36; i < 49; i++)
   {
	  MCF_INTC0_ICR(i) = MCF_INTC_ICR_IL(6);
   }
	
	
}

/********************************************************************/
void FEC_IMR_init()							//FSL configure the FEC IMRs in processor specific file
{
	MCF_INTC0_IMRH &= 	~(MCF_INTC_IMRH_INT_MASK36); // TXF
	MCF_INTC0_IMRH &= 	~(MCF_INTC_IMRH_INT_MASK37); // TXB
	MCF_INTC0_IMRH &= 	~(MCF_INTC_IMRH_INT_MASK40); // RXF
	MCF_INTC0_IMRH &= 	~(MCF_INTC_IMRH_INT_MASK42); // MII	
}
/********************************************************************/
void processor_UART_ICR_init(int dev)		//FSL configure the UART0 ICR and enable associtate IMR
{
  if(dev == 0)
  {
	  MCF_INTC0_ICR26 = MCF_INTC_ICR_IL(2);
	  MCF_INTC0_IMRL &= ~(MCF_INTC_IMRL_INT_MASK26);
  }
  else
  {
	  MCF_INTC0_ICR27 = MCF_INTC_ICR_IL(2);
	  MCF_INTC0_IMRL &= ~(MCF_INTC_IMRL_INT_MASK27);	
  }
	
}
/********************************************************************/
void processor_PIT_Timer_Init()				//FSL processor specific PIT config for 1 msec interrupt
{

   PIT_Timer_Init(0,41666);		// (41666/((sys_clk/2)/2^0))) = 1msec PIT interrupt
	
}

