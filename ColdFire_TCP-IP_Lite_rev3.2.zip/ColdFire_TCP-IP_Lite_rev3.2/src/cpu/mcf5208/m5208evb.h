/*********************************************************************
 *
 * Copyright:
 *	2005 FREESCALE, INC. All Rights Reserved.  
 *  You are hereby granted a copyright license to use, modify, and
 *  distribute the SOFTWARE so long as this entire notice is
 *  retained without alteration in any modified and/or redistributed
 *  versions, and that such modified versions are clearly identified
 *  as such. No licenses are granted by implication, estoppel or
 *  otherwise under any patents or trademarks of Motorola, Inc. This 
 *  software is provided on an "AS IS" basis and without warranty.
 *
 *  To the maximum extent permitted by applicable law, FREESCALE 
 *  DISCLAIMS ALL WARRANTIES WHETHER EXPRESS OR IMPLIED, INCLUDING 
 *  IMPLIED WARRANTIES OF MERCHANTABILITY OR FITNESS FOR A PARTICULAR
 *  PURPOSE AND ANY WARRANTY AGAINST INFRINGEMENT WITH REGARD TO THE 
 *  SOFTWARE (INCLUDING ANY MODIFIED VERSIONS THEREOF) AND ANY 
 *  ACCOMPANYING WRITTEN MATERIALS.
 * 
 *  To the maximum extent permitted by applicable law, IN NO EVENT
 *  SHALL MOTOROLA BE LIABLE FOR ANY DAMAGES WHATSOEVER (INCLUDING 
 *  WITHOUT LIMITATION, DAMAGES FOR LOSS OF BUSINESS PROFITS, BUSINESS 
 *  INTERRUPTION, LOSS OF BUSINESS INFORMATION, OR OTHER PECUNIARY
 *  LOSS) ARISING OF THE USE OR INABILITY TO USE THE SOFTWARE.   
 * 
 *  Freescale assumes no responsibility for the maintenance and support
 *  of this software
 ********************************************************************/

/*
 * File:		m5208evb.h
 * Purpose:		Evaluation board definitions and memory map information
 *
 * Notes:
 */

#ifndef _M5208EVB_H
#define _M5208EVB_H

void evb_specific_collect_sensor_data( void );

/********************************************************************/

/* 
 * System Bus Clock Info 
 */
#define REF_CLK_MHZ         	(16)
#define REF_CLK_KHZ         	(16000)
#define	SYS_CLK_MHZ		83.33	/* system bus frequency in MHz */
#define SYS_CLK_KHZ		83333	/* system bus frequency in kHz */
#define SYSTEM_PERIOD		12	/* system clock period in ns. */
extern int sys_clk_khz;
extern int sys_clk_mhz;

/*
 * Ethernet Port Info
 */
#define FEC_PHY0            (0x01)

/*
 *  SDRAM Timing Parameters
 */  
#define SDRAM_BL             	8       /* # of beats in a burst */
#define SDRAM_TWR               2      /* in clocks */
#define SDRAM_CASL          	2      /* CASL in clocks */
#define SDRAM_TRCD              2      /* in clocks */
#define SDRAM_TRP               2      /* in clocks */
#define SDRAM_TRFC              7      /* in clocks */
#define SDRAM_TREFI             7800    /* in ns */

/* 
 * Memory map definitions from linker command files 
 */
extern uint8 __SDRAM[];
extern uint8 __SDRAM_SIZE[];
extern uint8 __CORE_SRAM[];
extern uint8 __CORE_SRAM_SIZE[];
extern uint8 __EXT_SRAM[];
extern uint8 __EXT_SRAM_SIZE[];
extern uint8 __FLASH[];
extern uint8 __FLASH_SIZE[];

/* 
 * Memory Map Info 
 */

#define SDRAM_ADDRESS			(uint32)__SDRAM
#define SDRAM_SIZE				(uint32)__SDRAM_SIZE

#define SRAM_ADDRESS			(uint32)__CORE_SRAM
#define SRAM_SIZE				(uint32)__CORE_SRAM_SIZE

#define EXT_SRAM_ADDRESS		(uint32)__EXT_SRAM
#define EXT_SRAM_SIZE			(uint32)__EXT_SRAM_SIZE

#define FLASH_ADDRESS			(uint32)__FLASH
#define FLASH_SIZE				(uint32)__FLASH_SIZE

/*
 *	Interrupt Controller Definitions
 */
#define TIMER_NETWORK_LEVEL		3
#define FEC_LEVEL				4

/*
 *	Timer period info
 */
#define TIMER_NETWORK_PERIOD	1000000000/0x10000	/* 1 sec / max timeout */

/*
 * LED Info
 */
#undef HAS_LEDS
#define HAS_LEDS 1

/********************************************************************/
#ifdef HAS_LEDS /* { */    //FSL updated the LED definitions to work with m5208evb

	static unsigned char LED3=1,LED2=1,LED1=1,LED0=1;
	
	#define LED0_TOGGLE     MCF_GPIO_PODR_TIMER = (uint8)(MCF_GPIO_PODR_TIMER ^ MCF_GPIO_PODR_TIMER_PODR_TIMER0)
	#define LED1_TOGGLE     MCF_GPIO_PODR_TIMER = (uint8)(MCF_GPIO_PODR_TIMER ^ MCF_GPIO_PODR_TIMER_PODR_TIMER1);
	#define LED2_TOGGLE     MCF_GPIO_PODR_TIMER = (uint8)(MCF_GPIO_PODR_TIMER ^ MCF_GPIO_PODR_TIMER_PODR_TIMER2);
	#define LED3_TOGGLE     MCF_GPIO_PODR_TIMER = (uint8)(MCF_GPIO_PODR_TIMER ^ MCF_GPIO_PODR_TIMER_PODR_TIMER3);

	#define LED0_ON     	MCF_GPIO_PODR_TIMER = (uint8)(MCF_GPIO_PODR_TIMER | MCF_GPIO_PODR_TIMER_PODR_TIMER0)
	#define LED1_ON		    MCF_GPIO_PODR_TIMER = (uint8)(MCF_GPIO_PODR_TIMER | MCF_GPIO_PODR_TIMER_PODR_TIMER1);
	#define LED2_ON         MCF_GPIO_PODR_TIMER = (uint8)(MCF_GPIO_PODR_TIMER | MCF_GPIO_PODR_TIMER_PODR_TIMER2);
	#define LED3_ON         MCF_GPIO_PODR_TIMER = (uint8)(MCF_GPIO_PODR_TIMER | MCF_GPIO_PODR_TIMER_PODR_TIMER3);

	#define LED0_OFF        MCF_GPIO_PODR_TIMER = (uint8)(MCF_GPIO_PODR_TIMER & ~MCF_GPIO_PODR_TIMER_PODR_TIMER0)
	#define LED1_OFF        MCF_GPIO_PODR_TIMER = (uint8)(MCF_GPIO_PODR_TIMER & ~MCF_GPIO_PODR_TIMER_PODR_TIMER1);
	#define LED2_OFF        MCF_GPIO_PODR_TIMER = (uint8)(MCF_GPIO_PODR_TIMER & ~MCF_GPIO_PODR_TIMER_PODR_TIMER2);
	#define LED3_OFF        MCF_GPIO_PODR_TIMER = (uint8)(MCF_GPIO_PODR_TIMER & ~MCF_GPIO_PODR_TIMER_PODR_TIMER3);

	#define LED_INIT()		Leds_Init()
#else  /* No LEDS  */
	#define LED0_TOGGLE     /*MCF_GPIO_PORTTC = (uint8)(MCF_GPIO_PORTTC ^ MCF_GPIO_PORTTC_PORTTC0)*/
	#define LED1_TOGGLE     /*MCF_GPIO_PORTTC = (uint8)(MCF_GPIO_PORTTC ^ MCF_GPIO_PORTTC_PORTTC1)*/;
	#define LED2_TOGGLE     /*MCF_GPIO_PORTTC = (uint8)(MCF_GPIO_PORTTC ^ MCF_GPIO_PORTTC_PORTTC2)*/;
	#define LED3_TOGGLE     /*MCF_GPIO_PORTTC = (uint8)(MCF_GPIO_PORTTC ^ MCF_GPIO_PORTTC_PORTTC3)*/;

	#define LED0_ON     	/*MCF_GPIO_PORTTC = (uint8)(MCF_GPIO_PORTTC | MCF_GPIO_PORTTC_PORTTC0)*/
	#define LED1_ON		    /*MCF_GPIO_PORTTC = (uint8)(MCF_GPIO_PORTTC | MCF_GPIO_PORTTC_PORTTC1)*/;
	#define LED2_ON         /*MCF_GPIO_PORTTC = (uint8)(MCF_GPIO_PORTTC | MCF_GPIO_PORTTC_PORTTC2)*/;
	#define LED3_ON         /*MCF_GPIO_PORTTC = (uint8)(MCF_GPIO_PORTTC | MCF_GPIO_PORTTC_PORTTC3)*/;

	#define LED0_OFF        /*MCF_GPIO_PORTTC = (uint8)(MCF_GPIO_PORTTC & ~MCF_GPIO_PORTTC_PORTTC0)*/
	#define LED1_OFF        /*MCF_GPIO_PORTTC = (uint8)(MCF_GPIO_PORTTC & ~MCF_GPIO_PORTTC_PORTTC1)*/;
	#define LED2_OFF        /*MCF_GPIO_PORTTC = (uint8)(MCF_GPIO_PORTTC & ~MCF_GPIO_PORTTC_PORTTC2)*/;
	#define LED3_OFF        /*MCF_GPIO_PORTTC = (uint8)(MCF_GPIO_PORTTC & ~MCF_GPIO_PORTTC_PORTTC3)*/;
	#define LED_INIT()		/*void()*/
	#define RXLED_TOGGLE     /*MCF_GPIO_PORTLD = (uint8)(MCF_GPIO_PORTLD ^ MCF_GPIO_PORTLD_PORTLD5)*/;
	#define TXLED_TOGGLE     /*MCF_GPIO_PORTLD = (uint8)(MCF_GPIO_PORTLD ^ MCF_GPIO_PORTLD_PORTLD6)*/;
	#define ACTLED_TOGGLE    /*MCF_GPIO_PORTLD = (uint8)(MCF_GPIO_PORTLD ^ MCF_GPIO_PORTLD_PORTLD0)*/;
#endif
/********************************************************************/
/********************************************************************/
void Leds_Init();
void board_led_display(uint8 number);
/********************************************************************/


/********************************************************************/

#endif /* _M5208EVB_H */
