/*********************************************************************
 *
 * Copyright:
 *	2005 FREESCALE, INC. All Rights Reserved.  
 *  You are hereby granted a copyright license to use, modify, and
 *  distribute the SOFTWARE so long as this entire notice is
 *  retained without alteration in any modified and/or redistributed
 *  versions, and that such modified versions are clearly identified
 *  as such. No licenses are granted by implication, estoppel or
 *  otherwise under any patents or trademarks of Motorola, Inc. This 
 *  software is provided on an "AS IS" basis and without warranty.
 *
 *  To the maximum extent permitted by applicable law, FREESCALE 
 *  DISCLAIMS ALL WARRANTIES WHETHER EXPRESS OR IMPLIED, INCLUDING 
 *  IMPLIED WARRANTIES OF MERCHANTABILITY OR FITNESS FOR A PARTICULAR
 *  PURPOSE AND ANY WARRANTY AGAINST INFRINGEMENT WITH REGARD TO THE 
 *  SOFTWARE (INCLUDING ANY MODIFIED VERSIONS THEREOF) AND ANY 
 *  ACCOMPANYING WRITTEN MATERIALS.
 * 
 *  To the maximum extent permitted by applicable law, IN NO EVENT
 *  SHALL FREESCALE BE LIABLE FOR ANY DAMAGES WHATSOEVER (INCLUDING 
 *  WITHOUT LIMITATION, DAMAGES FOR LOSS OF BUSINESS PROFITS, BUSINESS 
 *  INTERRUPTION, LOSS OF BUSINESS INFORMATION, OR OTHER PECUNIARY
 *  LOSS) ARISING OF THE USE OR INABILITY TO USE THE SOFTWARE.   
 * 
 *  Freescale assumes no responsibility for the maintenance and support
 *  of this software
 ********************************************************************/

/*
 * File:		sysinit.c
 * Purpose:		Reset configuration of the M5282EVB
 */

#include "common.h"

/********************************************************************/

void scm_init(void);
void fbcs_init(void);
void sdramc_init(void);
void gpio_init(void);
void eport_init(void);
void wtm_init(void);
void mcf5208_PHY_init(void);	//FSL added proto and function below
/********************************************************************/

/* Actual system clock frequency */
int sys_clk_khz;
int sys_clk_mhz;

/********************************************************************/
void
sysinit (void)
{
   sys_clk_khz = SYS_CLK_KHZ;
   sys_clk_mhz = SYS_CLK_MHZ;

   wtm_init();
   scm_init();
   gpio_init();
   uart_init(0);
   uart_init(1);
   fbcs_init();
   sdramc_init();
   eport_init(); 
   mcf5208_PHY_init();  
   
/* Turn Instruction Cache ON */
#if (CACHE)
   mcf5xxx_wr_cacr(0
		| MCF5XXX_CACR_CENB
		| MCF5XXX_CACR_CINV
		| MCF5XXX_CACR_DISD
		| MCF5XXX_CACR_CEIB
		| MCF5XXX_CACR_CLNF_00);
#endif
		
}
/********************************************************************/
void
wtm_init (void)
{
	/* Disable watchdog timer */
	
	MCF_WTM_WCR = 0;

}
/********************************************************************/
void
scm_init (void)
{

	/* All masters are trusted */
    MCF_SCM_MPR = 0x77777777;
    
    /* Allow supervisor/user, read/write, and trusted/untrusted
       access to all slaves */
       
    MCF_SCM_PACRA = 0;
    MCF_SCM_PACRB = 0;
    MCF_SCM_PACRC = 0;
    MCF_SCM_PACRD = 0;
    MCF_SCM_PACRE = 0;
    MCF_SCM_PACRF = 0;

}
/********************************************************************/
void
fbcs_init (void)
{
    /* External SRAM */
    MCF_FBCS1_CSAR = EXT_SRAM_ADDRESS;
    MCF_FBCS1_CSCR = (MCF_FBCS_CSCR_PS_16
                    | MCF_FBCS_CSCR_AA
                    | MCF_FBCS_CSCR_SBM
                    | MCF_FBCS_CSCR_WS(1));
                    
    MCF_FBCS1_CSMR = (MCF_FBCS_CSMR_BAM_512K
                    | MCF_FBCS_CSMR_V);

    /* Boot SRAM connected to FBCS0 */
    MCF_FBCS0_CSAR = FLASH_ADDRESS;
    MCF_FBCS0_CSCR = (MCF_FBCS_CSCR_PS_16
    			        | MCF_FBCS_CSCR_BEM
                    | MCF_FBCS_CSCR_AA
                    | MCF_FBCS_CSCR_SBM
                    | MCF_FBCS_CSCR_WS(7));
                    
    MCF_FBCS0_CSMR = (MCF_FBCS_CSMR_BAM_32M
                    | MCF_FBCS_CSMR_V);
}
/********************************************************************/
void
sdramc_init (void)
{

	/*
	 * Check to see if the SDRAM has already been initialized
	 * by a run control tool
	 */
	if (!(MCF_SDRAMC_SDCR & MCF_SDRAMC_SDCR_REF_EN))
	{

		/* SDRAM chip select initialization */
		
		/* Initialize SDRAM chip select */
        MCF_SDRAMC_SDCS0 = (0
                          | MCF_SDRAMC_SDCS_BA(SDRAM_ADDRESS)
                          | MCF_SDRAMC_SDCS_CSSZ(MCF_SDRAMC_SDCS_CSSZ_32MBYTE));

        /* 
         * Basic configuration and initialization 
         */
         
        MCF_SDRAMC_SDCFG1 = (0
                    | MCF_SDRAMC_SDCFG1_SRD2RWP(SDRAM_CASL + (SDRAM_BL/2) + 1)
                    | MCF_SDRAMC_SDCFG1_SWT2RWP(SDRAM_TWR + 1)
                    | MCF_SDRAMC_SDCFG1_RD_LAT((int)((SDRAM_CASL*2) + 2))
                    | MCF_SDRAMC_SDCFG1_ACT2RW((int)((SDRAM_TRCD) + 0.5))
                    | MCF_SDRAMC_SDCFG1_PRE2ACT((int)((SDRAM_TRP) + 0.5))
                    | MCF_SDRAMC_SDCFG1_REF2ACT((int)(((SDRAM_TRFC) - 1) + 0.5))
                    | MCF_SDRAMC_SDCFG1_WT_LAT(3));
                    
		MCF_SDRAMC_SDCFG2 = (0
                    | MCF_SDRAMC_SDCFG2_BRD2RP(SDRAM_BL/2 + 1)
                    | MCF_SDRAMC_SDCFG2_BWT2RWP(SDRAM_BL/2 + SDRAM_TWR)
                    | MCF_SDRAMC_SDCFG2_BRD2W((int)((SDRAM_CASL + SDRAM_BL/2 +1.0)))
                    | MCF_SDRAMC_SDCFG2_BL(SDRAM_BL-1));

            
        /* 
         * Precharge and enable write to SDMR 
         */
        MCF_SDRAMC_SDCR = (0
                    | MCF_SDRAMC_SDCR_MODE_EN
                    | MCF_SDRAMC_SDCR_CKE
                    | MCF_SDRAMC_SDCR_DDR_MODE
                    | MCF_SDRAMC_SDCR_ADDR_MUX(1)
                    | MCF_SDRAMC_SDCR_REF_CNT((int)(((SDRAM_TREFI/(SYSTEM_PERIOD*64)) - 1) + 0.5))
                    | MCF_SDRAMC_SDCR_PS_16
                    | MCF_SDRAMC_SDCR_IPALL);            

        /* 
         * Write extended mode register 
         */
        MCF_SDRAMC_SDMR = (0
                         | MCF_SDRAMC_SDMR_BK_LEMR
                         | MCF_SDRAMC_SDMR_AD(0x0)
                         | MCF_SDRAMC_SDMR_CMD);
		
        /* 
         * Write mode register and reset DLL 
         */
        MCF_SDRAMC_SDMR = (0
                         | MCF_SDRAMC_SDMR_BK_LMR
                         | MCF_SDRAMC_SDMR_AD(0x163)
                         | MCF_SDRAMC_SDMR_CMD);
				
        /* 
         * Execute a PALL command 
         */
        MCF_SDRAMC_SDCR |= MCF_SDRAMC_SDCR_IPALL;
		
        /* 
         * Perform two REF cycles 
         */
        MCF_SDRAMC_SDCR |= MCF_SDRAMC_SDCR_IREF;
        MCF_SDRAMC_SDCR |= MCF_SDRAMC_SDCR_IREF;
			
        /* 
         * Write mode register and clear reset DLL 
         */
        MCF_SDRAMC_SDMR = (0
                         | MCF_SDRAMC_SDMR_BK_LMR
                         | MCF_SDRAMC_SDMR_AD(0x063)
                         | MCF_SDRAMC_SDMR_CMD);
				
        /* 
         * Enable auto refresh and lock SDMR 
         */
        MCF_SDRAMC_SDCR &= ~MCF_SDRAMC_SDCR_MODE_EN;
        MCF_SDRAMC_SDCR |= (0
                          | MCF_SDRAMC_SDCR_REF_EN
                          | MCF_SDRAMC_SDCR_DQS_OE(0x3));
            
	}
}
/********************************************************************/
void
gpio_init(void)
{
   /* Enable GPIO pins */
   MCF_PAD_PAR_UART = ( 0
                      | MCF_PAD_PAR_UART_PAR_UCTS0_UCTS0
                      | MCF_PAD_PAR_UART_PAR_URTS0_URTS0
                      | MCF_PAD_PAR_UART_PAR_U0RXD
                      | MCF_PAD_PAR_UART_PAR_U0TXD );
 
   /* Configure LED pins */
   MCF_GPIO_PODR_TIMER 	= 0x00;  /* LEDs = 'off' */
   MCF_PAD_PAR_TIMER 	= 0x00;   
   MCF_GPIO_PDDR_TIMER 	= 0x0F;
   
   MCF_PAD_DSCR_MISC &= 0x3C;	// timer pin drive strength set to 10pf
   
   /* Setup the Ethernet pins for MMI interface */
    /*
     * Make sure the external MII interface signals are enabled
     */
	//FSL added during mcf5208 port
	MCF_PAD_DSCR_FEC	= MCF_PAD_DSCR_FEC_DSE_50_pF;			//Drive strength of MDC and MDIO pins set to 50pF
	MCF_PAD_PAR_FECI2C	= MCF_PAD_PAR_FECI2C_PAR_MDC(3) | MCF_PAD_PAR_FECI2C_PAR_MDIO(3);  //config MDC and MDIO on pins
	MCF_PAD_PAR_FEC		= MCF_PAD_PAR_FEC_PAR_FEC_MII_FEC |MCF_PAD_PAR_FEC_PAR_FEC_7W_FEC; //config gpio pins for FEC MII mode

}

/********************************************************************/
void
eport_init(void)
{
	/*
	 * Allow interrupts from IRQ7 (black button)
	 */

	/* Set IRQ7 to be rising edge triggered */
	MCF_EPORT_EPPAR = MCF_EPORT_EPPAR_EPPA7_RISING;

	/* Enable EPORT interrupt 7 requests */
	MCF_EPORT_EPIER = MCF_EPORT_EPIER_EPIE7;

/* Can't enable interrupts until the interrupt controller
	header file is complete, so this is commented out for 
	now      */

	/* Enable IRQ7 in the IMR */
/*	MCF5208_INTC_IMRL &= ~(MCF5208_INTC_IMRL_INT_MASK7 | MCF5208_INTC_IMRL_MASKALL);
*/
}
/********************************************************************/
// Init external PHY - National Semiconductor DP83848C
/********************************************************************/
extern struct fec_statistics fecstats;
int DUPLEX_phy_r17_dpm;

void mcf5208_PHY_init(void)
{
  	unsigned short		reg0;
  	int i;

//FSL replace function call	fec_mii_init((SYSTEM_CLOCK));  with below MCF_FEC_MSCR macro
    /*
     * Configure MII interface speed. Must be <= 2.5MHz
     *
     * Desired MII clock is 2.5MHz
     * MII Speed Setting = System_Clock_Bus_Speed / (2.5MHz * 2)
     */
    MCF_FEC_MSCR = MCF_FEC_MSCR_MII_SPEED((uint32)(SYS_CLK_MHZ/5));

	do
	{
		while(!(fec_mii_read(FEC_PHY0, PHY_REG_CR, &reg0)))		//FSL read PHY control register
		{
			reg0=0;
		};
		
	} while(reg0&PHY_R0_RESET);		//Test RESET bit...1=in reset, 0=reset complete

#if (!AUTO)
	if (BaseT==100)		//FSL BaseT set to 100mpbs
		reg0 |= 0x2000;								// 100Mbps
	else				//FSL BaseT defaults to 10mbps
		reg0 &= ~0x2000;							// 10Mbps

	if (DUPLEX==0)
		reg0 |= 0x0100;								// Full Duplex
	else		
		reg0 &= ~0x0100;							// Half Duplex

	while(!fec_mii_write( FEC_PHY0, PHY_REG_CR, reg0|0x0200 ))
	{
	};					//Force re-negotiation
	
#endif

	while(!(fec_mii_read(FEC_PHY0, 0x10, &reg0)))	// read PHY status register
	{
		reg0=0;
	};
	DUPLEX_phy_r17_dpm = (int)((reg0&0x0004)>>2);	// 1=full,0=half duplex...used in ifec.c
	
	i=0;
	printf("\n\nEthernet Link" );
	do		//FSL read PHY status register
	{
		fec_mii_read(FEC_PHY0, 0x10, &reg0);
		i++;
		if(i>333333)
		{
			printf("FAILED...check cable please\n\n" );
			return;
		}
	}while (!(reg0&(PHY_R1_LS)));		//FSL exit while loop when Link Status up
	
	printf("Established!\n\n");

	
}
/********************************************************************/
